<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CommonController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\MasterController;
use App\Http\Controllers\Api\MerchantController;
use App\Http\Controllers\Api\ProfileController;
use App\Http\Controllers\Api\TransactionController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');


Route::post('login', [AuthController::class, 'login'])->name('login');

Route::middleware(['auth:api'])->group(function () {


    Route::get('logout', [AuthController::class, 'logout'])->name('logout');

    // Route::get('/', [DashboardController::class, 'index'])->name('/');
    Route::prefix('dashboard')->group(function () {
        Route::get('/transaction-filter', [DashboardController::class, 'transactionFilter'])->name('dashboard.transaction-filter');
        Route::get('/transaction-list', [DashboardController::class, 'transactionList'])->name('dashboard.transaction-list');
        Route::get('/merchant-filter', [DashboardController::class, 'merchantFilter'])->name('dashboard.merchant-filter');
        Route::get('/merchant-list', [DashboardController::class, 'merchantList'])->name('dashboard.merchant-list');
        // New
        Route::get('/transaction_data', [DashboardController::class, 'transactionData']);
        Route::get('/transaction_insights', [DashboardController::class, 'transactionInsights']);
    });
    Route::prefix('profile')->group(function () {
        Route::get('/get_profile', [ProfileController::class, 'index'])->name('profile.get');
        Route::post('/update_profile', [ProfileController::class, 'updateProfile'])->name('profile.update');
        Route::post('/update_password', [ProfileController::class, 'updatePassword'])->name('password.update');
    });

    Route::prefix('merchant')->group(function () {
        Route::get('/', [MerchantController::class, 'index'])->name('merchant.list');
        Route::get('/{merchant_id}/business_list', [MerchantController::class, 'getBusinessList'])->name('merchant.get_business_list');
        Route::get('/{business_id}/business_identity_list', [MerchantController::class, 'getBusinessIdentityList'])->name('merchant.get_business_identity_list');
        Route::get('/{business_id}/business_bank_list', [MerchantController::class, 'getBusinessBankList'])->name('merchant.get_business_bank_list');
        Route::get('/{business_id}/business_gst_list', [MerchantController::class, 'getBusinessGstList'])->name('merchant.get_business_gst_list');
        Route::get('/{business_id}/business_documents_list', [MerchantController::class, 'getBusinessDocumentsList'])->name('merchant.get_business_documents_list');
        Route::get('/{business_id}/business_policy_list', [MerchantController::class, 'getBusinessPolicyList'])->name('merchant.get_business_policy_list');
        Route::get('/{merchant_id}/secret_list', [MerchantController::class, 'getMerchantSecretList'])->name('merchant.secret_list');
        Route::post('/delete', [MerchantController::class, 'delete'])->name('merchant.delete');
        Route::post('/save_personal_details', [MerchantController::class, 'savePersonalDetails'])->name('merchant.save_personal_details');
        Route::post('/save_business_details', [MerchantController::class, 'saveBusinessDetails'])->name('merchant.save_business_details');
        Route::post('/save_business_identity', [MerchantController::class, 'saveBusinessIdentity'])->name('merchant.save_business_identity');
        Route::post('/save_business_bank', [MerchantController::class, 'saveBusinessBank'])->name('merchant.save_business_bank');
        Route::post('/save_business_gst', [MerchantController::class, 'saveBusinessGst'])->name('merchant.save_business_gst');
        Route::post('/save_business_documents', [MerchantController::class, 'saveBusinessDocuments'])->name('merchant.save_business_documents');
        Route::post('/save_business_policy', [MerchantController::class, 'saveBusinessPolicy'])->name('merchant.save_business_policy');
        Route::post('/generate_secret', [MerchantController::class, 'generateSecret'])->name('merchant.generate_secret');
        Route::get('/merchant_processor_list', [MerchantController::class, 'merchantProcessorMappingList']);
        Route::get('/get_merchant_processor', [MerchantController::class, 'getMerchantProcessorMapping']);
        Route::post('/save_merchant_processor', [MerchantController::class, 'saveMerchantProcessorMapping']);
        Route::get('/{id}', [MerchantController::class, 'get'])->name('merchant.get');
    });

    Route::prefix('transaction')->group(function () {
        Route::get('/', [TransactionController::class, 'index'])->name('transaction.list');
        Route::get('/get_transaction', [TransactionController::class, 'getTransaction'])->name('transaction.get');
    });

    Route::prefix('master')->group(function () {
        Route::prefix('business_type')->group(function () {
            Route::get('/', [MasterController::class, 'businessTypeList'])->name('business_type.list');
            Route::post('/save', [MasterController::class, 'saveBusinessType'])->name('business_type.save');
            Route::post('/delete', [MasterController::class, 'deleteBusinessType'])->name('business_type.delete');
            Route::get('/{id}', [MasterController::class, 'getBusinessType'])->name('business_type.get');
        });

        Route::prefix('business_category')->group(function () {
            Route::get('/', [MasterController::class, 'businessCategoryList'])->name('business_category.list');
            Route::post('/save', [MasterController::class, 'saveBusinessCategory'])->name('business_category.save');
            Route::post('/delete', [MasterController::class, 'deleteBusinessCategory'])->name('business_category.delete');
            Route::get('/{id}', [MasterController::class, 'getBusinessCategory'])->name('business_category.get');
        });

        Route::prefix('merchant_api_docs')->group(function () {
            Route::get('/', [MasterController::class, 'getMerchantApiDocs'])->name('merchant_api_docs');
            Route::post('/save', [MasterController::class, 'saveMerchantApiDocs'])->name('merchant_api_docs.save');
        });
    });

    Route::prefix('common')->group(function () {
        Route::get('/business_type_list', [CommonController::class, 'businessTypeList'])->name('common.business_type_list');
        Route::get('/business_category_list', [CommonController::class, 'businessCategoryList'])->name('common.business_category_list');
        Route::get('/business_subcategory_list', [CommonController::class, 'businessSubCategoryList'])->name('common.business_subcategory_list');
        Route::get('/country_list', [CommonController::class, 'countryList'])->name('common.country_list');
        Route::post('/upload_files', [CommonController::class, 'uploadFiles'])->name('common.upload_files');
        Route::get('/merchant_ajax_list', [CommonController::class, 'merchantAjaxList'])->name('common.merchant_ajax_list');
        Route::get('/payment_processor_list', [CommonController::class, 'paymentProcessorList']);
    });
});
