<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BusinessCategory;
use App\Models\BusinessType;
use App\Models\Country;
use App\Models\Merchant;
use App\Models\PaymentProcessor;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class CommonController extends Controller
{
    function businessTypeList(Request $request)
    {
        try {
            $data = [];

            $list = BusinessType::orderBy('id', 'desc');

            $data['list'] = $list->get();

            $this->response['status'] = 1;
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at CommonController@businessTypeList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function businessCategoryList(Request $request)
    {
        try {
            $data = [];

            $list = BusinessCategory::where('parent_id', null)->orderBy('id', 'desc')->get();

            $data['list'] = $list;

            $this->response['status'] = 1;
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at CommonController@businessCategoryList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function businessSubCategoryList(Request $request)
    {
        try {
            $data = [];

            $parentId = $request->get('parent_id');

            if ($parentId) {
                $list = BusinessCategory::where(['parent_id' => $parentId])
                    ->orderBy('id', 'desc')
                    ->get();
            } else {
                $list = [];
            }

            $data['list'] = $list;

            $this->response['status'] = 1;
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at CommonController@businessSubCategoryList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function countryList(Request $request)
    {
        try {
            $data = [];

            $list = Country::orderBy('id', 'desc')->get();

            $data['list'] = $list;

            $this->response['status'] = 1;
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at CommonController@countryList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function uploadFiles(Request $request)
    {
        try {
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf'];

            // Validate the files
            $request->validate([
                'files.*' => ['required', 'file', 'mimes:' . implode(',', $allowedExtensions)]
            ], [
                'files.*.required' => 'Please upload at least one file.',
                'files.*.file' => 'The uploaded item must be a valid file.',
                'files.*.mimes' => 'Only files with the following extensions are allowed: ' . implode(', ', $allowedExtensions)
            ]);

            $data = [];
            $destinationPath = 'uploads/temp';

            if ($request->file('files')) {
                foreach ($request->file('files') as $key => $file) {
                    $path = $file->store($destinationPath, 'public');
                    $fileName = $file->hashName();
                    $data[] = ['filename' => $fileName, 'path' => Storage::disk('public')->url($path)];
                }
            }

            $this->response['status'] = 1;
            $this->response['msg'] = 'Files successfully uploaded';
            $this->response['data'] = ['list' => $data];
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error'] = $e->errors()['files.0'][0];
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at CommonController@uploadFiles: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function merchantAjaxList(Request $request)
    {
        try {
            $data = [];

            $search = $request->get('search') ?? '';
            $id = $request->get('id') ?? '';

            $list = [];

            if(strlen($search) > 2) {
                $list = Merchant::select('id', 'merchant_id', 'name', 'email', 'phone')
                    ->where('name', 'like', '%' . $search . '%')
                    ->orderBy('name', 'asc')->get();
            }else if ($id) {
                $list = Merchant::select('id', 'merchant_id', 'name', 'email', 'phone')->where('id', $id)->orderBy('name', 'asc')->get();
            }

            $data['list'] = $list;

            $this->response['status'] = 1;
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at CommonController@merchantAjaxList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function paymentProcessorList(Request $request)
    {
        try {
            $list = [];

            $list = PaymentProcessor::with(['paymentProvider'])->orderBy('name', 'asc')->get();

            $data['list'] = $list;

            $this->response['status'] = 1;
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at CommonController@paymentProcessorList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }
}
