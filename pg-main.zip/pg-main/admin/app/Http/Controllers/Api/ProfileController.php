<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class ProfileController extends Controller
{
    function index(Request $request)
    {
        try {
            $user = $request->user();

            $this->response['status'] = 1;
            $this->response['msg'] = '';
            $this->response['data'] = $user;
            return response()->json($this->response, 200);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at ProfileController@index: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function updateProfile(Request $request)
    {
        try {
            $user = $request->user();

            $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email|max:255|unique:users,email,' . $user->id,
                'phone' => 'required|string|max:15|unique:users,phone,' . $user->id,
            ]);

            $user->name = $request->post('name');
            $user->email = $request->post('email');
            $user->phone = $request->post('phone');
            $user->save();

            $this->response['status'] = 1;
            $this->response['msg'] = '';
            $this->response['data'] = [
                'user' => $user,
                'token' => $user->createToken('token')->plainTextToken,
            ];
            return response()->json($this->response, 200);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at ProfileController@updateProfile: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function updatePassword(Request $request)
    {
        try {
            $user = $request->user();

            $request->validate([
                'current_password' => 'required',
                'new_password' => 'required|string|min:8|confirmed',
            ]);

            if (!Hash::check($request->post('current_password'), $user->password)) {
                $this->response['error'] = 'Current password is incorrect';
                return response()->json($this->response, 200);
            }
            
            $user->password = Hash::make($request->post('new_password'));
            $user->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Password updated successfully';
            return response()->json($this->response, 200);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at ProfileController@updatePassword: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }
}
