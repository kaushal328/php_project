<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Merchant;
use Illuminate\Http\Request;
use App\Models\Transaction;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Validation\ValidationException;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    function transactionFilter(Request $request)
    {
        try {
            $date_range = $data['date_range'] = $request->get('date_range') ?? '';
            $transactions = Transaction::with(['merchant']);
            if ($date_range) {
                switch ($date_range) {
                    case 'today':
                        $transactions->whereDate('created_at', now());
                        break;
                    case 'yesterday':
                        $transactions->whereDate('created_at', date('Y-m-d', strtotime('-1')));
                        break;
                    case 'last_seven_days':
                        $transactions->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                        // $transactions->whereDate('created_at', '<=', date('Y-m-d'));
                        break;
                    case 'this_month':
                        $transactions->whereMonth('created_at', date('m'));

                        break;
                    case 'last_month':
                        $transactions->whereMonth('created_at', date('m', strtotime('-1 month')));

                        break;
                    case 'this_year':
                        $transactions->whereYear('created_at', date('Y'));

                        break;
                    case 'last_year':
                        $transactions->whereYear('created_at', date('Y', strtotime('-1 year')));
                        break;
                }
            }

            $failedCount = clone $transactions;
            $failedCount = $failedCount->where(['payment_status' => 0])->count();
            $successCount = clone $transactions;
            $successCount = $successCount->where(['payment_status' => 1])->count();

            $this->response['status'] = 1;
            $this->response['data']['date_range'] = $date_range;
            $this->response['data']['counts']['failed'] = $failedCount;
            $this->response['data']['counts']['success'] = $successCount;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
        } catch (Exception $e) {
            Log::error('Exception at DashboardController@transactionFilter: ' . $e->getMessage());
            $this->response['error'] = 'Server error' . $e->getMessage();
            return response()->json($this->response, 500);
        }
    }

    function transactionList(Request $request)
    {
        try {
            $latestTransactions = Transaction::orderBy('id', 'desc')
                ->take(10)
                ->get(['id', 'transaction_id', 'merchant_id', 'order_no', 'transaction_type', 'amount', 'customer_name', 'customer_email', 'customer_phone_no', 'pg_order_id', 'pg_payment_id', 'payment_status', DB::raw('DATE(created_at) as date')]);


            $data['list'] =  $latestTransactions;

            $this->response['status'] = 1;
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (Exception $e) {
            $this->response['error'] = 'Something went wrong';
            return response()->json($this->response);
        }
    }


    function merchantFilter(Request $request)
    {
        try {
            $date_range = $data['date_range'] = $request->get('date_range') ?? '';
            $merchant = Merchant::orderBy('id', 'asc');
            if ($date_range) {
                switch ($date_range) {
                    case 'today':
                        $merchant->whereDate('created_at', now());
                        break;
                    case 'yesterday':
                        $merchant->whereDate('created_at', date('Y-m-d', strtotime('-1')));
                        break;
                    case 'last_seven_days':
                        $merchant->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                        // $merchant->whereDate('created_at', '<=', date('Y-m-d'));
                        break;
                    case 'this_month':
                        $merchant->whereMonth('created_at', date('m'));
                        break;
                    case 'last_month':
                        $merchant->whereMonth('created_at', date('m', strtotime('-1 month')));

                        break;
                    case 'this_year':
                        $merchant->whereYear('created_at', date('Y'));

                        break;
                    case 'last_year':
                        $merchant->whereYear('created_at', date('Y', strtotime('-1 year')));
                        break;
                }
            }

            $merchantCount =  $merchant->count();
            $this->response['status'] = 1;
            $this->response['data']['counts'] = $merchantCount;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
        } catch (Exception $e) {
            Log::error('Exception at DashboardController@merchantFilter: ' . $e->getMessage());
            $this->response['error'] = 'Something went wrong' . $e->getMessage();
            return response()->json($this->response, 500);
        }
    }

    function merchantList(Request $request)
    {
        try {
            $latestTransactions = Merchant::orderBy('id', 'desc')
                ->take(10)
                ->get(['id', 'merchant_id', 'name', 'email', 'phone']);
            $this->response['status'] = 1;
            $this->response['data'] = $latestTransactions;
            return response()->json($this->response);
        } catch (Exception $e) {
            $this->response['error'] = 'Something went wrong';
            return response()->json($this->response);
        }
    }

    // Transaction Data
    function transactionData(Request $request)
    {
        try {
            $date_range = $data['date_range'] = $request->get('date_range') ?? 'lifetime';
            $from_date = $data['from_date'] = $request->get('from_date') ?? '';
            $to_date = $data['to_date'] = $request->get('to_date') ?? '';

            $transactions = Transaction::with(['merchant']);

            $dayCount = 0;

            if ($date_range) {
                switch ($date_range) {
                    case 'today':
                        $transactions->whereDate('created_at', now());
                        $dayCount = 1;
                        break;

                    case 'yesterday':
                        $transactions->whereDate('created_at', date('Y-m-d', strtotime('-1')));
                        $dayCount = 1;
                        break;

                    case 'last_seven_days':
                        $transactions->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                        $dayCount = 7;
                        break;

                    case 'this_month':
                        $transactions->whereMonth('created_at', date('m'));
                        $dayCount = Carbon::now()->day;
                        break;

                    case 'last_month':
                        $start = Carbon::now()->subMonthNoOverflow()->startOfMonth();
                        $end = Carbon::now()->subMonthNoOverflow()->endOfMonth();

                        $transactions->whereBetween('created_at', [$start, $end]);
                        $dayCount = $start->diffInDays($end) + 1;

                        // Optional: store for chart grouping later
                        $from_date = $start->format('Y-m-d');
                        $to_date = $end->format('Y-m-d');
                        break;

                    case 'this_year':
                        $transactions->whereYear('created_at', date('Y'));
                        $dayCount = Carbon::now()->dayOfYear;
                        break;

                    case 'last_year':
                        $transactions->whereYear('created_at', date('Y', strtotime('-1 year')));
                        $dayCount = Carbon::now()->subYear()->daysInYear;
                        break;

                    case 'custom':
                        if ($from_date) $transactions->whereDate('created_at', '>=', $from_date);
                        if ($to_date) $transactions->whereDate('created_at', '<=', $to_date);
                        if ($from_date && $to_date) $dayCount = Carbon::parse($from_date)->diffInDays(Carbon::parse($to_date)) + 1;
                        break;
                    case 'lifetime':
                        $first = Transaction::orderBy('created_at', 'asc')->first();
                        if ($first) {
                            $from_date = $first->created_at;
                            $to_date = now();
                            $transactions->whereBetween('created_at', [$from_date, $to_date]);
                            $dayCount = Carbon::parse($from_date)->diffInDays(Carbon::parse($to_date)) + 1;
                        }
                        break;
                }
            }

            $collectedAmountTrx = clone $transactions;
            $collectedAmount = $collectedAmountTrx->where('payment_status', 1)->sum('amount');

            $totalTransaction = clone $transactions;
            $transactionsCount = $totalTransaction->count();

            $sucessTransaction = clone $transactions;
            $successCount =  $sucessTransaction->where(['payment_status' => 1])->count();
            $failedTransaction = clone $transactions;
            $failedCount = $failedTransaction->where(['payment_status' => 0])->count();

            $refundAmount = 0;

            // CHART DATA START
            // Define a base clone to reuse
            $chartTransactions = clone $transactions;
            $successChartData = [];
            $failedChartData = [];
            $labels = [];

            if ($dayCount === 1) {
                // Hourly chart
                for ($i = 0; $i < 24; $i++) {
                    $from = Carbon::today()->addHours($i);
                    $to = Carbon::today()->addHours($i + 1);
                    $labels[] = $from->format('H:00');
                    $successAmount = (clone $chartTransactions)->whereBetween('created_at', [$from, $to])->where('payment_status', 1)->sum('amount');
                    $failedAmount = (clone $chartTransactions)->whereBetween('created_at', [$from, $to])->where('payment_status', 0)->sum('amount');
                    $successChartData[] = round($successAmount, 2);
                    $failedChartData[] = round($failedAmount, 2);
                }
            } elseif ($dayCount <= 14) {
                // Daily chart
                $start = $from_date ? Carbon::parse($from_date)->startOfDay() : Carbon::now()->subDays($dayCount - 1)->startOfDay();
                $end = $to_date ? Carbon::parse($to_date)->endOfDay() : Carbon::now()->endOfDay();

                foreach (CarbonPeriod::create($start, '1 day', $end) as $date) {
                    $from = $date->copy()->startOfDay();
                    $to = $date->copy()->endOfDay();
                    $labels[] = $date->format('d M');
                    $successAmount = (clone $chartTransactions)->whereBetween('created_at', [$from, $to])->where('payment_status', 1)->sum('amount');
                    $failedAmount = (clone $chartTransactions)->whereBetween('created_at', [$from, $to])->where('payment_status', 0)->sum('amount');
                    $successChartData[] = round($successAmount, 2);
                    $failedChartData[] = round($failedAmount, 2);
                }
            } else {
                $maxChunks = 7;
                $chunkSize = ceil($dayCount / $maxChunks);

                // Use earliest date in the dataset if available, otherwise fall back
                if ($date_range === 'this_month') {
                    $start = Carbon::now()->startOfMonth();
                } elseif ($from_date) {
                    $start = Carbon::parse($from_date)->startOfDay();
                } else {
                    $start = Carbon::now()->subDays($dayCount - 1)->startOfDay();
                }

                $endDate = Carbon::now()->endOfDay(); // Always cap to today

                for ($i = 0; $i < $maxChunks; $i++) {
                    $from = (clone $start)->addDays($i * $chunkSize);
                    $to = (clone $from)->copy()->addDays($chunkSize - 1)->endOfDay();

                    // 🚫 Cap `to` to today's date if it goes beyond
                    if ($to > $endDate) {
                        $to = $endDate;
                    }

                    // If `from` > today, break early to avoid future data
                    if ($from > $endDate) {
                        break;
                    }

                    // Label
                    $labels[] = $from->format('d M') . ' - ' . $to->format('d M');

                    // Data
                    $successAmount = (clone $chartTransactions)->whereBetween('created_at', [$from, $to])->where('payment_status', 1)->sum('amount');
                    $failedAmount = (clone $chartTransactions)->whereBetween('created_at', [$from, $to])->where('payment_status', 0)->sum('amount');
                    $successChartData[] = round($successAmount, 2);
                    $failedChartData[] = round($failedAmount, 2);

                    // If we've reached today, no need to continue
                    if ($to->equalTo($endDate)) {
                        break;
                    }
                }
            }
            // CHART DATA END

            $this->response['status'] = 1;

            $this->response['data']['date_range'] = $date_range;

            $this->response['data']['amount']['collected'] = $collectedAmount;
            $this->response['data']['amount']['refund'] = $refundAmount;

            $this->response['data']['amount_chart_data']['labels'] = $labels;
            $this->response['data']['amount_chart_data']['success_data'] = $successChartData;
            $this->response['data']['amount_chart_data']['failed_data'] = $failedChartData;
            $this->response['data']['count']['total'] = $successCount;
            $this->response['data']['count']['success'] = $successCount;
            $this->response['data']['count']['failed'] = $failedCount;
            $this->response['data']['count']['total'] = $transactionsCount;
            $this->response['data']['count']['success_rate'] = ($successCount / $transactionsCount) * 100;

            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
        } catch (Exception $e) {
            Log::error('Exception at DashboardController@transactionData: ' . $e->getMessage());
            $this->response['error'] = 'Server error' . $e->getMessage();
            return response()->json($this->response, 500);
        }
    }

    function transactionInsights(Request $request)
    {
        try {
            $date_range = $data['date_range'] = $request->get('date_range') ?? '';
            $from_date = $data['from_date'] = $request->get('from_date') ?? '';
            $to_date = $data['to_date'] = $request->get('to_date') ?? '';

            $transactions = Transaction::orderBy('id', 'desc');

            if ($date_range) {
                switch ($date_range) {
                    case 'today':
                        $transactions->whereDate('created_at', now());
                        break;

                    case 'yesterday':
                        $transactions->whereDate('created_at', date('Y-m-d', strtotime('-1')));
                        break;

                    case 'last_seven_days':
                        $transactions->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                        break;

                    case 'this_month':
                        $transactions->whereMonth('created_at', date('m'));
                        break;

                    case 'last_month':
                        $transactions->whereMonth('created_at', date('m', strtotime('-1 month')));
                        break;

                    case 'this_year':
                        $transactions->whereYear('created_at', date('Y'));
                        break;

                    case 'last_year':
                        $transactions->whereYear('created_at', date('Y', strtotime('-1 year')));
                        break;

                    case 'custom':
                        if ($from_date) $transactions->whereDate('created_at', '>=', $from_date);
                        if ($to_date) $transactions->whereDate('created_at', '<=', $to_date);
                        break;
                }
            }

            $allTrx = clone $transactions;
            $allCount = $allTrx->count();
            $allAmount = $allTrx->sum('amount');

            $failedTrx = clone $transactions;
            $failedCount = $failedTrx->where(['payment_status' => 0])->count();
            $failedAmount = $failedTrx->where('payment_status', 0)->sum('amount');

            $successTrx = clone $transactions;
            $successCount = $successTrx->where(['payment_status' => 1])->count();
            $successAmount = $successTrx->where('payment_status', 1)->sum('amount');

            $refundCount = 0;
            $refundAmount = 0;

            $this->response['status'] = 1;

            $this->response['data']['date_range'] = $date_range;

            $this->response['data']['counts']['all'] = $allCount;
            $this->response['data']['counts']['failed'] = $failedCount;
            $this->response['data']['counts']['success'] = $successCount;
            $this->response['data']['counts']['refund'] = $refundCount;

            $this->response['data']['amount']['all'] = $allAmount;
            $this->response['data']['amount']['failed'] = $failedAmount;
            $this->response['data']['amount']['success'] = $successAmount;
            $this->response['data']['amount']['refund'] = $refundAmount;


            $this->response['data']['chart_data'] = [];
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
        } catch (Exception $e) {
            Log::error('Exception at DashboardController@transactionInsights: ' . $e->getMessage());
            $this->response['error'] = 'Server error' . $e->getMessage();
            return response()->json($this->response, 500);
        }
    }
}
