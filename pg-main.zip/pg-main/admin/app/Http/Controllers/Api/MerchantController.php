<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Merchant;
use App\Models\MerchantBusiness;
use App\Models\MerchantBusinessBank;
use App\Models\MerchantBusinessDocument;
use App\Models\MerchantBusinessGstDetail;
use App\Models\MerchantBusinessIdentity;
use App\Models\MerchantBusinessPolicy;
use App\Models\MerchantPaymentProcessorMapping;
use App\Models\MerchantSecret;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class MerchantController extends Controller
{
    function index(Request $request)
    {
        try {
            $data = [];

            $date_range = $data['date_range'] = $request->get('date_range') ?? '';
            $from_date = $data['from_date'] = $request->get('from_date') ?? '';
            $to_date = $data['to_date'] = $request->get('to_date') ?? '';
            $search = $data['search'] = $request->get('search') ?? '';
            $status = $data['status'] = $request->get('status') ?? '';
            $page = $data['page'] = $request->get('page') ?? 1;
            $per_page = $data['per_page'] = $request->get('per_page') ?? 50;
            $list = Merchant::orderBy('id', 'desc');
            if ($date_range) {
                switch ($date_range) {
                    case 'today':
                        $list->whereDate('created_at', now());
                        break;
                    case 'yesterday':
                        $list->whereDate('created_at', date('Y-m-d', strtotime('-1')));
                        break;
                    case 'last_seven_days':
                        $list->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                        // $list->whereDate('created_at', '<=', date('Y-m-d'));
                        break;
                    case 'this_month':
                        $list->whereMonth('created_at', date('m'));

                        break;
                    case 'last_month':
                        $list->whereMonth('created_at', date('m', strtotime('-1 month')));

                        break;
                    case 'this_year':
                        $list->whereYear('created_at', date('Y'));

                        break;
                    case 'last_year':
                        $list->whereYear('created_at', date('Y', strtotime('-1 year')));
                        break;

                    case 'custom':
                        if ($from_date) {
                            $list->whereDate('created_at', '>=', $from_date);

                            if ($to_date) {
                                $list->whereDate('created_at', '<=', $to_date);
                            }
                        }
                        break;
                }
            }

            if ($search) {
                $list->where(function ($q) use ($search) {
                    $q->orWhere('merchant_id', 'like', '%' . $search . '%');
                    $q->orWhere('name', 'like', '%' . $search . '%');
                    $q->orWhere('email', 'like', '%' . $search . '%');
                    $q->orWhere('phone', 'like', '%' . $search . '%');
                });
            }
            if ($status != '') {
                $list->where('status', $status);
            }

            $data['total'] = $total = $list->count();
            $data['total_pages'] = $total < $per_page ? 1 : ceil($total / $per_page);
            $data['list'] = $list
                ->skip(($page - 1) * $per_page)
                ->take($per_page)
                ->orderBy('id', 'desc')
                ->get();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Merchant list';
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@index: ' . $e->getMessage());
            $this->response['error'] = 'Server error' . $e->getMessage();
            return response()->json($this->response, 500);
        }
    }

    function get(Request $request)
    {
        try {
            $merchant = Merchant::with(['businesses'])->find($request->id);
            if (!$merchant) {
                $this->response['error'] = 'Record not found';
                return response()->json($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = 'Merchant details';
            $this->response['data'] = $merchant;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@get: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function getBusinessList(Request $request)
    {
        try {
            $list = MerchantBusiness::with(['businessType', 'businessCategory', 'businessSubCategory', 'registeredCountry', 'currentCountry'])
                ->where('user_id', $request->merchant_id)
                ->orderBy('id', 'desc')
                ->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $list;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@getBusinessList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function getBusinessIdentityList(Request $request)
    {
        try {
            $list = MerchantBusinessIdentity::where('user_business_id', $request->business_id)->orderBy('id', 'desc')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $list;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@getBusinessIdentityList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function getBusinessBankList(Request $request)
    {
        try {
            $list = MerchantBusinessBank::where('user_business_id', $request->business_id)->orderBy('id', 'desc')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $list;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@getBusinessBankList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function getBusinessGstList(Request $request)
    {
        try {
            $list = MerchantBusinessGstDetail::where('user_business_id', $request->business_id)->orderBy('id', 'desc')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $list;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@getBusinessGstList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function getBusinessDocumentsList(Request $request)
    {
        try {
            $list = MerchantBusinessDocument::where('user_business_id', $request->business_id)->orderBy('id', 'desc')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $list;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@getBusinessDocumentsList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function getMerchantSecretList(Request $request)
    {
        try {
            $list = MerchantSecret::where('user_id', $request->merchant_id)->orderBy('id', 'desc')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $list;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@getMerchantSecretList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function getBusinessPolicyList(Request $request)
    {
        try {
            $list = MerchantBusinessPolicy::where('user_business_id', $request->business_id)->orderBy('id', 'desc')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $list;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@getBusinessPolicyList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function savePersonalDetails(Request $request)
    {
        try {
            $request->validate(
                [
                    'name' => 'required',
                    'email' => 'required|email|unique:merchant_db.users,email,' . $request->post('id'),
                    'phone' => 'required|unique:merchant_db.users,phone,' . $request->post('id'),
                    'password' => 'required_without:id|confirmed',
                    'status' => '',
                ],
                [
                    'password.required_without' => 'The password field is required.',
                ],
            );

            $merchant = Merchant::find($request->post('id'));
            if (!$merchant) {
                $merchant = new Merchant();
            }

            $merchant->name = $request->post('name');
            $merchant->email = $request->post('email');
            $merchant->phone = $request->post('phone');
            if (!$merchant->id) {
                $merchant->merchant_id = generateUniqueId('merchant_db', 'merchant_id', 'users', 9, true, 'M');
                $merchant->password = Hash::make($request->password);
            }
            $merchant->status = $request->post('status') ?? 1;
            $merchant->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record saved';
            $this->response['data'] = $merchant;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@savePersonalDetails: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function saveBusinessDetails(Request $request)
    {
        try {
            $request->validate(
                [
                    'name' => 'required',
                    'business_type_id' => 'required',
                    'pan_number' => 'required',
                    'business_category_id' => 'required',
                    'business_subcategory_id' => 'required',
                    'registered_address' => 'required',
                    'registered_pincode' => 'required',
                    'registered_city' => 'required',
                    'registered_state' => 'required',
                    'registered_country_id' => 'required',
                    'current_address_same_as_registered' => '',
                    'current_address' => 'required_unless:current_address_same_as_registered,1',
                    'current_pincode' => 'required_unless:current_address_same_as_registered,1',
                    'current_city' => 'required_unless:current_address_same_as_registered,1',
                    'current_state' => 'required_unless:current_address_same_as_registered,1',
                    'current_country_id' => 'required_unless:current_address_same_as_registered,1',
                ],
                [
                    'business_type_id.required' => 'The registered country field is required',
                    'business_category_id.required' => 'The business category field is required',
                    'business_subcategory_id.required' => 'The business sub-category field is required',
                    'registered_country_id.required' => 'The registered country field is required',
                    'current_address.required_unless' => 'The current address field is required.',
                    'current_pincode.required_unless' => 'The current pincode field is required.',
                    'current_city.required_unless' => 'The current city field is required.',
                    'current_state.required_unless' => 'The current state field is required.',
                    'current_country_id.required_unless' => 'The current country field is required.',
                ],
            );

            $merchant = Merchant::find($request->post('merchant_id'));
            if (!$merchant) {
                $this->response['error'] = 'Something went wrong! Please restart the process.';
                return response()->json($this->response);
            }

            $merchantBusiness = MerchantBusiness::find($request->post('id'));
            if (!$merchantBusiness) {
                $merchantBusiness = new MerchantBusiness();
            }

            $merchantBusiness->name = $request->post('name');
            $merchantBusiness->user_id = $merchant->id;
            $merchantBusiness->business_type_id = $request->post('business_type_id');
            $merchantBusiness->pan_number = $request->post('pan_number');
            $merchantBusiness->business_category_id = $request->post('business_category_id');
            $merchantBusiness->business_subcategory_id = $request->post('business_subcategory_id');
            $merchantBusiness->registered_address = $request->post('registered_address');
            $merchantBusiness->registered_pincode = $request->post('registered_pincode');
            $merchantBusiness->registered_city = $request->post('registered_city');
            $merchantBusiness->registered_state = $request->post('registered_state');
            $merchantBusiness->registered_country_id = $request->post('registered_country_id');
            $merchantBusiness->current_address_same_as_registered = $request->post('current_address_same_as_registered');
            $merchantBusiness->current_address = $request->post('current_address');
            $merchantBusiness->current_pincode = $request->post('current_pincode');
            $merchantBusiness->current_city = $request->post('current_city');
            $merchantBusiness->current_state = $request->post('current_state');
            $merchantBusiness->current_country_id = $request->post('current_country_id');
            $merchantBusiness->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record saved';
            $this->response['data'] = $merchantBusiness;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@saveBusinessDetails: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function saveBusinessIdentity(Request $request)
    {
        try {
            $request->validate(
                [
                    'authorized_signatory_name' => 'required',
                    'authorized_signatory_pan_number' => 'required',
                    'aadhaar_number' => 'required',
                ],
                [
                    'authorized_signatory_name.required' => 'The Authorized Signatory Name field is required.',
                    'authorized_signatory_pan_number.required' => 'The Authorized Signatory PAN is required.',
                    'aadhaar_number.required' => 'The Aadhaar Number field is required.',
                ],
            );

            $merchantBusiness = MerchantBusiness::find($request->post('merchant_business_id'));
            if (!$merchantBusiness) {
                $this->response['error'] = 'Something went wrong! Please restart the process.';
                return response()->json($this->response);
            }

            $merchantBusinessIdentity = MerchantBusinessIdentity::find($request->post('id'));
            if (!$merchantBusinessIdentity) {
                $merchantBusinessIdentity = new MerchantBusinessIdentity();
            }

            $merchantBusinessIdentity->user_business_id = $merchantBusiness->id;
            $merchantBusinessIdentity->authorized_signatory_name = $request->post('authorized_signatory_name');
            $merchantBusinessIdentity->authorized_signatory_pan_number = $request->post('authorized_signatory_pan_number');
            $merchantBusinessIdentity->aadhaar_number = $request->post('aadhaar_number');
            $merchantBusinessIdentity->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record saved';
            $this->response['data'] = $merchantBusinessIdentity;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@saveBusinessIdentity: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function saveBusinessBank(Request $request)
    {
        try {
            $request->validate(
                [
                    'bank_name' => 'required',
                    'account_name' => 'required',
                    'account_number' => 'required',
                    'ifsc_code' => 'required',
                    'cancel_cheque_image' => 'required',
                ],
                [
                    'bank_name.required' => 'The Bank Name field is required.',
                    'account_name.required' => 'The Account Name field is required.',
                    'account_number.required' => 'The Account Number field is required.',
                    'ifsc_code.required' => 'The IFSC Code field is required.',
                    'cancel_cheque_image.required' => 'The Cancelled Cheque field is required.',
                ],
            );

            $merchantBusiness = MerchantBusiness::find($request->post('merchant_business_id'));
            if (!$merchantBusiness) {
                $this->response['error'] = 'Something went wrong! Please restart the process.';
                return response()->json($this->response);
            }

            $merchantBusinessBank = MerchantBusinessBank::find($request->post('id'));
            if (!$merchantBusinessBank) {
                $merchantBusinessBank = new MerchantBusinessBank();
            }

            $merchantBusinessBank->user_business_id = $merchantBusiness->id;
            $merchantBusinessBank->bank_name = $request->post('bank_name');
            $merchantBusinessBank->account_name = $request->post('account_name');
            $merchantBusinessBank->account_number = $request->post('account_number');
            $merchantBusinessBank->ifsc_code = $request->post('ifsc_code');
            $merchantBusinessBank->cancel_cheque_image = $request->post('cancel_cheque_image');

            $cancel_cheque_image = $request->post('cancel_cheque_image');
            if ($cancel_cheque_image) {
                $moveResponse = moveImage('uploads/temp', 'uploads/merchant/cancel_cheque', $cancel_cheque_image);
                if (!$moveResponse['success']) {
                    $this->response['error'] = 'Please upload a valid Cancelled Cheque.';
                    return response()->json($this->response);
                }
            }

            $merchantBusinessBank->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record saved';
            $this->response['data'] = $merchantBusinessBank;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@saveBusinessBank: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function saveBusinessGst(Request $request)
    {
        try {
            $request->validate(
                [
                    'cin_number' => '',
                    'dont_have_gst' => 'required',
                    'gst_number' => 'required_unless:dont_have_gst,1',
                ],
                [
                    'gst_number.required_unless' => 'The GST Number field is required.',
                ],
            );

            $merchantBusiness = MerchantBusiness::find($request->post('merchant_business_id'));
            if (!$merchantBusiness) {
                $this->response['error'] = 'Something went wrong! Please restart the process.';
                return response()->json($this->response);
            }

            $merchantBusinessGstDetail = MerchantBusinessGstDetail::find($request->post('id'));
            if (!$merchantBusinessGstDetail) {
                $merchantBusinessGstDetail = new MerchantBusinessGstDetail();
            }

            $merchantBusinessGstDetail->user_business_id = $merchantBusiness->id;
            $merchantBusinessGstDetail->cin_number = $request->post('cin_number');
            $merchantBusinessGstDetail->dont_have_gst = $request->post('dont_have_gst');
            $merchantBusinessGstDetail->gst_number = $request->post('gst_number');
            $merchantBusinessGstDetail->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record saved';
            $this->response['data'] = $merchantBusinessGstDetail;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@saveBusinessGst: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function saveBusinessDocuments(Request $request)
    {
        try {
            $request->validate(
                [
                    'pan_card' => 'required',
                    'business_certificate' => 'required',
                    'address_proof' => 'required',
                    'gst_certificate' => 'required',
                    'aadhaar_front' => 'required',
                    'aadhaar_back' => 'required',
                    'authorized_signatory_pan' => 'required',
                ],
                [
                    'pan_card.required' => 'The Business PAN Card is required.',
                    'business_certificate.required' => 'The Business Document is required.',
                    'address_proof.required' => 'The Address Document is required.',
                    'gst_certificate.required' => 'The GST Certificate is required.',
                    'aadhaar_front.required' => 'The Aadhaar Card Front is required.',
                    'aadhaar_back.required' => 'The Aadhaar Card Back is required.',
                    'authorized_signatory_pan.required' => 'The Authorised Signatory PAN Card is required.',
                ],
            );

            $merchantBusiness = MerchantBusiness::find($request->post('merchant_business_id'));
            if (!$merchantBusiness) {
                $this->response['error'] = 'Something went wrong! Please restart the process.';
                return response()->json($this->response);
            }

            $merchantBusinessDocument = MerchantBusinessDocument::find($request->post('id'));
            if (!$merchantBusinessDocument) {
                $merchantBusinessDocument = new MerchantBusinessDocument();
            }

            $panCard = $request->post('pan_card');
            $businessCertificate = $request->post('business_certificate');
            $addressProof = $request->post('address_proof');
            $gstCertificate = $request->post('gst_certificate');
            $aadhaarFront = $request->post('aadhaar_front');
            $aadhaarBack = $request->post('aadhaar_back');
            $authorizedSignatoryPan = $request->post('authorized_signatory_pan');

            if ($panCard) {
                $moveResponse = moveImage('uploads/temp', 'uploads/merchant/documents', $panCard);
                if (!$moveResponse['success']) {
                    $this->response['error'] = 'Please upload a valid PAN Card.';
                    return response()->json($this->response);
                }
            }

            if ($businessCertificate) {
                $moveResponse = moveImage('uploads/temp', 'uploads/merchant/documents', $businessCertificate);
                if (!$moveResponse['success']) {
                    $this->response['error'] = 'Please upload a valid Business Certificate.';
                    return response()->json($this->response);
                }
            }

            if ($addressProof) {
                $moveResponse = moveImage('uploads/temp', 'uploads/merchant/documents', $addressProof);
                if (!$moveResponse['success']) {
                    $this->response['error'] = 'Please upload a valid Address Proof.';
                    return response()->json($this->response);
                }
            }

            if ($gstCertificate) {
                $moveResponse = moveImage('uploads/temp', 'uploads/merchant/documents', $gstCertificate);
                if (!$moveResponse['success']) {
                    $this->response['error'] = 'Please upload a valid GST Certificate.';
                    return response()->json($this->response);
                }
            }

            if ($aadhaarFront) {
                $moveResponse = moveImage('uploads/temp', 'uploads/merchant/documents', $aadhaarFront);
                if (!$moveResponse['success']) {
                    $this->response['error'] = 'Please upload a valid Aadhaar Card Front.';
                    return response()->json($this->response);
                }
            }

            if ($aadhaarBack) {
                $moveResponse = moveImage('uploads/temp', 'uploads/merchant/documents', $aadhaarBack);
                if (!$moveResponse['success']) {
                    $this->response['error'] = 'Please upload a valid Aadhaar Card Back.';
                    return response()->json($this->response);
                }
            }

            if ($authorizedSignatoryPan) {
                $moveResponse = moveImage('uploads/temp', 'uploads/merchant/documents', $authorizedSignatoryPan);
                if (!$moveResponse['success']) {
                    $this->response['error'] = 'Please upload a valid Authorized Signatory PAN Card.';
                    return response()->json($this->response);
                }
            }

            $merchantBusinessDocument->user_business_id = $merchantBusiness->id;
            $merchantBusinessDocument->pan_card = $panCard;
            $merchantBusinessDocument->business_certificate = $businessCertificate;
            $merchantBusinessDocument->address_proof = $addressProof;
            $merchantBusinessDocument->gst_certificate = $gstCertificate;
            $merchantBusinessDocument->aadhaar_front = $aadhaarFront;
            $merchantBusinessDocument->aadhaar_back = $aadhaarBack;
            $merchantBusinessDocument->authorized_signatory_pan = $authorizedSignatoryPan;
            $merchantBusinessDocument->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record saved';
            $this->response['data'] = $merchantBusinessDocument;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@saveBusinessDocuments: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function saveBusinessPolicy(Request $request)
    {
        try {
            $request->validate(
                [
                    'website_url' => 'required|url|active_url',
                    'terms_and_conditions_url' => 'required|url|active_url',
                    'privacy_policy_url' => 'required|url|active_url',
                    'return_and_refund_policy_url' => 'required|url|active_url',
                    'cancellation_policy_url' => 'required|url|active_url',
                    'shipping_policy_url' => 'required|url|active_url',
                ],
                [
                    'website_url.required' => 'The Website Url is required.',
                    'terms_and_conditions_url.required' => 'The Terms & Conditions Url is required.',
                    'privacy_policy_url.required' => 'The Privacy Policy Url is required.',
                    'return_and_refund_policy_url.required' => 'The Return & Refund Policy Url is required.',
                    'cancellation_policy_url.required' => 'The Cancellation Policy Url is required.',
                    'shipping_policy_url.required' => 'The Shipping Policy Url is required.',
                    'website_url.url' => 'The Website Url is required.',
                    'terms_and_conditions_url.url' => 'The Terms & Conditions Url is required.',
                    'privacy_policy_url.url' => 'The Privacy Policy Url is required.',
                    'return_and_refund_policy_url.url' => 'The Return & Refund Policy Url is required.',
                    'cancellation_policy_url.url' => 'The Cancellation Policy Url is required.',
                    'shipping_policy_url.url' => 'The Shipping Policy Url is required.',
                    'website_url.active_url' => 'The Website Url is required.',
                    'terms_and_conditions_url.active_url' => 'The Terms & Conditions Url is required.',
                    'privacy_policy_url.active_url' => 'The Privacy Policy Url is required.',
                    'return_and_refund_policy_url.active_url' => 'The Return & Refund Policy Url is required.',
                    'cancellation_policy_url.active_url' => 'The Cancellation Policy Url is required.',
                    'shipping_policy_url.active_url' => 'The Shipping Policy Url is required.',
                ],
            );

            $merchantBusiness = MerchantBusiness::find($request->post('merchant_business_id'));
            if (!$merchantBusiness) {
                $this->response['error'] = 'Something went wrong! Please restart the process.';
                return response()->json($this->response);
            }

            $merchantBusinessPolicy = MerchantBusinessPolicy::find($request->post('id'));
            if (!$merchantBusinessPolicy) {
                $merchantBusinessPolicy = new MerchantBusinessPolicy();
            }

            $merchantBusinessPolicy->user_business_id = $merchantBusiness->id;
            $merchantBusinessPolicy->website_url = $request->post('website_url');
            $merchantBusinessPolicy->terms_and_conditions_url = $request->post('terms_and_conditions_url');
            $merchantBusinessPolicy->privacy_policy_url = $request->post('privacy_policy_url');
            $merchantBusinessPolicy->return_and_refund_policy_url = $request->post('return_and_refund_policy_url');
            $merchantBusinessPolicy->cancellation_policy_url = $request->post('cancellation_policy_url');
            $merchantBusinessPolicy->shipping_policy_url = $request->post('shipping_policy_url');
            $merchantBusinessPolicy->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record saved';
            $this->response['data'] = $merchantBusinessPolicy;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@saveBusinessPolicy: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function generateSecret(Request $request)
    {
        try {
            $merchant = Merchant::find($request->post('merchant_id'));
            if (!$merchant) {
                $this->response['error'] = 'Something went wrong! Selected merchant not found.';
                return response()->json($this->response);
            }

            $secretList = MerchantSecret::where('user_id', $merchant->id)->get();
            foreach ($secretList as $secret) {
                $secret->status = 0;
                $secret->is_revoked = 1;
                $secret->revoked_at = Carbon::now();
                $secret->save();
            }

            $secret = new MerchantSecret();
            $secret->user_id = $merchant->id;
            $secret->secret_key = strtoupper(generateUniqueId('merchant_db', 'secret_key', 'user_secrets', 64));
            $secret->salt = strtoupper(generateUniqueId('merchant_db', 'salt', 'user_secrets', 32));
            $secret->status = 1;
            $secret->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'New secret generated successfully.';
            $this->response['data'] = $secret;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@generateSecret: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function delete(Request $request)
    {
        try {
            $merchant = Merchant::find($request->post('id'));
            if (!$merchant) {
                $this->response['error'] = 'Record not found';
                return response()->json($this->response, 200);
            }

            $merchant->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record deleted';
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@delete: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    // save processor mapping

    function saveMerchantProcessorMapping(Request $request)
    {
        try {
            $request->validate(
                [
                    'merchant_id' => 'required',
                    'payment_processor_id' => 'required',
                    'status' => 'required',
                ],
                [
                    'payment_processor_id.required' => 'The processor is required.',
                ],
            );

            $merchantId = $request->post('merchant_id');
            $paymentProcessorId = $request->post('payment_processor_id');
            $status = $request->post('status') ?? 1;

            $merchant = Merchant::find($merchantId);
            if (!$merchant) {
                $this->response['error'] = 'Selected merchant not found.';
                return response()->json($this->response);
            }

            $merchantProcessorMapping = MerchantPaymentProcessorMapping::where(['merchant_id' => $merchant->id, 'payment_processor_id' => $paymentProcessorId])->first();
            if (!$merchantProcessorMapping) $merchantProcessorMapping = new MerchantPaymentProcessorMapping();

            $merchantProcessorMapping->merchant_id = $merchant->id;
            $merchantProcessorMapping->payment_processor_id = $paymentProcessorId;
            $merchantProcessorMapping->status = $status;
            $merchantProcessorMapping->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record saved';
            $this->response['data'] = [];
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@saveMerchantProcessorMapping: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function merchantProcessorMappingList(Request $request)
    {
        try {
            $merchantId = $request->get('merchant_id');
            
            $merchant = Merchant::find($merchantId);
            if (!$merchant) {
                $this->response['error'] = 'Selected merchant not found.';
                return response()->json($this->response);
            }

            $merchantProcessorMapping = MerchantPaymentProcessorMapping::with(['paymentProcessor.paymentProvider'])->where(['merchant_id' => $merchant->id])->get();

            $data['list'] = $merchantProcessorMapping;

            $this->response['status'] = 1;
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@merchantProcessorMappingList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function getMerchantProcessorMapping(Request $request)
    {
        try {
            $id = $request->get('id');

            $merchantPaymentProcessorMapping = MerchantPaymentProcessorMapping::find($id);
            if (!$merchantPaymentProcessorMapping) {
                $this->response['error'] = 'Selected record not found.';
                return response()->json($this->response);
            }

            $this->response['status'] = 1;
            $this->response['data'] = $merchantPaymentProcessorMapping;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MerchantController@getMerchantProcessorMapping: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }
}
