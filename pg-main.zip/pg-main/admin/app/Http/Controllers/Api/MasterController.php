<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BusinessCategory;
use App\Models\BusinessType;
use App\Models\MerchantApiDoc;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class MasterController extends Controller
{
    // Business Type

    function businessTypeList(Request $request)
    {
        try {
            $data = [];

            $name = $data['name'] = $request->get('name') ?? '';
            $page = $data['page'] = $request->get('page') ?? 1;
            $per_page = $data['per_page'] = $request->get('per_page') ?? 50;

            $list = BusinessType::orderBy('id', 'desc');

            if ($name) {
                $list->where('name', 'like', '%' . $name . '%');
            }
            
            $data['total'] = $total = $list->count();
            $data['total_pages'] = $total < $per_page ? 1 : ceil($total / $per_page);
            $data['list'] = $list->skip(($page - 1) * $per_page)->take($per_page)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Business Type list';
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MasterController@businessTypeList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function getBusinessType(Request $request)
    {
        try {
            $businessType = BusinessType::find($request->id);
            if (!$businessType) {
                $this->response['error'] = 'Record not found';
                return response()->json($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = 'Business Type details';
            $this->response['data'] = $businessType;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MasterController@getBusinessType: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function saveBusinessType(Request $request)
    {
        try {
            $request->validate([
                'name' => 'required',
                'status' => 'required',
            ]);

            $businessType = BusinessType::find($request->post('id'));
            if (!$businessType) $businessType = new BusinessType();

            $businessType->name = $request->post('name');
            $businessType->status = $request->post('status') ?? 1;
            $businessType->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record saved';
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MasterController@saveBusinessType: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }
    
    function deleteBusinessType(Request $request)
    {
        try {
            $businessType = BusinessType::find($request->post('id'));
            if (!$businessType) {
                $this->response['error'] = 'Record not found';
                return response()->json($this->response, 200);
            }
            
            $businessType->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record deleted';
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MasterController@deleteBusinessType: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    // Business Category

    function businessCategoryList(Request $request)
    {
        try {
            $data = [];

            $name = $data['name'] = $request->get('name') ?? '';
            $page = $data['page'] = $request->get('page') ?? 1;
            $per_page = $data['per_page'] = $request->get('per_page') ?? 50;

            $list = BusinessCategory::with(['parentCategory'])->orderBy('id', 'desc');

            if ($name) {
                $list->where('name', 'like', '%' . $name . '%');
            }
            
            $data['total'] = $total = $list->count();
            $data['total_pages'] = $total < $per_page ? 1 : ceil($total / $per_page);
            $data['list'] = $list->skip(($page - 1) * $per_page)->take($per_page)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Business Category list';
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MasterController@businessCategoryList: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function getBusinessCategory(Request $request)
    {
        try {
            $businessCategory = BusinessCategory::find($request->id);
            if (!$businessCategory) {
                $this->response['error'] = 'Record not found';
                return response()->json($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = 'Business Category details';
            $this->response['data'] = $businessCategory;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MasterController@getBusinessCategory: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function saveBusinessCategory(Request $request)
    {
        try {
            $request->validate([
                'parent_id' => '',
                'name' => 'required',
                'status' => 'required',
            ]);

            $businessCategory = BusinessCategory::find($request->post('id'));
            if (!$businessCategory) $businessCategory = new BusinessCategory();

            $businessCategory->parent_id = $request->post('parent_id');
            $businessCategory->name = $request->post('name');
            $businessCategory->status = $request->post('status') ?? 1;
            $businessCategory->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record saved';
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MasterController@saveBusinessCategory: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }
    
    function deleteBusinessCategory(Request $request)
    {
        try {
            $businessCategory = BusinessCategory::find($request->post('id'));
            if (!$businessCategory) {
                $this->response['error'] = 'Record not found';
                return response()->json($this->response, 200);
            }
            
            $businessCategory->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = 'Record deleted';
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MasterController@deleteBusinessCategory: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    // Merchant API Docs

    function getMerchantApiDocs(Request $request)
    {
        try {
            $apiDocs = MerchantApiDoc::find(1);

            $this->response['status'] = 1;
            $this->response['msg'] = 'Merchant API Docs';
            $this->response['data'] = $apiDocs;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at MasterController@getMerchantApiDocs: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function saveMerchantApiDocs(Request $request)
    {
        try {
            $request->validate([
                'docs' => 'required',
                'status' => 'required',
            ]);

            $apiDocs = MerchantApiDoc::find(1);
            if(!$apiDocs) $apiDocs = new MerchantApiDoc();

            $apiDocs->docs = $request->post('docs');
            $apiDocs->status = $request->post('status') ?? 1;
            $apiDocs->save();

            $this->response['status'] = 1;
            $this->response['msg'] = 'API Docs updated';
            $this->response['data'] = $apiDocs;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at MasterController@saveMerchantApiDocs: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }
}
