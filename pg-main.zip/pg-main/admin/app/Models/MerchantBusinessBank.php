<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;

class MerchantBusinessBank extends Model
{
    use SoftDeletes;

    protected $connection = 'merchant_db';
    protected $table = 'user_business_banks';
    protected $appends = ['cancel_cheque_image_path'];

    protected function cancelChequeImagePath(): Attribute
    {
        return Attribute::make(
            get: function ($value) {
                $file = isset($this->attributes['cancel_cheque_image']) && !empty($this->attributes['cancel_cheque_image']) ? $this->attributes['cancel_cheque_image'] : null;
                if ($file) {
                    return Storage::disk('public')->url('uploads/merchant/cancel_cheque/' . $file);
                }
                return null;
            },
        );
    }
}
