<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PaymentProcessor extends Model
{
    use SoftDeletes;

    protected $connection = 'routing_db';
    protected $table = 'payment_processors';

    function paymentProvider()
    {
        return $this->belongsTo(PaymentProvider::class, 'payment_provider_id');
    }
}
