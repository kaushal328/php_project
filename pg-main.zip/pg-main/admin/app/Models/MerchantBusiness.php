<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MerchantBusiness extends Model
{
    use SoftDeletes;

    protected $connection = 'merchant_db';
    protected $table = 'user_businesses';

    public function businessType()
    {
        return $this->belongsTo(BusinessType::class, 'business_type_id');
    }

    public function businessCategory()
    {
        return $this->belongsTo(BusinessCategory::class, 'business_category_id');
    }

    public function businessSubCategory()
    {
        return $this->belongsTo(BusinessCategory::class, 'business_subcategory_id');
    }

    public function registeredCountry()
    {
        return $this->belongsTo(Country::class, 'registered_country_id');
    }

    public function currentCountry()
    {
        return $this->belongsTo(Country::class, 'current_country_id');
    }
}
