<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PaymentProvider extends Model
{
    use SoftDeletes;

    protected $connection = 'admin_db';
    protected $table = 'payment_providers';
    protected $fillable = [
        'name',
        'status',
    ];
}
