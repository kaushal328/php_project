<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MerchantSecret extends Model
{
    use SoftDeletes;

    protected $connection = 'merchant_db';
    protected $table = 'user_secrets';
    protected $appends = ['masked_secret_key', 'masked_salt'];

    protected function maskedSecretKey(): Attribute
    {
        return Attribute::make(
            get: function ($value) {
                $val = isset($this->attributes['secret_key']) && !empty($this->attributes['secret_key']) ? $this->attributes['secret_key'] : null;
                if ($val) {
                    return substr($val, 0, 3) . str_repeat('*', 10) . substr($val, -3);
                }
                return null;
            },
        );
    }

    protected function maskedSalt(): Attribute
    {
        return Attribute::make(
            get: function ($value) {
                $val = isset($this->attributes['salt']) && !empty($this->attributes['salt']) ? $this->attributes['salt'] : null;
                if ($val) {
                    return substr($val, 0, 3) . str_repeat('*', 5) . substr($val, -3);
                }
                return null;
            },
        );
    }
}
