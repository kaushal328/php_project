<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UpiTransaction extends Model
{
    use SoftDeletes;

    protected $connection = 'routing_db';
    protected $table = 'upi_transactions';

    function transaction()
    {
        return $this->morphOne(Transaction::class, 'transactionable');
    }
}
