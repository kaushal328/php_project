<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BusinessCategory extends Model
{
    use SoftDeletes;

    protected $connection = 'admin_db';
    protected $table = 'business_categories';

    function parentCategory()
    {
        return $this->belongsTo(BusinessCategory::class, 'parent_id');
    }
}
