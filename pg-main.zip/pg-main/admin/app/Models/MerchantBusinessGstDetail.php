<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MerchantBusinessGstDetail extends Model
{
    use SoftDeletes;

    protected $connection = 'merchant_db';
    protected $table = 'user_business_gst_details';
}
