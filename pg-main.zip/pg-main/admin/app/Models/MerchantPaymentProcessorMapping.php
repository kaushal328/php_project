<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MerchantPaymentProcessorMapping extends Model
{
    use SoftDeletes;

    protected $connection = 'routing_db';
    protected $table = 'merchant_payment_processor_mappings';

    function paymentProcessor()
    {
        return $this->belongsTo(PaymentProcessor::class, 'payment_processor_id');
    }
}
