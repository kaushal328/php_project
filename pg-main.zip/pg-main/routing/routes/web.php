<?php

use App\Http\Controllers\PaymentController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    echo "Ok. But not here!"; exit;
});

Route::prefix('payment')->group(function () {
    Route::post('initiate', [PaymentController::class, 'initiate']);
    Route::post('charge_upi', [PaymentController::class, 'chargeUpi'])->name('charge_upi');
    Route::post('check_upi_transaction_status', [PaymentController::class, 'checkUpiStatus'])->name('check_upi_status');
    
    Route::any('failed/{transaction_id?}', [PaymentController::class, 'paymentFailed'])->name('payment.failed');
    Route::any('success/{transaction_id?}', [PaymentController::class, 'paymentSuccess'])->name('payment.success');
});