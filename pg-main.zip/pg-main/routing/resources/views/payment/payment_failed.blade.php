<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f8f8f8;
        }

        .failure-container {
            background-color: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }

        .failure-icon {
            font-size: 4em;
            color: #e74c3c;
            /* Red color for failure */
            margin-bottom: 20px;
        }

        .failure-title {
            font-size: 2em;
            color: #333;
            margin-bottom: 15px;
        }

        .failure-message {
            color: #777;
            margin-bottom: 25px;
            line-height: 1.6;
        }

        .retry-button {
            background-color: #3498db;
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
        }

        .retry-button:hover {
            background-color: #2980b9;
        }

        .support-link {
            display: block;
            margin-top: 20px;
            color: #3498db;
            text-decoration: none;
        }

        .support-link:hover {
            text-decoration: underline;
        }

        .error-details {
            margin-top: 20px;
            color: #777;
            font-size: 0.9em;

        }
    </style>
</head>

<body>

    <div class="failure-container">
        <div class="failure-icon">&#x274C;</div>
        <h2 class="failure-title">Payment Failed</h2>
        <p class="failure-message">
            We're sorry, but your payment could not be processed. Please check your payment details and try again.
        </p>

        <button class="retry-button">Retry Payment</button>

        <a href="/" class="support-link">Contact Support</a>

        <p class="error-details" id="errorDetails"></p>

        <br />
        <br />

        <p class="redirection-text" style="margin-bottom: 16px; text-align: center;">Redirecting to website in <span id="countdown">7</span>
            seconds...</p>
    </div>

    <script>
        var countdown = 7;

        // Example error detail population. Replace with your actual error details.
        document.getElementById('errorDetails').textContent = "Error Code: 500.";

        // Countdown timer
        const returnUrl = "{{ isset($returnUrl) ? $returnUrl : '' }}";
        if (returnUrl) {
            const countdownElement = document.getElementById('countdown');
            const countdownInterval = setInterval(function() {
                countdown--;
                countdownElement.textContent = countdown;

                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    if (returnUrl) window.location.href = returnUrl;
                }
            }, 1000);
        } else {
            document.querySelector('.redirection-text').style.display = 'none';
        }
    </script>
</body>

</html>
