<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Gateway</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: system-ui, -apple-system, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            background: linear-gradient(to bottom right, #f9fafb, #f3f4f6);
        }

        .container {
            background: white;
            border-radius: 1rem;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 64rem;
            overflow: hidden;
        }

        .header {
            background: #2563eb;
            padding: 1.5rem;
            color: white;
        }

        .header h1 {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 0.25rem;
        }

        .header p {
            color: #bfdbfe;
        }

        .content {
            display: flex;
            min-height: 32rem;
        }

        .left-panel {
            width: 25%;
            border-right: 1px solid #e5e7eb;
            padding: 1.5rem;
        }

        .middle-panel {
            width: 35%;
            border-right: 1px solid #e5e7eb;
            padding: 1.5rem;
        }

        .right-panel {
            width: 40%;
            padding: 1.5rem;
        }

        .section {
            margin-bottom: 2rem;
        }

        .section h2 {
            color: #374151;
            font-size: 0.875rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }

        .merchant-name {
            color: #111827;
            font-size: 1.125rem;
            font-weight: bold;
        }

        .amount {
            display: flex;
            align-items: center;
            font-size: 1.5rem;
            font-weight: bold;
            color: #111827;
        }

        .amount::before {
            content: "₹";
            margin-right: 0.25rem;
        }

        .payment-options {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .payment-option {
            width: 100%;
            padding: 1rem;
            border: 2px solid #e5e7eb;
            border-radius: 0.5rem;
            background: none;
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: all 0.2s;
        }

        .payment-option:hover {
            border-color: #60a5fa;
        }

        .payment-option.selected {
            border-color: #2563eb;
            background: #eff6ff;
        }

        .payment-option-icon {
            width: 1.5rem;
            height: 1.5rem;
            color: #2563eb;
            margin-right: 1rem;
        }

        .payment-option-text {
            text-align: left;
        }

        .payment-option-title {
            color: #111827;
            font-weight: 600;
            margin-bottom: 0.25rem;
        }

        .payment-option-description {
            color: #6b7280;
            font-size: 0.875rem;
        }

        .payment-form {
            display: none;
        }

        .payment-form.active {
            display: block;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-label {
            display: block;
            color: #374151;
            font-size: 0.875rem;
            font-weight: 500;
            margin-bottom: 0.5rem;
        }

        .form-input {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            font-size: 1rem;
            transition: border-color 0.2s;
        }

        .form-input:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        .proceed-button {
            width: 100%;
            margin-top: 2rem;
            padding: 1rem;
            border: none;
            border-radius: 0.5rem;
            background: #2563eb;
            color: white;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .proceed-button:hover {
            background: #1d4ed8;
        }

        .proceed-button:disabled {
            background: #d1d5db;
            cursor: not-allowed;
        }

        .error {
            color: #ef4444;
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }

        .success {
            color: rgb(10, 137, 35);
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }

        @media (max-width: 768px) {
            .content {
                flex-direction: column;
            }

            .left-panel,
            .middle-panel,
            .right-panel {
                width: 100%;
                border-right: none;
                border-bottom: 1px solid #e5e7eb;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="content">
            <div class="left-panel">
                <div class="section">
                    <p class="merchant-name">{{ $data['Merchant']['name'] }}</p>
                </div>

                <div class="section">
                    <h2>Amount</h2>
                    <div class="amount">{{ number_format($data['Amount'], 2) }}</div>
                </div>
            </div>

            <div class="middle-panel">
                <div class="section">
                    <h2>Select Payment Method</h2>
                    <div class="payment-options">
                        @foreach ($data['processors'] as $processor)
                            <button class="payment-option"
                                data-processor-type="{{ $processor['payment_processor']['processor_type'] }}"
                                data-processor-id="{{ $processor['payment_processor']['id'] }}">
                                <svg class="payment-option-icon" viewBox="0 0 24 24" fill="none"
                                    stroke="currentColor" stroke-width="2">
                                    <path
                                        d="M3 10h18M7 15h.01M11 15h.01M15 15h.01M3 10l1.5-5h15l1.5 5M3 10v8a2 2 0 002 2h14a2 2 0 002-2v-8" />
                                </svg>
                                <div class="payment-option-text">
                                    <p class="payment-option-title">{{ $processor['payment_processor']['name'] }}</p>
                                    <p class="payment-option-description">
                                        {{ $processor['payment_processor']['subtitle'] }}</p>
                                </div>
                            </button>
                        @endforeach
                    </div>
                </div>
            </div>

            <div class="right-panel">
                <div id="no-method-section" class="section">
                    <p>Please select a payment method to proceed.</p>
                </div>

                <div id="error-section" class="section" style="display: none;">
                    <p></p>
                </div>

                <!-- UPI Payment Form -->
                <div id="UPIFormSection" class="payment-form">
                    <form id="UPIForm" action="{{ route('charge_upi') }}" method="POST">
                        <div class="form-group">
                            <label class="form-label">Pay with UPI ID / Number</label>
                            <input type="hidden" class="form-input" name="PaymentProcessorId" value="" />
                            <input type="hidden" class="form-input" name="RawTxnId" value="{{ $data['RawTxnId'] }}" />
                            <input type="text" class="form-input" name="vpa" placeholder="Enter your UPI ID (e.g., name@upi)" />
                        </div>
                        <button type="submit" class="proceed-button">Verify & Pay</button>
                    </form>
                </div>

            </div>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <script>
        var interval;

        $(document).ready(function() {
            $(document).on('click', '.payment-option', function() {
                const processorType = $(this).data('processor-type');
                const processorId = $(this).data('processor-id');

                // Select the payment method
                selectPayment($(this), processorType, processorId);
            });
        })

        function selectPayment(button, processorType, processorId) {
            $('#no-method-section').hide();

            // Remove selected class from all options
            $('.payment-option').each((i, btn) => {
                console.log(btn);

                $(btn).removeClass('selected');
            });

            // Add selected class to clicked option
            button.addClass('selected');

            // Hide all payment forms
            $('.payment-form').each((i, form) => {
                $(form).removeClass('active');
            });

            // Get related form
            const form = $(`#${processorType}FormSection`)

            // Show selected payment form
            form.addClass('active');

            // Set the processor ID in the form
            form.find('input[name="PaymentProcessorId"]').val(processorId);
        }

        $(document).on('submit', '#UPIForm', function(e) {
            e.preventDefault();

            const _this = $(this);
            const url = $(this).attr('action');
            const data = $(this).serializeArray();

            $('#error-section').hide();
            $('#error-section p').text('');

            _this.find('.proceed-button').text('Please wait...').attr('disabled', true);

            $.post(url, data, function(response) {
                console.log(response);

                // Handle success response
                if (response.status == 1) {
                    if (response.message) {
                        $('#error-section').show();
                        $('#error-section p').text(response.message);
                        $('#error-section p').addClass('success');
                    }

                    if (response?.next_action && response?.next_action == 'waiting_for_payment') {
                        const order_id = response?.order_id;

                        interval = setInterval(() => {
                            checkPaymentStatus(order_id)
                        }, 5000);
                    }
                } else {
                    _this.find('.proceed-button').text('Verify & Pay').attr('disabled', false);

                    if (response.message) {
                        $('#error-section').show();
                        $('#error-section p').text(response.message);
                        $('#error-section p').addClass('error');
                    }
                }

                if (response.redirect_url) {
                    setTimeout(() => {
                        window.location.href = response.redirect_url;
                    }, 500);
                }
            }, 'json');
        });

        async function checkPaymentStatus(order_id) {
            const url = "{{ route('check_upi_status') }}";
            const data = {
                order_id: order_id
            };

            try {
                const response = await $.post(url, data);

                if (response?.redirect_url) {
                    // setTimeout(() => {
                    window.location.href = response.redirect_url;
                    // }, 500);
                }

                if (response?.status && (response?.status == 1 || response?.status == 0)) {
                    clearInterval(interval);
                    $('#UPIForm').find('.proceed-button').text('Verify & Pay').attr('disabled', false);
                }

            } catch (error) {
                console.error('Error:', error);
            }
        }
    </script>
</body>

</html>
