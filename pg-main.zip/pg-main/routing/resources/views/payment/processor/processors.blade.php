<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="{{ asset('assets/css/main.css') }}" rel="stylesheet" />

    <style>
        .error {
            color: #ef4444;
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }

        .success {
            color: rgb(10, 137, 35);
            font-size: 0.875rem;
            margin-top: 0.5rem;
        }
    </style>
</head>

<body>
    <div class="dashboard_wrapper">
        <div class="dashboard_inner_section desktop">
            <ul class="right_ul_top">
                <li>
                    <a href="#"><img src="{{ asset('assets/images/ellipsis-horizontal.pn') }}" alt=""
                            class="img-fluid" /></a>
                </li>
                <li>
                    <a href="#"><img src="{{ asset('assets/images/close.png') }}" alt=""
                            class="img-fluid" /></a>
                </li>
            </ul>
            <div class="row">
                <div class="col-lg-3 col-sm-4 col-md-4 col-12">
                    <div class="dashboard_left_section">
                        <div class="logo_section">
                            <span class="text-white">PG Logo</span>
                        </div>
                        <div class="price_summary_section">
                            <h3 class="title">Price Summary</h3>
                            <span>₹ {{ number_format($data['Amount'], 2) }}</span>
                        </div>
                        <div class="user_id_section_main">
                            <h3 class="title">
                                <img src="{{ asset('assets/images/user.png') }}" alt="" class="img-fluid" />
                                {{ $data['Merchant']['name'] }}
                            </h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 col-sm-4 col-md-4 col-12">
                    <div class="dashboard_right_section">
                        <div class="row">
                            <div class="col-lg-5 col-sm-4 col-md-4 col-12 padding_right_0">
                                <div class="right_inner_section_main">
                                    <h3 class="title">Select Payment Option</h3>
                                    <div class="upi_app_dropdown">
                                        <ul>
                                            @foreach ($data['processors'] as $processor)
                                                <li class="payment-option"
                                                    data-processor-type="{{ $processor['payment_processor']['processor_type'] }}"
                                                    data-processor-id="{{ $processor['payment_processor']['id'] }}">
                                                    <a href="javascript:;" class="active payment-option-inner">
                                                        <span class="left">
                                                            <img src="{{ asset('assets/images/ll/1.png') }}"
                                                                alt="" class="img-fluid" />
                                                            {{ $processor['payment_processor']['name'] }}
                                                        </span>
                                                        <span>
                                                            <img src="{{ asset('assets/images/upi/1.png') }}"
                                                                alt="" class="img-fluid" />
                                                            <img src="{{ asset('assets/images/upi/2.png') }}"
                                                                alt="" class="img-fluid" />
                                                            <img src="{{ asset('assets/images/upi/3.png') }}"
                                                                alt="" class="img-fluid" />
                                                        </span>
                                                    </a>
                                                </li>
                                            @endforeach
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-7 col-sm-4 col-md-4 col-12 padding_left_0">
                                <div class="right_section_right_main">
                                    <div class="upi_input_main">
                                        <div id="error-section" class="section" style="display: none;">
                                            <p></p>
                                        </div>
                                        <div id="UPIFormSection" class="payment-form">
                                            <form id="UPIForm" action="{{ route('charge_upi') }}" method="POST">
                                                <h3>Pay with UPI ID/ Number</h3>
                                                <div class="upi_input_section">
                                                    <input type="hidden" name="PaymentProcessorId" value="" />
                                                    <input type="hidden" name="RawTxnId" value="{{ $data['RawTxnId'] }}" />
                                                    <input type="text" name="vpa" class="form-control" placeholder="example@ohkhdfcbank" />
                                                </div>
                                                <div class="upi_input_main_btn">
                                                    <button type="submit" class="proceed-button">
                                                        <img src="{{ asset('assets/images/verif.png') }}" alt=""
                                                            class="img-fluid" />
                                                        <span>Verify & Pay</span>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="right_text_bottom">
                        <p class="title">Secured by<span>Logo</span></p>
                    </div>
                </div>
            </div>
        </div>


        {{-- MOBILE SECTIONS STARTS --}}

        <div class="dashboard_mobile_section">
            <div class="mobile_header_nav_section">
                <div class="container">
                    <div class="left_section_nav_header">
                        <a href="#"><img src="{{ asset('assets/images/left.png') }}" alt=""
                                class="img-fluid" /></a>
                        <a href="#"><img src="{{ asset('assets/images/left_logo.png') }}" alt=""
                                class="img-fluid" /></a>
                        <h3>Company Name</h3>
                    </div>
                    {{-- <div class="right_section_nav_header">
                        <a href="#">
                            <img src="{{ asset('assets/images/userss.png') }}" alt="" class="img-fluid" />
                        </a>
                    </div> --}}
                </div>
            </div>

            <div class="payment_top_header">
                <span>Payment Option</span>
                <div class="payment_method_header">
                    <h3>₹ {{ number_format($data['Amount'], 2) }}</h3>
                    <div class="time">
                        <img src="{{ asset('assets/images/upi/time.png') }}" alt="" class="img-fluid" />
                        12:33
                    </div>
                </div>
            </div>

            <div class="upi_nav_outer">
                <div class="right_inner_section_main">
                    <div class="upi_app_dropdown">
                        <ul>
                            @foreach ($data['processors'] as $processor)
                                <li class="payment-option"
                                    data-processor-type="{{ $processor['payment_processor']['processor_type'] }}"
                                    data-processor-id="{{ $processor['payment_processor']['id'] }}">
                                    <a href="javascript:;" class="active payment-option-inner">
                                        <span class="left">
                                            <img src="{{ asset('assets/images/ll/1.png') }}" alt=""
                                                class="img-fluid" />
                                            {{ $processor['payment_processor']['name'] }}
                                        </span>
                                        <span>
                                            <img src="{{ asset('assets/images/upi/1.png') }}" alt=""
                                                class="img-fluid" />
                                            <img src="{{ asset('assets/images/upi/2.png') }}" alt=""
                                                class="img-fluid" />
                                            <img src="{{ asset('assets/images/upi/3.png') }}" alt=""
                                                class="img-fluid" />
                                        </span>
                                    </a>
                                    {{-- <span>{{ $processor['payment_processor']['subtitle'] }}</span> --}}

                                    <div class="upi_input_main">
                                        <div id="error-section" class="section" style="display: none;">
                                            <p></p>
                                        </div>
                                        <div id="UPIFormSection" class="payment-form">
                                            <form id="UPIForm" action="{{ route('charge_upi') }}" method="POST">
                                                <h3>Pay with UPI ID/ Number</h3>
                                                <div class="upi_input_section">
                                                    <input type="hidden" name="PaymentProcessorId" value="" />
                                                    <input type="hidden" name="RawTxnId" value="{{ $data['RawTxnId'] }}" />
                                                    <input type="text" name="vpa" class="form-control" placeholder="example@ohkhdfcbank" />
                                                </div>
                                                <div class="upi_input_main_btn">
                                                    <button type="submit" class="proceed-button">
                                                        <img src="{{ asset('assets/images/verif.png') }}" alt=""
                                                            class="img-fluid" />
                                                        <span>Verify & Pay</span>
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>

            <div class="right_text_bottom">
                <div class="container">
                    <p class="title">Secured by<span>Logo</span></p>
                </div>
            </div>

            {{-- <div class="bottom_section_mobile_nav">
                <div class="container">
                    <div class="bottom_nav_inner">
                        <div class="left_section_price_mobile">
                            <h3>₹ {{ number_format($data['Amount'], 2) }}</h3>
                            <p>
                                View Details
                                <img src="images/up.png" alt="" class="img-fluid" />
                            </p>
                        </div>
                        <div class="right_section_price_mobile">
                            <a href="#">Continue</a>
                        </div>
                    </div>
                </div>
            </div> --}}
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"
        integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

    <script>
        var interval;

        $(document).ready(function() {
            $(document).on('click', '.payment-option', function() {
                const processorType = $(this).data('processor-type');
                const processorId = $(this).data('processor-id');

                // Select the payment method
                selectPayment($(this), processorType, processorId);
            });

            var processors = <?php echo json_encode($data['processors']); ?>;
            if (processors.length) {
                selectPayment($('.payment-option'), processors[0].payment_processor.processor_type, processors[0]
                    .payment_processor.id)
            }

        })

        function selectPayment(button, processorType, processorId) {
            $('#no-method-section').hide();

            // Remove active class from all options
            $('.payment-option').each((i, btn) => {
                $(btn).find('.payment-option-inner').removeClass('active');
            });

            // Add active class to clicked option
            button.find('.payment-option-inner').addClass('active');

            // Hide all payment forms
            $('.payment-form').each((i, form) => {
                $(form).removeClass('active');
            });

            // Get related form
            const form = $(`#${processorType}FormSection`)

            // Show active payment form
            form.addClass('active');

            // Set the processor ID in the form
            form.find('input[name="PaymentProcessorId"]').val(processorId);
        }

        $(document).on('submit', '#UPIForm', function(e) {
            e.preventDefault();

            const _this = $(this);
            const url = $(this).attr('action');
            const data = $(this).serializeArray();

            $(this).find('#error-section').hide();
            $(this).find('#error-section p').text('');

            _this.find('.proceed-button span').html('Please wait...');
            _this.find('.proceed-button').attr('disabled', true);

            $.post(url, data, function(response) {
                console.log(response);

                // Handle success response
                if (response.status == 1) {
                    if (response.message) {
                        _this.closest('.upi_input_main').find('#error-section').show();
                        _this.closest('.upi_input_main').find('#error-section p').text(response.message);
                        _this.closest('.upi_input_main').find('#error-section p').addClass('success');
                    }

                    if (response?.next_action && response?.next_action == 'waiting_for_payment') {
                        const order_id = response?.order_id;

                        let simulator = response?.full_response?.response?.data?.payload || null;
                        
                        if(simulator) {
                            _this.find('.proceed-button').closest('.upi_input_main_btn').append(`<a target="_blank" href="${simulator.gpay}">Click here to Open GPay</a>`)
                        }

                        interval = setInterval(() => {
                            checkPaymentStatus(order_id)
                        }, 5000);
                    }
                } else {
                    _this.find('.proceed-button span').html('Verify & Pay');
                    _this.find('.proceed-button').attr('disabled', false);

                    if (response.message) {
                        _this.closest('.upi_input_main').find('#error-section').show();
                        _this.closest('.upi_input_main').find('#error-section p').text(response.message);
                        _this.closest('.upi_input_main').find('#error-section p').addClass('error');
                    }
                }

                if (response.redirect_url) {
                    setTimeout(() => {
                        window.location.href = response.redirect_url;
                    }, 500);
                }
            }, 'json');
        });

        async function checkPaymentStatus(order_id) {
            const url = "{{ route('check_upi_status') }}";
            const data = {
                order_id: order_id
            };

            try {
                const response = await $.post(url, data);

                if (response?.redirect_url) {
                    // setTimeout(() => {
                    window.location.href = response.redirect_url;
                    // }, 500);
                }

                if (response?.status && (response?.status == 1 || response?.status == 0)) {
                    clearInterval(interval);
                    $('#UPIForm').find('.proceed-button span').text('Verify & Pay')
                    $('#UPIForm').find('.proceed-button').attr('disabled', false);
                }

            } catch (error) {
                console.error('Error:', error);
            }
        }
    </script>

</body>

</html>
