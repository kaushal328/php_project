<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f8f8f8;
        }

        .success-container {
            background-color: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }

        .success-icon {
            font-size: 4em;
            color: #27ae60;
            /* Green color for success */
            margin-bottom: 20px;
        }

        .success-title {
            font-size: 2em;
            color: #333;
            margin-bottom: 15px;
        }

        .success-message {
            color: #777;
            margin-bottom: 25px;
            line-height: 1.6;
        }

        .continue-button {
            background-color: #27ae60;
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1em;
            transition: background-color 0.3s ease;
        }

        .continue-button:hover {
            background-color: #219653;
        }

        .transaction-details {
            margin-top: 20px;
            color: #777;
            font-size: 0.9em;
        }

        .transaction-details p {
            margin: 5px 0;
        }
    </style>
</head>

<body>

    <div class="success-container">
        <div class="success-icon">&#x2705;</div>
        <h2 class="success-title">Payment Successful</h2>
        <p class="success-message">
            Your payment has been processed successfully. Thank you for your purchase!
        </p>

        <button class="continue-button">Continue Shopping</button>

        <div class="transaction-details" id="transactionDetails">
            <p>Transaction ID: TXN123456789</p>
            <p>Amount: $100.00</p>
            <p>Date: 2024-10-27</p>
        </div>
        <p class="redirection-text" style="margin-bottom: 16px; text-align: center;">Redirecting to website in <span id="countdown">7</span> seconds...</p>

    </div>

    <script>
        var countdown = 7;

        // Example transaction detail population. Replace with your actual transaction details.
        const merchantTxnRefNo = '{{ isset($merchantTxnRefNo) ? $merchantTxnRefNo : '' }}';
        const transactionId = '{{ isset($transactionId) ? $transactionId : '' }}';
        const transactionAmount = '{{ isset($amount) ? $amount : '' }}';
        const transactionDate = '{{ isset($transactionDate) ? $transactionDate : '' }}';

        document.getElementById('transactionDetails').innerHTML = `
            <p>Transaction ID: ${transactionId}</p>
            <p>Amount: INR ${transactionAmount}</p>
            <p>Date: ${transactionDate}</p>
        `;

        // Countdown timer
        const returnUrl = "{{ isset($returnUrl) ? $returnUrl : '' }}";
        if (returnUrl) {
            const countdownElement = document.getElementById('countdown');
            const countdownInterval = setInterval(function() {
                countdown--;
                countdownElement.textContent = countdown;

                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    if (returnUrl) window.location.href = returnUrl;
                }
            }, 1000);
        } else {
            document.querySelector('.redirection-text').style.display = 'none';
        }
    </script>
</body>

</html>
