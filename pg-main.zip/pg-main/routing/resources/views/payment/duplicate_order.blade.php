<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
    <style>
        body {
            font-family: sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f4f4f4;
        }

        .error-container {
            padding: 40px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .error-message {
            color: #d9534f;
            /* Red color for error */
            font-size: 1.5em;
            margin-bottom: 20px;
        }

        .error-details {
            color: #333;
            font-size: 1em;
            line-height: 1.6;
        }

        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>

<body>

    <div class="error-container">
        <div class="error-message">
            OOPS. There is an error in the request. Duplicate order ID detected.
        </div>
        <div class="error-details">
            Please check the following:
            <ul>
                <li>Ensure that the order ID is unique and not already processed.</li>
                <li>If you believe this is an error, please contact support.</li>
                <li>Check your transaction history for any duplicate entries.</li>
            </ul>
        </div>
        <a href="#" class="back-button">Go Back</a>
    </div>

</body>

</html>
