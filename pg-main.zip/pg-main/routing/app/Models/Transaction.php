<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Transaction extends Model
{
    use SoftDeletes;

    protected $connection = 'routing_db';
    protected $table = 'transactions';
    protected $fillable = [
        'transaction_id',
        'payment_processor_id',
        'merchant_payment_processor_mapping_id',
        'merchant_id',
        'order_no',
        'transaction_type',
        'merchant_txn_ref_no',
        'currency',
        'amount',
        'return_url',
        'notify_url',
        'customer_phone_no',
        'customer_email',
        'customer_name',
        'payment_status',
    ];

    function merchant()
    {
        return $this->belongsTo(Merchant::class, 'merchant_id');
    }

    function transactionable()
    {
        return $this->morphTo();
    }
}
