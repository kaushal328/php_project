<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RawTransaction extends Model
{
    use SoftDeletes;

    protected $connection = 'routing_db';
    protected $table = 'raw_transactions';

    function merchant()
    {
        return $this->belongsTo(Merchant::class, 'merchant_id');
    }
}
