<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Merchant extends Model
{
    use SoftDeletes;

    protected $connection = 'merchant_db';
    protected $table = 'users';

    function secret()
    {
        return $this->hasOne(MerchantSecret::class, 'user_id')->where('status', 1);
    }
}
