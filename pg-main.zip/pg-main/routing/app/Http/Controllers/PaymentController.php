<?php

namespace App\Http\Controllers;

use App\Models\Merchant;
use App\Models\MerchantPaymentProcessorMapping;
use App\Models\RawTransaction;
use App\Models\Transaction;
use App\Models\UpiTransaction;
use App\Services\Cashfree\CashfreeUpiPaymentService;
use App\Services\Jio\UpiPaymentService;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    protected $upiPaymentService;
    protected $cashfreeUpiPaymentService;

    public function __construct()
    {
        $this->upiPaymentService = new UpiPaymentService();
        $this->cashfreeUpiPaymentService = new CashfreeUpiPaymentService();
    }

    function initiate(Request $request)
    {
        try {
            $mid = $request->post('mid');
            $payload = $request->post('payload');

            if (!$mid || !$payload) {
                return view('payment.invalid_mid_payload');
            }

            $merchant = Merchant::with(['secret'])->where('merchant_id', $mid)->first();
            if (!$merchant || !$merchant->secret) {
                return view('payment.invalid_mid_payload');
            }

            $merchantSecretKey = $merchant->secret->secret_key;

            $decryptedPayload = hash_decrypt($payload, $merchantSecretKey);

            if (!$decryptedPayload) {
                return view('payment.invalid_data_payload');
            }

            $decryptedPayload = json_decode($decryptedPayload, true);

            $rawTransaction = RawTransaction::where(['merchant_id' => $merchant->id, 'moved_to_transaction' => 0])->orderBy('id', 'desc')->first();
            if ($rawTransaction && $rawTransaction->order_no == $decryptedPayload['OrderNo']) {
                return view('payment.duplicate_order');
            }

            $rawTransaction = new RawTransaction();
            $rawTransaction->merchant_id = $merchant->id;
            $rawTransaction->order_no = $decryptedPayload['OrderNo'];
            $rawTransaction->transaction_type = $decryptedPayload['PaymentType'];
            $rawTransaction->currency = $decryptedPayload['Currency'];
            $rawTransaction->amount = $decryptedPayload['Amount'];
            $rawTransaction->return_url = $decryptedPayload['ReturnUrl'];
            $rawTransaction->notify_url = $decryptedPayload['NotifyUrl'];
            $rawTransaction->customer_phone_no = $decryptedPayload['CustPhoneNo'];
            $rawTransaction->customer_email = $decryptedPayload['CustEmail'];
            $rawTransaction->customer_name = $decryptedPayload['CustName'];
            $rawTransaction->customer_address1 = '';
            $rawTransaction->customer_address2 = '';
            $rawTransaction->customer_city = '';
            $rawTransaction->customer_state = '';
            $rawTransaction->customer_country = 'India';
            $rawTransaction->customer_pincode = '';
            $rawTransaction->udf1 = $decryptedPayload['Udf1'];
            $rawTransaction->udf2 = $decryptedPayload['Udf2'];
            $rawTransaction->udf3 = $decryptedPayload['Udf3'];
            $rawTransaction->udf4 = $decryptedPayload['Udf4'];
            $rawTransaction->udf5 = $decryptedPayload['Udf5'];
            $rawTransaction->udf6 = '';
            $rawTransaction->udf7 = '';
            $rawTransaction->udf8 = '';
            $rawTransaction->udf9 = '';
            $rawTransaction->udf10 = '';
            $rawTransaction->save();

            $processors = MerchantPaymentProcessorMapping::with(['paymentProcessor'])
                ->where('merchant_id', $rawTransaction->merchant_id)
                ->get()->toArray();

            $data = $decryptedPayload;
            $data['EncPayload'] = $payload;
            $data['Merchant'] = $merchant->toArray();
            $data['RawTxnId'] = custom_encrypt($rawTransaction->id, $merchantSecretKey);
            $data['processors'] = $processors;

            return view('payment.processor.processors', ['data' => $data]);
        } catch (Exception $e) {
            Log::error('Exception occurred at PaymentController@initiate: ' . $e->getMessage());
            return view('payment.server_error');
        }
    }

    function chargeUpi(Request $request)
    {
        try {
            $rawTransactionId = $request->post('RawTxnId');
            $paymentProcessorId = $request->post('PaymentProcessorId');
            $vpa = $request->post('vpa');

            if (!$vpa) {
                return response()->json([
                    'status' => false,
                    'message' => 'Enter valid UPI ID',
                ]);
            }

            $rawTransaction = RawTransaction::with(['merchant'])->orderBy('id', 'desc')->find(custom_decrypt($rawTransactionId));
            if (!$rawTransaction || $rawTransaction->moved_to_transaction == 1) {
                return response()->json([
                    'status' => false,
                    'message' => 'Invalid transaction.',
                    'redirect_url' => route('payment.failed'),
                ]);
            }


            $merchantPaymentProcessorMapping = MerchantPaymentProcessorMapping::with(['paymentProcessor.paymentProvider'])->where('merchant_id', $rawTransaction->merchant_id)->where('payment_processor_id', $paymentProcessorId)->first();
            if (!$merchantPaymentProcessorMapping) {
                return response()->json([
                    'status' => false,
                    'message' => 'Invalid transaction..',
                    'redirect_url' => route('payment.failed'),
                ]);
            }

            $merchantPaymentProcessor = $merchantPaymentProcessorMapping->paymentProcessor;
            if (!$merchantPaymentProcessor) {
                return response()->json([
                    'status' => false,
                    'message' => 'Invalid transaction...',
                    'redirect_url' => route('payment.failed'),
                ]);
            }

            $merchantPaymentProcessorProvider = $merchantPaymentProcessor->paymentProvider;
            if (!$merchantPaymentProcessor) {
                return response()->json([
                    'status' => false,
                    'message' => 'Invalid transaction....',
                    'redirect_url' => route('payment.failed'),
                ]);
            }

            //process the payment with bank
            $merchantTxnRefNo = generateUniqueId('routing_db', 'merchant_txn_ref_no', 'transactions', 10);

            $upiTransaction = new UpiTransaction();
            $upiTransaction->upi_id = $vpa;
            $upiTransaction->payer_name = $rawTransaction->customer_name;
            $upiTransaction->status = 1;
            $upiTransaction->save();

            $transaction = $upiTransaction->transaction()->create([
                'transaction_id' => generateUniqueId('routing_db', 'transaction_id', 'transactions', 10, true, false, 'TXN'),
                'payment_processor_id' => $merchantPaymentProcessor->id,
                'merchant_payment_processor_mapping_id' => $merchantPaymentProcessorMapping->id,
                'merchant_id' => $rawTransaction->merchant_id,
                'order_no' => $rawTransaction->order_no,
                'transaction_type' => $rawTransaction->transaction_type,
                'merchant_txn_ref_no' => $merchantTxnRefNo,
                'currency' => $rawTransaction->currency,
                'amount' => $rawTransaction->amount,
                'return_url' => $rawTransaction->return_url,
                'notify_url' => $rawTransaction->notify_url,
                'customer_phone_no' => $rawTransaction->customer_phone_no,
                'customer_email' => $rawTransaction->customer_email,
                'customer_name' => $rawTransaction->customer_name,
                'payment_status' => 0,
                // 'transaction_request' => null,
                // 'transaction_response' => null,
            ]);

            $rawTransaction->moved_to_transaction = 1;
            $rawTransaction->save();

            $providerType = $merchantPaymentProcessorProvider->type;

            if ($providerType == 'CASHFREE') {
                $dataToSend = [
                    'amount' => $rawTransaction->amount,
                    'customer_id' => (string) mt_rand(1000000000, 9999999999),
                    'customer_name' => $rawTransaction->customer_name,
                    'customer_phone' => $rawTransaction->customer_phone_no,
                    'customer_email' => $rawTransaction->customer_email,
                    'return_url' => $rawTransaction->return_url,
                    'notify_url' => $rawTransaction->notify_url,
                    'vpa' => $vpa,
                ];

                $paymentResponse = $this->cashfreeUpiPaymentService->pay($dataToSend);

                $pRequest = $paymentResponse['request'];
                $pResponse = $paymentResponse['response'];
                $orderId = '';

                if(isset($paymentResponse['status']) && $paymentResponse['status'] == 1) {
                    $pData = $paymentResponse['data'] ?? [];
                    $pStatus = $pData['payment_status'];
                    $orderId = $pData['order_id'] ?? '';
                    $cfPaymentId = isset($pData['cf_payment_id']) && !empty($pData['cf_payment_id']) ? $pData['cf_payment_id'] : null;

                    if($cfPaymentId) {
                        $transaction->pg_payment_id = $cfPaymentId;
                    }

                    $transaction->payment_status = $pStatus;
                    $transaction->pg_order_id = $orderId;
                    $transaction->pg_order_response = json_encode($pData['order_response']);

                }

                $transaction->transaction_request = json_encode($pRequest);
                $transaction->transaction_response = json_encode($pResponse);
                $transaction->save();

                return response()->json([
                    'status' => $paymentResponse['status'],
                    'message' => $paymentResponse['message'],
                    'order_id' => $orderId,
                    'next_action' => $paymentResponse['next_action'] ?? '',
                    'full_response' => $paymentResponse,
                ]);
            } else if ($providerType == 'JIO') {
                $dataToSend = [
                    'aggregatorID' => 'AJP2100000070001',
                    'amount' => $rawTransaction->amount,
                    'currencyCode' => 356,
                    'customerEmailID' => $rawTransaction->customer_email,
                    'merchantId' => 'JP2100000070001',
                    'merchantTxnNo' => $merchantTxnRefNo,
                    'payType' => 0,
                    'returnURL' => $rawTransaction->return_url,
                    'transactionType' => 'SALE',
                    'txnDate' => date('YmdHis'),
                    'paymentMode' => 'UPI',
                    'customerUPIAlias' => $vpa,
                ];

                $paymentResponse = $this->upiPaymentService->initiateSale($dataToSend);

                $paymentStatus = $this->upiPaymentService->checkTransactionStatusCode($paymentResponse);
            }

            // if ($paymentStatus == 1) {
            //     $data = [
            //         'merchantTxnRefNo' => $merchantTxnRefNo,
            //         'returnUrl' => $rawTransaction->return_url . '?payload=' . hash_encrypt(json_encode(['status' => 'success', 'merchantTxnRefNo' => $merchantTxnRefNo]), $rawTransaction->merchant->secret->secret_key),
            //     ];

            //     return view('payment.payment_success', $data);
            // } else {
            //     $data = [
            //         'merchantTxnRefNo' => $merchantTxnRefNo,
            //         'returnUrl' => $rawTransaction->return_url . '?payload=' . hash_encrypt(json_encode(['status' => 'failed', 'merchantTxnRefNo' => $merchantTxnRefNo]), $rawTransaction->merchant->secret->secret_key),
            //     ];

            //     return view('payment.payment_failed', $data);
            // }
        } catch (Exception $e) {
            Log::error('Exception occurred at PaymentController@chargeUpi: ' . $e);
            return response()->json([
                'status' => false,
                'message' => 'Server error occurred. Please try again later.',
                'redirect_url' => route('payment.failed'),
            ]);
        }
    }

    function checkUpiStatus(Request $request)
    {
        $orderId = $request->post('order_id');

        $transaction = Transaction::where('pg_order_id', $orderId)->first();

        if (!$transaction) {
            return response()->json([
                'status' => 0,
                'redirect_url' => route('payment.failed'),
            ]);
        }

        $response = $this->cashfreeUpiPaymentService->check($orderId);

        if($response['status'] == 1) {
            $transaction->payment_status = 1;
            $transaction->pg_payment_response = json_encode($response);
            $transaction->save();

            $response['redirect_url'] = route('payment.success', ['transaction_id' => custom_encrypt($transaction->transaction_id)]);
        }else if($response['status'] == 0) {
            $response['redirect_url'] = route('payment.failed', ['transaction_id' => custom_encrypt($transaction->transaction_id)]);
        }

        return response()->json($response);
    }

    function paymentFailed(Request $request)
    {
        $transactionId = $request->route('transaction_id');
        $transactionId = custom_decrypt($request->route('transaction_id'));

        $data = [
            'merchantTxnRefNo' => '',
            'returnUrl' => '',
            'message' => 'Payment failed',
            'transactionId' => '',
        ];

        if ($transactionId) {
            $transaction = Transaction::where('transaction_id', $transactionId)->first();
            if ($transaction) {
                $data = [
                    'merchantTxnRefNo' => $transaction->merchant_txn_ref_no,
                    'returnUrl' => $transaction->return_url,
                    'message' => 'Payment failed',
                    'transactionId' => $transaction->transaction_id,
                ];
            }
        }

        return view('payment.payment_failed', $data);
    }

    function paymentSuccess(Request $request)
    {
        $transactionId = $request->route('transaction_id');
        $transactionId = custom_decrypt($request->route('transaction_id'));

        $data = [
            'merchantTxnRefNo' => '',
            'amount' => '',
            'returnUrl' => '',
            'message' => 'Payment success',
            'transactionId' => '',
        ];

        if ($transactionId) {
            $transaction = Transaction::where('transaction_id', $transactionId)->first();
            if ($transaction) {
                $data = [
                    'merchantTxnRefNo' => $transaction->merchant_txn_ref_no,
                    'amount' => $transaction->amount,
                    'transactionDate' => $transaction->created_at,
                    'returnUrl' => $transaction->return_url,
                    'message' => 'Payment success',
                    'transactionId' => $transaction->transaction_id,
                ];
            }
        }

        return view('payment.payment_success', $data);
    }
}
