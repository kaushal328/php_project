<?php

function generateSecureHash(array $params, string $secretKey): string
{
    $hashFields = [
        'aggregatorID',
        'amount',
        'currencyCode',
        'customerEmailID',
        'merchantId',
        'merchantTxnNo',
        'payType',
        'returnURL',
        'transactionType',
        'txnDate',
    ];

    $filteredValues = [];

    // Step 1: Remove null or empty values
    foreach ($hashFields as $field) {
        $value = $params[$field] ?? null;
        if ($value !== null && $value !== '') {
            $filteredValues[$field] = $value;
        }
    }

    ksort($filteredValues); // Sort by key (parameter name)

    $concatenatedValues = implode('', array_values($filteredValues));

    $secureHash = hash_hmac('sha256', $concatenatedValues, $secretKey);

    // dd($secureHash);

    return strtolower($secureHash);
}
