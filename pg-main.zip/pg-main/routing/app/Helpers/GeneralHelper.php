<?php

use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

function formatErrors($errors = [])
{
    $error_array = [];

    if (count($errors) > 0) {
        foreach ($errors as $k => $v) {
            $error_array[$k] = $v[0];
        }
    }

    return $error_array;
}

function convertDateFormat($dateString)
{
    if (empty($dateString)) {
        return '';
    }

    $date = Carbon::createFromFormat('Y-m-d', $dateString);
    if (!$date) {
        return '';
    }

    $formattedDate = $date->format('d-m-Y');
    return $formattedDate;
}

function formatDate($dateString)
{
    if (empty($dateString)) {
        return '';
    }

    $date = Carbon::createFromFormat('Y-m-d', $dateString);
    if (!$date) {
        return '';
    }

    $formattedDate = $date->format('M d, Y');
    return $formattedDate;
}

function createSlug($id = '', $name = '', $table_name = '')
{
    $count = 0;
    $name = Str::slug($name);
    $slug_name = $name; // Create temp name
    while (true) {
        $result = DB::table($table_name)
            ->select('id')
            ->when($id, function ($q) use ($id) {
                $q->where('id', '!=', $id);
            })
            ->where('slug', $slug_name)
            ->count();

        if ($result == 0) {
            break;
        }

        $slug_name = $name . '-' . ++$count;
    }
    return $slug_name; // Return temp name
}

function pagination($total, $per_page = 10, $page = 1, $url = '?')
{
    $adjacents = '2';
    $page = $page == 0 ? 1 : $page;
    $start = ($page - 1) * $per_page;
    $prev = $page - 1;
    $next = $page + 1;
    $lastpage = ceil($total / $per_page);
    $lpm1 = $lastpage - 1;
    $pagination = '';

    //paginate_button current
    if ($lastpage > 1) {
        $pagination .= '<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mt-3">';
        $pagination .= "<ul class='pagination pagination-borderless' style='padding: 0px 10px 0px 15px;'>";
        if ($lastpage < 7 + $adjacents * 2) {
            // Place the left arrow before the page numbers
            if ($page > 1) {
                $pagination .= "<li class='page-item prev'><a href='{$url}page=$prev' class='page-link'><i class='ti tabler-chevron-left tabler-xs'></i></a></li>";
            } else {
                $pagination .= "<li class='page-item prev disabled'><span class='page-link'><i class='ti tabler-chevron-left tabler-xs'></i></span></li>";
            }

            for ($counter = 1; $counter <= $lastpage; $counter++) {
                if ($counter == $page) {
                    $pagination .= "<li class='page-item active'><a class='current page-link'>$counter</a></li>";
                } else {
                    $pagination .= "<li class='page-item'><a href='{$url}page=$counter' class='page-link'>$counter</a></li>";
                }
            }

            // Place the right arrow after the page numbers
            if ($next <= $lastpage) {
                $pagination .= "<li class='page-item next'><a href='{$url}page=$next' class='page-link'><i class='ti tabler-chevron-right tabler-xs'></i></a></li>";
            } else {
                $pagination .= "<li class='page-item next disabled'><span class='page-link'><i class='ti tabler-chevron-right tabler-xs'></i></span></li>";
            }
        } elseif ($lastpage > 5 + $adjacents * 2) {
            // Place the left arrow before the page numbers
            $pagination .= "<li class='page-item prev'><a href='{$url}page=$prev' class='page-link'><i class='ti tabler-chevron-left tabler-xs'></i></a></li>";

            for ($counter = 1; $counter < 4 + $adjacents * 2; $counter++) {
                if ($counter == $page) {
                    $pagination .= "<li class='page-item active'><a class='current page-link'>$counter</a></li>";
                } else {
                    $pagination .= "<li class='page-item'><a href='{$url}page=$counter' class='page-link'>$counter</a></li>";
                }
            }

            $pagination .= "<li class='dot' style='padding: 0px 10px;float: left;'>...</li>";
            $pagination .= "<li class='page-item'><a href='{$url}page=$lpm1' class='page-link'>$lpm1</a></li>";
            $pagination .= "<li class='page-item'><a href='{$url}page=$lastpage' class='page-link'>$lastpage</a></li>";

            // Place the right arrow after the page numbers
            if ($next <= $lastpage) {
                $pagination .= "<li class='page-item next'><a href='{$url}page=$next' class='page-link'><i class='ti tabler-chevron-right tabler-xs'></i></a></li>";
            } else {
                $pagination .= "<li class='page-item next disabled'><span class='page-link'><i class='ti tabler-chevron-right tabler-xs'></i></span></li>";
            }
        } else {
            // Place the left arrow before the page numbers
            if ($page > 1) {
                $pagination .= "<li class='page-item prev'><a href='{$url}page=$prev' class='page-link'><i class='ti tabler-chevron-left tabler-xs'></i></a></li>";
            } else {
                $pagination .= "<li class='page-item prev disabled'><span class='page-link'><i class='ti tabler-chevron-left tabler-xs'></i></span></li>";
            }

            $pagination .= "<li class='page-item'><a href='{$url}page=1' class='page-link'>1</a></li>";
            $pagination .= "<li class='page-item'><a href='{$url}page=2' class='page-link'>2</a></li>";
            $pagination .= "<li class='dot' style='padding: 0px 10px;float: left;'>...</li>";

            for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++) {
                if ($counter == $page) {
                    $pagination .= "<li class='page-item active'><a class='current page-link'>$counter</a></li>";
                } else {
                    $pagination .= "<li class='page-item'><a href='{$url}page=$counter' class='page-link'>$counter</a></li>";
                }
            }

            $pagination .= "<li class='dot' style='padding: 0px 10px;float: left;'>..</li>";
            $pagination .= "<li class='page-item'><a href='{$url}page=$lpm1' class='page-link'>$lpm1</a></li>";
            $pagination .= "<li class='page-item'><a href='{$url}page=$lastpage' class='page-link'>$lastpage</a></li>";
        }

        $pagination .= '</ul>';
        $pagination .= '</div>';
    }
    return $pagination;
}

function primaryBadge($name = '')
{
    return '<span class="badge bg-label-primary">' . $name . '</span>';
}

function successBadge($name = '')
{
    return '<span class="badge bg-success bg-glow">' . $name . '</span>';
}

function dangerBadge($name = '')
{
    return '<span class="badge bg-label-danger">' . $name . '</span>';
}

function warningBadge($name = '')
{
    return '<span class="badge bg-warning bg-glow">' . $name . '</span>';
}

function limitCharacters($inputString, $limit)
{
    if (strlen($inputString) <= $limit) {
        return $inputString;
    } else {
        $truncatedString = substr($inputString, 0, $limit);
        $truncatedString .= '...';

        return $truncatedString;
    }
}

function generateUniqueId($connection = 'mysql', $column = '', $table = '', $length = 10, $upperCase = false, $numericOnly = false, $prefix = '')
{
    if ($column && $table) {
        if ($numericOnly) {
            $uniqueId = str_pad(mt_rand(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);
        } else {
            $uniqueId = Str::random($length);
            if ($upperCase) {
                $uniqueId = strtoupper($uniqueId);
            }
        }

        if ($prefix) {
            $uniqueId = $prefix . $uniqueId;
        }

        while (DB::connection($connection)->table($table)->where($column, $uniqueId)->exists()) {
            if ($numericOnly) {
                $uniqueId = str_pad(mt_rand(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);
            } else {
                $uniqueId = Str::random($length);
                if ($upperCase) {
                    $uniqueId = strtoupper($uniqueId);
                }
            }

            if ($prefix) {
                $uniqueId = $prefix . $uniqueId;
            }
        }

        return $uniqueId;
    }

    throw new Exception('Column and table name are required.');
}

function hash_encrypt($str, $key)
{
    $iv = substr(hash('sha256', $key), 0, 16);
    $output = openssl_encrypt($str, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($output);
}

function hash_decrypt($str, $key)
{
    $iv = substr(hash('sha256', $key), 0, 16);
    $output = openssl_decrypt(base64_decode($str), 'AES-256-CBC', $key, 0, $iv);
    return $output;
}

function moveImage($fromDirectory, $toDirectory, $file)
{
    // Construct full file paths
    $sourceFile = $fromDirectory . '/' . $file;
    $targetFile = $toDirectory . '/' . $file;

    if (Storage::disk('public')->exists($targetFile)) {
        return ['success' => true];
    }

    if (Storage::disk('public')->exists($sourceFile)) {
        Storage::disk('public')->move($sourceFile, $targetFile);
        return ['success' => true];
    } else {
        return ['success' => false, 'error' => 'Upload a valid file'];
    }
}

function custom_encrypt($str)
{
    if (!$str) {
        return '';
    }

    $key = env('APP_KEY');
    $iv = substr(hash('sha256', $key), 0, 16);
    $output = openssl_encrypt($str, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($output);
}

function custom_decrypt($str)
{
    if (!$str) {
        return '';
    }

    $key = env('APP_KEY');
    $iv = substr(hash('sha256', $key), 0, 16);
    $output = openssl_decrypt(base64_decode($str), 'AES-256-CBC', $key, 0, $iv);
    return $output;
}
