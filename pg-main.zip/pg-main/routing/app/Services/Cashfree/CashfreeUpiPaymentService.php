<?php

namespace App\Services\Cashfree;

use Carbon\Carbon;
use Illuminate\Support\Facades\Http;

class CashfreeUpiPaymentService
{
    protected $apiVersion;
    protected $clientId;
    protected $clientSecret;

    public function __construct()
    {
        $this->apiVersion = '2025-01-01';
        $this->clientId = 'TEST10546572768717584bd6b8ca290527564501';
        $this->clientSecret = 'cfsk_ma_test_0060e8866cb6c0e7cb7b78411643fb3a_29edde2a';
    }

    public function pay($data)
    {
        // Create Order

        $order = $this->createOrder($data);

        $orderRequest = $order['request'];
        $orderResponse = $order['response'];

        if (!$order || !isset($order['response']) || empty($order['response'])) {
            return [
                'status' => 0,
                'message' => 'Unable to create order',
                'request' => $orderRequest,
                'response' => $orderResponse,
            ];
        }

        if (!isset($orderResponse['payment_session_id']) || empty($orderResponse['payment_session_id'])) {
            return [
                'status' => 0,
                'message' => 'Unable to create order',
                'request' => $orderRequest,
                'response' => $orderResponse,
            ];
        }


        // Create Payment

        $paymentSessionId = $orderResponse['payment_session_id'];
        $vpa = $data['vpa'] ?? null;

        $payment = $this->makePayment($paymentSessionId, $vpa);

        $paymentRequest = $payment['request'];
        $paymentResponse = $payment['response'];

        if (!$payment || !isset($payment['response']) || empty($payment['response'])) {
            return [
                'status' => 0,
                'message' => 'Unable to initiate payment',
                'request' => $paymentRequest,
                'response' => $paymentResponse,
            ];
        }

        if (!isset($paymentResponse['cf_payment_id']) || empty($paymentResponse['cf_payment_id'])) {
            if (isset($paymentResponse['code'])) {
                if ($paymentResponse['code'] == 'upi_id_invalid') {
                    return [
                        'status' => 0,
                        'message' => 'Invalid UPI ID',
                        'request' => $paymentRequest,
                        'response' => $paymentResponse,
                    ];
                }

                if ($paymentResponse['code'] == 'return_url_invalid') {
                    return [
                        'status' => 0,
                        'message' => 'Invalid Return URL',
                        'request' => $paymentRequest,
                        'response' => $paymentResponse,
                    ];
                }
            }

            return [
                'status' => 0,
                'message' => 'Unable to initiate payment',
                'request' => $paymentRequest,
                'response' => $paymentResponse,
            ];
        }

        $data = [
            'status' => 1,
            'message' => 'Please open your UPI app and complete the payment and come back to this page. Do not close or refresh the page.',
            'next_action' => 'waiting_for_payment',
            'request' => $paymentRequest,
            'response' => $paymentResponse,
            'data' => [
                'order_id' => $orderResponse['order_id'],
                'order_response' => $orderResponse,
                'payment_status' => 2, // Pending for payment
                'payment_session_id' => $paymentSessionId,
                'cf_order_id' => $orderResponse['cf_order_id'],
                'cf_payment_id' => $paymentResponse['cf_payment_id'],
                'simulator' => $paymentResponse['data']['payload'],
            ]
        ];

        return $data;
    }

    public function check($order_id)
    {
        if (!$order_id || empty($order_id)) {
            return [
                'status' => 0,
                'message' => 'Invalid order ID',
                'response' => null,
            ];
        }

        $payments = $this->checkStatus($order_id);

        if (!$payments || empty($payments) || count($payments) == 0) {
            return [
                'status' => 0,
                'message' => 'Unable to check status',
                'response' => $payments,
            ];
        }

        $payment = $payments[0];

        // Available options: SUCCESS, NOT_ATTEMPTED, FAILED, USER_DROPPED, VOID, CANCELLED, PENDING 

        if ($payment['payment_status'] == 'PENDING' || $payment['payment_status'] == 'NOT_ATTEMPTED') {
            return [
                'status' => 2,
                'message' => 'Payment pending for capture',
                'response' => $payment,
            ];
        }

        if ($payment['is_captured'] == true && $payment['payment_status'] == 'SUCCESS') {
            return [
                'status' => 1,
                'message' => 'Payment successful',
                'response' => $payment,
            ];
        }

        // if ($payment['payment_status'] == 'NOT_ATTEMPTED') {
        //     return [
        //         'status' => 0,
        //         'message' => 'Payment not attempted',
        //         'response' => $payment,
        //     ];
        // }

        if ($payment['payment_status'] == 'FAILED') {
            return [
                'status' => 0,
                'message' => 'Payment failed',
                'response' => $payment,
            ];
        }

        if ($payment['payment_status'] == 'USER_DROPPED') {
            return [
                'status' => 0,
                'message' => 'Payment dropped by user',
                'response' => $payment,
            ];
        }

        if ($payment['payment_status'] == 'VOID') {
            return [
                'status' => 0,
                'message' => 'Payment voided',
                'response' => $payment,
            ];
        }

        if ($payment['payment_status'] == 'CANCELLED') {
            return [
                'status' => 0,
                'message' => 'Payment cancelled',
                'response' => $payment,
            ];
        }

        return $payments;
    }

    // Cashfree API

    public function createOrder($data)
    {
        $url = 'https://sandbox.cashfree.com/pg/orders';

        $payload = [
            'order_currency' => 'INR',
            'order_amount' => $data['amount'],
            'order_note' => date('Y-m-d H:i:s'),
            'order_expiry_time' => Carbon::now()->addMinutes(30),
            'customer_details' => [
                'customer_id' => $data['customer_id'],
                'customer_name' => $data['customer_name'],
                'customer_phone' => $data['customer_phone'],
                'customer_email' => $data['customer_email'],
            ],
            'order_meta' => [
                'return_url' => $data['return_url'],
                'notify_url' => $data['notify_url'],
                'payment_methods' => 'upi',
            ]
        ];

        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'x-api-version' => $this->apiVersion,
            'x-client-id' => $this->clientId,
            'x-client-secret' => $this->clientSecret,
        ])->post($url, $payload);

        return ['request' => $payload, 'response' => $response->json()];
    }

    public function makePayment($payment_session_id, $vpa): array
    {
        $url = 'https://sandbox.cashfree.com/pg/orders/sessions';

        $payload = [
            'payment_session_id' => $payment_session_id,
            'payment_method' => [
                'upi' => [
                    'channel' => 'link',
                    'upi_id' => $vpa,
                ]
            ],
        ];

        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'x-api-version' => $this->apiVersion,
            'x-client-id' => $this->clientId,
            'x-client-secret' => $this->clientSecret,
        ])->post($url, $payload);

        return ['request' => $payload, 'response' => $response->json()];
    }

    public function checkStatus($order_id)
    {
        $url = 'https://sandbox.cashfree.com/pg/orders/' . $order_id . '/payments';

        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'x-api-version' => $this->apiVersion,
            'x-client-id' => $this->clientId,
            'x-client-secret' => $this->clientSecret,
        ])->get($url);

        return $response->json();
    }
}
