<?php

namespace App\Services\Jio;

use Illuminate\Support\Facades\Http;

class UpiPaymentService
{
    public function initiateSale($data): array
    {
        $url = 'https://uat.jiopay.co.in/tsp/pg/api/v2/initiateSale';

        $payload = $data;
        $payload['secureHash'] = generateSecureHash($data, 'JP2100000070001');

        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post($url, $payload);

        return $response->json();
    }

    public function checkTransactionStatusCode($response)
    {
        $transactionStatus = 0;

        if($response['responseCode'] == '0000') {
            $transactionStatus = 1;
        }

        return $transactionStatus;
    }
}
