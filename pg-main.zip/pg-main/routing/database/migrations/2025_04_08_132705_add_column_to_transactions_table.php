<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('transactions', function (Blueprint $table) {
            $table->string('pg_order_id')->nullable()->after('transaction_response');
            $table->text('pg_order_response')->nullable()->after('pg_order_id');
            $table->string('pg_payment_id')->nullable()->after('pg_order_response');
            $table->text('pg_payment_response')->nullable()->after('pg_payment_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('transactions', function (Blueprint $table) {
            $table->dropColumn(['pg_order_id', 'pg_order_response', 'pg_payment_id', 'pg_payment_response']);
        });
    }
};
