<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('raw_transactions', function (Blueprint $table) {
            $table->id();
            $table->integer('merchant_id');
            $table->string('order_no');
            $table->string('transaction_type')->comment('sale, refund');
            $table->string('currency');
            $table->string('amount');
            $table->string('return_url');
            $table->string('notify_url')->nullable();
            $table->string('customer_phone_no')->nullable();
            $table->string('customer_email')->nullable();
            $table->string('customer_name')->nullable();
            $table->string('customer_address1')->nullable();
            $table->string('customer_address2')->nullable();
            $table->string('customer_city')->nullable();
            $table->string('customer_state')->nullable();
            $table->string('customer_country')->nullable();
            $table->string('customer_pincode')->nullable();
            $table->string('udf1')->nullable();
            $table->string('udf2')->nullable();
            $table->string('udf3')->nullable();
            $table->string('udf4')->nullable();
            $table->string('udf5')->nullable();
            $table->string('udf6')->nullable();
            $table->string('udf7')->nullable();
            $table->string('udf8')->nullable();
            $table->string('udf9')->nullable();
            $table->string('udf10')->nullable();
            $table->tinyInteger('moved_to_transaction')->default(0);
            $table->tinyInteger('status')->default(1);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('raw_transactions');
    }
};
