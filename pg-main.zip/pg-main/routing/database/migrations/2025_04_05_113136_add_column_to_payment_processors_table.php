<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('payment_processors', function (Blueprint $table) {
            $table->integer('payment_provider_id')->after('id');
            $table->string('processor_type')->after('payment_provider_id');
            $table->string('subtitle')->nullable()->after('name');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('payment_processors', function (Blueprint $table) {
            $table->dropColumn(['payment_provider_id', 'processor_type']);
        });
    }
};
