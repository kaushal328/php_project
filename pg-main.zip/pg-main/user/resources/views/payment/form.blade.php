<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Initiation Form</title>
    <style>
        body {
            font-family: sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            /* height: 100vh; */
            margin: 0;
            background-color: #f4f4f4;
        }

        .form-container {
            text-align: left;
            padding: 40px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 400px;
            /* Adjust width as needed */
        }

        .form-container label {
            display: block;
            margin-bottom: 5px;
        }

        .form-container input[type="text"],
        .form-container input[type="number"],
        .form-container input[type="email"],
        .form-container input[type="url"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-container button[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }

        .form-container button[type="submit"]:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: #d9534f;
            margin-top: 10px;
        }
    </style>
</head>

<body>

    <div class="form-container">
        <h2>Initiate Payment</h2>

        @if ($errors->any())
            <div class="error-message">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="POST" action="{{ route('payment.submit') }}">
            @csrf

            <label for="Mid">Merchant ID (Mid):</label>
            <input type="text" id="Mid" name="Mid" value="MLcZQQtNJI" required >

            <label for="Amount">Amount:</label>
            <input type="number" id="Amount" name="Amount" value="234" required >

            <label for="Currency">Currency:</label>
            <input type="text" id="Currency" name="Currency" value="INR" required >

            <label for="OrderNo">Order Number:</label>
            <input type="text" id="OrderNo" name="OrderNo" value="ORDER234942" required >

            <label for="CustPhoneNo">Customer Phone:</label>
            <input type="text" id="CustPhoneNo" name="CustPhoneNo" value="9033878878">

            <label for="CustEmail">Customer Email:</label>
            <input type="email" id="CustEmail" name="CustEmail" value="rakeshmsuthar@gmail.com">

            <label for="SecretKey">Secret Key:</label>
            <input type="text" id="SecretKey" name="SecretKey" value="LPF2NDP6BTIST2XGPZG7UMWJIG5LHJKEAQB16HWEHCXTN5NYFK46JQDVHWXTZWOR" required >

            <label for="SaltKey">Salt:</label>
            <input type="text" id="SaltKey" name="SaltKey" value="916ZD3WFW6QXRXJHDP5WO9HE7VGOXFSU" required >

            <label for="Description">Description:</label>
            <input type="text" id="Description" name="Description" value="Test description">

            <label for="PaymentType">Payment Type:</label>
            <input type="text" id="PaymentType" name="PaymentType" value="S" required >

            <label for="CustName">Customer Name:</label>
            <input type="text" id="CustName" name="CustName" value="Rakesh">

            <label for="Udf1">Additional Field 1:</label>
            <input type="text" id="Udf1" name="Udf1" value="{{ old('Udf1') }}">

            <label for="Udf2">Additional Field 2:</label>
            <input type="text" id="Udf2" name="Udf2" value="{{ old('Udf2') }}">

            <label for="Udf3">Additional Field 3:</label>
            <input type="text" id="Udf3" name="Udf3" value="{{ old('Udf3') }}">

            <label for="Udf4">Additional Field 4:</label>
            <input type="text" id="Udf4" name="Udf4" value="{{ old('Udf4') }}">

            <label for="Udf5">Additional Field 5:</label>
            <input type="text" id="Udf5" name="Udf5" value="{{ old('Udf5') }}">

            <label for="ReturnUrl">Return URL:</label>
            <input type="url" id="ReturnUrl" name="ReturnUrl" value="{{ old('ReturnUrl') }}" required >
            
            <label for="ReturnUrl">Notify URL:</label>
            <input type="url" id="NotifyUrl" name="NotifyUrl" value="{{ old('NotifyUrl') }}">

            <button type="submit">Submit Payment Request</button>
        </form>
    </div>

</body>

</html>
