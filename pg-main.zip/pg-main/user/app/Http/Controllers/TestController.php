<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class TestController extends Controller
{
    function form(Request $request)
    {
        return view('payment.form');
    }

    function submit(Request $request)
    {
        $data = $request->post();

        // Assuming custom_encrypt returns an array with 'data' key.
        $encryptedData = custom_encrypt(json_encode($data), $data['SecretKey']);

        ?>
            <form method="POST" action="http://pg-routing.local/payment/initiate">
                <input type="hidden" name="payload" value="<?php echo $encryptedData; ?>">
                <input type="hidden" name="mid" value="<?php echo $data['Mid'] ?>">
                <input type="submit" style="display: none;">
            </form>
            <script language='javascript'>
                document.querySelectorAll('[type="submit"]')[0].click();
            </script>
        <?php

    }

    function response(Request $request)
    {
        $payload = $request->get('payload');

        $decryptedData = hash_decrypt($payload, 'LPF2NDP6BTIST2XGPZG7UMWJIG5LHJKEAQB16HWEHCXTN5NYFK46JQDVHWXTZWOR');

        $data['payload'] = $payload;
        $data['data'] = json_decode($decryptedData, true);

        echo "<pre>";
        print_r($data);
        exit;
    }
}


