<?php

use App\Http\Controllers\TestController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::prefix('test')->group(function () {
    Route::get('/form', [TestController::class, 'form']);
    Route::post('/submit', [TestController::class, 'submit'])->name('payment.submit');
    Route::any('/response', [TestController::class, 'response']);
});