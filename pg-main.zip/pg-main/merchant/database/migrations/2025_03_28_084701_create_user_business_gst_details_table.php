<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_business_gst_details', function (Blueprint $table) {
            $table->id();
            $table->integer('user_business_id');
            $table->string('cin_number')->nullable();
            $table->tinyInteger('dont_have_gst')->default(0);
            $table->string('gst_number');
            $table->text('gst_api_response')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_business_gst_details');
    }
};
