<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_businesses', function (Blueprint $table) {
            $table->id();
            $table->integer('user_id');
            $table->integer('business_type_id');
            $table->string('name');
            $table->string('pan_number')->nullable();
            $table->integer('business_category_id');
            $table->integer('business_subcategory_id');
            $table->string('registered_address')->nullable();
            $table->string('registered_pincode')->nullable();
            $table->string('registered_city')->nullable();
            $table->string('registered_state')->nullable();
            $table->integer('registered_country_id')->nullable();
            $table->tinyInteger('current_address_same_as_registered')->nullable();
            $table->string('current_address')->nullable();
            $table->string('current_pincode')->nullable();
            $table->string('current_city')->nullable();
            $table->string('current_state')->nullable();
            $table->integer('current_country_id')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_businesses');
    }
};
