<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('user_secrets', function (Blueprint $table) {
            $table->tinyInteger('is_revoked')->default(0)->after('status');
            $table->timestamp('revoked_at')->nullable()->after('is_revoked');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('user_secrets', function (Blueprint $table) {
            $table->dropColumn(['is_revoked', 'revoked_at']);
        });
    }
};
