<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'Merchant',
            'merchant_id' => 'M123456789',
            'email' => 'merchant@gmail.com',
            'phone' => '8454986458',
            'password' => Hash::make('123456'),
        ]);
    }
}
