<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserBusiness extends Model
{
    use SoftDeletes;

    protected $connection = 'merchant_db';
    protected $table = 'user_businesses';
}
