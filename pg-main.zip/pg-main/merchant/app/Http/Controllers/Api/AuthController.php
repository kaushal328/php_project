<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    function login(Request $request)
    {
        try {
            $request->validate([
                'email' => 'required|email',
                'password' => 'required'
            ]);

            $email = $request->post('email');
            $password = $request->post('password');
            $user = User::where('email', $email)->first();
            if (!$user || !Hash::check($password, $user->password)) {
                $this->response['error'] = 'Invalid email or password';
                return response()->json($this->response, 200);
            }

            auth()->login($user);

            $this->response['status'] = 1;
            $this->response['msg'] = 'Login successful';
            $this->response['data'] = [
                'user' => $user,
                'token' => $user->createToken('token')->plainTextToken,
            ];
            return response()->json($this->response, 200);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at AuthController@login: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function logout(Request $request)
    {
        try {
            auth()->logout();
            return redirect()->route('login');
        } catch (Exception $e) {
            Log::error('Exception at AuthController@logout: ' . $e->getMessage());
            return abort(500);
        }
    }
}
