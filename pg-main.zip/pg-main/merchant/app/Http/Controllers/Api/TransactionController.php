<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class TransactionController extends Controller
{
    function index(Request $request)
    {
        try {
            $data = [];
            $user = $request->user();
            $date_range = $data['date_range'] = $request->get('date_range') ?? '';
            $from_date = $data['from_date'] = $request->get('from_date') ?? '';
            $to_date = $data['to_date'] = $request->get('to_date') ?? '';
            $search = $data['search'] = $request->get('search') ?? '';
            $export = $request->get('export') ?? '';
            $merchantId = $data['merchant_id'] = $request->get('merchant_id') ?? '';
            $paymentStatus = $data['payment_status'] = $request->get('payment_status') ?? '';
            $page = $data['page'] = $request->get('page') ?? 1;
            $perPage = $data['per_page'] = $request->get('per_page') ?? 50;
            $list = Transaction::where('merchant_id', $user->id)->orderBy('id', 'desc');
            if ($search) {
                $list->where(function ($q) use ($search) {
                    $q->orWhere('transaction_id', 'like', '%' . $search . '%');
                    $q->orWhere('order_no', 'like', '%' . $search . '%');
                    $q->orWhere('merchant_txn_ref_no', 'like', '%' . $search . '%');
                    $q->orWhere('amount', 'like', '%' . $search . '%');
                    $q->orWhere('customer_phone_no', 'like', '%' . $search . '%');
                    $q->orWhere('customer_email', 'like', '%' . $search . '%');
                    $q->orWhere('customer_name', 'like', '%' . $search . '%');
                    $q->orWhere('customer_address1', 'like', '%' . $search . '%');
                    $q->orWhere('customer_address2', 'like', '%' . $search . '%');
                    $q->orWhere('customer_city', 'like', '%' . $search . '%');
                    $q->orWhere('customer_state', 'like', '%' . $search . '%');
                    $q->orWhere('customer_country', 'like', '%' . $search . '%');
                    $q->orWhere('customer_pincode', 'like', '%' . $search . '%');
                });
            }
            if ($date_range) {
                switch ($date_range) {
                    case 'today':
                        $list->whereDate('created_at', now());
                        break;
                    case 'yesterday':
                        $list->whereDate('created_at', date('Y-m-d', strtotime('-1')));
                        break;
                    case 'last_seven_days':
                        $list->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                        // $list->whereDate('created_at', '<=', date('Y-m-d'));
                        break;
                    case 'this_month':
                        $list->whereMonth('created_at', date('m'));
                        break;
                    case 'last_month':
                        $list->whereMonth('created_at', date('m', strtotime('-1 month')));

                        break;
                    case 'this_year':
                        $list->whereYear('created_at', date('Y'));
                        break;
                    case 'last_year':
                        $list->whereYear('created_at', date('Y', strtotime('-1 year')));
                        break;
                    case 'custom':
                        if ($from_date) {
                            $list->whereDate('created_at', '>=', $from_date);
                        }
                        if ($to_date) {
                            $list->whereDate('created_at', '<=', $to_date);
                        }
                        break;
                }
            }

            if ($merchantId) {
                $list->where('merchant_id', $merchantId);
            }
            if ($paymentStatus != '') {
                $list->where('payment_status', $paymentStatus);
            }
            $data['total'] = $total = $list->count();
            $data['total_pages'] = $total < $perPage ? 1 : ceil($total / $perPage);
            $data['list'] = $list
                ->skip(($page - 1) * $perPage)
                ->take($perPage)
                ->orderBy('id', 'desc')
                ->get();

            $fileName = '';
            if ($export == 1) {
                $data['list'] = $list->get();

                $spreadSheet = new Spreadsheet();
                $sheet = $spreadSheet->getActiveSheet();
                $sheet->setTitle('Merchant List');
                $sheet->setCellValue('A1', 'Merchant Id');
                $sheet->setCellValue('B1', 'Name');
                $sheet->setCellValue('C1', 'Phone no');
                $sheet->setCellValue('D1', 'Email Id');
                $row = 2;
                if (isset($data['list']) && !empty($data['list'])) {
                    foreach ($data['list'] as $key => $val) {
                        $sheet->setCellValue('A' . $row, $val['merchant_id']);
                        $sheet->setCellValue('B' . $row, $val['customer_name']);
                        $sheet->setCellValue('C' . $row, $val['customer_phone_no']);
                        $sheet->setCellValue('D' . $row, $val['customer_email']);
                        $row++;
                    }
                    $fileName = 'merchant-list' . date('Ymd') . '.xlsx';
                    $filePath = storage_path('app/public/' . $fileName);
                    $writer = new Xlsx($spreadSheet);
                    $writer->save($filePath);
                }
            }
            $this->response['status'] = 1;
            $this->response['msg'] = 'Transaction list for Admin';
            $this->response['data'] = $data;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at TransactionController@index: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }

    function getTransaction(Request $request)
    {
        try {
            $user = $request->user();
            $transactionId = $request->get('transaction_id') ?? '';
            $transaction = Transaction::where('merchant_id', $user->id)->with(['transactionable'])->find($transactionId);
            if (!$transaction) {
                $this->response['error'] = 'Transaction not found';
                return response()->json($this->response,);
            }
            $this->response['status'] = 1;
            $this->response['msg'] = 'Transaction details';
            $this->response['data'] = $transaction;
            return response()->json($this->response);
        } catch (ValidationException $e) {
            $this->response['error_array'] = formatErrors($e->errors());
            return response()->json($this->response, 200);
        } catch (Exception $e) {
            Log::error('Exception at TransactionController@getTransaction: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }
}
