<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\MerchantApiDoc;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class CommonController extends Controller
{
    function getMerchantApiDocs(Request $request)
    {
        try {
            $apiDocs = MerchantApiDoc::find(1);

            $this->response['status'] = 1;
            $this->response['msg'] = 'Merchant API Docs';
            $this->response['data'] = $apiDocs;
            return response()->json($this->response);
        } catch (Exception $e) {
            Log::error('Exception at CommonController@getMerchantApiDocs: ' . $e->getMessage());
            $this->response['error'] = 'Server error';
            return response()->json($this->response, 500);
        }
    }
}
