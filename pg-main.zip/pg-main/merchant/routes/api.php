<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CommonController;
use App\Http\Controllers\Api\ProfileController;
use App\Http\Controllers\Api\TransactionController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\HomeController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::post('login', [AuthController::class, 'login'])->name('login');

Route::middleware(['auth:api'])->group(function () {

    Route::prefix('dashboard')->group(function () {
        Route::get('/transaction-filter', [HomeController::class, 'transactionFilter'])->name('transaction-filter');
        Route::get('/transaction-list', [HomeController::class, 'transactionList'])->name('transaction-list');

        Route::get('/transaction_data', [HomeController::class, 'transactionData']);
        Route::get('/transaction_insights', [HomeController::class, 'transactionInsights']);
    });
    Route::get('logout', [AuthController::class, 'logout'])->name('logout');
    Route::prefix('profile')->group(function () {
        Route::get('/get_profile', [ProfileController::class, 'index'])->name('profile.get');
        Route::post('/update_profile', [ProfileController::class, 'updateProfile'])->name('profile.update');
        Route::post('/update_password', [ProfileController::class, 'updatePassword'])->name('password.update');
    });
    Route::prefix('transaction')->group(function () {
        Route::get('/', [TransactionController::class, 'index'])->name('transaction.list');
        Route::get('/get_transaction', [TransactionController::class, 'getTransaction'])->name('transaction.get');
    });
    Route::prefix('common')->group(function () {
        Route::get('/merchant_api_docs', [CommonController::class, 'getMerchantApiDocs'])->name('common.merchant_api_docs');
    });
});
