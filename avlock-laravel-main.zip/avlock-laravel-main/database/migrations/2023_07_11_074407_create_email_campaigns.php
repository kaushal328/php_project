<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void {
      Schema::create('email_campaigns', function (Blueprint $table) {
        $table->integer('id')->autoIncrement();
        $table->string('campaign_id');
        $table->string('title')->nullable();
        $table->dateTime('start_date')->nullable();
        $table->dateTime('end_date')->nullable();
        $table->decimal('budget', 18, 3)->default(0.000);
        $table->bigInteger('total_email_sent')->nullable();
        $table->bigInteger('total_email_delivered')->nullable();
        $table->bigInteger('total_email_opened')->nullable();
        $table->bigInteger('total_email_clicked')->nullable();
        $table->bigInteger('total_email_bounced')->nullable();
        $table->bigInteger('total_email_failed')->nullable();
        $table->dateTime('report_date')->nullable();
        $table->tinyInteger('status')->default(1);
        $table->integer('created_by')->default(0);
        $table->integer('updated_by')->default(0);
        $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
        $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
        $table->softDeletes();
        $table->index('campaign_id');
      });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('email_campaigns');
    }
};
