<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('exhibitions', function (Blueprint $table) {
      $table->integer('id')->autoIncrement();
      $table->string('title')->nullable();
      $table->text('description')->nullable();
      $table->text('images')->nullable();
      $table->string('city')->nullable();
      $table->integer('country_id')->default(0)->comment("Primary id of countries table");
      $table->string('contact_number')->nullable();
      $table->string('contact_email')->nullable();
      $table->string('venue')->nullable();
      $table->string('exhibition_status')->nullable()->comment("Approved / Pending / Cancelled");
      $table->dateTime('start_date')->nullable();
      $table->dateTime('end_date')->nullable();
      $table->tinyInteger('status')->default(1);
      $table->integer('created_by')->default(0);
      $table->integer('updated_by')->default(0);
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
      $table->softDeletes();
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('exhibitions');
  }
};
