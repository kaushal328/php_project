<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    // Add lat and long to the 'activity_logs' table
    if (!Schema::hasColumns('activity_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('activity_logs', function (Blueprint $table) {
        $table->string('latitude')->nullable()->after('ip');
        $table->string('longitude')->nullable()->after('latitude');
        $table->string('platform')->nullable()->default('web')->after('longitude');
      });
    }

    // Add lat and long to the 'login_logs' table
    if (!Schema::hasColumns('login_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('login_logs', function (Blueprint $table) {
        $table->string('latitude')->nullable()->after('ip_address');
        $table->string('longitude')->nullable()->after('latitude');
        $table->string('platform')->nullable()->default('web')->after('longitude');
      });
    }

    // Add lat and long to the 'rfq_logs' table
    if (!Schema::hasColumns('rfq_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('rfq_logs', function (Blueprint $table) {
        $table->string('latitude')->nullable()->after('ip');
        $table->string('longitude')->nullable()->after('latitude');
        $table->string('platform')->nullable()->default('web')->after('longitude');
      });
    }

    // Add lat and long to the 'rfq_response_logs' table
    if (!Schema::hasColumns('rfq_response_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('rfq_response_logs', function (Blueprint $table) {
        $table->string('latitude')->nullable()->after('ip');
        $table->string('longitude')->nullable()->after('latitude');
        $table->string('platform')->nullable()->default('web')->after('longitude');
      });
    }

    // Add lat and long to the 'sales_visit_report_logs' table
    if (!Schema::hasColumns('sales_visit_report_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('sales_visit_report_logs', function (Blueprint $table) {
        $table->string('latitude')->nullable()->after('ip');
        $table->string('longitude')->nullable()->after('latitude');
        $table->string('platform')->nullable()->default('web')->after('longitude');
      });
    }

    // Add lat and long to the 'task_logs' table
    if (!Schema::hasColumns('task_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('task_logs', function (Blueprint $table) {
        $table->string('latitude')->nullable()->after('ip');
        $table->string('longitude')->nullable()->after('latitude');
        $table->string('platform')->nullable()->default('web')->after('longitude');
      });
    }
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    if (Schema::hasColumns('activity_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('activity_logs', function (Blueprint $table) {
        $table->dropColumn(['latitude', 'longitude', 'platform']);
      });
    }

    if (Schema::hasColumns('login_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('login_logs', function (Blueprint $table) {
        $table->dropColumn(['latitude', 'longitude', 'platform']);
      });
    }

    if (Schema::hasColumns('rfq_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('rfq_logs', function (Blueprint $table) {
        $table->dropColumn(['latitude', 'longitude', 'platform']);
      });
    }

    if (Schema::hasColumns('rfq_response_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('rfq_response_logs', function (Blueprint $table) {
        $table->dropColumn(['latitude', 'longitude', 'platform']);
      });
    }

    if (Schema::hasColumns('sales_visit_report_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('sales_visit_report_logs', function (Blueprint $table) {
        $table->dropColumn(['latitude', 'longitude', 'platform']);
      });
    }

    if (Schema::hasColumns('task_logs', ['latitude', 'longitude', 'platform'])) {
      Schema::table('task_logs', function (Blueprint $table) {
        $table->dropColumn(['latitude', 'longitude', 'platform']);
      });
    }
  }
};
