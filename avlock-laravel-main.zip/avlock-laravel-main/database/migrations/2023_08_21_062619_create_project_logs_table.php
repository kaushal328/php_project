<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('project_logs', function (Blueprint $table) {
      $table->integer('id')->autoIncrement();
      $table->integer('fk_rfq_id')->default(0);
      $table->integer('lead_id')->default(0);
      $table->integer('curr_stage_id')->default(0);
      $table->integer('curr_sub_stage_id')->default(0);
      $table->text('curr_user')->nullable();
      $table->text('curr_user_ids')->nullable();
      $table->text('attachments')->nullable();
      $table->text('comments')->nullable();
      $table->tinyInteger('status')->default(1);
      $table->string('ip')->nullable();
      $table->string('latitude')->nullable();
      $table->string('longitude')->nullable();
      $table->string('platform')->nullable()->default('web');
      $table->string('action')->nullable();
      $table->string('action_from')->nullable();
      $table->integer('created_by')->default(0);
      $table->integer('updated_by')->default(0);
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('project_logs');
  }
};
