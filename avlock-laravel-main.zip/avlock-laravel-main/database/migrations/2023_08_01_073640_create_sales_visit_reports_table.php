<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('sales_visit_reports', function (Blueprint $table) {
      $table->integer('id')->autoIncrement();
      $table->integer('sales_person')->default(0)->comment('primary id of users table having role sales');
      $table->string('report_no')->nullable();
      $table->string('customer_name')->nullable();
      $table->dateTime('visit_date')->nullable();
      $table->string('location')->nullable();
      $table->string('reason_for_visit')->nullable();
      $table->text('application_details')->nullable();
      $table->string('annual_volume')->nullable();
      $table->string('product_of_interest')->nullable();
      $table->text('specification')->nullable();
      $table->string('installation_method')->nullable();
      $table->string('price')->nullable();
      $table->string('sop_and_lifetime')->nullable();
      $table->text('industry_type')->nullable();
      $table->string('customer_benefit')->nullable();
      $table->text('customer_representatives')->nullable();
      $table->tinyInteger('status')->default(1);
      $table->integer('created_by')->default(0);
      $table->integer('updated_by')->default(0);
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
      $table->softDeletes();
      $table->index('created_by');
      $table->index('updated_by');
      $table->index('sales_person');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('sales_visit_reports');
  }
};
