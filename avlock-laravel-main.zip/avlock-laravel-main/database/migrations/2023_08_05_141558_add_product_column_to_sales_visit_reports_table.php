<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::table('sales_visit_reports', function (Blueprint $table) {
      $table->integer('fk_product_id')->default(0)->comment('primary id of products table')->after('product_of_interest');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::table('sales_visit_reports', function (Blueprint $table) {
      $table->dropColumn(['fk_product_id']);
    });
  }
};
