<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {

    Schema::table('users', function (Blueprint $table) {
      $table->string('employee_id', 255)->nullable()->after('id');
      $table->string('p', 255)->nullable()->after('password');
      $table->string('mobile', 255)->nullable()->after('email');
      $table->string('image', 255)->nullable()->after('mobile');
      $table->integer('fk_designation_id')->default(0)->after('image');
      $table->text('permissions')->nullable()->after('fk_designation_id');
      $table->tinyInteger('status')->default(1)->after('permissions');

      $table->index('fk_designation_id');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::table('users', function (Blueprint $table) {
      $table->dropColumn('employee_id');
      $table->dropColumn('p');
      $table->dropColumn('mobile');
      $table->dropColumn('image');
      $table->dropColumn('fk_designation_id');
      $table->dropColumn('permissions');
      $table->dropColumn('status');
    });
  }
};
