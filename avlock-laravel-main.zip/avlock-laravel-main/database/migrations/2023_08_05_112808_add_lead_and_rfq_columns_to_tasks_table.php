<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::table('tasks', function (Blueprint $table) {
      $table->integer('fk_lead_id')->default(0)->comment('primary id of leads table')->after('fk_task_type_id');
      $table->integer('fk_rfq_id')->default(0)->comment('primary id of rfqs table')->after('fk_lead_id');
      $table->index('fk_lead_id');
      $table->index('fk_rfq_id');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::table('tasks', function (Blueprint $table) {
      $table->dropColumn(['fk_lead_id', 'fk_rfq_id']);
    });
  }
};
