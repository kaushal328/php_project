<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::table('tasks', function (Blueprint $table) {
      $table->integer('fk_task_type_id')->default(0)->after('title')->comment('primary id of task_types table');
      $table->integer('fk_user_id')->default(0)->after('fk_status_id')->comment('primary id of users table');
      $table->dateTime('start')->nullable()->after('description');
      $table->dateTime('end')->nullable()->after('start');
      $table->integer('created_by')->default(0)->after('attachment');
      $table->integer('updated_by')->default(0)->after('created_by');
      $table->tinyInteger('allDay')->default(1)->after('fk_user_id');
      $table->index('fk_task_type_id');
      $table->index('fk_user_id');
      $table->index('created_by');
      $table->index('updated_by');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::table('tasks', function (Blueprint $table) {
      $table->dropColumn('fk_task_type_id');
      $table->dropColumn('fk_user_id');
      $table->dropColumn('created_by');
      $table->dropColumn('updated_by');
      $table->dropColumn('allDay');
    });
  }
};
