<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('user_roles', function (Blueprint $table) {
      $table->increments('id');
      $table->unsignedBigInteger('fk_user_id');
      $table->foreign('fk_user_id')->references('id')->on('users')->onDelete('cascade')->onUpdate('cascade');

      $table->integer('fk_department_id')->unsigned();
      $table->foreign('fk_department_id')->references('id')->on('departments')->onDelete('cascade')->onUpdate('cascade');

      $table->integer('fk_department_type_id')->unsigned();
      $table->foreign('fk_department_type_id')->references('id')->on('department_types')->onDelete('cascade')->onUpdate('cascade');

      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));

      $table->index('fk_user_id');
      $table->index('fk_department_id');
      $table->index('fk_department_type_id');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('user_roles');
  }
};
