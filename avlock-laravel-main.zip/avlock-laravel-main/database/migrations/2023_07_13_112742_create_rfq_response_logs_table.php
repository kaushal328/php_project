<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('rfq_response_logs', function (Blueprint $table) {
      $table->increments('id')->unsigned();
      $table->integer('rfq_id')->default(0);
      $table->text('response')->nullable();
      $table->text('industries')->nullable();
      $table->text('other_industries')->nullable();
      $table->string('ip')->nullable();
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('rfq_response_logs');
  }
};
