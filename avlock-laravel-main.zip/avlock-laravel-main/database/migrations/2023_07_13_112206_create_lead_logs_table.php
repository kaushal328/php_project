<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('lead_logs', function (Blueprint $table) {
      $table->increments('id')->unsigned();
      $table->integer('fk_region_id')->default(0)->comment("primary id of regions table");
      $table->string('customer_name', 255)->nullable();
      $table->string('company', 255)->nullable();
      $table->string('designation', 255)->nullable();
      $table->string('email', 255)->nullable();
      $table->string('contact_no', 255)->nullable();
      $table->integer('fk_source_id')->default(0)->comment("primary id of sources table");
      $table->string('smo_platform', 255)->nullable()->comment("Facebook / Instagram / LinkedIn");
      $table->string('adwords_platform', 255)->nullable()->comment("Google");
      $table->integer('fk_rsmr_id')->default(0)->comment("primary id of portal_user table");
      $table->integer('fk_rsmv_id')->default(0)->comment("primary id of portal_user table");
      $table->string('reference', 255)->nullable();
      $table->integer('fk_client_id')->default(0);
      $table->dateTime('enquiry_date')->nullable();
      $table->text('address1')->nullable();
      $table->text('address2')->nullable();
      $table->string('city', 255)->nullable();
      $table->string('pincode', 255)->nullable();
      $table->string('state', 255)->nullable();
      $table->integer('fk_designation_id')->default(0);
      $table->string('application', 255)->nullable();
      $table->text('description')->nullable();
      $table->string('enquiry_status', 255)->nullable();
      $table->integer('assigned_rsm')->default(0);
      $table->tinyInteger('status')->default(1);
      $table->integer('created_by')->default(0);
      $table->integer('updated_by')->default(0);
      $table->softDeletes();
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('lead_logs');
  }
};
