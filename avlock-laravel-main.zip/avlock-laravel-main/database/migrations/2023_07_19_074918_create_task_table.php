<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void {
      Schema::create('tasks', function (Blueprint $table) {
        $table->integer('id')->autoIncrement();
        $table->string('title');
        $table->text('description')->nullable();
        $table->unsignedInteger('fk_status_id')->default(0)->comment('primary id of statuses table');
        $table->text('attachment')->nullable();
        $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
        $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
        $table->softDeletes();

        $table->index('fk_status_id');
      });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::dropIfExists('tasks');
    }
};
