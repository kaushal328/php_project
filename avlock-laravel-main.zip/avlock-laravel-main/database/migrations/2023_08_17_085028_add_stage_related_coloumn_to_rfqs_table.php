<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    // Add lat and long to the 'rfq' table
    if (!Schema::hasColumns('rfqs', ['curr_stage_id', 'curr_sub_stage_id', 'curr_user', 'curr_user_ids'])) {
      Schema::table('rfqs', function (Blueprint $table) {
        $table->integer('curr_stage_id')->default(0)->after('assigned_rsm_name');
        $table->integer('curr_sub_stage_id')->default(0)->after('curr_stage_id');
        $table->text('curr_user')->nullable()->after('curr_sub_stage_id');
        $table->text('curr_user_ids')->nullable()->after('curr_user');
      });
    }

    // Add lat and long to the 'rfq_logs' table
    if (!Schema::hasColumns('rfq_logs', ['curr_stage_id', 'curr_sub_stage_id', 'curr_user', 'curr_user_ids', 'action_from'])) {
      Schema::table('rfq_logs', function (Blueprint $table) {
        $table->integer('curr_stage_id')->default(0)->after('assigned_rsm_name');
        $table->integer('curr_sub_stage_id')->default(0)->after('curr_stage_id');
        $table->text('curr_user')->nullable()->after('curr_sub_stage_id');
        $table->text('curr_user_ids')->nullable()->after('curr_user');
        $table->string('action_from')->nullable()->after('action');
      });
    }
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    if (Schema::hasColumns('rfqs', ['curr_stage_id', 'curr_sub_stage_id', 'curr_user', 'curr_user_ids'])) {
      Schema::table('rfqs', function (Blueprint $table) {
        $table->dropColumn(['curr_stage_id', 'curr_sub_stage_id', 'curr_user', 'curr_user_ids']);
      });
    }

    if (Schema::hasColumns('rfq_logs', ['curr_stage_id', 'curr_sub_stage_id', 'curr_user', 'curr_user_ids', 'action_from'])) {
      Schema::table('rfq_logs', function (Blueprint $table) {
        $table->dropColumn(['curr_stage_id', 'curr_sub_stage_id', 'curr_user', 'curr_user_ids', 'action_from']);
      });
    }
  }
};
