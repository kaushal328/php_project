<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('bookpost_data', function (Blueprint $table) {
      $table->integer('id')->autoIncrement();
      $table->integer('fk_bookpost_campaign_id')->comment('primary id of bookpost_campaign table');
      $table->string('designation')->nullable();
      $table->string('country')->nullable();
      $table->string('pincode')->nullable();
      $table->string('name');
      $table->text('address')->nullable();
      $table->string('city');
      $table->string('email');
      $table->string('mobile');
      $table->tinyInteger('status')->default(1);
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
      $table->softDeletes();
      $table->index('fk_bookpost_campaign_id');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('bookpost_data');
  }
};
