<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('rfqs', function (Blueprint $table) {
      $table->integer('id')->autoIncrement();
      $table->integer('lead_id')->default(0);
      $table->integer('rsm_id')->default(0);
      $table->string('rsm_name')->nullable();
      $table->string('rfq_number');
      $table->integer('banner_id')->default(0);
      $table->string('customer_name')->nullable();
      $table->string('contact_no')->nullable();
      $table->string('email')->nullable();
      $table->integer('designation_id')->default(0);
      $table->text('address1')->nullable();
      $table->text('address2')->nullable();
      $table->string('city')->nullable();
      $table->string('state')->nullable();
      $table->string('pincode')->nullable();
      $table->text('industry')->nullable();
      $table->integer('industry_id')->default(0);
      $table->string('industry_name')->nullable();
      $table->integer('product_id')->default(0);
      $table->string('product_images')->nullable();
      $table->integer('product_field_count')->default(0);
      $table->tinyInteger('status')->default(1);
      $table->integer('created_by')->default(0);
      $table->integer('updated_by')->default(0);
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
      $table->softDeletes();
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('rfqs');
  }
};
