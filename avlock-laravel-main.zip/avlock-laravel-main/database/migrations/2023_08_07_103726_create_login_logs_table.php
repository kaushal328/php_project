<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('login_logs', function (Blueprint $table) {
      $table->integer('id')->autoIncrement();
      $table->integer('user_id')->default(0);
      $table->string('email', 255)->nullable();
      $table->string('password', 255)->nullable();
      $table->string('ip_address', 255)->nullable();
      $table->boolean('success')->default(false);
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
      $table->index('user_id');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('login_logs');
  }
};
