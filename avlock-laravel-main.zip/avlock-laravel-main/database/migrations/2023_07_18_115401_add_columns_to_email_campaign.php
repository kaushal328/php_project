<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void {
      Schema::table('email_campaigns', function (Blueprint $table) {
        $table->bigInteger('total_data')->after('report_date')->nullable();
        $table->bigInteger('delivered')->after('total_data')->nullable();
        $table->float('delivery_rate', 10, 2)->after('delivered')->default(0);
        $table->bigInteger('opens')->after('delivery_rate')->nullable();
        $table->float('open_rate', 10, 2)->after('opens')->default(0);
        $table->bigInteger('enquire_now')->comment('Whatsapp link')->after('open_rate')->nullable();
        $table->bigInteger('facebook')->after('enquire_now')->nullable();
        $table->bigInteger('twitter')->after('facebook')->nullable();
        $table->bigInteger('instagram')->after('twitter')->nullable();
        $table->bigInteger('linkedin')->after('instagram')->nullable();
        $table->bigInteger('pinterest')->after('linkedin')->nullable();
        $table->bigInteger('website')->after('pinterest')->nullable();
        $table->bigInteger('total_clicks')->after('website')->nullable();
        $table->bigInteger('clicks')->after('total_clicks')->nullable();
        $table->float('click_to_open_rate', 10, 2)->after('clicks')->default(0);
        $table->bigInteger('unsubscribe')->after('click_to_open_rate')->nullable();
        $table->float('unsubscribe_rate', 10, 2)->after('unsubscribe')->default(0);
        $table->bigInteger('bounce')->after('unsubscribe_rate')->nullable();
        $table->float('bounce_rate')->after('bounce')->default(0);
      });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {
        Schema::table('email_campaigns', function (Blueprint $table) {
          $table->dropColumn('total_data');
          $table->dropColumn('delivered');
          $table->dropColumn('delivery_rate');
          $table->dropColumn('opens');
          $table->dropColumn('open_rate');
          $table->dropColumn('enquire_now');
          $table->dropColumn('facebook');
          $table->dropColumn('twitter');
          $table->dropColumn('instagram');
          $table->dropColumn('linkedin');
          $table->dropColumn('pinterest');
          $table->dropColumn('website');
          $table->dropColumn('total_clicks');
          $table->dropColumn('clicks');
          $table->dropColumn('click_to_open_rate');
          $table->dropColumn('unsubscribe');
          $table->dropColumn('unsubscribe_rate');
          $table->dropColumn('bounce');
          $table->dropColumn('bounce_rate');
        });
    }
};