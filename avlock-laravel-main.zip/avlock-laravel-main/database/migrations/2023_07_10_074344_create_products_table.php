<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('products', function (Blueprint $table) {
      $table->increments('id')->unsigned();
      $table->integer('vendor_id')->unsigned()->nullable();
      $table->integer('product_category_id')->unsigned()->nullable();
      $table->string('product_name', 255)->nullable();
      $table->text('slug')->nullable();
      $table->string('video_link', 255)->nullable();
      $table->text('short_description')->nullable();
      $table->text('long_description')->nullable();
      $table->text('keyfeatures')->nullable();
      $table->text('seo_title')->nullable();
      $table->text('seo_keywords')->nullable();
      $table->text('seo_description')->nullable();
      $table->string('image', 255)->nullable();
      $table->string('image_alt_text', 255)->nullable();
      $table->text('all_images')->nullable();
      $table->text('all_catalogues')->nullable();
      $table->integer('home_category_id')->unsigned()->default(0);
      $table->text('key_data')->nullable();
      $table->text('all_desc')->nullable();
      $table->integer('filter_group_id')->unsigned()->nullable();
      $table->integer('product_field_count')->unsigned()->default(5);
      $table->tinyInteger('status')->default(1);
      $table->softDeletes();
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('products');
  }
};
