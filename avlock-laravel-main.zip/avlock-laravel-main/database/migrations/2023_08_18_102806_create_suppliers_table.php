<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
  /**
   * Run the migrations.
   */
  public function up(): void {
      Schema::create('suppliers', function (Blueprint $table) {
        $table->integer('id')->autoIncrement();
        $table->dateTime('assessment_date');
        $table->string('organization_name');
        $table->text('office_address')->nullable();
        $table->text('factory_address')->nullable();
        $table->text('assessment_team_details')->nullable();
        $table->text('supplier_category')->nullable();
        $table->string('constitution')->nullable();
        $table->string('business_nature')->nullable();
        $table->text('director_contact')->nullable();
        $table->text('technical_contact')->nullable();
        $table->text('commercial_contact')->nullable();
        $table->text('qa_contact')->nullable();
        $table->string('landline')->nullable();
        $table->string('establishment_year')->nullable();
        $table->string('experience_year')->nullable();
        $table->text('weekly_holiday')->nullable();
        $table->time('working_hours_start')->nullable();
        $table->time('working_hours_end')->nullable();
        $table->string('nearest_railway_station')->nullable();
        $table->string('nearest_post_office')->nullable();
        $table->string('nearest_airport')->nullable();
        $table->string('plant_located_in_own_land')->nullable();
        $table->text('plant_located_in_own_land_comment')->nullable();
        $table->text('if_own_land')->nullable();
        $table->text('if_own_land_comment')->nullable();
        $table->string('open_area_sqr_mtr')->nullable();
        $table->string('covered_area_sqr_mtr')->nullable();
        $table->string('electric_power_available')->nullable();
        $table->string('electric_power_capacity')->nullable();
        $table->string('generator_available')->nullable();
        $table->string('generator_capacity')->nullable();
        $table->string('sufficient_generator_capacity')->nullable();
        $table->text('connected_generator_equipment')->nullable();
        $table->text('not_connected_generator_equipment')->nullable();
        $table->text('operations_carriedout')->nullable();
        $table->string('full_inhouse_facility_item')->nullable();
        $table->text('full_inhouse_facility_item_comment')->nullable();
        $table->string('technology_indigenous')->nullable();
        $table->text('technology_indigenous_comment')->nullable();
        $table->string('technology_adopted')->nullable();
        $table->text('technology_adopted_comment')->nullable();
        $table->string('technical_colaboration')->nullable();
        $table->text('technical_colaboration_comment')->nullable();
        $table->string('joint_venture')->nullable();
        $table->text('joint_venture_comment')->nullable();
        $table->string('no_of_employees')->nullable();
        $table->string('no_of_employees_company_role')->nullable();
        $table->string('no_of_contract_labour')->nullable();
        $table->text('no_of_skilled_employees')->nullable();
        $table->text('no_of_unskilled_employees')->nullable();
        $table->string('environment')->nullable();
        $table->text('environment_comment')->nullable();
        $table->string('safety')->nullable();
        $table->text('safety_comment')->nullable();
        $table->string('factory_license')->nullable();
        $table->text('factory_license_comment')->nullable();
        $table->string('pollution_control_board')->nullable();
        $table->text('pollution_control_board_comment')->nullable();
        $table->string('weight_and_measure')->nullable();
        $table->text('weight_and_measure_comment')->nullable();
        $table->string('ecc_no')->nullable();
        $table->string('range')->nullable();
        $table->string('division')->nullable();
        $table->string('collectorate')->nullable();
        $table->string('cst_no')->nullable();
        $table->string('tin_no')->nullable();
        $table->string('pan_no')->nullable();
        $table->string('vat_reg_no')->nullable();
        $table->string('service_tax_no')->nullable();
        $table->string('plant_layout_attached')->nullable();
        $table->string('plant_layout_certified')->nullable();
        $table->text('problem_solving_technique')->nullable();
        $table->text('major_customer_business_share')->nullable();
        $table->string('order_in_hand')->nullable()->comment('In lakhs');
        $table->string('last_year_revenue')->nullable()->comment('In lakhs');
        $table->string('second_last_year_revenue')->nullable()->comment('In lakhs');
        $table->string('expansion_plan_attachment')->nullable();
        $table->text('expansion_plan_attachment_doc')->nullable();
        $table->string('pending_litigation_against_vendor')->nullable();
        $table->text('pending_litigation_against_vendor_comment')->nullable();
        $table->text('above_question_yes')->nullable();
        $table->text('scrap_disposal_system')->nullable();
        $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
        $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
        $table->softDeletes();
      });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void {
      Schema::dropIfExists('suppliers');
  }
};
