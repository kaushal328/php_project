<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('product_categories', function (Blueprint $table) {
      $table->increments('id')->unsigned();
      $table->integer('parent_id')->unsigned()->default(0);
      $table->text('child_id')->nullable();
      $table->string('category_name', 255)->nullable();
      $table->text('slug')->nullable();
      $table->integer('route_id')->unsigned()->nullable();
      $table->text('description')->nullable();
      $table->integer('sequence')->unsigned()->nullable();
      $table->string('image', 255)->nullable();
      $table->string('image_thumb', 255)->nullable();
      $table->string('image_alt', 255)->nullable();
      $table->text('seo_title')->nullable();
      $table->text('meta')->nullable();
      $table->text('seo_keyword')->nullable();
      $table->integer('filter_group_id')->unsigned()->default(0);
      $table->tinyInteger('status')->default(1);
      $table->text('filters')->nullable();
      $table->float('tax_per', 8, 2)->default(0);
      $table->tinyInteger('show_at_home')->default(1);
      $table->softDeletes();
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
      $table->index('parent_id');
      $table->index('route_id');
      $table->index('filter_group_id');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('product_categories');
  }
};
