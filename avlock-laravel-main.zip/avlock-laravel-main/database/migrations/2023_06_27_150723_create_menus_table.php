<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('menus', function (Blueprint $table) {
      $table->increments('id')->unsigned();
      $table->integer('parent_id')->unsigned()->default(0);
      $table->string('title', 255);
      $table->string('slug', 255);
      $table->tinyInteger('can_view')->default(0);
      $table->tinyInteger('can_add')->default(0);
      $table->tinyInteger('can_edit')->default(0);
      $table->tinyInteger('can_delete')->default(0);
      $table->tinyInteger('can_import')->default(0);
      $table->tinyInteger('can_export')->default(0);
      $table->tinyInteger('status')->default(1);
      $table->softDeletes();
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
      $table->index('parent_id');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('menus');
  }
};
