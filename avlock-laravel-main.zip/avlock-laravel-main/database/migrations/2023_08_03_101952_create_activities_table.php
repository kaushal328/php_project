<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
  /**
   * Run the migrations.
   */
  public function up(): void
  {
    Schema::create('activities', function (Blueprint $table) {
      $table->integer('id')->autoIncrement();
      $table->string('title');
      $table->text('description')->nullable();
      $table->dateTime('start')->nullable();
      $table->dateTime('end')->nullable();
      $table->integer('fk_task_type_id')->default(0)->comment('primary id of task_types table');
      $table->integer('fk_lead_id')->default(0)->comment('primary id of leads table');
      $table->integer('fk_rfq_id')->default(0)->comment('primary id of rfqs table');
      $table->integer('fk_user_id')->default(0)->comment('primary id of users table');
      $table->text('attachment')->nullable();
      $table->tinyInteger('status')->default(1);
      $table->integer('created_by')->default(0);
      $table->integer('updated_by')->default(0);
      $table->timestamp('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
      $table->timestamp('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));
      $table->softDeletes();
      $table->index('fk_task_type_id');
      $table->index('fk_lead_id');
      $table->index('fk_rfq_id');
      $table->index('fk_user_id');
      $table->index('created_by');
      $table->index('updated_by');
    });
  }

  /**
   * Reverse the migrations.
   */
  public function down(): void
  {
    Schema::dropIfExists('activities');
  }
};
