<?php
/*
    *   Developed by : Maaz - Digi Interface
    *   Created On : 3rd July 2023
*/

namespace App\Utils;

use App\Enums\ErrorType;

class ResponseMessageUtils
{

  public static function sendResponse($result, $code = 200)
  {
    return response()->json($result, $code);
  }
}
