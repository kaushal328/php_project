<?php

namespace App\Imports;

use App\Models\EmailData;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\SkipsFailures;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class EmailDataImport implements ToCollection, SkipsEmptyRows, WithHeadingRow{

  protected $emailCampaignId;
  protected $headerIsValid = true;
  use Importable, SkipsFailures;

  public function __construct($emailCampaignId) {
    $this->emailCampaignId = $emailCampaignId;  
  }

  public function collection(Collection $rows) {
    foreach ($rows as $row) {
      $sheetVals = [
        'name' => $row['name'],
        'address' => $row['address'],
        'city' => $row['city'],
        'email' => $row['email'],
        'mobile' => $row['mobile'],
        'fk_email_campaign_id' => $this->emailCampaignId,
      ];


      // Validate the row data
      $validator = Validator::make($sheetVals, [
        'name' => 'required|string',
        'address' => 'required|string',
        'city' => 'required|string',
        'email' => 'required|email',
        'mobile' => 'required|string',
        'fk_email_campaign_id' => 'required|integer',
      ]);

      EmailData::Create($sheetVals);
    }
  }
}