<?php

namespace App\Imports;

use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use App\Models\SmsData;

class SmsDataImport implements ToModel, WithHeadingRow
{
  protected $fk_sms_campaign_id;
  public function __construct($fk_sms_campaign_id)
  {
    $this->fk_sms_campaign_id = $fk_sms_campaign_id;
  }
  public function model(array $row)
  {
    return new SmsData([
      'name' => $row['name'],
      'address' => $row['address'],
      'city' => $row['city'],
      'email' => $row['email'],
      'mobile' => $row['mobile'],
      'fk_sms_campaign_id' => $this->fk_sms_campaign_id,
    ]);
  }
}
