<?php

namespace App\Providers;

use App\Events\ActivityLogCreated;
use App\Events\PiLogCreated;
use App\Events\CreditLimitLogCreated;
use App\Events\PoLogCreated;
use App\Events\ProjectLogCreated;
use App\Events\ProjectQuotationLogCreated;
use App\Events\ProjectQuotationLogTempCreated;
use App\Events\ProjectSamplingLogCreated;
use App\Events\RfqLogCreated;
use App\Events\RfqProductLogCreated;
use App\Events\SalesVisitReportLogCreated;
use App\Events\TaskLogCreated;
use App\Events\TenderQuotationLogCreated;
use App\Listeners\CreateActivityLogListener;
use App\Listeners\CreatePiLogListener;
use App\Listeners\CreateCreditLimitLogListener;
use App\Listeners\CreatePoLogListener;
use App\Listeners\CreateProjectLogListener;
use App\Listeners\CreateProjectQuotationLogListener;
use App\Listeners\CreateProjectQuotationLogTempListener;
use App\Listeners\CreateProjectSamplingLogListener;
use App\Listeners\CreateRfqLogListener;
use App\Listeners\CreateRfqProductLogListener;
use App\Listeners\CreateSalesVisitReportLogListener;
use App\Listeners\CreateTaskLogListener;
use App\Listeners\CreateTenderQuotationLogListener;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{
  /**
   * The event to listener mappings for the application.
   *
   * @var array<class-string, array<int, class-string>>
   */
  protected $listen = [
    Registered::class => [
      SendEmailVerificationNotification::class,
    ],
    TaskLogCreated::class => [
      CreateTaskLogListener::class,
    ],
    ActivityLogCreated::class => [
      CreateActivityLogListener::class,
    ],
    SalesVisitReportLogCreated::class => [
      CreateSalesVisitReportLogListener::class,
    ],
    RfqLogCreated::class => [
      CreateRfqLogListener::class,
    ],
    ProjectLogCreated::class => [
      CreateProjectLogListener::class,
    ],
    ProjectQuotationLogCreated::class => [
      CreateProjectQuotationLogListener::class,
    ],
    ProjectQuotationLogTempCreated::class => [
      CreateProjectQuotationLogTempListener::class,
    ],
    PoLogCreated::class => [
      CreatePoLogListener::class,
    ],
    PiLogCreated::class => [
      CreatePiLogListener::class,
    ],
    CreditLimitLogCreated::class => [
      CreateCreditLimitLogListener::class,
    ],
    RfqProductLogCreated::class => [
      CreateRfqProductLogListener::class,
    ],
    TenderQuotationLogCreated::class => [
      CreateTenderQuotationLogListener::class,
    ],
    ProjectSamplingLogCreated::class => [
      CreateProjectSamplingLogListener::class,
    ],
  ];

  /**
   * Register any events for your application.
   */
  public function boot(): void
  {
    //
  }

  /**
   * Determine if events and listeners should be automatically discovered.
   */
  public function shouldDiscoverEvents(): bool
  {
    return false;
  }
}
