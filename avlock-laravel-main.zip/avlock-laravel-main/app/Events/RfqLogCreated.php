<?php

namespace App\Events;

use App\Models\Rfq;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class RfqLogCreated
{
  use Dispatchable, InteractsWithSockets, SerializesModels;
  public $rfq;

  /**
   * Create a new event instance.
   */
  public function __construct(Rfq $rfq)
  {
    $this->rfq = $rfq;
  }

  /**
   * Get the channels the event should broadcast on.
   *
   * @return array<int, \Illuminate\Broadcasting\Channel>
   */
  public function broadcastOn(): array
  {
    return [
      new PrivateChannel('channel-name'),
    ];
  }
}
