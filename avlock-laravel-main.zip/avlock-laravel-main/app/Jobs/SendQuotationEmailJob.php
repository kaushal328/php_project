<?php

namespace App\Jobs;

use App\Mail\QuotationEmailMailable;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class SendQuotationEmailJob implements ShouldQueue
{
  use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;


  protected $recipient;
  protected $subject;
  protected $content;
  /**
   * Create a new job instance.
   */
  public function __construct($recipient, $subject, $content)
  {
    $this->recipient = $recipient;
    $this->subject = $subject;
    $this->content = $content;
  }

  /**
   * Execute the job.
   */
  public function handle(): void
  {
    Mail::to($this->recipient)->send(new QuotationEmailMailable($this->subject, $this->content));
  }
}
