<?php

namespace App\Jobs;

use App\Models\ProjectSamplingSubStage;
use App\Models\RFQ;
use App\Models\User;
use App\Models\SubStage;
use Illuminate\Bus\Queueable;
use Illuminate\Support\Facades\Mail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendSamplingChangeStageNotification implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 120;
    protected $ids;
    protected $requestData;

    public function __construct($ids, array $requestData)
    {
        $this->ids = $ids;
        $this->requestData = $requestData;
    }

    /**
     * Execute the job.
     */
    public function handle()
    {

        $ids = $this->ids;
        $requestData = $this->requestData;

        $userForMail = User::whereIn('id', $ids)->get();

        if ($userForMail->isNotEmpty()) {
            $rfq = RFQ::with('lead', 'quotationTemp')->find($requestData['rfq_id']);
            $currSubStage = ProjectSamplingSubStage::find($requestData['sub_stage_id']);
            $emailAddresses = $userForMail->pluck('email')->toArray();

            $emails = [];
            $title = '';

            $user = User::find($rfq->rsm_id)->toArray();
            $divisionHead = getDivisionHead($rfq->division_id, 5);

            switch ($currSubStage->id) {

                case '1': // Sampling Request Forwarded to PSM
                    $psm = getDivisionHead($rfq->division_id, 7, false);
                    $mailUsers = array_merge([$user], $divisionHead, $psm);
                    $title = 'Hi PSM Team,';
                    break;

                case '4': // Sample Couriered / Handovered
                    $insideSales = getDivisionHead($rfq->division_id, 6, false);
                    $mailUsers = array_merge([$user], $divisionHead, $insideSales);
                    $title = 'Hi Inside Sales Team,';
                    break;


                default:
                    $mailUsers = [];
                    $title = 'Hi Team,';
                    break;
            }

            if (!empty($mailUsers)) {
                $emails = array_unique(array_column($mailUsers, 'email'));
            }

            // Generate URL
            $url = 'https://crm.avlock.in/project/samplingform/' . $rfq->lead_id . '/' .  $requestData['rfq_id'] . '?sampling_id=';
            if (!empty($requestData['sampling_id'])) {
                $url .= $requestData['sampling_id'];
            }


            $mailData = [
                'users' => $userForMail,
                'rfq' => $rfq,
                'subject' => $currSubStage->subject ?? '',
                'headingOne' => $currSubStage->mail_content_heading_1 ?? '',
                'headingTwo' => $currSubStage->mail_content_heading_2 ?? '',
                'currSubStage' => $currSubStage,
                'title' => $title,
                'emailAddresses' => $emails,
                // 'ccAddresses' => 'avlockcrm@gmail.com',
                'ccAddresses' => 'shoeb.digiinterface@gmail.com',
                'bccAddresses' => 'rakesh.digiinterface@gmail.com',
                'url' => $url,
            ];


            if ($currSubStage && !empty($currSubStage->name) && !empty($emails) && $currSubStage->send_email == 1) {
                Mail::send('mail_templates.sampling_stage_change', $mailData, function ($mail) use ($mailData) {
                    $mail->from(env('MAIL_FROM_ADDRESS'), 'Avlock CRM');
                    $mail->to('altamash.digiinterface@gmail.com');
                    // $mail->to($mailData['emailAddresses']);
                    $mail->subject($mailData['subject']);

                    // Add CC
                    if (!empty($mailData['ccAddresses'])) {
                        $mail->cc($mailData['ccAddresses']);
                    }

                    // Add BCC
                    if (!empty($mailData['bccAddresses'])) {
                        $mail->bcc($mailData['bccAddresses']);
                    }
                });
            }
        }
    }
}
