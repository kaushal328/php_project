<?php

namespace App\Jobs;

use App\Mail\RfqEmailMailable;
use App\Models\Rfq;
use App\Models\SubStage;
use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class SendRfqEmailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;


    public $timeout = 120;
    protected $rfqId;

    public function __construct(int $rfqId)
    {
        $this->rfqId = $rfqId;
    }

    /**
     * Execute the job.
     */
    public function handle()
    {

        $rfqId = $this->rfqId;

        $rfq = RFQ::with(['lead', 'quotationTemp'])->find($rfqId);
        $user = $rfq->rsm ? $rfq->rsm->toArray() : [];

        $divisionHead = getDivisionHead($rfq->division_id, 5);
        $insideSales = getDivisionHead($rfq->division_id, 6, false);
        $mailUsers = array_merge([$user], $divisionHead, $insideSales);

        if (!empty($mailUsers)) {
            $emails = array_unique(array_column($mailUsers, 'email'));
        }

        $url = 'https://crm.avlock.in/project/list?customer=' . $rfqId;
        // $url = 'http://localhost:3000/login?returnUrl=project/list?customer=' . $rfqId;

        $mailData = [
            'rfq' => $rfq,
            'title' => 'Hi Inside Sales Team,',
            'subject' => 'RFQ Added Successfully - Please Process for Quotation',
            'headingOne' => 'New RFQ Added Successfully',
            'headingTwo' => 'Kindly proceed with processing the quotation at your earliest convenience.',
            'emailAddresses' => $emails,
            'bccAddresses' => 'rakesh.digiinterface@gmail.com',
            'ccAddresses' => 'avlockcrm@gmail.com',
            // 'ccAddresses' => 'shoeb.digiinterface@gmail.com',
            'qtnInEmail' => 0,
            'url' => $url,
            'poNo' => '',
        ];

        if (!empty($emails)) {
            Mail::send('mail_templates.stage_change', $mailData, function ($mail) use ($mailData) {
                $mail->from(env('MAIL_FROM_ADDRESS'), 'Avlock CRM');
                // $mail->to('altamash.digiinterface@gmail.com');
                $mail->to($mailData['emailAddresses']);
                $mail->subject($mailData['subject']);

                // Add CC
                if (!empty($mailData['ccAddresses'])) {
                    $mail->cc($mailData['ccAddresses']);
                }

                // Add BCC
                if (!empty($mailData['bccAddresses'])) {
                    $mail->bcc($mailData['bccAddresses']);
                }
            });
        }
    }
}
