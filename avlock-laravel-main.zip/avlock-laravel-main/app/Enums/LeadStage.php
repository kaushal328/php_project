<?php

namespace App\Enums;

enum LeadStage: int {
  case RAWLEAD = 1;
  case POTENTIALLEAD = 2;
  case PROSPECTLEAD = 3;
  case QUALIFIEDLEAD = 4;
  case LEADFINALIZED = 5;

  public static function getListForHTML(): array {

    $allList = [
      self::RAWLEAD->value,
      self::POTENTIALLEAD->value,
      self::PROSPECTLEAD->value,
      self::QUALIFIEDLEAD->value,
      self::LEADFINALIZED->value,
    ];

    asort($allList);

    return $allList;
  }

  public static function getTextFromValue(string $key): string {
    $list = self::getListForHTMLList();
    return empty($list[$key]) ? '' : $list[$key];
  }
}
