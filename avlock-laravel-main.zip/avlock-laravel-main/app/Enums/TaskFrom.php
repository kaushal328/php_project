<?php

namespace App\Enums;

enum TaskFrom: string {
  case REGULAR = 'regular';
  case MONTHLY_PLAN = 'monthly_plan';

  public static function getListForHTML(): array {

    $allList = [
      ['value' => self::REGULAR->value, 'name' => 'Regular'],
      ['value' => self::MONTHLY_PLAN->value, 'name' => 'Monthly Plan'],
    ];

    asort($allList);

    return $allList;
  }

  public static function getTextFromValue(string $key): string {
    $list = self::getListForHTML();
    return empty($list[$key]) ? '' : $list[$key];
  }
}
