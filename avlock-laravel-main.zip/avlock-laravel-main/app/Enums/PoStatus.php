<?php

namespace App\Enums;

enum PoStatus: string
{
  case ACTIVE = "active";
  case DELIVERY_CONFIRMED = "delivery_confirmed";
  case PO_NOT_MATCH = "po_not_match";

  public static function getListForHTML(): array
  {

    $allList = [
      self::ACTIVE->value => 'Active',
      self::DELIVERY_CONFIRMED->value => 'Delivery Confirmed',
      self::PO_NOT_MATCH->value => 'Purchase Order Not Match',
    ];

    asort($allList);

    return $allList;
  }

  public static function getTextFromValue(string $key): string
  {
    $list = self::getListForHTML();
    return empty($list[$key]) ? '' : $list[$key];
  }
}
