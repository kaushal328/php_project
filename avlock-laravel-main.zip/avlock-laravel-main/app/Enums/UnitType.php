<?php

namespace App\Enums;

enum UnitType: int {
  
  case DAYS = 1;
  case MONTHS = 2;
  case YEARS = 3;

  public static function getListForHTML(): array {

    $allList = [
      ['id' => self::DAYS->value, 'name' => 'Days'],
      ['id' => self::MONTHS->value, 'name' => 'Months'],
      ['id' => self::YEARS->value, 'name' => 'Years'],
    ];

    asort($allList);

    return $allList;
  }

  public static function getListForHTMLList(): array {

    $allList = [
      self::DAYS->value => 'Advance',
      self::MONTHS->value => 'Months',
      self::YEARS->value => 'Years'
    ];

    asort($allList);

    return $allList;
  }

  public static function getTextFromValue(string $key): string {
    $list = self::getListForHTMLList();
    return empty($list[$key]) ? '' : $list[$key];
  }
}
