<?php

namespace App\Enums;

enum QuotationStatus: string
{
  case INITIATED = "initiated";
  case LAR_ENTERED = "lar_entered";
  case TERMS_FINALISED = "terms_finalised";
  case PREPARED = "prepared";
  case SENT_TO_CLIENT = "sent_to_client";

  public static function getListForHTML(): array
  {

    $allList = [
      self::INITIATED->value => 'Quotation Preparation Initiated',
      self::LAR_ENTERED->value => 'LAR Entered',
      self::TERMS_FINALISED->value => 'Quotation Terms Finalised',
      self::PREPARED->value => 'Quotation Prepared',
      self::SENT_TO_CLIENT->value => 'Quotation Sent to Client',
    ];

    asort($allList);

    return $allList;
  }

  public static function getTextFromValue(string $key): string
  {
    $list = self::getListForHTML();
    return empty($list[$key]) ? '' : $list[$key];
  }
}
