<?php

namespace App\Enums;

enum ValueType: string {
  case SELECT = 'select';
  case TYPE = 'type';


  public static function getListForHTML(): array {

    $allList = [
      ['id' => self::SELECT, 'name' => 'Select'],
      ['id' => self::TYPE, 'name' => 'Type']
    ];

    asort($allList);

    return $allList;
  }

  public static function getTextFromValue(string $key): string
  {
    $list = self::getListForHTML();
    return empty($list[$key]) ? '' : $list[$key];
  }
}
