<?php

namespace App\Enums;

enum ErrorType: string
{
  case ERROR = "error";
  case VALIDATION = "validition";
}
