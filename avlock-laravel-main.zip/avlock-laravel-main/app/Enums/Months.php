<?php

namespace App\Enums;

enum Months: string
{
  case JANUARY = 'january';
  case FEBRUARY = 'february';
  case MARCH = 'march';
  case APRIL = 'april';
  case MAY = 'may';
  case JUNE = 'june';
  case JULY = 'july';
  case AUGUST = 'august';
  case SEPTEMBER = 'september';
  case OCTOBER = 'october';
  case NOVEMBER = 'november';
  case DECEMBER = 'december';


  public static function getListForHTML(): array
  {

    $allList = [
      ['id' => self::JANUARY, 'name' => 'January'],
      ['id' => self::FEBRUARY, 'name' => 'February'],
      ['id' => self::MARCH, 'name' => 'March'],
      ['id' => self::APRIL, 'name' => 'April'],
      ['id' => self::MAY, 'name' => 'May'],
      ['id' => self::JUNE, 'name' => 'June'],
      ['id' => self::JULY, 'name' => 'July'],
      ['id' => self::AUGUST, 'name' => 'August'],
      ['id' => self::SEPTEMBER, 'name' => 'September'],
      ['id' => self::OCTOBER, 'name' => 'October'],
      ['id' => self::NOVEMBER, 'name' => 'November'],
      ['id' => self::DECEMBER, 'name' => 'December'],
    ];

    asort($allList);

    return $allList;
  }

  public static function getTextFromValue(string $key): string
  {
    $list = self::getListForHTML();
    return empty($list[$key]) ? '' : $list[$key];
  }
}
