<?php

namespace App\Enums;

enum ClientType: int
{
  case ADVANCE = 1;
  case CREDIT = 2;

  public static function getListForHTML(): array
  {

    $allList = [
      ['id' => self::ADVANCE->value, 'name' => 'Advance'],
      ['id' => self::CREDIT->value, 'name' => 'Credit'],
    ];

    asort($allList);

    return $allList;
  }

  public static function getListForHTMLList(): array
  {

    $allList = [
      self::ADVANCE->value => 'Advance',
      self::CREDIT->value => 'Credit'
    ];

    asort($allList);

    return $allList;
  }

  public static function getTextFromValue(string $key): string
  {
    $list = self::getListForHTMLList();
    return empty($list[$key]) ? '' : $list[$key];
  }
}
