<?php

namespace App\Enums;

enum Monogram: string {
  case MS = 'ms';
  case MR = 'mr';
  case MRS = 'mrs';


  public static function getListForHTML(): array {

    $allList = [
      ['id' => self::MS, 'name' => 'Ms.'],
      ['id' => self::MR, 'name' => 'Mr'],
      ['id' => self::MRS, 'name' => 'Mrs']
    ];

    asort($allList);

    return $allList;
  }

  public static function getTextFromValue(string $key): string
  {
    $list = self::getListForHTML();
    return empty($list[$key]) ? '' : $list[$key];
  }
}
