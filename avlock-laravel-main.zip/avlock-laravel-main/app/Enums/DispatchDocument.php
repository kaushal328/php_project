<?php

namespace App\Enums;

enum DispatchDocument: string
{
  case PackagingSlip = 'Package Slip';
  case Labeling = 'Labeling';
  case DeliveryNote = 'Delivery Note';

  public static function getListForHTML(): array
  {
    $allList = [
      ['id' => 1, 'name' => 'Sales Order'],
      ['id' => 2, 'name' => 'Packaging/Label'],
      ['id' => 3, 'name' => 'Delivery Note'],
      ['id' => 4, 'name' => 'E-Invoice'],
      ['id' => 5, 'name' => 'E-Way Bill']
    ];

    asort($allList);

    return $allList;
  }

  public static function getTextFromValue(string $key): string
  {
    $list = self::getListForHTML();
    foreach ($list as $item) {
      if ($item['id'] == $key || $item['name'] == $key) {
        return $item['name'];
      }
    }
    return '';
  }
}
