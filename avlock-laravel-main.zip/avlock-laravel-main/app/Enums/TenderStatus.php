<?php

namespace App\Enums;

enum TenderStatus: string
{
    case Won = 'Won';
    case Lost = 'Lost';

    public static function getListForHTML(): array
    {
        $allList = [
            ['id' => 1, 'name' => 'Won'],
            ['id' => 2, 'name' => 'Lost'],
        ];

        asort($allList);

        return $allList;
    }

    public static function getTextFromValue(string $key): string
    {
        $list = self::getListForHTML();
        foreach ($list as $item) {
            if ($item['id'] == $key || $item['name'] == $key) {
                return $item['name'];
            }
        }
        return '';
    }
}
