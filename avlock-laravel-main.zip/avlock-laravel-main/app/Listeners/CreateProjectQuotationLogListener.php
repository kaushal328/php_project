<?php

namespace App\Listeners;

use App\Events\ProjectQuotationLogCreated;
use App\Models\ProjectQuotationLog;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;

class CreateProjectQuotationLogListener
{

  protected $request;

  /**
   * Create the event listener.
   */
  public function __construct(Request $request)
  {
    $this->request = $request;
  }

  /**
   * Handle the event.
   */
  public function handle(ProjectQuotationLogCreated $event): void
  {
    $quotation = $event->quotation;

    $projectQuotationLog = new ProjectQuotationLog();
    $projectQuotationLog->fk_project_quotation_temp_id = $quotation->fk_project_quotation_temp_id;
    $projectQuotationLog->fk_quotation_id = $quotation->id;
    $projectQuotationLog->fk_rfq_id = $quotation->fk_rfq_id;
    $projectQuotationLog->fk_lead_id = $quotation->fk_lead_id;
    $projectQuotationLog->quotation_date = $quotation->quotation_date;
    $projectQuotationLog->quotation_no = $quotation->quotation_no;
    $projectQuotationLog->sales_person = $quotation->sales_person ?? 0;
    $projectQuotationLog->prepared_by = $quotation->prepared_by ?? 0;
    $projectQuotationLog->salutation = $quotation->salutation ?? '';
    $projectQuotationLog->requirements = $quotation->requirements;
    $projectQuotationLog->requirement_total = $quotation->requirement_total;
    $projectQuotationLog->service_detail = $quotation->service_detail;
    $projectQuotationLog->service_total = $quotation->service_total;
    $projectQuotationLog->total_basic_value = $quotation->total_basic_value;
    $projectQuotationLog->quotation_terms = $quotation->quotation_terms;
    $projectQuotationLog->bank_details = $quotation->bank_details;
    $projectQuotationLog->quotation_status = $quotation->quotation_status;
    $projectQuotationLog->special_notes = $quotation->special_notes;

    $projectQuotationLog->is_sent_to_client = $quotation->is_sent_to_client ?? 1;
    $projectQuotationLog->status = $quotation->status ?? 1;
    $projectQuotationLog->ip = $this->request->ip();
    $projectQuotationLog->latitude = $this->request->header('latitude') ?? '';
    $projectQuotationLog->longitude = $this->request->header('longitude') ?? '';
    $projectQuotationLog->platform = $this->request->header('platform') ?? 'web';
    $projectQuotationLog->action = $quotation->action;
    $projectQuotationLog->created_by = $quotation->created_by ?? 0;
    $projectQuotationLog->updated_by = $quotation->updated_by ?? 0;
    $projectQuotationLog->save();
  }
}
