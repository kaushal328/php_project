<?php

namespace App\Listeners;

use App\Events\RfqLogCreated;
use App\Models\RfqLog;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;

class CreateRfqLogListener
{
  protected $request;

  /**
   * Create the event listener.
   */
  public function __construct(Request $request)
  {
    $this->request = $request;
  }

  /**
   * Handle the event.
   */
  public function handle(RfqLogCreated $event): void
  {
    $rfq = $event->rfq;

    $rfqLog = new RfqLog();
    $rfqLog->rfq_date = $rfq->rfq_date;
    $rfqLog->fk_rfq_id = $rfq->id;
    $rfqLog->lead_id = $rfq->lead_id;
    $rfqLog->rsm_id = $rfq->rsm_id;
    $rfqLog->rsm_name = $rfq->rsm_name;
    $rfqLog->rfq_number = $rfq->rfq_number;
    $rfqLog->banner_id = $rfq->banner_id;
    $rfqLog->footer_id = $rfq->footer_id;
    $rfqLog->customer_name = $rfq->customer_name;
    $rfqLog->contact_no = $rfq->contact_no;
    $rfqLog->email = $rfq->email;
    $rfqLog->designation_id = $rfq->designation_id;
    $rfqLog->address1 = $rfq->address1;
    $rfqLog->address2 = $rfq->address2;
    $rfqLog->city = $rfq->city;
    $rfqLog->state = $rfq->state;
    $rfqLog->pincode = $rfq->pincode;
    $rfqLog->industry = $rfq->industry;
    $rfqLog->product_id = $rfq->product_id ?? 0;
    $rfqLog->fk_project_segment_id = $rfq->fk_project_segment_id ?? 0;
    $rfqLog->fk_product_category_id = $rfq->fk_product_category_id ?? 0;
    $rfqLog->fk_project_type_id = $rfq->fk_project_type_id ?? 0;
    $rfqLog->division_id = $rfq->division_id ?? 0;
    $rfqLog->fk_source_id = $rfq->fk_source_id;
    $rfqLog->designation_id = $rfq->designation_id ?? 0;
    $rfqLog->currency = $rfq->currency ?? '';
    $rfqLog->product_images = $rfq->product_images;
    $rfqLog->project_segments = $rfq->project_segments;
    $rfqLog->product_field_count = $rfq->product_field_count;
    $rfqLog->response_industries = $rfq->response_industries;
    $rfqLog->response_other_industries = $rfq->response_other_industries;
    $rfqLog->assigned_rsm = $rfq->assigned_rsm ?? 0;
    $rfqLog->assigned_rsm_name = $rfq->assigned_rsm_name;
    $rfqLog->lead_addresses_id = $rfq->lead_addresses_id;
    $rfqLog->lead_contact_people_id = $rfq->lead_contact_people_id;
    $rfqLog->rfq_remark = $rfq->rfq_remark;
    $rfqLog->curr_stage_id = $rfq->curr_stage_id ?? 0;
    $rfqLog->curr_sub_stage_id = $rfq->curr_sub_stage_id ?? 0;
    $rfqLog->curr_user = $rfq->curr_user;
    $rfqLog->curr_user_ids = $rfq->curr_user_ids;
    $rfqLog->comm_users = $rfq->comm_users;
    $rfqLog->comm_user_ids = $rfq->comm_user_ids;
    $rfqLog->attachments = $rfq->attachments;
    $rfqLog->comments = $rfq->comments;
    $rfqLog->no_of_pieces_required = $rfq->no_of_pieces_required;
    $rfqLog->fk_supplier_id = $rfq->fk_supplier_id ?? 0;
    $rfqLog->rfq_approved_requirements = $rfq->rfq_approved_requirements;
    $rfqLog->fk_po_id = $rfq->fk_po_id ?? 0;
    $rfqLog->status = $rfq->status ?? 1;
    $rfqLog->ip = $this->request->ip();
    $rfqLog->latitude = $this->request->header('x-user-latitude') ?? $this->request->header('latitude') ?? '';
    $rfqLog->longitude = $this->request->header('x-user-longitude') ?? $this->request->header('longitude') ?? '';
    $formattedAddress = getFormattedAddress($rfqLog->latitude, $rfqLog->longitude);
    $rfqLog->formatted_address = $formattedAddress;
    $rfqLog->platform = $this->request->header('platform') ?? 'web';
    $rfqLog->action = $rfq->action;
    $rfqLog->action_from = $rfq->action_from;
    $rfqLog->created_by = $rfq->created_by ?? 0;
    $rfqLog->updated_by = $rfq->updated_by ?? 0;
    $rfqLog->save();
  }
}
