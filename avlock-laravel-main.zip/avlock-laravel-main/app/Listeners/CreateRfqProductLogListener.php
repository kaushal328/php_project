<?php

namespace App\Listeners;

use App\Events\RfqProductLogCreated;
use App\Models\RfqProductLog;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;

class CreateRfqProductLogListener
{

  protected $request;

  /**
   * Create the event listener.
   */
  public function __construct(Request $request)
  {
    $this->request = $request;
  }

  /**
   * Handle the event.
   */
  public function handle(RfqProductLogCreated $event): void
  {
    $rfqProduct = $event->rfqProduct;

    $rfqProductLog = new RfqProductLog();
    $rfqProductLog->rfq_product_id = $rfqProduct->id;
    $rfqProductLog->rfq_id = $rfqProduct->rfq_id;
    $rfqProductLog->product_id = $rfqProduct->product_id;
    $rfqProductLog->product_part_id = $rfqProduct->product_part_id;
    $rfqProductLog->product_qty = $rfqProduct->product_qty;
    $rfqProductLog->response = $rfqProduct->response;
    $rfqProductLog->is_response_received = $rfqProduct->is_response_received ?? 0;
    $rfqProductLog->ip = $this->request->ip();
    $rfqProductLog->latitude = $this->request->header('latitude') ?? '';
    $rfqProductLog->longitude = $this->request->header('longitude') ?? '';
    $rfqProductLog->platform = $this->request->header('platform') ?? 'web';
    $rfqProductLog->action = $rfqProduct->action;
    $rfqProductLog->save();
  }
}
