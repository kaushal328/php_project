<?php

namespace App\Listeners;

use App\Events\ProjectLogCreated;
use App\Models\ProjectLog;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;

class CreateProjectLogListener
{

  protected $request;

  /**
   * Create the event listener.
   */
  public function __construct(Request $request)
  {
    $this->request = $request;
  }

  /**
   * Handle the event.
   */
  public function handle(ProjectLogCreated $event): void
  {
    $rfq = $event->rfq;

    $projectLog = new ProjectLog();
    $projectLog->rfq_date = $rfq->rfq_date;
    $projectLog->fk_rfq_id = $rfq->id;
    $projectLog->lead_id = $rfq->lead_id;
    $projectLog->curr_stage_id = $rfq->curr_stage_id ?? 0;
    $projectLog->curr_sub_stage_id = $rfq->curr_sub_stage_id ?? 0;
    $projectLog->curr_user = $rfq->curr_user;
    $projectLog->curr_user_ids = $rfq->curr_user_ids;
    $projectLog->comm_users = $rfq->comm_users;
    $projectLog->comm_user_ids = $rfq->comm_user_ids;
    $projectLog->attachments = $rfq->attachments;
    $projectLog->comments = $rfq->comments;
    $projectLog->fk_supplier_id = $rfq->fk_supplier_id ?? 0;
    $projectLog->rfq_approved_requirements = $rfq->rfq_approved_requirements;
    $projectLog->fk_po_id = $rfq->fk_po_id ?? 0;
    $projectLog->status = $rfq->status ?? 1;
    $projectLog->ip = $this->request->ip();
    $projectLog->latitude = $this->request->header('latitude') ?? '';
    $projectLog->longitude = $this->request->header('longitude') ?? '';
    $projectLog->platform = $this->request->header('platform') ?? 'web';
    $projectLog->formatted_address = $rfq->formatted_address;
    $projectLog->action = $rfq->action;
    $projectLog->action_from = $rfq->action_from;
    $projectLog->created_by = $rfq->created_by ?? 0;
    $projectLog->updated_by = $rfq->updated_by ?? 0;
    $projectLog->save();
  }
}
