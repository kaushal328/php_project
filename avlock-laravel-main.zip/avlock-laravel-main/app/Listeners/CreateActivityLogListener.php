<?php

namespace App\Listeners;

use App\Events\ActivityLogCreated;
use App\Models\ActivityLog;
use Carbon\Carbon;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Log;

class CreateActivityLogListener
{

  protected $request;

  /**
   * Create the event listener.
   */
  public function __construct(Request $request)
  {
    $this->request = $request;
  }

  /**
   * Handle the event.
   */
  public function handle(ActivityLogCreated $event): void
  {
    $activity = $event->activity;

    $activityLog = new ActivityLog();
    $activityLog->fk_activity_id = $activity->id;
    $activityLog->fk_activity_type_id = $activity->fk_activity_type_id ?? 0;
    $activityLog->comment = $activity->comment;
    $activityLog->is_physical_visit = $activity->is_physical_visit ?? 0;
    $activityLog->start_time = $activity->start_time ?? Carbon::now();
    $activityLog->end_time = $activity->end_time;
    $activityLog->fk_task_type_id = $activity->fk_task_type_id;
    $activityLog->fk_lead_id = $activity->fk_lead_id;
    $activityLog->fk_rfq_id = $activity->fk_rfq_id;
    $activityLog->fk_user_id = $activity->fk_user_id;
    $activityLog->attachment = $activity->attachment;
    $activityLog->fk_svr_id = $activity->fk_svr_id;
    $activityLog->status = $activity->status;
    $activityLog->ip = $this->request->ip();
    $activityLog->latitude = $this->request->header('x-user-latitude') ?? $this->request->header('latitude') ?? '';
    $activityLog->longitude = $this->request->header('x-user-longitude') ?? $this->request->header('longitude') ?? '';
    $formattedAddress = $this->getFormattedAddress($activityLog->latitude, $activityLog->longitude);
    $activityLog->formatted_address = $formattedAddress;
    $activityLog->location = $formattedAddress;
    $activityLog->platform = $this->request->header('platform') ?? 'web';
    $activityLog->action = $activity->action;
    $activityLog->created_by = $activity->created_by ?? 0;
    $activityLog->updated_by = $activity->updated_by ?? 0;
    $activityLog->save();
  }

  private function getFormattedAddress($latitude, $longitude)
  {
    try {
      $client = new Client();

      $response = $client->get('https://maps.googleapis.com/maps/api/geocode/json', [
        'query' => [
          'latlng' => $latitude . ',' . $longitude,
          'key' => 'AIzaSyCGx_Fl0yKDXwvqekOgYiU78Th3MAWzOxE',
        ]
      ]);

      $body = json_decode($response->getBody(), true);

      if ($response->getStatusCode() == 200 && $body['status'] == 'OK') {
        return $body['results'][0]['formatted_address'];
      }
    } catch (\Exception $e) {
      Log::error("Geocoding Error: " . $e->getMessage());
      return null;
    }
  }
}
