<?php

namespace App\Listeners;

use Illuminate\Http\Request;
use App\Models\CreditLimitLog;
use App\Events\CreditLimitLogCreated;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

class CreateCreditLimitLogListener
{

  protected $request;

  /**
   * Create the event listener.
   */
  public function __construct(Request $request)
  {
    $this->request = $request;
  }

  /**
   * Handle the event.
   */
  public function handle(CreditLimitLogCreated $event): void
  {
    $lead = $event->lead;

    $creditLimitLog = new CreditLimitLog();
    $creditLimitLog->lead_id = $lead->id;
    $creditLimitLog->credit_limit = $lead->credit_limit;
    $creditLimitLog->action = $lead->action;
    $creditLimitLog->save();
  }
}
