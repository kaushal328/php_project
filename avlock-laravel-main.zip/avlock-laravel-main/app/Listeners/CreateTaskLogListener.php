<?php

namespace App\Listeners;

use App\Enums\PlanType;
use App\Enums\TaskFrom;
use App\Events\TaskLogCreated;
use App\Models\TaskLog;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;

class CreateTaskLogListener
{
  protected $request;

  /**
   * Create the event listener.
   */
  public function __construct(Request $request)
  {
    $this->request = $request;
  }

  /**
   * Handle the event.
   */
  public function handle(TaskLogCreated $event): void
  {

    $task = $event->task;

    $taskLog = new TaskLog();
    $taskLog->fk_task_id = $task->id;
    $taskLog->title = $task->title;
    $taskLog->fk_task_type_id = $task->fk_task_type_id ?? 3;
    $taskLog->fk_type_task_id = $task->fk_type_task_id ?? 0;
    $taskLog->fk_lead_id = $task->fk_lead_id ?? 0;
    $taskLog->fk_rfq_id = $task->fk_rfq_id ?? 0;
    $taskLog->description = $task->description;
    $taskLog->start = $task->start;
    $taskLog->end = $task->end;
    $taskLog->fk_status_id = $task->fk_status_id;
    $taskLog->fk_user_id = $task->fk_user_id;
    $taskLog->allDay = $task->allDay ?? 1;
    $taskLog->attachment = $task->attachment;
    $taskLog->remark = $task->remark;
    $taskLog->task_user = $task->task_user;
    $taskLog->is_physical_visit = $task->is_physical_visit ?? 0;
    $taskLog->fk_svr_id = $task->fk_svr_id ?? 0;
    $taskLog->monthly_plan_record_id = $task->monthly_plan_record_id ?? 0;
    $taskLog->task_from = $task->task_from ?? TaskFrom::REGULAR;
    $taskLog->ip = $this->request->ip();
    $taskLog->latitude = $this->request->header('x-user-latitude') ?? $this->request->header('latitude') ?? '';
    $taskLog->longitude = $this->request->header('x-user-longitude') ?? $this->request->header('longitude') ?? '';
    $formattedAddress = getFormattedAddress($taskLog->latitude, $taskLog->longitude);
    $taskLog->formatted_address = $formattedAddress;
    $taskLog->platform = $this->request->header('platform') ?? 'web';
    $taskLog->action = $task->action;
    $taskLog->created_by = $task->created_by ?? 0;
    $taskLog->updated_by = $task->updated_by ?? 0;
    $taskLog->save();
  }
}
