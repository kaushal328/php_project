<?php

namespace App\Listeners;

use App\Events\ProjectQuotationLogTempCreated;
use App\Models\ProjectQuotationLogTemp;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;

class CreateProjectQuotationLogTempListener
{
  protected $request;

  /**
   * Create the event listener.
   */
  public function __construct(Request $request)
  {
    $this->request = $request;
  }

  /**
   * Handle the event.
   */
  public function handle(ProjectQuotationLogTempCreated $event): void
  {
    $quotationTemp = $event->quotationTemp;

    $projectQuotationLogTemp = new ProjectQuotationLogTemp();
    $projectQuotationLogTemp->fk_quotation_id = $quotationTemp->id;
    $projectQuotationLogTemp->fk_rfq_id = $quotationTemp->fk_rfq_id;
    $projectQuotationLogTemp->fk_lead_id = $quotationTemp->fk_lead_id;
    $projectQuotationLogTemp->quotation_date = $quotationTemp->quotation_date;
    $projectQuotationLogTemp->quotation_no = $quotationTemp->quotation_no;
    $projectQuotationLogTemp->sales_person = $quotationTemp->sales_person ?? 0;
    $projectQuotationLogTemp->salutation = $quotationTemp->salutation ?? '';
    $projectQuotationLogTemp->prepared_by = $quotationTemp->prepared_by ?? 0;
    $projectQuotationLogTemp->requirements = $quotationTemp->requirements;
    $projectQuotationLogTemp->requirement_total = $quotationTemp->requirement_total;
    $projectQuotationLogTemp->service_detail = $quotationTemp->service_detail;
    $projectQuotationLogTemp->service_total = $quotationTemp->service_total;
    $projectQuotationLogTemp->total_basic_value = $quotationTemp->total_basic_value;
    $projectQuotationLogTemp->final_amount = $quotationTemp->final_amount;
    $projectQuotationLogTemp->igst = $quotationTemp->igst;
    $projectQuotationLogTemp->igst_value = $quotationTemp->igst_value;
    $projectQuotationLogTemp->sgst = $quotationTemp->sgst;
    $projectQuotationLogTemp->sgst_value = $quotationTemp->sgst_value;
    $projectQuotationLogTemp->cgst = $quotationTemp->cgst;
    $projectQuotationLogTemp->cgst_value = $quotationTemp->cgst_value;
    $projectQuotationLogTemp->duration_date = $quotationTemp->duration_date;
    $projectQuotationLogTemp->duration = $quotationTemp->duration;
    $projectQuotationLogTemp->reference = $quotationTemp->reference;
    $projectQuotationLogTemp->set_name = $quotationTemp->set_name;
    $projectQuotationLogTemp->set_value = $quotationTemp->set_value;
    $projectQuotationLogTemp->quotation_terms = $quotationTemp->quotation_terms;
    $projectQuotationLogTemp->terms = $quotationTemp->terms;
    $projectQuotationLogTemp->bank_details = $quotationTemp->bank_details;
    $projectQuotationLogTemp->quotation_status = $quotationTemp->quotation_status;
    $projectQuotationLogTemp->status = $quotationTemp->status ?? 1;
    $projectQuotationLogTemp->special_notes = $quotationTemp->special_notes;
    $projectQuotationLogTemp->is_sent_to_client = $quotationTemp->is_sent_to_client;
    $projectQuotationLogTemp->is_revised = $quotationTemp->is_revised;
    $projectQuotationLogTemp->ip = $this->request->ip();
    $projectQuotationLogTemp->latitude = $this->request->header('latitude') ?? '';
    $projectQuotationLogTemp->longitude = $this->request->header('longitude') ?? '';
    $projectQuotationLogTemp->platform = $this->request->header('platform') ?? 'web';
    $projectQuotationLogTemp->action = $quotationTemp->action;
    $projectQuotationLogTemp->created_by = $quotationTemp->created_by ?? 0;
    $projectQuotationLogTemp->updated_by = $quotationTemp->updated_by ?? 0;
    $projectQuotationLogTemp->save();
  }
}
