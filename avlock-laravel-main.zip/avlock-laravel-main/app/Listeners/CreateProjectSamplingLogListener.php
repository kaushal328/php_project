<?php

namespace App\Listeners;

use App\Events\ProjectSamplingLogCreated;
use App\Models\ProjectSamplingLog;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;

class CreateProjectSamplingLogListener
{
    /**
     * Create the event listener.
     */
    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /**
     * Handle the event.
     */
    public function handle(ProjectSamplingLogCreated $event): void
    {
        $sampling = $event->sampling;

        $samplingLog = new ProjectSamplingLog();
        $samplingLog->fk_sampling_id = $sampling->id;
        $samplingLog->fk_rfq_id = $sampling->fk_rfq_id;
        $samplingLog->lead_id = $sampling->lead_id;
        $samplingLog->main_sub_stage_id = $sampling->main_sub_stage_id ?? 0;
        $samplingLog->sub_stage_id = $sampling->sub_stage_id ?? 0;
        $samplingLog->sub_stage_user_ids = $sampling->sub_stage_user_ids ?? [];
        $samplingLog->sub_stage_attachments = $sampling->sub_stage_attachments ?? [];
        $samplingLog->sub_stage_remark = $sampling->sub_stage_remark;
        $samplingLog->status = $sampling->status ?? 1;
        $samplingLog->fk_supplier_id = $sampling->fk_supplier_id ?? 0;
        $samplingLog->ip = $this->request->ip();
        $samplingLog->latitude = $this->request->header('latitude') ?? '';
        $samplingLog->longitude = $this->request->header('longitude') ?? '';
        $samplingLog->platform = $this->request->header('platform') ?? 'web';
        $samplingLog->action = $sampling->action;
        $samplingLog->action_from = $sampling->action_from;
        $samplingLog->created_by = $sampling->created_by ?? 0;
        $samplingLog->updated_by = $sampling->updated_by ?? 0;
        $samplingLog->save();
    }
}
