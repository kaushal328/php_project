<?php

namespace App\Listeners;

use App\Events\SalesVisitReportLogCreated;
use App\Models\SalesVisitReportLog;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;

class CreateSalesVisitReportLogListener
{
  protected $request;

  /**
   * Create the event listener.
   */
  public function __construct(Request $request)
  {
    $this->request = $request;
  }

  /**
   * Handle the event.
   */
  public function handle(SalesVisitReportLogCreated $event): void
  {
    $svr = $event->svr;

    $svrLog = new SalesVisitReportLog();
    $svrLog->fk_sales_visit_report_id = $svr->id;
    $svrLog->sales_person = $svr->sales_person;
    $svrLog->fk_task_type_id = $svr->fk_task_type_id;
    $svrLog->fk_lead_id = $svr->fk_lead_id;
    $svrLog->fk_rfq_id = $svr->fk_rfq_id;
    $svrLog->report_no = $svr->report_no;
    $svrLog->customer_name = $svr->customer_name;
    $svrLog->visit_date = $svr->visit_date;
    $svrLog->location = $svr->location;
    $svrLog->state_id = $svr->state_id;
    $svrLog->city_id = $svr->city_id;
    $svrLog->reason_for_visit = $svr->reason_for_visit;
    $svrLog->application_details = $svr->application_details;
    $svrLog->svr_remark = $svr->svr_remark;
    $svrLog->annual_volume = $svr->annual_volume;
    $svrLog->product_of_interest = $svr->product_of_interest;
    $svrLog->fk_product_id = $svr->fk_product_id;
    $svrLog->products = $svr->products;
    $svrLog->specification = $svr->specification;
    $svrLog->installation_method = $svr->installation_method;
    $svrLog->price = $svr->price;
    $svrLog->sop_and_lifetime = $svr->sop_and_lifetime;
    $svrLog->industry_type = $svr->industry_type;
    $svrLog->customer_benefit = $svr->customer_benefit;
    $svrLog->customer_representatives = $svr->customer_representatives;
    $svrLog->svr_attachments = $svr->svr_attachments;
    $svrLog->lead_addresses_id = $svr->lead_addresses_id;
    $svrLog->lead_contact_people_id = $svr->lead_contact_people_id;
    $svrLog->status = $svr->status;
    $svrLog->ip = $this->request->ip();
    $svrLog->latitude = $this->request->header('x-user-latitude') ?? $this->request->header('latitude') ?? '';
    $svrLog->longitude = $this->request->header('x-user-longitude') ?? $this->request->header('longitude') ?? '';
    $formattedAddress = getFormattedAddress($svrLog->latitude, $svrLog->longitude);
    $svrLog->formatted_address = $formattedAddress;
    $svrLog->platform = $this->request->header('platform') ?? 'web';
    $svrLog->action = $svr->action;
    $svrLog->created_by = $svr->created_by ?? 0;
    $svrLog->updated_by = $svr->updated_by ?? 0;
    $svrLog->save();
  }
}
