<?php

namespace App\Listeners;

use Illuminate\Http\Request;
use App\Models\TenderQuotation;
use App\Models\TenderQuotationLog;
use Illuminate\Queue\InteractsWithQueue;
use App\Events\TenderQuotationLogCreated;
use Illuminate\Contracts\Queue\ShouldQueue;

class CreateTenderQuotationLogListener {
  /**
   * Create the event listener.
   */

   protected $request;

  public function __construct(Request $request) {
    $this->request = $request;
  }

  /**
   * Handle the event.
   */
  public function handle(TenderQuotationLogCreated $event): void {

    $tenderQuotation = $event->tenderQuotation;

    $tenderQuotationLog = new TenderQuotationLog();
    $tenderQuotationLog->tender_quotation_id = $tenderQuotation->id;
    $tenderQuotationLog->tender_id = $tenderQuotation->tender_id;
    $tenderQuotationLog->quotation_no = $tenderQuotation->quotation_no;
    $tenderQuotationLog->quotation_date = $tenderQuotation->quotation_date;
    $tenderQuotationLog->quotation_remark = $tenderQuotation->quotation_remark;
    $tenderQuotationLog->terms = $tenderQuotation->terms;
    $tenderQuotationLog->user_ids = $tenderQuotation->user_ids ?? [];
    $tenderQuotationLog->users = $tenderQuotation->users ?? [];
    $tenderQuotationLog->ip = $this->request->ip();
    $tenderQuotationLog->latitude = $this->request->header('latitude') ?? '';
    $tenderQuotationLog->longitude = $this->request->header('longitude') ?? '';
    $tenderQuotationLog->platform = $this->request->header('platform') ?? 'web';
    $tenderQuotationLog->action = $tenderQuotation->action;
    $tenderQuotationLog->created_by = $tenderQuotation->created_by ?? 0;
    $tenderQuotationLog->updated_by = $tenderQuotation->updated_by ?? 0;
    $tenderQuotationLog->save();
  }
}
