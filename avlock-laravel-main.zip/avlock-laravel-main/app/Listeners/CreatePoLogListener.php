<?php

namespace App\Listeners;

use App\Events\PoLogCreated;
use App\Models\PurchaseOrderLog;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;

class CreatePoLogListener
{

  protected $request;

  /**
   * Create the event listener.
   */
  public function __construct(Request $request)
  {
    $this->request = $request;
  }

  /**
   * Handle the event.
   */
  public function handle(PoLogCreated $event): void
  {
    $po = $event->po;

    $poLog = new PurchaseOrderLog();
    $poLog->fk_po_id = $po->id;
    $poLog->fk_quotation_id = $po->fk_quotation_id;
    $poLog->fk_rfq_id = $po->fk_rfq_id;
    $poLog->fk_lead_id = $po->fk_lead_id;
    $poLog->po_date = $po->po_date;
    $poLog->po_no = $po->po_no;
    $poLog->prepared_by = $po->prepared_by ?? 0;
    $poLog->po_details = $po->po_details;
    $poLog->po_details_total = $po->po_details_total;
    $poLog->po_status = $po->po_status;
    $poLog->curr_stage_id = $po->curr_stage_id ?? 0;
    $poLog->curr_sub_stage_id = $po->curr_sub_stage_id ?? 0;
    $poLog->curr_user = $po->curr_user;
    $poLog->curr_user_ids = $po->curr_user_ids;
    $poLog->comm_users = $po->comm_users;
    $poLog->comm_user_ids = $po->comm_user_ids;
    $poLog->attachments = $po->attachments;
    $poLog->comments = $po->comments;
    $poLog->status = $po->status ?? 1;
    $poLog->ip = $this->request->ip();
    $poLog->latitude = $this->request->header('latitude') ?? '';
    $poLog->longitude = $this->request->header('longitude') ?? '';
    $poLog->platform = $this->request->header('platform') ?? 'web';
    $poLog->action = $po->action;
    $poLog->created_by = $po->created_by ?? 0;
    $poLog->updated_by = $po->updated_by ?? 0;
    $poLog->save();
  }
}
