<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
  use HasFactory, SoftDeletes;

  protected $hidden = ['deleted_at', 'created_at', 'updated_at'];

  protected $fillable = [
    'product_category_id',
    'product_name',
    'short_description',
    'long_description',
    'product_field_count',
    'status',
  ];

  public function category()
  {
    return $this->belongsTo(ProductCategory::class, 'product_category_id');
  }

  public function parameters()
  {
    return $this->hasMany(ProductParameter::class, 'product_id')->orderBy('sequence');
  }

  public function partNo()
  {
    return $this->hasMany(ProductPart::class, 'product_id', 'id');
  }

  public function images()
  {
    return $this->hasMany(ProductImage::class, 'product_id');
  }
}
