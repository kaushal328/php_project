<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProjectSamplingPurchaseInvoice extends Model
{
    use HasFactory, SoftDeletes;

    function rfq()
    {
        return $this->belongsTo(Rfq::class, 'fk_rfq_id');
    }

    function lead()
    {
        return $this->belongsTo(Lead::class, 'lead_id');
    }
}
