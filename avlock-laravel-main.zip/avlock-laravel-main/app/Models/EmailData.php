<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class EmailData extends Model {
    use HasFactory, SoftDeletes;
    protected $hidden = ['created_at', 'updated_at', 'deleted_at'];

    protected $fillable = [
      'fk_email_campaign_id',
      'name',
      'address',
      'city',
      'email',
      'mobile',
      'status',
    ];

    /**
     * Get the email campaign associated with email data.
     */
    public function campaign(): BelongsTo {
      return $this->belongsTo(EmailCampaign::class, 'fk_email_campaign_id')->withTrashed();
    }
}
