<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SalesVisitReportLog extends Model
{
  use HasFactory;
  protected $hidden = ['created_at', 'updated_at'];

  protected $fillable = [
    'fk_sales_visit_report_id',
    'sales_person',
    'report_no',
    'customer_name',
    'visit_date',
    'location',
    'reason_for_visit',
    'application_details',
    'svr_remark',
    'annual_volume',
    'product_of_interest',
    'fk_product_id',
    'specification',
    'installation_method',
    'price',
    'sop_and_lifetime',
    'industry_type',
    'customer_benefit',
    'customer_representatives',
    'status',
    'action',
    'created_by',
    'updated_by',
  ];
}
