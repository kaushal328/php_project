<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class TenderSalesOrder extends Model
{
    use HasFactory, SoftDeletes;

    public function tender(): BelongsTo
    {
        return $this->belongsTo(Tender::class, 'fk_tender_id');
    }

    public function quotation(): BelongsTo
    {
        return $this->belongsTo(TenderQuotation::class, 'fk_quotation_id');
    }

    public function purchaseOrder(): BelongsTo
    {
        return $this->belongsTo(TenderPurchaseOrder::class, 'fk_po_id');
    }
}
