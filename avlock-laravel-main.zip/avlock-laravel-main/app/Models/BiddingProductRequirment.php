<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class BiddingProductRequirment extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = ['tender_id', 'product_id', 'product_part_id', 'part_no', 'description', 'qty', 'rate', 'created_at', 'updated_at', 'deleted_at'];
    protected $hidden = ['created_at', 'updated_at', 'deleted_at'];

    function product(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    function tender(): BelongsTo
    {
        return $this->belongsTo(Tender::class, 'tender_id');
    }

    function consignee(): HasMany
    {
        return $this->hasMany(BiddingConsigneeRequirment::class, 'product_id');
    }
}
