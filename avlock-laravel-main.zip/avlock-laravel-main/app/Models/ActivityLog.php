<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ActivityLog extends Model
{
  use HasFactory;
  protected $hidden = ['created_at', 'updated_at'];

  protected $fillable = [
    'fk_activity_id',
    'title',
    'description',
    'start',
    'end',
    'fk_task_type_id',
    'fk_lead_id',
    'fk_rfq_id',
    'fk_user_id',
    'attachment',
    'status',
    'action',
    'created_by',
    'updated_by',
  ];
}
