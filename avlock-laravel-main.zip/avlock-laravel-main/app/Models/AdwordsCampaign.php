<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AdwordsCampaign extends Model {
    use HasFactory, SoftDeletes;
    protected $hidden = ['created_at', 'deleted_at', 'updated_at'];
    protected $fillable = [
      'platform',
      'campaign_id',
      'title',
      'start_date',
      'end_date',
      'budget',
      'total_enquiry_received',
      'report_date',
      'status',
      'created_by',
      'updated_by',
    ];
    
}
