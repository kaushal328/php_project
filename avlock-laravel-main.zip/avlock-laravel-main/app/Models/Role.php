<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Role extends Model {
    use HasFactory;
    use SoftDeletes;
    protected $hidden = ['deleted_at', 'created_at', 'updated_at'];

    protected $fillable = [
      'department_id',
      'department_type_id',
      'permissions',
    ];

    /**
     * Get the department associated with role.
     */
    public function department(): BelongsTo {
      return $this->belongsTo(Department::class, 'department_id')->where('is_department', 1);
    }

    /**
     * Get the department type associated with role.
     */
    public function departmentType(): BelongsTo {
      return $this->belongsTo(DepartmentType::class, 'department_type_id');
    }
}
