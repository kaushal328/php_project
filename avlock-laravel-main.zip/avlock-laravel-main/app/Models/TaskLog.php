<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TaskLog extends Model
{
  use HasFactory;
  protected $hidden = ['created_at', 'updated_at'];

  protected $fillable = [
    'title',
    'fk_task_id',
    'fk_task_type_id',
    'fk_lead_id',
    'fk_rfq_id',
    'description',
    'start',
    'end',
    'fk_status_id',
    'fk_user_id',
    'allDay',
    'attachment',
    'action',
    'created_by',
    'updated_by',
  ];
}
