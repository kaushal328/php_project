<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasOne;

class SmsData extends Model
{
  use HasFactory, SoftDeletes;

  protected $hidden = ['created_at', 'updated_at', 'deleted_at'];

  protected $fillable = [
    'fk_sms_campaign_id',
    'name',
    'address',
    'city',
    'email',
    'mobile',
    'status'
  ];

  /**
   * Get the Campaign associated with SMS Data.
   */
  public function campaign(): BelongsTo {
    return $this->BelongsTo(SmsCampaign::class, 'fk_sms_campaign_id')->withTrashed();
  }

}
