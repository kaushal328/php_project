<?php

namespace App\Models;

use App\Models\BookpostCampaign;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasOne;

class BookpostData extends Model
{
    use HasFactory, SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at'];

    protected $fillable = [
  
      'fk_bookpost_campaign_id',
      'designation',
      'country',
      'pincode',
      'name',
      'address',
      'city',
      'email',
      'mobile'  

    ];

    /**
     * Get the Campaign associated with Bookpost Data.
     */
    public function campaign(): BelongsTo
    {
        return $this->BelongsTo(BookpostCampaign::class, 'fk_bookpost_campaign_id')->withTrashed();
    }

}
