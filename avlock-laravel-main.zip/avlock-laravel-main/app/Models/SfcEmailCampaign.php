<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class SfcEmailCampaign extends Model {
    use HasFactory, SoftDeletes;

    protected $hidden = ['created_at', 'updated_at', 'deleted_at'];
    protected $fillable = [
      'campaign_id',
      'title',
      'start_date',
      'end_date',
      'budget',
      'total_email_sent',
      'total_email_delivered',
      'total_email_opened',
      'total_email_clicked',
      'total_email_bounced',
      'total_email_failed',
      'report_date',
      'total_data',
      'delivered',
      'delivery_rate',
      'opens',
      'open_rate',
      'enquire_now',
      'facebook',
      'twitter',
      'instagram',
      'linkedin',
      'pinterest',
      'website',
      'total_clicks',
      'clicks',
      'click_to_open_rate',
      'unsubscribe',
      'unsubscribe_rate',
      'bounce',
      'bounce_rate',
      'status',
      'created_by',
      'updated_by',
    ];
}
