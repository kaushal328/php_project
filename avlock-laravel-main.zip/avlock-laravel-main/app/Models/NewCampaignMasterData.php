<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class NewCampaignMasterData extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
      'industry_ids'
    ];

    function entries()
    {
        return $this->hasMany(NewCampaignMasterDataEntry::class, 'master_data_id');
    }

    // Accessor to get industry IDs as an array
    public function getIndustryIdsAttribute($value) {
      return explode(',', $value);
    }

    // Accessor to get industry IDs as an array
    public function getDivisionIdsAttribute($value) {
      return explode(',', $value);
    }

    // public function industry(){
    //   $industryIds = $this->getIndustryIdsAttribute($this->attributes['industry_ids']);
    //   return $this->belongsTo(Industry::class, $industryIds)->orderBy('id', 'asc');
    // }
  
}
