<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class NewCampaignData extends Model {
  use HasFactory, SoftDeletes;

  protected $table = 'new_campaign_datas';

  public function masterDataEntry(): BelongsTo {
    return $this->belongsTo(NewCampaignMasterDataEntry::class, 'master_data_entry_id');
  }

  public function newCampaign(): BelongsTo {
    return $this->belongsTo(NewCampaign::class, 'campaign_id');
  }
}
