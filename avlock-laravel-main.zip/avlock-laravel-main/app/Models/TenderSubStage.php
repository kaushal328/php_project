<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TenderSubStage extends Model
{
    use HasFactory;
    use \Staudenmeir\EloquentJsonRelations\HasJsonRelationships;

    protected $casts = [
        'next_sub_stage_ids' => 'json',
    ];

    function stage()
    {
        return $this->belongsTo(TenderStage::class, 'stage_id');
    }

    function nextSubStage()
    {
        return $this->belongsToJson(TenderSubStage::class, 'next_sub_stage_ids');
    }
}
