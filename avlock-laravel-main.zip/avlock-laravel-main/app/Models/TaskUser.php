<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TaskUser extends Model
{
    use HasFactory;

    protected $fillable = [
        'fk_task_id',
        'fk_user_id',
        'user_name',
        'created_at',
        'updated_at',
      ];

    public function task()
    {
        return $this->belongsTo(Task::class, 'fk_task_id');
    }

    function user()
    {
        return $this->belongsTo(User::class, 'fk_user_id');
    }
}
