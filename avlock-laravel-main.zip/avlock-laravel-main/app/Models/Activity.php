<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Activity extends Model
{
  use HasFactory, SoftDeletes;
  // protected $hidden = ['created_at', 'updated_at', 'deleted_at'];
  protected $fillable = [
    'title',
    'description',
    'start',
    'end',
    'fk_task_type_id',
    'fk_lead_id',
    'fk_rfq_id',
    'fk_user_id',
    'attachment',
    'status',
    'created_by',
    'updated_by',
  ];

  /**
   * Get the task Type associated with Activity.
   */
  public function taskType(): BelongsTo
  {
    return $this->BelongsTo(TaskType::class, 'fk_task_type_id');
  }

  /**
   * Get the Lead associated with Activity.
   */
  public function lead(): BelongsTo
  {
    return $this->BelongsTo(Lead::class, 'fk_lead_id');
  }

  /**
   * Get the Lead associated with Activity.
   */
  public function rfq(): BelongsTo
  {
    return $this->BelongsTo(Rfq::class, 'fk_rfq_id');
  }

  function activityType()
  {
    return $this->belongsTo(ActivityType::class, 'fk_activity_type_id');
  }

  function svr()
  {
    return $this->belongsTo(SalesVisitReport::class, 'fk_svr_id');
  }

  public function user(): BelongsTo
  {
    return $this->BelongsTo(User::class, 'fk_user_id');
  }

  public function createdBy(): BelongsTo
  {
    return $this->BelongsTo(User::class, 'created_by');
  }

  public function latestActivityLog(): HasOne
  {
    return $this->hasOne(ActivityLog::class, 'fk_activity_id')
      ->latest();
  }

  function leadAddress(): BelongsTo
  {
    return $this->belongsTo(LeadAddresses::class, 'lead_addresses_id');
  }

  function leadContactPeople(): BelongsTo
  {
    return $this->belongsTo(LeadContactPeople::class, 'lead_contact_people_id');
  }
}
