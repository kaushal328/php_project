<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class ProjectLog extends Model
{
  use HasFactory;

  function stage(): BelongsTo
  {
    return $this->belongsTo(Stage::class, 'curr_stage_id');
  }

  function subStage(): BelongsTo
  {
    return $this->belongsTo(SubStage::class, 'curr_sub_stage_id');
  }

  function actionBy(): BelongsTo
  {
    return $this->belongsTo(User::class, 'updated_by');
  }

  function po(): BelongsTo
  {
    return $this->belongsTo(PurchaseOrder::class, 'fk_po_id');
  }

  function rfq(): BelongsTo
  {
    return $this->belongsTo(Rfq::class, 'fk_rfq_id');
  }
}
