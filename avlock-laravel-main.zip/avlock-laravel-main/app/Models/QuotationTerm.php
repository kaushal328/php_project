<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class QuotationTerm extends Model {
  use HasFactory, SoftDeletes;

  protected $hidden = ['deleted_at', 'created_at', 'updated_at'];

  protected $fillable = [
    'title',
  ];

  public function setNameAttribute($value) {
    $this->attributes['title'] = $value ? convertToCamelCase($value) : $value;
  }

  public function termsCategory(): BelongsTo {
    return $this->belongsTo(QuotationTermCategory::class, 'fk_category_id');
  }
}
