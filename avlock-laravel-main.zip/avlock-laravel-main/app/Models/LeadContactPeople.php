<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;

class LeadContactPeople extends Model {
  use HasFactory, SoftDeletes;

  protected $fillable = [
    'lead_id',
    'lead_address_id',
    'designations',
    'monogram',
    'customer_name',
    'email',
    'contact_no',
    'alt_email_one',
    'alt_email_two',
    'alt_contact_one',
    'alt_contact_two',
  ];

  protected $casts = [
    'designations' => 'array',
  ];

  // Define relationships if needed
  public function lead() {
    return $this->belongsTo(Lead::class);
  }

  public function leadAddress() {
    return $this->belongsTo(LeadAddresses::class, 'lead_address_id');
  }
}
