<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Reminder extends Model {
  use HasFactory, SoftDeletes;
  protected $hidden = ['deleted_at', 'created_at', 'updated_at'];

  protected $fillable = [
    'task_type',
    'for_me',
    'lead',
    'rfq',
    'comment',
    'status',
    'reminder_time',
    'created_by',
    'updated_by',
  ];

  public function reminderUser() {
    return $this->hasMany(ReminderUser::class, 'fk_reminder_id');
  }

  /**
   * Get the task Type associated with Task.
   */
  public function taskType(): BelongsTo {
    return $this->BelongsTo(TaskType::class, 'task_type');
  }

    /**
   * Get the Lead associated with Task.
   */
  public function Remminderlead(): BelongsTo {
    return $this->BelongsTo(Lead::class, 'lead');
  }

  /**
   * Get the rfq associated with Task.
   */
  public function Remminderfq(): BelongsTo {
    return $this->BelongsTo(Rfq::class, 'rfq');
  }

  function reminderBy()
  {
    return $this->BelongsTo(User::class, 'created_by');
  }
}
