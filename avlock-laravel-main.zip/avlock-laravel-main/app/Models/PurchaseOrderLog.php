<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PurchaseOrderLog extends Model
{
  use HasFactory;

  function stage(): BelongsTo
  {
    return $this->belongsTo(Stage::class, 'curr_stage_id');
  }

  function subStage(): BelongsTo
  {
    return $this->belongsTo(SubStage::class, 'curr_sub_stage_id');
  }
}
