<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProjectQuotationTemp extends Model
{
  use HasFactory, SoftDeletes;

  public $fillable = [
    'total_basic_value_in_inr'
  ];

  function lead(): BelongsTo
  {
    return $this->belongsTo(Lead::class, 'fk_lead_id');
  }

  function rfq(): BelongsTo
  {
    return $this->belongsTo(Rfq::class, 'fk_rfq_id');
  }

  function salesPerson(): BelongsTo
  {
    return $this->belongsTo(User::class, 'sales_person');
  }

  function preparedBy(): BelongsTo
  {
    return $this->belongsTo(User::class, 'prepared_by');
  }

  public function purchaseOrder()
  {
    return $this->hasOne(PurchaseOrder::class, 'fk_quotation_id');
  }
}
