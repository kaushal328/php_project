<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TenderQuotation extends Model {
    use HasFactory, SoftDeletes;

    protected $fillable = [
      'tender_id',
      'quotation_no',
      'user_ids',
      'users',
      'quotation_date',
      'terms',
      'quotation_remark',
      'created_by',
      'updated_by',
    ];

    function tender()
    {
      return $this->belongsTo(Tender::class, 'tender_id');
    }

    function preparedBy()
    {
      return $this->belongsTo(User::class, 'created_by');
    }
}
