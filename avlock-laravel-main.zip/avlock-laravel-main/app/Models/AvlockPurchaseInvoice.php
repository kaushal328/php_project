<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class AvlockPurchaseInvoice extends Model
{
  use HasFactory, SoftDeletes;

  function po(): BelongsTo
  {
    return $this->belongsTo(PurchaseOrder::class, 'fk_po_id');
  }

  public function deliveryNoteDate(): BelongsTo
  {
    return $this->belongsTo(DeliveryNote::class, 'delivery_note_date');
  }

  function quotation(): BelongsTo
  {
    return $this->belongsTo(ProjectQuotation::class, 'fk_quotation_id');
  }

  function lead(): BelongsTo
  {
    return $this->belongsTo(Lead::class, 'fk_lead_id');
  }

  function rfq(): BelongsTo
  {
    return $this->belongsTo(Rfq::class, 'fk_rfq_id');
  }

  function salesOrderDate(): BelongsTo
  {
    return $this->belongsTo(AvlockSalesOrder::class, 'sales_order_id');
  }
}
