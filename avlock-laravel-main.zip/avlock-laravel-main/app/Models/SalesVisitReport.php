<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class SalesVisitReport extends Model
{
  use HasFactory, SoftDeletes;
  protected $hidden = ['created_at', 'updated_at', 'deleted_at'];

  protected $fillable = [
    'sales_person',
    'report_no',
    'customer_name',
    'visit_date',
    'location',
    'reason_for_visit',
    'application_details',
    'svr_remark',
    'annual_volume',
    'product_of_interest',
    'fk_product_id',
    'specification',
    'installation_method',
    'price',
    'sop_and_lifetime',
    'industry_type',
    'customer_benefit',
    'customer_representatives',
    'status',
    'created_by',
    'updated_by',
  ];

  /**
   * Get the Sale Person associated with Report.
   */
  public function reportSalesPerson(): BelongsTo
  {
    return $this->belongsTo(User::class, 'sales_person');
  }

  /**
   * Get the Product associated with Report.
   */
  public function product(): BelongsTo
  {
    return $this->BelongsTo(Product::class, 'fk_product_id');
  }

  public function lead()
  {
    return $this->belongsTo(Lead::class, 'fk_lead_id');
  }

  public function rfq()
  {
    return $this->belongsTo(Rfq::class, 'fk_rfq_id');
  }

  public function user()
  {
    return $this->belongsTo(User::class, 'sales_person');
  }

  public function customer()
  {
    return $this->belongsTo(Lead::class, 'fk_lead_id');
  }

  public function state(): BelongsTo
  {
    return $this->belongsTo(State::class, 'state_id');
  }

  public function city(): BelongsTo
  {
    return $this->belongsTo(City::class, 'city_id');
  }

  public function division(): BelongsTo
  {
    return $this->belongsTo(Division::class, 'division_id');
  }

  public function activityType(): BelongsTo
  {
    return $this->belongsTo(ActivityType::class, 'fk_activity_type_id');
  }

  function leadAddress(): BelongsTo
  {
    return $this->belongsTo(LeadAddresses::class, 'lead_addresses_id');
  }

  function leadContactPeople(): BelongsTo
  {
    return $this->belongsTo(LeadContactPeople::class, 'lead_contact_people_id');
  }

}
