<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProjectSamplingLog extends Model
{
    use HasFactory, SoftDeletes;

    use \Staudenmeir\EloquentJsonRelations\HasJsonRelationships;

    protected $casts = [
        'sub_stage_user_ids' => 'json',
    ];

    function subStage()
    {
        return $this->belongsTo(ProjectSamplingSubStage::class, 'sub_stage_id');
    }

    function updatedBy() {
        return $this->belongsTo(User::class, 'updated_by');
    }

    function users()
    {
        return $this->belongsToJson(User::class, 'sub_stage_user_ids');
    }
}
