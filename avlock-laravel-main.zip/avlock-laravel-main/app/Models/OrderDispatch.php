<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class OrderDispatch extends Model
{
    use HasFactory, SoftDeletes;

    public function so(): BelongsTo
    {
        return $this->belongsTo(AvlockSalesOrder::class, 'sales_order_id');
    }
}
