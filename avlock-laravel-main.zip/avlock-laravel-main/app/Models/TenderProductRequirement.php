<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class TenderProductRequirement extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = ['tender_id', 'product_id', 'product_part_id', 'part_no', 'description', 'qty', 'rate', 'created_at', 'updated_at', 'deleted_at'];
    protected $hidden = ['created_at', 'updated_at', 'deleted_at'];

    function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    function consignee()
    {
        return $this->hasMany(TenderConsigneeRequirment::class, 'product_id');
    }
}
