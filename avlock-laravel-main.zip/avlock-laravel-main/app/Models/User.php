<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use PHPOpenSourceSaver\JWTAuth\Contracts\JWTSubject;

class User extends Authenticatable implements JWTSubject
{
  use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

  /**
   * The attributes that are mass assignable.
   *
   * @var array<int, string>
   */
  protected $fillable = [
    'name',
    'email',
    'password',
  ];

  /**
   * The attributes that should be hidden for serialization.
   *
   * @var array<int, string>
   */
  protected $hidden = [
    'p',
    'password',
    'remember_token',
    'created_at',
    'updated_at',
    'email_verified_at',
    // 'permissions',
    'deleted_at'
  ];

  /**
   * The attributes that should be cast.
   *
   * @var array<string, string>
   */
  protected $casts = [
    'email_verified_at' => 'datetime',
    'password' => 'hashed',
  ];

  /**
   * Get the identifier that will be stored in the subject claim of the JWT.
   *
   * @return mixed
   */
  public function getJWTIdentifier()
  {
    return $this->getKey();
  }

  /**
   * Return a key value array, containing any custom claims to be added to the JWT.
   *
   * @return array
   */
  public function getJWTCustomClaims()
  {
    return [];
  }

  public function roles()
  {
    return $this->hasMany(UserRole::class, 'fk_user_id');
  }

  public function tenders()
  {
    return $this->hasMany(Tender::class, 'sub_stage_user_ids', 'id');
  }

  public function designation()
  {
    return $this->hasOne(Designation::class, 'id', 'fk_designation_id');
  }

  public function setRsmCodeAttribute($value)
  {
    $this->attributes['rsm_code'] = strtoupper($value);
  }

  public function rfqs()
  {
    return $this->hasMany(Rfq::class, 'rsm_id', 'id');
  }
}
