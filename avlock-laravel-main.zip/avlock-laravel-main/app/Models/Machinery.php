<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Machinery extends Model {
  use HasFactory, SoftDeletes;
    protected $hidden = ['created_at', 'deleted_at', 'updated_at'];
    protected $fillable = [
      'mc_no',
      'mc_name',
      'make',
      'year_of_make',
      'operations_carried',
      'booked_for_hrs',
      'remarks',
      'status',
    ];
}
