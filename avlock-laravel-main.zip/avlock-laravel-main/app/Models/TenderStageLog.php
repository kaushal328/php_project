<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TenderStageLog extends Model
{
    use HasFactory;
    use \Staudenmeir\EloquentJsonRelations\HasJsonRelationships;

    protected $casts = [
        'user_ids' => 'json',
    ];

    function subStage()
    {
        return $this->belongsTo(TenderSubStage::class, 'sub_stage_id');
    }

    function tender() {
        return $this->belongsTo(Tender::class, 'tender_id');
    }

    function users()
    {
        return $this->belongsToJson(User::class, 'user_ids');
    }
}
