<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class PurchaseOrder extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * Get the Sale Person associated with Report.
     */
    public function quotation(): BelongsTo
    {
        return $this->belongsTo(ProjectQuotationTemp::class, 'fk_quotation_id');
    }

    public function rfq(): BelongsTo
    {
        return $this->belongsTo(Rfq::class, 'fk_rfq_id');
    }

    public function lead(): BelongsTo
    {
        return $this->belongsTo(Lead::class, 'fk_lead_id');
    }

    public function preparedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'prepared_by');
    }

    public function agreement(): HasMany
    {
        return $this->hasMany(PurchaseOrderAgreement::class, 'fk_po_id');
    }

    public function packaging(): HasMany
    {
        return $this->hasMany(PurchaseOrderPackagingList::class, 'fk_po_id');
    }

    public function labelling(): HasMany
    {
        return $this->hasMany(PurchaseOrderLabelling::class, 'fk_po_id');
    }

    public function dneInvoice(): HasMany
    {
        return $this->hasMany(PurchaseOrderDneInvoice::class, 'fk_po_id');
    }

    public function qualityReport(): HasMany
    {
        return $this->hasMany(PurchaseOrderPdrQuality::class, 'fk_po_id');
    }

    public function lr(): HasMany
    {
        return $this->hasMany(PurchaseOrderLr::class, 'fk_po_id');
    }

    public function purchaseInvoice(): HasMany
    {
        return $this->hasMany(PurchaseInvoice::class, 'fk_po_id');
    }

    public function invoice(): HasMany
    {
        return $this->hasMany(AvlockPurchaseInvoice::class, 'fk_po_id');
    }

    function stage(): BelongsTo
    {
        return $this->belongsTo(Stage::class, 'curr_stage_id');
    }

    function subStage(): BelongsTo
    {
        return $this->belongsTo(SubStage::class, 'curr_sub_stage_id');
    }

    function updatedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'prepared_by');
    }

    public function poType(): BelongsTo
    {
        return $this->belongsTo(PurchaseOrderType::class, 'po_type_id');
    }

    public function tender(): BelongsTo
    {
        return $this->belongsTo(Tender::class, 'fk_tender_id');
    }

    public function poDespatchDetail(): hasMany
    {
        return $this->hasMany(PoDespatchDetail::class, 'po_id');
    }

    public function tenderQuotation(): HasOne
    {
        return $this->hasOne(TenderBidding::class, 'tender_id', 'fk_tender_id');
    }

    public function salesOrder(): HasOne
    {
        return $this->hasOne(AvlockSalesOrder::class, 'fk_po_id');
    }

    function tenderSubStage(): BelongsTo
    {
        return $this->belongsTo(TenderSubStage::class, 'curr_sub_stage_id');
    }

    public function poDetail(): HasMany
    {
        return $this->hasMany(PurchaseOrderDetail::class, 'fk_po_id');
    }
}
