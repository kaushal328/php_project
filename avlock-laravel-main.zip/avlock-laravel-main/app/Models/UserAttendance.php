<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserAttendance extends Model
{
  use HasFactory;
  protected $hidden = ['created_at', 'updated_at'];


  protected $fillable = [
    'fk_user_id',
    'checkin_time',
    'checkout_time',
    'attendance_date',
  ];

  public function user()
  {
    return $this->belongsTo(User::class, 'fk_user_id');
  }
}
