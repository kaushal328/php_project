<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Lead extends Model
{
  use HasFactory, SoftDeletes;

  protected $hidden = ['created_at', 'updated_at', 'deleted_at'];

  protected $fillable = [
    'fk_region_id',
    'customer_name',
    'company',
    'designation',
    'country_id',
    'email',
    'contact_no',
    'fk_source_id',
    'customer_type',
    'smo_platform',
    'adwords_platform',
    'fk_rsmr_id',
    'fk_rsmv_id',
    'reference',
    'credit_limit',
    'is_client',
    'enquiry_date',
    'address1',
    'address2',
    'city',
    'pincode',
    'state',
    'fk_designation_id',
    'application',
    'description',
    'enquiry_status',
    'assigned_rsm',
    'status',
    'created_by',
    'updated_by',
  ];

  protected $casts = [
    'designations' => 'array',
  ];

  /**
   * Get the Source campaign associated with Lead.
   */
  public function region(): BelongsTo
  {
    return $this->belongsTo(Region::class, 'fk_region_id');
  }

  /**
   * Get the Source campaign associated with Lead.
   */
  public function source(): BelongsTo
  {
    return $this->belongsTo(Source::class, 'fk_source_id');
  }

  /**
   * Get the User campaign associated with Lead.
   */
  public function rsmr(): BelongsTo
  {
    return $this->belongsTo(User::class, 'fk_rsmr_id');
  }

  /**
   * Get the User campaign associated with Lead.
   */
  public function rsmv(): BelongsTo
  {
    return $this->belongsTo(User::class, 'fk_rsmv_id');
  }

  /**
   * Get the Designation associated with Lead.
   */
  public function designation(): BelongsTo
  {
    return $this->belongsTo(Designation::class, 'fk_designation_id');
  }

  /**
   * Get the User assignedRSM associated with Lead.
   */
  public function assignedRsm(): BelongsTo
  {
    return $this->belongsTo(User::class, 'assigned_rsm');
  }

  public function customer(): BelongsTo
  {
    return $this->belongsTo(User::class, 'fk_rsmr_id');
  }

  public function country(): BelongsTo
  {
    return $this->belongsTo(Country::class, 'country_id');
  }

  function rsmUser(): BelongsTo
  {
    return $this->belongsTo(User::class, 'fk_rsmr_id');
  }

  function rfq(): HasOne
  {
    return $this->hasOne(Rfq::class, 'lead_id');
  }

  function rfqCount()
  {
    return $this->hasMany(Rfq::class, 'lead_id');
  }

  function activityCount()
  {
    return $this->hasMany(Activity::class, 'fk_lead_id');
  }

  function svr()
  {
    return $this->hasMany(SalesVisitReport::class, 'fk_lead_id');
  }

  function rfqs(): HasMany
  {
    return $this->hasMany(Rfq::class, 'lead_id');
  }

  function division()
  {
    return $this->belongsTo(Division::class, 'division_id');
  }

  function leadStage()
  {
    return $this->belongsTo(LeadStage::class, 'lead_stage_id');
  }

  public function leadAddress(): HasMany {
    return $this->hasMany(LeadAddresses::class, 'lead_id');
  }

  public function LeadContactPeople(): HasMany {
    return $this->hasMany(LeadContactPeople::class, 'lead_id');
  }

}
