<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Rfq extends Model
{
    use HasFactory, SoftDeletes;

    protected $hidden = ['updated_at', 'deleted_at'];

    public function product(): HasMany
    {
        return $this->hasMany(RfqProduct::class, 'rfq_id')->orderBy('sequence');
    }

    function banner(): BelongsTo
    {
        return $this->belongsTo(RfqBanner::class, 'banner_id');
    }

    function footer(): BelongsTo
    {
        return $this->belongsTo(Footer::class, 'footer_id');
    }

    function lead(): BelongsTo
    {
        return $this->belongsTo(Lead::class, 'lead_id');
    }

    function rfqResponse(): HasOne
    {
        return $this->hasOne(RfqResponse::class, 'rfq_id');
    }

    function designation(): BelongsTo
    {
        return $this->belongsTo(LeadDesignation::class, 'designation_id');
    }

    function stage(): BelongsTo
    {
        return $this->belongsTo(Stage::class, 'curr_stage_id');
    }

    function subStage(): BelongsTo
    {
        return $this->belongsTo(SubStage::class, 'curr_sub_stage_id');
    }

    function division(): BelongsTo
    {
        return $this->belongsTo(Division::class, 'division_id');
    }

    function projectType(): BelongsTo
    {
        return $this->belongsTo(ProjectType::class, 'fk_project_type_id');
    }

    function projectSegment(): BelongsTo
    {
        return $this->belongsTo(ProjectSegment::class, 'fk_project_segment_id');
    }
    function quotation(): HasOne
    {
        return $this->hasOne(ProjectQuotation::class, 'fk_rfq_id');
    }

    function quotationTemp(): HasOne
    {
        return $this->hasOne(ProjectQuotationTemp::class, 'fk_rfq_id');
    }

    public function products(): HasMany
    {
        return $this->hasMany(RfqProduct::class, 'rfq_id');
    }

    function stageLogs()
    {
        return $this->hasMany(ProjectLog::class, 'fk_rfq_id');
    }

    function currencyData()
    {
        return $this->belongsTo(Currency::class, 'currency');
    }

    function source()
    {
        return $this->belongsTo(Source::class, 'fk_source_id');
    }

    function rsm(): BelongsTo
    {
        return $this->belongsTo(User::class, 'rsm_id');
    }

    function purchaseOrder()
    {
        return $this->hasMany(PurchaseOrder::class, 'fk_rfq_id');
    }

    function salesOrder()
    {
        return $this->hasMany(AvlockSalesOrder::class, 'fk_rfq_id');
    }

    function leadContactPeople(): BelongsTo
    {
        return $this->belongsTo(LeadContactPeople::class, 'lead_contact_people_id');
    }
}
