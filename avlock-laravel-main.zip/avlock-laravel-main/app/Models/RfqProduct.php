<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class RfqProduct extends Model {
  use HasFactory, SoftDeletes;

  protected $fillable = [
    'rfq_id',
    'product_id',
    'product_part_id',
    'product_qty',
    'response',
    'is_response_received',
    'ip',
  ];

  function product(): BelongsTo {
    return $this->belongsTo(Product::class, 'product_id');
  }

  function productPart(): BelongsTo {
    return $this->belongsTo(ProductPart::class, 'product_part_id');
  }
}
