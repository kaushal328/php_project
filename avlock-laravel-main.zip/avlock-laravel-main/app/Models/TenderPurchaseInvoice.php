<?php

namespace App\Models;

use App\Models\Tender;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class TenderPurchaseInvoice extends Model {
    use HasFactory, SoftDeletes;

    function tender(): BelongsTo {
      return $this->belongsTo(Tender::class, 'fk_tender_id');
    }
  

}
