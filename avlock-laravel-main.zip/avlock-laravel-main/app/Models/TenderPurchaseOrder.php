<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class TenderPurchaseOrder extends Model
{
    use HasFactory;

    function subStage()
    {
        return $this->belongsTo(TenderSubStage::class, 'curr_sub_stage_id');
    }

    public function quotation(): HasOne
    {
        return $this->HasOne(TenderQuotation::class, 'tender_id');
    }

    function tender()
    {
        return $this->belongsTo(Tender::class, 'fk_tender_id');
    }

    function preparedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'prepared_by');
    }
}
