<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Region extends Model
{
  use HasFactory, SoftDeletes;
  protected $hidden = ['deleted_at', 'created_at', 'updated_at'];

  protected $fillable = [
    'name',
    'code',
  ];

  public function setNameAttribute($value)
  {
    $this->attributes['name'] = $value ? convertToCamelCase($value) : $value;
  }

  public function setCodeAttribute($value)
  {
    $this->attributes['code'] = $value ? strtoupper(trim($value)) : $value;
  }

  function lead()
  {
    return $this->hasOne(Lead::class, 'fk_region_id');
  }

  function leads()
  {
    return $this->hasMany(Lead::class, 'fk_region_id');
  }
}
