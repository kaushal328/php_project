<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Tender extends Model
{
  use HasFactory, SoftDeletes, \Staudenmeir\EloquentJsonRelations\HasJsonRelationships;

  protected $hidden = ['deleted_at'];

  protected $fillable = [
    'name',
    'organization',
    'description',
    'filing_date_from',
    'filing_date_to',
    'reminder_to',
    'sub_stage_id',
    'sub_stage_user_ids',
    'sub_stage_remark',
    'sub_stage_attachments',
  ];

  protected $casts = [
    'sub_stage_user_ids' => 'json',
  ];

  function products()
  {
    return $this->hasMany(TenderProductRequirement::class, 'tender_id');
  }

  public function subStageUsers()
  {
    return $this->belongsToJson(User::class, 'sub_stage_user_ids');
  }

  function currentSubStage()
  {
    return $this->belongsTo(TenderSubStage::class, 'sub_stage_id');
  }

  function division()
  {
    return $this->belongsTo(Division::class, 'division_id');
  }

  function inspectionRequiredBy()
  {
    return $this->belongsTo(Inspection::class, 'inspection_required_by');
  }

  function consignee()
  {
    return $this->hasMany(TenderConsigneeRequirment::class, 'tender_id');
  }

  function tenderBidding()
  {
    return $this->hasOne(TenderBidding::class, 'tender_id');
  }

  function pos()
  {
    return $this->hasMany(PurchaseOrder::class, 'fk_tender_id')->orderBy('id', 'desc');
  }
}
