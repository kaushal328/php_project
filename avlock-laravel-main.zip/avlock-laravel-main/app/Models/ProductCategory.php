<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProductCategory extends Model
{
  use HasFactory, SoftDeletes;

  protected $hidden = ['deleted_at', 'created_at', 'updated_at'];

  protected $fillable = [
    'parent_id',
    'category_name',
    'description',
    'image',
    'image_thumb',
    'image_alt',
    'status',
  ];
}
