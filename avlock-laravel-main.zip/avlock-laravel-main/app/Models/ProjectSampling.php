<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProjectSampling extends Model
{
    use HasFactory, SoftDeletes, \Staudenmeir\EloquentJsonRelations\HasJsonRelationships;

    protected $casts = [
        'sub_stage_user_ids' => 'json',
    ];

    public function subStageUsers()
    {
        return $this->belongsToJson(User::class, 'sub_stage_user_ids');
    }

    function rfq()
    {
        return $this->belongsTo(Rfq::class, 'fk_rfq_id');
    }

    function lead()
    {
        return $this->belongsTo(Lead::class, 'lead_id');
    }

    function currentSubStage()
    {
        return $this->belongsTo(ProjectSamplingSubStage::class, 'sub_stage_id');
    }

    function mainSubStage()
    {
        return $this->belongsTo(ProjectSamplingSubStage::class, 'main_sub_stage_id');
    }

    function pdrQuality(): HasOne
    {
        return $this->hasOne(ProjectSamplingPdrQuality::class, 'fk_sampling_id');
    }
}
