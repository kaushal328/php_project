<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Task extends Model
{
  use HasFactory, SoftDeletes;

  protected $hidden = ['created_at', 'updated_at', 'deleted_at'];

  protected $fillable = [
    'title',
    'description',
    'start',
    'end',
    'fk_task_type_id',
    'fk_lead_id',
    'fk_rfq_id',
    'fk_user_id',
    'fk_status_id',
    'attachment',
    'status',
    'created_by',
    'updated_by',
  ];

  /**
   * Get the Status associated with Task.
   */
  public function statuses(): BelongsTo
  {
    return $this->BelongsTo(Status::class, 'fk_status_id');
  }


  /**
   * Get the task Type associated with Task.
   */
  public function taskType(): BelongsTo
  {
    return $this->BelongsTo(TaskType::class, 'fk_task_type_id');
  }

  /**
   * Get the Lead associated with Task.
   */
  public function lead(): BelongsTo
  {
    return $this->BelongsTo(Lead::class, 'fk_lead_id');
  }

  /**
   * Get the Lead associated with Task.
   */
  public function rfq(): BelongsTo
  {
    return $this->BelongsTo(Rfq::class, 'fk_rfq_id');
  }

  /*
  * Get comments related to task
  */
  public function comments(): HasMany
  {
    return $this->HasMany(Comment::class, 'fk_task_id');
  }

  /*
  * Get assigned to name of the user
  */
  public function assignedTo(): BelongsTo
  {
    return $this->BelongsTo(User::class, 'fk_user_id');
  }

  /*
  * Get assigned to name of the user
  */
  public function assignedBy(): BelongsTo
  {
    return $this->BelongsTo(User::class, 'created_by');
  }

  /*
  * Get assigned to name of the user
  */
  public function assignedToUsers(): hasMany
  {
    return $this->hasMany(TaskUser::class, 'fk_task_id');
  }

  /**
   * Get the SVR associated with Task.
   */
  public function svr(): BelongsTo
  {
    return $this->BelongsTo(SalesVisitReportLog::class, 'fk_svr_id');
  }

  public function createdBy(): BelongsTo
  {
    return $this->BelongsTo(User::class, 'created_by');
  }
}
