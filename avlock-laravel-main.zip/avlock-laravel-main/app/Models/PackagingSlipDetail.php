<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class PackagingSlipDetail extends Model
{
    use HasFactory, SoftDeletes;

    public function PackagingSlip(): BelongsTo
    {
        return $this->belongsTo(PackagingSlip::class, 'packaging_slip_id');
    }

    public function labeling(): HasMany
    {
        return $this->HasMany(Labeling::class, 'packaging_slip_detail_id');
    }

    public function productPart(): BelongsTo
    {
        return $this->belongsTo(ProductPart::class, 'product_part_id');
    }

    public function dispatchDate(): BelongsTo
    {
        return $this->belongsTo(PoDespatchDetail::class, 'dispatch_date');
    }

    public function lead(): BelongsTo
    {
        return $this->belongsTo(Lead::class);
    }
}
