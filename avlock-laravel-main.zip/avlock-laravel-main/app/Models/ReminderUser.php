<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ReminderUser extends Model {
  use HasFactory;
  protected $hidden = ['created_at', 'updated_at'];

  protected $fillable = [
    'fk_reminder_id',
    'fk_user_id',
    'user_name',
  ];

  function user()
  {
      return $this->belongsTo(User::class, 'fk_user_id');
  }
}
