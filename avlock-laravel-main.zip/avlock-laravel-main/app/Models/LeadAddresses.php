<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;

class LeadAddresses extends Model {
    use HasFactory,SoftDeletes;

    protected $fillable = [
      "lead_id",
      "address_one",
      "address_two",
      "pincode",
      "city",
      "state",
      "shipping_pincode",
      "shipping_city",
      "shipping_state",
      "shipping_address",
    ];
}
