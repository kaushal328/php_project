<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class SvrProduct extends Model {
    use HasFactory, SoftDeletes;
    protected $hidden = ['created_at', 'updated_at'];

    protected $fillable = [
      "svr_id",
      "product_id",
      "status",
    ];

    function product(): BelongsTo {
      return $this->belongsTo(Product::class, 'product_id');
    }
}
