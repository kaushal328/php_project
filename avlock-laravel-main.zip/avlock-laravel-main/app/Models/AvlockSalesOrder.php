<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class AvlockSalesOrder extends Model
{
  use HasFactory, SoftDeletes;

  function po(): BelongsTo
  {
    return $this->belongsTo(PurchaseOrder::class, 'fk_po_id');
  }

  function quotation(): BelongsTo
  {
    return $this->belongsTo(ProjectQuotation::class, 'fk_quotation_id');
  }

  function dispatch(): BelongsTo
  {
    return $this->belongsTo(PoDespatchDetail::class, 'dispatch_id');
  }

  function lead(): BelongsTo
  {
    return $this->belongsTo(Lead::class, 'fk_lead_id');
  }

  function dc(): HasMany
  {
    return $this->hasMany(DeliveryConfirmation::class, 'sales_order_id');
  }

  function invoice(): HasMany
  {
    return $this->hasMany(AvlockPurchaseInvoice::class, 'sales_order_id');
  }

  function ewayBill(): HasMany
  {
    return $this->hasMany(EwayBill::class, 'sales_order_id');
  }

  function od(): HasMany
  {
    return $this->hasMany(OrderDispatch::class, 'sales_order_id');
  }

  function deliveryNote(): HasMany
  {
    return $this->hasMany(DeliveryNote::class, 'sales_order_id');
  }

  function packaging(): HasMany
  {
    return $this->hasMany(PackagingSlip::class, 'sales_order_date');
  }

  function rfq(): BelongsTo
  {
    return $this->belongsTo(Rfq::class, 'fk_rfq_id');
  }
}
