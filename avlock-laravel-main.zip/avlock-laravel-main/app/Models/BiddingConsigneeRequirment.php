<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class BiddingConsigneeRequirment extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'tender_id',
        'product_id',
        'name',
        'qty',
        'delivery_period',
    ];

    public function biddingPro(): BelongsTo
    {
        return $this->belongsTo(BiddingProductRequirment::class, 'product_id');
    }
}
