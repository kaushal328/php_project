<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class NewCampaign extends Model {
    use HasFactory, SoftDeletes;

    public function masterData(): BelongsTo {
      return $this->belongsTo(NewCampaignMasterData::class, 'master_data_id');
    }
  
    public function campaignType(): BelongsTo {
      return $this->belongsTo(NewCampaignType::class, 'campaign_type_id');
    }
  
    public function campaignPlatform(): BelongsTo {
      return $this->belongsTo(NewCampaignTypePlatform::class, 'campaign_platform_id');
    }
  
    public function rsmUsers(): BelongsTo {
      return $this->belongsTo(User::class, 'rsm_user_id');
    }

    public function marketingUsers(): BelongsTo {
      return $this->belongsTo(User::class, 'marketing_user_id');
    }

}
