<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Designation extends Model
{
  use HasFactory;
  use SoftDeletes;
  protected $dates = ['deleted_at'];
  protected $hidden = ['deleted_at', 'created_by', 'updated_by', 'updated_at'];

  /**
   * The attributes that are mass assignable.
   *
   * @var array<int, string>
   */
  protected $fillable = ['title', 'status', 'created_by', 'updated_by'];

  function division()
  {
    return $this->belongsTo(Division::class, 'division_id');
  }
}
