<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Item extends Model {
    use HasFactory, SoftDeletes;
    protected $hidden = ['created_at', 'updated_at', 'deleted_at'];
    protected $fillable = [
      'item_supplied',
      'raw_material',
      'raw_material_supplier',
      'ppm_level_supplier',
      'present_supplies',
      'currennt_capacity',
      'capacity_utilization',
      'create_capacity_short_notice',
      'inventory_kept_days',
    ];
}
