<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class BankerDetail extends Model {
    use HasFactory, SoftDeletes;
    protected $hidden = ['created_at', 'deleted_at', 'updated_at'];
    protected $fillable = [
      'supplier_id',
      'account_name',
      'ifsc_code',
      'account_number',
      'bank_name',
      'bank_branch_name',
      'cancel_cheque',
      'status',
      'created_by',
      'updated_by',
    ];
}
