<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Instrument extends Model {
  use HasFactory, SoftDeletes;
  protected $hidden = ['created_at', 'deleted_at', 'updated_at'];
  protected $fillable = [
    'description',
    'make',
    'range',
    'quantity',
    'least_count',
    'least_calibrated_date',
    'due_date_next_calibration',
    'status',
  ];
}
