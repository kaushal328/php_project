<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class DeliveryNote extends Model
{
    use HasFactory, SoftDeletes;

    public function PurchaseOrder(): BelongsTo
    {
        return $this->belongsTo(PurchaseOrder::class, 'fk_po_id');
    }

    public function salesOrder(): BelongsTo
    {
        return $this->belongsTo(AvlockSalesOrder::class, 'sales_order_id');
    }

    public function quotation(): BelongsTo
    {
        return $this->belongsTo(ProjectQuotationTemp::class, 'fk_quotation_id');
    }

    public function packagingSlipDate(): BelongsTo
    {
        return $this->belongsTo(PackagingSlip::class, 'packaging_date');
    }

    public function rfq(): BelongsTo
    {
        return $this->belongsTo(Rfq::class, 'fk_rfq_id');
    }

    public function lead(): BelongsTo
    {
        return $this->belongsTo(Lead::class, 'fk_lead_id');
    }
}
