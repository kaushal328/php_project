<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Labeling extends Model
{
    use HasFactory, SoftDeletes;

    public function packagingSlip(): BelongsTo
    {
        return $this->belongsTo(PackagingSlip::class, 'packaging_slip_id');
    }

    public function packagingSlipDetail(): BelongsTo
    {
        return $this->belongsTo(PackagingSlipDetail::class, 'packaging_slip_detail_id');
    }
}
