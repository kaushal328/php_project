<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class PackagingSlip extends Model
{
    use HasFactory, SoftDeletes;

    public function PurchaseOrder(): BelongsTo
    {
        return $this->belongsTo(PurchaseOrder::class, 'fk_po_id');
    }

    public function salesOrderDate(): BelongsTo
    {
        return $this->belongsTo(AvlockSalesOrder::class, 'sales_order_date');
    }

    public function lead(): BelongsTo
    {
        return $this->belongsTo(Lead::class, 'fk_lead_id');
    }

    public function quotation(): BelongsTo
    {
        return $this->belongsTo(ProjectQuotationTemp::class);
    }

    public function rfq(): BelongsTo
    {
        return $this->belongsTo(Rfq::class, 'fk_rfq_id');
    }
}
