<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Exhibition extends Model
{
    use HasFactory, SoftDeletes;

    protected $hidden = ['deleted_at', 'created_at', 'updated_at'];

    protected $fillable = [
        'title',
        'description',
        'images',
        'city',
        'country_id',
        'contact_number',
        'contact_email',
        'venue',
        'exhibition_status',
        'start_date',
        'end_date',
        'status'
    ];

    /**
     * Get the Campaign associated with SMS Data.
     */
    public function countryName(): BelongsTo
    {
        return $this->BelongsTo(Country::class, 'country_id');
    }
}
