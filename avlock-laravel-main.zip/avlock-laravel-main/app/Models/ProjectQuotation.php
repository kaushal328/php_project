<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class ProjectQuotation extends Model
{
  use HasFactory, SoftDeletes;

  function tempQuotation(): BelongsTo
  {
    return $this->belongsTo(ProjectQuotationTemp::class, 'fk_project_quotation_temp_id');
  }

  function lead(): BelongsTo
  {
    return $this->belongsTo(Lead::class, 'fk_lead_id');
  }

  function rfq(): BelongsTo
  {
    return $this->belongsTo(Rfq::class, 'fk_rfq_id');
  }

  function salesPerson(): BelongsTo
  {
    return $this->belongsTo(User::class, 'sales_person');
  }

  function preparedBy(): BelongsTo
  {
    return $this->belongsTo(User::class, 'prepared_by');
  }
}
