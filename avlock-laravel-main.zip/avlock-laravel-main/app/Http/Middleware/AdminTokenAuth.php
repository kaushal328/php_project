<?php

namespace App\Http\Middleware;

use App\Models\User;
use App\Utils\ResponseMessageUtils;
use Closure;
use Illuminate\Http\Request;
use PHPOpenSourceSaver\JWTAuth\Exceptions\JWTException;
use PHPOpenSourceSaver\JWTAuth\Exceptions\TokenExpiredException;
use PHPOpenSourceSaver\JWTAuth\Exceptions\TokenInvalidException;
use PHPOpenSourceSaver\JWTAuth\Facades\JWTAuth;
use Symfony\Component\HttpFoundation\Response;
use Session;

class AdminTokenAuth
{

  public $response = [
    'status' => 0,
    'msg' => '',
    'error' => '',
    'errors' => [],
    'data' => [],
  ];
  /**
   * Handle an incoming request.
   *
   * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
   */
  public function handle(Request $request, Closure $next): Response
  {

    try {

      // if (!$request->header('device-id')) {
      //   $this->response['error'] = __('auth.device_id_require');
      //   return ResponseMessageUtils::sendResponse($this->response, 401);
      // }

      // if (!$request->header('latitude')) {
      //   $this->response['error'] = __('auth.lat_require');
      //   return ResponseMessageUtils::sendResponse($this->response, 401);
      // }

      // if (!$request->header('longitude')) {
      //   $this->response['error'] = __('auth.long_require');
      //   return ResponseMessageUtils::sendResponse($this->response, 401);
      // }

      // if (!$request->header('platform')) {
      //   $this->response['error'] = __('auth.platform_require');
      //   return ResponseMessageUtils::sendResponse($this->response, 401);
      // }

      $token = $request->header('access-token');
      $token = str_replace('Bearer ', '', $token);

      $user = JWTAuth::setToken($token)->getPayload();

      // You can access the authenticated user
    } catch (TokenExpiredException $e) {
      // Token has expired
      $this->response['error'] = __('auth.token_expired');

      return ResponseMessageUtils::sendResponse($this->response, 401);
    } catch (TokenInvalidException $e) {
      // Invalid token
      $this->response['error'] = __('auth.invalid_token');
      return ResponseMessageUtils::sendResponse($this->response, 401);
    } catch (JWTException $e) {
      // General exception
      $this->response['error'] = __('auth.authentication_failed');
      return ResponseMessageUtils::sendResponse($this->response, 401);
    }
    $userData = User::with('roles', 'designation')->where('id', $user['sub'])->first();

    if (empty($userData)) {
      $this->response['error'] = __('admin.user_does_not_exist');
      return ResponseMessageUtils::sendResponse($this->response, 401);
    }

    return $next($request);
  }
}
