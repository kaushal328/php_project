<?php

namespace App\Http\Middleware;

use App\Utils\ResponseMessageUtils;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Symfony\Component\HttpFoundation\Response;

class AppBasicAuth
{

  public $response = [
    'status' => 0,
    'msg' => '',
    'error' => '',
    'errors' => [],
    'data' => [],
  ];

  /**
   * Handle an incoming request.
   *
   * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
   */
  public function handle(Request $request, Closure $next): Response
  {
    $AUTH_USER = 'digi';
    $AUTH_PASS = '123456';
    header('Cache-Control: no-cache, must-revalidate, max-age=0');
    $hasSuppliedCredentials = !(empty($_SERVER['PHP_AUTH_USER']) && empty($_SERVER['PHP_AUTH_PW']));
    $isNotAuthenticated = (!$hasSuppliedCredentials ||
      $_SERVER['PHP_AUTH_USER'] != $AUTH_USER ||
      $_SERVER['PHP_AUTH_PW']   != $AUTH_PASS
    );
    if ($isNotAuthenticated) {
      $this->response['error'] = __('auth.authentication_failed');
      return ResponseMessageUtils::sendResponse($this->response, 401);
    }
    if (!$request->header('platform')) {
      $this->response['error'] = __('auth.platform_require');
      return ResponseMessageUtils::sendResponse($this->response, 401);
    }
    if (!in_array($request->header('platform'), config('global.PLATFORM'))) {
      $this->response['error'] = __('auth.invalid_platform');
    }

    if (!$request->header('device-id')) {
      $this->response['error'] = __('auth.device_id_require');
      return ResponseMessageUtils::sendResponse($this->response, 401);
    }

    if (!$request->header('latitude')) {
      $this->response['error'] = __('auth.lat_require');
      return ResponseMessageUtils::sendResponse($this->response, 401);
    }

    if (!$request->header('longitude')) {
      $this->response['error'] = __('auth.long_require');
      return ResponseMessageUtils::sendResponse($this->response, 401);
    }

    if (!$request->header('platform')) {
      $this->response['error'] = __('auth.platform_require');
      return ResponseMessageUtils::sendResponse($this->response, 401);
    }


    $lang = $request->header('Accept-Language', null);
    if (!empty($lang)) {
      App::setLocale($lang);
    }

    return $next($request);
  }
}
