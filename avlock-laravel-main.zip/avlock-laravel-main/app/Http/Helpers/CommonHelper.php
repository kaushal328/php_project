<?php

use App\Models\LoginLog;
use App\Models\NotificationHistory;
use App\Models\ProjectQuotation;
use App\Models\ProjectQuotationTemp;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderConsignee;
use App\Models\PurchaseOrderConsigneeDate;
use App\Models\PurchaseOrderDetail;
use App\Models\Rfq;
use PHPOpenSourceSaver\JWTAuth\Facades\JWTAuth;
use App\Models\User;
use App\Models\UserRole;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use GuzzleHttp\Client;
use PHPOpenSourceSaver\JWTAuth\Exceptions\JWTException;
use PHPOpenSourceSaver\JWTAuth\Exceptions\TokenExpiredException;
use PHPOpenSourceSaver\JWTAuth\Exceptions\TokenInvalidException;

if (!function_exists('readUserToken')) {
    function readUserToken()
    {

        $response = [
            'status' => 0,
            'msg' => '',
            'error' => '',
            'errors' => [],
            'data' => [],
        ];

        try {

            $token = request()->header('access-token');
            $userToken = str_replace('Bearer ', '', $token);
            $token = JWTAuth::setToken($userToken)->getPayload();
            $userCheck = User::find($token['sub'])->first();

            // You can access the authenticated user
        } catch (TokenExpiredException $e) {
            // Token has expired
            $response['error'] = __('auth.token_expired');

            return $response;
        } catch (TokenInvalidException $e) {
            // Invalid token
            $response['error'] = __('auth.invalid_token');
            return $response;
        } catch (JWTException $e) {
            // General exception
            $response['error'] = __('auth.authentication_failed');
            return $response;
        }

        if (empty($userCheck)) {
            $response['error'] = __('auth.please_login_and_try_again');
            return $response;
        }

        $response['status'] = 1;
        $response['token'] = $token;

        return $response;
    }
}

if (!function_exists('convertToCamelCase')) {
    function convertToCamelCase($str)
    {
        // Convert the string to lowercase and remove leading/trailing spaces
        $str = strtolower(trim($str));

        // Split the string into an array of words
        $words = explode(" ", $str);

        // Capitalize the first letter of each word
        $capitalizedWords = array_map(function ($word) {
            return ucfirst($word);
        }, $words);

        // Join the words back into a single string with spaces in between
        $camelCaseString = implode(" ", $capitalizedWords);

        return $camelCaseString;
    }
}

if (!function_exists('moveFile')) {
    function moveFile($toPath, $fileName)
    {
        if ($fileName) {
            $sourcePath = 'public/uploads/temp/' . $fileName;
            $destinationPath = 'public/uploads/' . $toPath . '/' . $fileName;

            if (Storage::exists($sourcePath)) {
                // Storage::makeDirectory('public/uploads/' . $toPath);
                Storage::move($sourcePath, $destinationPath);
            }
        }
    }
}

if (!function_exists('bookPostPdfContent')) {
    /**
     * Get the path to the storage folder.
     *
     * @param  string  $path
     * @return string
     */
    function bookPostPdfContent($BOOKPOSTDATA, $envelopeWidth, $envelopeHeight)
    {
        $pageWidth = 29.7;
        $pageHeight = 42;

        $pageContent = '';

        // dd($BOOKPOSTDATA->toArray());
        foreach ($BOOKPOSTDATA->toArray() as $key => $b) {
            $contact_person = $b['contact_person'] ?? '-';
            $company = $b['company'] ?? '-';

            $address_1 = $b['address_1'] ?? '';
            $address_2 = $b['address_2'] ?? '';

            $city = $b['city'] ?? '';
            $state = $b['state'] ?? '';
            $pincode = $b['pincode'] ?? '';

            $cps = $city . ' - ' . $state . ', ' . $pincode;

            $mobileNo = $b['contact_number'] ?? 'NA';

            $pageContent .= '
          <div style="width: 48%; float: ' . ($key % 2 === 0 ? 'left' : 'right') .  '; height: 16.30%;">
            <p class="content" style="text-align: left;">
              Kind Attn: ' . $contact_person .
                '<br>' . $company .
                '<br/>' . ($address_1 ? $address_1 . '<br />' : '')
                . ($address_2 ? $address_2 . '<br />' : '')
                . ($cps ? $cps . '<br />' : '') .
                'Mobile No - ' . ($mobileNo ? $mobileNo : '') . '
            </p>
          </div>';
            if ($key > 0 && $key % 2 == 1) {
                $pageContent .= '<div style="clear: both;"></div>';
            }
        }

        $htmlContent = '<html>
              <head>
              <title>Envelope PDF</title>
              <style>


                  @page {
                    size: "A4";
                  }

                  body {
                    margin-top: 0;
                    padding-top: 0;
                    font-family: sans-serif;
                    line-height: 1.4
                  }

                  .page {
                    width: 40%;
                    margin-top: 0px;
                    padding-top: 0px;
                    border: 1px solid black;
                  }

                  .header{
                    font-size: 14px;
                    font-weight: bold;
                    text-align: right;
                    margin-top: 0px;
                  }

                  .content{
                    font-size: 14px;
                    font-weight: bold;
                    text-align: right;
                    margin-top: 0px;
                    padding-top: 0px;
                  }


              </style>
              </head><body>' . $pageContent . '</body></html>';



        // foreach ($BOOKPOSTDATA as $b) {

        //   // $pageContent .= '<div class="page"><p class="header">Kind Attn:'. ( $b->designation ?? '' ) .'</p><p class="content"> To,</p><p class="content">'. ( $b->address ?? '' ) .',</p><p class="content">'. ( $b->city ?? '' ) .', '. ( $b->pincode ?? '' ) .'</p><p class="content">'. ( $b->country ?? '' ) .'</p></div>';

        //   $pageContent .= '<div class="page">
        //       <p class="content">Kind Attn:' . ($b->designation ?? '') . '<br>To,<br>' . ($b->address ?? '') . ',<br>' . ($b->city ?? '') . ', ' . ($b->pincode ?? '') . '<br>' . ($b->country ?? '') . '</p>
        //       </div>';
        // }

        // /*
        //   $envelopeHeight - 100 : blank page issue resoved after subtracting 100 px
        //   */

        // $htmlContent = '<html>
        //           <head>
        //           <title>Envelope PDF</title>
        //           <style>


        //               @page {
        //                 size: ' . $envelopeWidth . 'px ' . $envelopeHeight . 'px;
        //               }

        //               body {
        //                 margin-top: 0;
        //                 padding-top: 0;
        //               }

        //               .page {
        //                 width: ' . $envelopeWidth . 'px;
        //                 height: ' . ($envelopeHeight - 100) . 'px;
        //                 margin-top: 0px;
        //                 padding-top: 0px;
        //               }

        //               .header{
        //                 font-size: 6px;
        //                 font-weight: semi-bold;
        //                 text-align: right;
        //                 margin-top: 0px;
        //                 margin-right: 60px;
        //               }

        //               .content{
        //                 font-size: 6px;
        //                 font-weight: semi-bold;
        //                 text-align: right;
        //                 margin-top: 0px;
        //                 margin-right: 60px;
        //                 padding-top: 0px;
        //               }


        //           </style>
        //           </head><body>' . $pageContent . '</body></html>';

        // $htmlContent = trim( $htmlContent );
        // $htmlContent = preg_replace('/[\r\n]+/', '', $htmlContent);
        // $htmlContent = preg_replace('/[\n]+/', '', $htmlContent);
        // $htmlContent = preg_replace('!\s+!', ' ', $htmlContent);

        return $htmlContent;
    }
}

if (!function_exists('generateUniqueNumber')) {
    function generateUniqueNumber($lastEntryId, $prefix)
    {
        $nextId = $lastEntryId + 1;
        $randomNumber = str_pad($nextId, 12, '0', STR_PAD_LEFT);
        $uniqueNumber = $prefix  . $randomNumber;
        return $uniqueNumber;
    }
}

if (!function_exists('generateSvrNumber')) {
    function generateSvrNumber($recordCount, $prefix)
    {
        $nextId = $recordCount + 1;
        $randomNumber = str_pad($nextId, 3, '0', STR_PAD_LEFT);
        $uniqueNumber = $prefix  . $randomNumber;

        return $uniqueNumber;
    }
}


if (!function_exists('recordLoginLogs')) {
    function recordLoginLogs($logsArray = [])
    {
        if (is_array($logsArray) && !empty($logsArray)) {
            $loginLog = new LoginLog();
            $loginLog->user_id = $logsArray['user_id'] ?? 0;
            $loginLog->email = $logsArray['email'] ?? '';
            $loginLog->password = $logsArray['password'] ?? '';
            $loginLog->ip_address = $logsArray['ip_address'] ?? '';
            $loginLog->latitude = $logsArray['latitude'] ?? '';
            $loginLog->longitude = $logsArray['longitude'] ?? '';
            $loginLog->platform = $logsArray['platform'] ?? 'web';
            $loginLog->success = $logsArray['success'] ?? false;
            $loginLog->save();
        }
    }
}

if (!function_exists('generateRandomOTP')) {
    function generateRandomOTP()
    {
        return (rand(100000, 999999));
        // return (1234);
    }
}

if (!function_exists('customDecoder')) {
    function customDecoder($encrypted_str = '')
    {
        if (!$encrypted_str) return "";

        $parsedWordArray = base64_decode($encrypted_str);

        $parsedStr = utf8_decode($parsedWordArray);

        $key = 'avlock@123';
        $str = openssl_decrypt($parsedStr, 'AES-256-ECB', $key);
        return $str;
    }
}


if (!function_exists('custom_encrypt')) {
    function custom_encrypt($str)
    {
        // $iv = openssl_random_pseudo_bytes(16);
        // $encrypted = openssl_encrypt($str, 'aes-128-cbc', OPENSSL_RAW_DATA, $iv);
        // $base64 = base64_encode($iv . $encrypted);
        // return $base64;
        $a = mt_rand(1000000000, 9999999999);
        $b = mt_rand(1000000000, 9999999999);

        return $a . $str . $b;
    }
}


if (!function_exists('toSqlWithBindings')) {
    function toSqlWithBindings($query)
    {
        $bindings = $query->getBindings();
        $sql = $query->toSql();

        foreach ($bindings as $binding) {
            $value = is_numeric($binding) ? $binding : "'$binding'";
            $sql = preg_replace('/\?/', $value, $sql, 1);
        }

        return $sql;
    }
}

if (!function_exists('convertAmountToWords')) {
    function convertAmountToWords($amount, $currency = 'INR')
    {
        $no = floor($amount);
        $point = round($amount - $no, 2) * 100;
        $hundred = null;
        $digits_1 = strlen($no);
        $i = 0;
        $str = array();
        $words = array(
            '0' => '',
            '1' => 'one',
            '2' => 'two',
            '3' => 'three',
            '4' => 'four',
            '5' => 'five',
            '6' => 'six',
            '7' => 'seven',
            '8' => 'eight',
            '9' => 'nine',
            '10' => 'ten',
            '11' => 'eleven',
            '12' => 'twelve',
            '13' => 'thirteen',
            '14' => 'fourteen',
            '15' => 'fifteen',
            '16' => 'sixteen',
            '17' => 'seventeen',
            '18' => 'eighteen',
            '19' => 'nineteen',
            '20' => 'twenty',
            '30' => 'thirty',
            '40' => 'forty',
            '50' => 'fifty',
            '60' => 'sixty',
            '70' => 'seventy',
            '80' => 'eighty',
            '90' => 'ninety'
        );
        $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');

        // Convert number to words
        while ($i < $digits_1) {
            $divider = ($i == 2) ? 10 : 100;
            $number = floor($no % $divider);
            $no = floor($no / $divider);
            $i += ($divider == 10) ? 1 : 2;
            if ($number) {
                $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
                $str[] = ($number < 21) ? $words[$number] . " " . $digits[$counter] . $plural . " " . $hundred
                    : $words[floor($number / 10) * 10] . " " . $words[$number % 10] . " " . $digits[$counter] . $plural . " " . $hundred;
            } else {
                $str[] = null;
            }
        }
        $str = array_reverse($str);
        $result = implode('', $str);

        $currencyNames = [
            'INR' => ['name' => 'Rupees', 'fraction' => 'Paise'],
            'USD' => ['name' => 'Dollars', 'fraction' => 'Cents'],
            'EUR' => ['name' => 'Euros', 'fraction' => 'Cents'],
            'GBP' => ['name' => 'Pounds', 'fraction' => 'Pence']
        ];

        $currencyData = $currencyNames[strtoupper($currency)] ?? ['name' => 'Rupees', 'fraction' => 'Paise'];

        $points = ($point) ? $words[floor($point / 10)] . " " . $words[$point % 10] . " " . $currencyData['fraction'] : '';

        $amountInWords = ucwords(strtolower($result)) . ($points ? ' and ' . $points : '') . " " . $currencyData['name'] . " Only";

        return $amountInWords;
    }
}



if (!function_exists('sendFcmNotification')) {
    function sendFcmNotification($fcmIds = array(), $notificationData = array(), $reminderUserIdArray = [])
    {
        $authKey = config('global.FCM_SERVER_KEY');

        if (is_array($fcmIds) && !empty($fcmIds)) {
            $authToken = array(
                'Authorization: key=' . $authKey,
                'Content-Type: application/json'
            );

            if (is_array($fcmIds)) {
                $auth_token = $authToken;

                //FCM MSG DATA
                $dataArray['title']        = $notificationData['title'];
                $dataArray['body']         = $notificationData['body'];
                $dataArray['sound']        = "default";

                // $deviceArray = $fcmIds;
                //store fcm id to device array
                $deviceArray = array();
                foreach ($fcmIds as $key => $val) {
                    $deviceArray[] = $val;
                }

                $arrayChunkLength = 500;
                $deviceArrayChunk = array_chunk($deviceArray, $arrayChunkLength, true);
                $isPost = true;
                foreach ($deviceArrayChunk as $deviceArray) {
                    $fields = array(
                        'registration_ids' => $deviceArray,
                        'notification' => $dataArray,
                        'data'             => $dataArray,
                    );
                    $postdata = json_encode($fields);
                    $result =  fcmCallingToCurl($auth_token, $isPost, $postdata);
                }

                //storing fcm notifcation history for vendor and customer both by calling function
                storeNotificationHistory($fcmIds, $notificationData, $reminderUserIdArray);
            }
        }
    }
}

if (!function_exists('fcmCallingToCurl')) {
    function fcmCallingToCurl($auth_token, $isPost = false, $post_data = array())
    {
        $url = "https://fcm.googleapis.com/fcm/send";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        if (is_array($auth_token)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $auth_token);
        }
        if ($isPost) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
        }
        $result = curl_exec($ch);

        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        $errNoCurl = curl_errno($ch);
        curl_close($ch);

        if ($err || $errNoCurl) {
            Log::error("Fcm Curl Call has Error number " . $errNoCurl . " and Error is ::" . $err);
        } else {
            Log::error("Fcm Curl Call Success has :: " . $result);

            return $result;
        }

        // return $result;
    }
}

if (!function_exists('storeNotificationHistory')) {
    function storeNotificationHistory($fcmIds = array(), $notificationData = array(), $reminderUserIdArray = [])
    {
        //store fcm notification history


        if (!empty($reminderUserIdArray)) {
            foreach ($reminderUserIdArray as $val) {
                $id = $val;
                $currentDatetime = Carbon::now()->format('Y-m-d H:i:s');
                $notification = array();
                $i = 0;
                foreach ($fcmIds as $key => $val) {

                    $notification[$i]['user_id'] = $id;
                    $notification[$i]['device_id'] = $key;
                    $notification[$i]['title'] = $notificationData['title'];
                    $notification[$i]['body'] = $notificationData['body'];
                    $notification[$i]['notification_date'] = $currentDatetime;
                    $notification[$i]['status'] = 1;
                    $notification[$i]['created_at'] = $currentDatetime;
                    $notification[$i]['updated_at'] = $currentDatetime;
                    $i++;
                }

                NotificationHistory::insert($notification);
                Log::info("New record inserted to Notification History");
            }
        }
    }
}

if (!function_exists('getProductNameFromId')) {
    function getProductNameFromId($productList = array(), $productId = 0): string
    {
        foreach ($productList as $item) {
            if ($item->id == $productId) {
                return $item->product_name;
            }
        }
        return '';
    }
}

if (!function_exists('getParamValue')) {
    function getParamValue($valuesList = array(), $paramId = 0): string
    {
        foreach ($valuesList as $item) {
            if ($item->id == $paramId) {
                return $item->value[0] ?? '';
            }
        }
        return '';
    }
}

if (!function_exists('getPoCount')) {
    function getPoCount(): string
    {
        $modelCount = PurchaseOrder::where('status', 1)->count();
        return $modelCount;
    }
}

if (!function_exists('getPqcount')) {
    function getPqcount(): string
    {
        $modelCount = ProjectQuotation::where('status', 1)->count();
        return $modelCount;
    }
}

if (!function_exists('getRfqCount')) {
    function getRfqCount(): string
    {
        $modelCount = Rfq::where('status', 1)->count();
        return $modelCount;
    }
}

// if (!function_exists('generateSeries')) {
//     function generateSeries($prefix, $table, $column)
//     {
//         // dd($prefix);
//         // $latest = DB::table($table)->where($column, 'like', '%' . $prefix . '%')->orderBy($column, 'desc')->first();
//         $latest = DB::table($table)->where($column, 'like', "%$prefix%")->whereRaw('CAST(SUBSTRING(' . $column . ', -4) AS UNSIGNED) = (SELECT MAX(CAST(SUBSTRING(' . $column . ', -4) AS UNSIGNED))FROM ' . $table . ' WHERE ' . $column . ' LIKE "%' . $prefix . '%")')->first();

//         dd($latest);

//         dd('locha hai');

//         if (!$latest) {
//             return $prefix . '0001';
//         }

//         $latestNumber = $latest->$column;
//         $last4 = intval(substr($latestNumber, -4));

//         $nextNumber = $last4 + 1;
//         $formattedNextNumber = str_pad($nextNumber, 4, '0', STR_PAD_LEFT);

//         return $prefix . $formattedNextNumber;
//     }
// }

if (!function_exists('generateSeries')) {
    function generateSeries($prefix, $table, $column)
    {

        // $latest = DB::table($table)->where($column, 'like', '%' . $prefix . '%')->orderBy($column, 'desc')->first();
        $records = DB::table($table)->where($column, 'like', "%$prefix%")->get($column);

        $maxNumber = 0;
        foreach ($records as $record) {
            $seriesNo = $record->$column;
            $numberPart = substr($seriesNo, -4);
            $number = 0;
            if (is_numeric($numberPart)) {
                $number = intval($numberPart);
            }

            if ($number > $maxNumber) {
                $maxNumber = $number;
            }
        }

        if ($maxNumber == 0) {
            return $prefix . '0001';
        }

        $nextNumber = $maxNumber + 1;
        $formattedNextNumber = str_pad($nextNumber, 4, '0', STR_PAD_LEFT);
        return $prefix . $formattedNextNumber;
    }
}

if (!function_exists('getFormattedAddress')) {
    function getFormattedAddress($latitude, $longitude)
    {
        try {
            $client = new Client();

            $response = $client->get('https://maps.googleapis.com/maps/api/geocode/json', [
                'query' => [
                    'latlng' => $latitude . ',' . $longitude,
                    'key' => 'AIzaSyCGx_Fl0yKDXwvqekOgYiU78Th3MAWzOxE',
                ]
            ]);

            $body = json_decode($response->getBody(), true);

            if ($response->getStatusCode() == 200 && $body['status'] == 'OK') {
                return $body['results'][0]['formatted_address'];
            }
        } catch (\Exception $e) {
            Log::error("Geocoding Error: " . $e->getMessage());
            return null;
        }
    }
}

if (!function_exists('moneyFormatIndia')) {
    function moneyFormatIndia($num)
    {
        // Convert number to string and split into integer and decimal parts
        $explrestunits = "";
        $num = preg_replace('/[^0-9.]/', '', $num); // Remove any non-numeric characters
        $num = explode('.', $num); // Split by decimal point
        $restunits = $num[0]; // Integer part of the number
        $decimalpart = isset($num[1]) ? '.' . $num[1] : ''; // Decimal part of the number, if any

        // Get the last 3 digits for the first section
        $lastthree = substr($restunits, strlen($restunits) - 3);

        // Remove the last 3 digits and add commas for every two digits
        $restunits = substr($restunits, 0, strlen($restunits) - 3);
        if (strlen($restunits) > 0) {
            $explrestunits = preg_replace("/\B(?=(\d{2})+(?!\d))/", ",", $restunits);
        }

        // Combine all parts
        $formatted_number = $explrestunits . "," . $lastthree . $decimalpart;

        return $formatted_number;
    }
}

if (!function_exists('formatIndianRupees')) {
    function formatIndianRupees($number, $decimalPlaces = 2)
    {
        // Convert scientific notation to a standard decimal format
        if (strpos(strtolower($number), 'e') !== false) {
            $number = sprintf('%f', $number); // Convert to float with standard notation
        }

        $parts = explode('.', $number);
        $wholePart = $parts[0];
        $decimalPart = isset($parts[1]) ? $parts[1] : '';

        $wholePart = strrev($wholePart);
        $formattedWhole = '';
        for ($i = 0; $i < strlen($wholePart); $i++) {
            if ($i == 3) {
                $formattedWhole .= ',';
            } elseif ($i > 3 && ($i - 3) % 2 == 0) {
                $formattedWhole .= ',';
            }
            $formattedWhole .= $wholePart[$i];
        }
        $formattedWhole = strrev($formattedWhole);

        $result = $formattedWhole;
        if ($decimalPart !== '') {
            $result .= '.' . str_pad(substr($decimalPart, 0, $decimalPlaces), $decimalPlaces, '0', STR_PAD_RIGHT);
        } else {
            $result .= '.' . str_repeat('0', $decimalPlaces);
        }

        return $result;
    }
}


if (!function_exists('getUsdToInrRate')) {
    function getUsdToInrRate()
    {
        try {
            $url = "https://api.freecurrencyapi.com/v1/latest?apikey=fca_live_Kyy0bFHX81dLvqBqRdxXp6jOhn3awKOXZbUaeM6R&currencies=INR";

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            $result = curl_exec($ch);

            $err = curl_error($ch);
            $errNoCurl = curl_errno($ch);
            curl_close($ch);

            if ($err || $errNoCurl) {
                Log::error("getUsdToInrRate has Error number " . $errNoCurl . " and Error is ::" . $err);
                return ['error' => "Something went wrong! Please contact support."];
            } else {
                $usdToInrRate = json_decode($result)->data->INR ?? null;
                if (!$usdToInrRate) {
                    return ['error' => "Something went wrong! Please contact support."];
                }
                return ['data' => $usdToInrRate];
            }
        } catch (Exception $e) {
            return ['error' => "Something went wrong! Please contact support."];
        }
    }

    if (!function_exists('getCurrencyToInrRate')) {
        function getCurrencyToInrRate($currency)
        {
            try {
                // Modify the URL to accept the dynamic currency input
                $url = "https://api.freecurrencyapi.com/v1/latest?apikey=fca_live_Kyy0bFHX81dLvqBqRdxXp6jOhn3awKOXZbUaeM6R&currencies=INR&base_currency=" . strtoupper($currency);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

                $result = curl_exec($ch);

                $err = curl_error($ch);
                $errNoCurl = curl_errno($ch);
                curl_close($ch);

                if ($err || $errNoCurl) {
                    Log::error("getCurrencyToInrRate has Error number " . $errNoCurl . " and Error is ::" . $err);
                    return ['error' => "Something went wrong! Please contact support."];
                } else {
                    $currencyToInrRate = json_decode($result)->data->INR ?? null;
                    if (!$currencyToInrRate) {
                        return ['error' => "Something went wrong! Please contact support."];
                    }
                    return ['data' => $currencyToInrRate];
                }
            } catch (Exception $e) {
                return ['error' => "Something went wrong! Please contact support."];
            }
        }
    }

    // function getDivisionHead($userId = '', $departmentId = '')
    // {
    //     if (!$userId || !$departmentId) return null;

    //     $userDetails = User::find($userId);
    //     if (!$userDetails) return null;

    //     $departmentHeads = UserRole::where('fk_department_id', $departmentId)->where('fk_department_type_id', 1)->get()->toArray();

    //     $departmentHeadsUserIds = array_column($departmentHeads, 'fk_user_id');

    //     $userDivisions = explode(',', $userDetails->toArray()['division_ids']);

    //     $users = [];

    //     foreach ($userDivisions as $divisionId) {
    //         $departmentHeadUsers = User::whereIn('id', $departmentHeadsUserIds)->whereRaw("FIND_IN_SET(?, division_ids) > 0", [$divisionId])->get();

    //         $users = array_merge($users, $departmentHeadUsers->toArray());
    //     }

    //     return $users;
    // }

    function updateDescriptionFromPartDescription()
    {
        $quotations = ProjectQuotationTemp::all();

        foreach ($quotations as $quotation) {
            if (!empty($quotation->requirements)) {
                $requirements = json_decode($quotation->requirements, true);

                if (is_array($requirements)) {
                    $updated = false;

                    foreach ($requirements as &$requirement) {
                        if (!empty($requirement['partDescription'])) {
                            $requirement['description'] = $requirement['partDescription'];
                            $updated = true;
                        }
                    }

                    if ($updated) {
                        $quotation->requirements = json_encode($requirements);
                        $quotation->save();
                    }
                }
            }
        }

        return "Descriptions updated successfully.";
    }

    function updateTenderPoDetails()
    {
        $tenderPos = PurchaseOrder::where('po_type', 2)->get();

        foreach ($tenderPos as $tpo) {
            $exists = PurchaseOrderDetail::where('fk_po_id', $tpo->id)->exists();
            if ($exists) {
                continue;
            }

            $poDetails = json_decode($tpo->po_details, true);
            foreach ($poDetails as $pd) {
                $poDetailObj = new PurchaseOrderDetail();
                $poDetailObj->fk_po_id = $tpo->id ?? null;
                $poDetailObj->product_part_id = $pd['product_part_id'] ?? null;
                $poDetailObj->part_no = $pd['part_no'] ?? null;
                $poDetailObj->qty = $pd['qty'] ?? null;
                $poDetailObj->description = $pd['description'] ?? null;
                $poDetailObj->avlock_description = $pd['avlock_description'] ?? null;
                $poDetailObj->rate = $pd['rate'] ?? null;
                $poDetailObj->basic_value = $pd['basic_value'] ?? null;
                $poDetailObj->save();
                $lastPoDetailId = $poDetailObj->id;

                foreach ($pd['consignees'] as $consignee) {
                    $poConObj = new PurchaseOrderConsignee();
                    $poConObj->fk_po_id = $tpo->id ?? null;
                    $poConObj->purchase_order_detail_id = $lastPoDetailId ?? null;
                    $poConObj->name = $consignee['name'] ?? null;
                    $poConObj->qty = $consignee['qty'] ?? null;
                    $poConObj->unit = $consignee['unit'] ?? null;
                    $poConObj->delivery_period = $consignee['delivery_period'] ?? null;
                    $poConObj->basic_value = $consignee['basic_value'] ?? null;
                    $poConObj->save();
                    $lastConId = $poConObj->id;

                    if (!empty($consignee['consigneesDates']) && is_array($consignee['consigneesDates'])) {
                        foreach ($consignee['consigneesDates'] as $conDate) {
                            $conDateObj = new PurchaseOrderConsigneeDate();
                            $conDateObj->fk_po_id = $tpo->id ?? null;
                            $conDateObj->purchase_order_detail_id = $lastPoDetailId ?? null;
                            $conDateObj->purchase_order_consignee_id = $lastConId ?? null;
                            $conDateObj->delivery_start_date = Carbon::createFromFormat('d/m/Y', $conDate['delivery_start_date']);
                            $conDateObj->delivery_end_date = Carbon::createFromFormat('d/m/Y', $conDate['delivery_end_date']);
                            $conDateObj->qty = $conDate['qty'] ?? null;
                            $conDateObj->save();
                        }
                    }
                }
            }
        }
    }


    function updateTotalBasicValueInInr()
    {
        set_time_limit(600);

        $errors = [];
        $quotationsQuery = ProjectQuotationTemp::with('rfq.currencyData');

        $quotationsQuery->chunk(100, function ($quotations) use (&$errors) {
            foreach ($quotations as $quotation) {
                try {
                    if (!empty($quotation->total_basic_value)) {
                        $totalBasicValue = $quotation->total_basic_value;
                        $currency = optional($quotation->rfq)->currencyData->title ?? null;

                        if ($currency) {
                            $currencyToInrRateResponse = getCurrencyToInrRate($currency);

                            if (isset($currencyToInrRateResponse['data'])) {
                                $currencyToInrRate = $currencyToInrRateResponse['data'];
                                $totalBasicValueInInr = $totalBasicValue * floatval($currencyToInrRate);
                            } else {
                                $totalBasicValueInInr = $totalBasicValue;
                            }
                        } else {
                            $totalBasicValueInInr = $totalBasicValue;
                        }

                        $quotation->total_basic_value_in_inr = $totalBasicValueInInr;
                        $quotation->save();
                    }
                } catch (Exception $e) {
                    $errors[] = "Error processing quotation ID: {$quotation->id} - " . $e->getMessage();
                }
            }
        });

        return [
            'message' => "Basic Value update process completed",
            'errors' => $errors
        ];
    }


    function updatePoTotalBasicValueInInr()
    {
        set_time_limit(600);

        $errors = [];
        $quotationsQuery = PurchaseOrder::with('rfq.currencyData');

        $quotationsQuery->chunk(100, function ($quotations) use (&$errors) {
            foreach ($quotations as $quotation) {
                try {
                    if (!empty($quotation->po_details_total)) {
                        $serviceTotal = $quotation->service_total;
                        $poDetailTotal = $quotation->po_details_total;
                        $totalBasicValue = $serviceTotal + $poDetailTotal;
                        $currency = optional($quotation->rfq)->currencyData->title ?? null;

                        if ($currency) {
                            $currencyToInrRateResponse = getCurrencyToInrRate($currency);

                            if (isset($currencyToInrRateResponse['data'])) {
                                $currencyToInrRate = $currencyToInrRateResponse['data'];
                                $totalBasicValueInInr = $totalBasicValue * floatval($currencyToInrRate);
                            } else {
                                $totalBasicValueInInr = $totalBasicValue;
                            }
                        } else {
                            $totalBasicValueInInr = $totalBasicValue;
                        }

                        $quotation->total_basic_value = $totalBasicValue;
                        $quotation->total_basic_value_in_inr = $totalBasicValueInInr;
                        $quotation->save();
                    }
                } catch (Exception $e) {
                    $errors[] = "Error processing quotation ID: {$quotation->id} - " . $e->getMessage();
                }
            }
        });

        return [
            'message' => "Basic Value update process completed",
            'errors' => $errors
        ];
    }


    function updateQtnTotalBasicValueInInr()
    {
        set_time_limit(600);

        $errors = [];
        $quotationsQuery = new ProjectQuotationTemp();

        $quotationsQuery->chunk(100, function ($quotations) use (&$errors) {
            foreach ($quotations as $quotation) {
                try {
                    if (!empty($quotation->total_basic_value)) {
                        $serviceTotal = $quotation->service_total;
                        $totalBasicValue = $quotation->total_basic_value;
                        $finalBasicValue = $serviceTotal + $totalBasicValue;
                        $quotation->total_basic_value = $finalBasicValue;
                        $quotation->save();
                    }
                } catch (Exception $e) {
                    $errors[] = "Error processing quotation ID: {$quotation->id} - " . $e->getMessage();
                }
            }
        });

        return [
            'message' => "Basic Value update process completed",
            'errors' => $errors
        ];
    }





    function getDivisionHead($divisionId = '', $departmentId = '',  $onlyHeads = true)
    {
        $departmentHeads = UserRole::where('fk_department_id', $departmentId)
            ->when($onlyHeads, function ($q) {
                $q->whereIn('fk_department_type_id', [1, 6]);
            })
            ->get()->toArray();

        $departmentHeadsUserIds = array_column($departmentHeads, 'fk_user_id');
        $departmentHeadUsers = User::whereIn('id', $departmentHeadsUserIds)->whereRaw("FIND_IN_SET(?, division_ids) > 0", [$divisionId])->get()->toArray();

        return $departmentHeadUsers;
    }
}
