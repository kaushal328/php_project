<?php

namespace App\Http\Controllers\Test;

use App\Http\Controllers\Controller;
use App\Models\Rfq;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class EmailController extends Controller
{
    function index(Request $request)
    {
        $mailData = [];
        $userObject = [];

        Mail::send('mail_templates.stage_change', $mailData, function ($mail) use ($userObject) {
            $mail->subject('Avlock Alert');
            $mail->to('altamash.digiinterface@gmail.com');
        });
    }
}
