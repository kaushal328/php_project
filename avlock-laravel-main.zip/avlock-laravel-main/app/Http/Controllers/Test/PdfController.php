<?php

namespace App\Http\Controllers\Test;

use App\Http\Controllers\Controller;
use App\Http\Resources\DeliveryNoteResource;
use App\Http\Resources\ProjectQuotationResource;
use App\Http\Resources\PurchaseInvoiceResource;
use App\Http\Resources\PurchaseOrderResource;
use App\Http\Resources\RfqFillDetailsResource;
use App\Http\Resources\SalesOrderResource;
use App\Http\Resources\TenderPurchaseOrderResource;
use App\Http\Resources\TenderQuotationResource;
use App\Models\AvlockPurchaseInvoice;
use App\Models\AvlockSalesOrder;
use App\Models\DeliveryNote;
use App\Models\EwayBill;
use App\Models\ProjectQuotationTemp;
use App\Models\PurchaseOrder;
use App\Models\Rfq;
use App\Models\Labeling;
use App\Models\Lead;
use App\Models\LeadAddresses;
use App\Models\LeadContactPeople;
use App\Models\PackagingSlip;
use App\Models\PackagingSlipDetail;
use App\Models\Product;
use App\Models\ProductPart;
use App\Models\SalesVisitReport;
use App\Http\Resources\SalesVisitReportResource;
use App\Http\Resources\TabulationResource;
use App\Models\Tabulation;
use App\Models\TenderBidding;
use App\Models\TenderPurchaseOrder;
use App\Models\TenderPurchaseOrderRn;
use App\Models\TenderQuotation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Spatie\LaravelPdf\Facades\Pdf;
use Spatie\LaravelPdf\Enums\Format;
use function Spatie\LaravelPdf\Support\pdf;

class PdfController extends Controller
{
    function quotation()
    {
        $quotationId = 1029; // From project_quotation_temps table

        $quotationObject = ProjectQuotationTemp::with('salesPerson.designation', 'rfq.leadContactPeople', 'preparedBy', 'lead.source', 'rfq.source', 'rfq.currencyData', 'rfq.designation')->find($quotationId);

        $quotation = new ProjectQuotationResource($quotationObject);

        $details = json_decode(json_encode($quotation));

        if ($details->rfq->division_id == 1) { // HE
            $view = 'pdf.quotation.he';
        } else if ($details->rfq->division_id == 2) { // LE
            $view = 'pdf.quotation.le';
        } else if ($details->rfq->division_id == 4) { // SFC
            $view = 'pdf.quotation.sfc';
        } else if ($details->rfq->division_id == 5) { // AD
            $view = 'pdf.quotation.ad';
        } else { // All others
            $view = 'pdf.quotation.le';
        }

        return view($view, ['details' => $details]);

        return pdf()
            ->view($view, ['details' => $details])
            ->format(Format::A4)
            ->margins(10, 10, 10, 10)
            ->name($details->quotation_no . '.pdf')
            ->header(view('header', ['details' => $details]))
            ->footer(view('pdf.quotation.footer', ['details' => $details]));

        // $pdf = Pdf::loadView('pdf.quotation.le', ['details' => $details]);
        // return $pdf->download('invoice.pdf');

        // save('/storage/app/public/uploads/pdf/quotation.pdf');
    }

    function rfq()
    {
        ini_set('memory_limit', '512000000');

        $rfqId = 3222;

        $detailsResource = Rfq::with(['banner', 'lead', 'product', 'rfqResponse', 'designation'])->find($rfqId);

        if (!$detailsResource) {
            echo "RFQ not found";
            return;
        }

        $details = new RfqFillDetailsResource($detailsResource);

        $details = json_decode(json_encode($details));

        return view('pdf.rfq.view', ['details' => $details]);

        return pdf()
            ->view('pdf.rfq.view', ['details' => $details])
            ->format(Format::A4)
            ->margins(10, 10, 10, 10)
            ->name($details->rfq_number . '.pdf');

        // Pdf::view('pdf.rfq.view', ['details' => $details])
        //     ->format(Format::A4)
        //     ->margins(10, 10, 10, 10)
        //     ->save(storage_path('app/public/uploads/pdf/rfq/' . str_replace(['/', '-'], '', $details->rfq_number) . '.pdf'));
    }

    public function po(Request $request)
    {
        try {

            $poId = $request->po_id ?? '';
            $viewPdf = $request->view_pdf;

            $poDetails = PurchaseOrder::with(['quotation', 'preparedBy', 'lead', 'rfq', 'rfq.banner', 'rfq.footer', 'rfq.designation', 'rfq.source'])->find(52);
            $detail = new PurchaseOrderResource($poDetails);

            $data = json_decode(json_encode($detail));

            return view('pdf.po.view', ['details' => $data]);

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "Purchase Order Pdf"]);
                $this->response['data']['html'] = view('pdf.po.view', ['details' => $data['details']])->render();

                return $this->sendResponse($this->response, 200);
            }

            $path = 'pdf/po/' . str_replace(['-', '/'], '', $poDetails->po_no) . '.pdf';


            MyPdf::view('pdf.po.view', ['details' => $data['details']])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Purchase Order Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Purchase Order pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function label()
    {
        $labelId = 1;

        $labelObject = Labeling::with(['PurchaseOrder'])->find($labelId);

        $details = json_decode(json_encode($labelObject));
        $view = 'pdf.dispatch.view';

        return view($view, ['details' => $details]);

        return pdf()
            ->view($view, ['details' => $details])
            ->format(Format::A4)
            ->margins(10, 10, 10, 10)
            ->name('Label.pdf');
    }

    function usdToInr()
    {
        $usdToInrRateResponse = getUsdToInrRate();
        if (isset($usdToInrRateResponse['error']) && !empty($usdToInrRateResponse['error'])) {
            echo $usdToInrRateResponse['error'];
            exit();
        }

        $usdToInrRate = json_decode($usdToInrRateResponse['data'])->data->INR;

        dd($usdToInrRate);
    }

    function addressTest()
    {
        $leads = Lead::get();

        $noInLeadIds = [];

        foreach ($leads as $key => $lead) {
            $leadInAddress = LeadAddresses::where('address1', $lead->address1)->where('lead_id', $lead->id)->first();

            // if (!$leadInAddress) dd($lead->id);

            if (!$leadInAddress) {
                $leadAddress = new LeadAddresses();
                $leadAddress->lead_id = $lead->id;
                $leadAddress->address1 = $lead->address1;
                $leadAddress->address2 = $lead->address2;
                $leadAddress->city = $lead->city;
                $leadAddress->pincode = $lead->pincode;
                $leadAddress->state = $lead->state;
                $leadAddress->shipping_address1 = $lead->address1;
                $leadAddress->shipping_address2 = $lead->address2;
                $leadAddress->shipping_city = $lead->city;
                $leadAddress->shipping_pincode = $lead->pincode;
                $leadAddress->shipping_state = $lead->state;
                $leadAddress->is_shipping_same = 1;
                $leadAddress->is_default = 1;
                $leadAddress->save();


                $newLeadAddressId = $leadAddress->id;

                $leadInContact = LeadContactPeople::where('customer_name', $lead->customer_name)->where('lead_id', $lead->id)->first();

                if (!$leadInContact) {
                    $leadContactPerson = new LeadContactPeople();
                    $leadContactPerson->lead_id = $lead->id;
                    $leadContactPerson->lead_address_id = $newLeadAddressId;
                    $leadContactPerson->monogram = $lead->monogram;
                    $leadContactPerson->customer_name = $lead->customer_name;
                    $leadContactPerson->designations = $lead->designations;
                    $leadContactPerson->email = $lead->email;
                    $leadContactPerson->alt_email_one = $lead->alt_email_one;
                    $leadContactPerson->alt_email_two = $lead->alt_email_two;
                    $leadContactPerson->contact_no = $lead->contact_no;
                    $leadContactPerson->alt_contact_one = $lead->alt_contact_one;
                    $leadContactPerson->alt_contact_two = $lead->alt_contact_two;
                    $leadContactPerson->save();
                }
            }
        }
    }

    public function downloadPackagingPdf(Request $request)
    {
        $id = 13; // Consider making this dynamic based on the request
        $viewPdf = $request->view_pdf;
        $mainView = 'mainView';

        $transformPsdObj = [];
        if (!empty($mainView)) {
            $psdObj = PackagingSlipDetail::with(['packagingSlip.lead', 'packagingSlip.salesOrderDate', 'packagingSlip.rfq'])->where('packaging_slip_id', $id)->get();

            foreach ($psdObj as $value) {
                $productPartIds = !empty($value->product_part_ids) ? explode(',', $value->product_part_ids) : [];
                $productParts = ProductPart::whereIn('id', $productPartIds)->pluck('part_no')->filter() ?? '';
                $productPartNames = $productParts->isNotEmpty() ? $productParts->implode(', ') : '';
                $labels = [];
                $labelings = Labeling::where('packaging_slip_detail_id', $value->id)->get() ?? [];
                foreach ($labelings as $labelItem) {
                    $labels[] = [
                        'qty' => $labelItem->qty ?? 0,
                        'no_of_carton' => $labelItem->no_of_carton ?? 0,
                        'total_qty' => $labelItem->total_qty ?? 0,
                        'weight_carton' => $labelItem->weight_carton ?? 0,
                        'total_weight' => $labelItem->total_weight ?? 0,
                    ];
                }
                $batchNo = $value->batch_no ?? '';
                $transformPsdObj[] = [
                    'part_no' => $productPartNames,
                    'batch_no' => $batchNo,
                    'labels' => $labels,
                ];
            }

            $packagingSlipObj = PackagingSlip::with(['lead', 'rfq', 'PurchaseOrder', 'salesOrderDate'])->where('id', $id)->first();
        }

        if (empty($mainView)) {
            $labelObj = Labeling::with(['packagingSlipDetail'])->find($id);
            if ($labelObj) {
                $productPartIds = !empty($labelObj->packagingSlipDetail->product_part_ids) ? explode(',', $labelObj->packagingSlipDetail->product_part_ids) : [];
                $productParts = ProductPart::whereIn('id', $productPartIds)->get(['part_no', 'description']);
                $productPartNames = $productParts->isNotEmpty() ? $productParts->map(function ($part) {
                    return $part->part_no;
                })->implode(', ') : '';

                $descriptionList = $productParts->isNotEmpty()
                    ? $productParts->map(function ($part) {
                        return $part->description;
                    })->implode(', ')
                    : '';
            }
        }

        $totalCartons = 0;
        $totalQty = 0;
        $totalWeight = 0;

        $totalCartons = array_sum(array_map(function ($item) {
            return array_sum(array_column($item['labels'], 'no_of_carton'));
        }, $transformPsdObj));

        $totalQty = array_sum(array_map(function ($item) {
            return array_sum(array_column($item['labels'], 'total_qty'));
        }, $transformPsdObj));

        $totalWeight = array_sum(array_map(function ($item) {
            return array_sum(array_column($item['labels'], 'total_weight'));
        }, $transformPsdObj));

        $data = [
            'poDispatchDetail' => $transformPsdObj,
            'details' => $packagingSlipObj ?? [],
            'labelProductPartNames' => $productPartNames ?? [],
            'labelDescriptionLists' => $descriptionList ?? '',
            'labels' => $labelObj ?? [],
            'totalCartons' => $totalCartons,
            'totalQty' => $totalQty,
            'totalWeight' => $totalWeight
        ];


        $view = ($mainView == 'mainView') ? 'pdf.dispatch.main_view' : 'pdf.dispatch.view';
        return view($view, $data);

        return pdf()
            ->view($view, $data)
            ->format(Format::A4)
            ->margins(10, 10, 10, 10)
            ->name('label.pdf');
    }

    // function invoice()
    // {
    //   $invoiceId = 1;

    //   $labelObject = AvlockPurchaseInvoice::with(['po', 'lead', 'rfq'])->find($invoiceId);

    //   $details = json_decode(json_encode($labelObject));
    //   $view = 'pdf.dispatch.invoice_view';

    //   return view($view, ['details' => $details]);

    //   return pdf()
    //     ->view($view, ['details' => $details])
    //     ->format(Format::A4)
    //     ->margins(10, 10, 10, 10)
    //     ->name('Label.pdf');
    // }

    // function delivery()
    // {
    //   $invoiceId = 1;

    //   $labelObject = DeliveryNote::with(['PurchaseOrder', 'rfq', 'lead'])->find($invoiceId);

    //   $details = json_decode(json_encode($labelObject));
    //   $view = 'pdf.dispatch.delivery_note_view';

    //   return view($view, ['details' => $details]);

    //   return pdf()
    //     ->view($view, ['details' => $details])
    //     ->format(Format::A4)
    //     ->margins(10, 10, 10, 10)
    //     ->name('Label.pdf');
    // }

    function tender()
    {
        $deliveryNoteId = $request->dn_id;
        $deliveryObject = DeliveryNote::with(['PurchaseOrder', 'rfq', 'lead'])->find($deliveryNoteId);

        $details = json_decode(json_encode($deliveryObject));

        $view = 'pdf.dispatch.delivery_note_view';

        return view($view, ['details' => $details]);

        return pdf()
            ->view($view, ['details' => $details])
            ->format(Format::A4)
            ->margins(10, 10, 10, 10)
            ->name('Label.pdf');
    }

    public function delivery(Request $request)
    {
        try {

            $deliveryNoteId = 8;
            $viewPdf = $request->view_pdf;
            $deliveryObject = DeliveryNote::with(['PurchaseOrder', 'salesOrder', 'rfq', 'rfq.currencyData', 'lead'])->find($deliveryNoteId);
            $details = new DeliveryNoteResource($deliveryObject);
            $details = json_decode(json_encode($details));
            $view = 'pdf.dispatch.delivery_note_view';

            return view($view, ['details' => $details]);

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Delivery Note"]);
            $this->response['data']['html'] = view($view, ['details' => $details])->render();
            return $this->sendResponse($this->response, 200);

            $path = 'pdf/dispatch/' . str_replace(['-', '/'], '', $deliveryObject->delivery_note_no) . '.pdf';

            MyPdf::view($view, ['details' => $details])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Delivery Note Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Delivery Note pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function invoice(Request $request)
    {
        try {

            $invoiceId = 4;
            $viewPdf = $request->view_pdf;
            $invoiceObject = AvlockPurchaseInvoice::with(['po', 'rfq.banner', 'rfq.footer', 'rfq.currencyData', 'deliveryNoteDate'])->find($invoiceId);
            $details = new PurchaseInvoiceResource($invoiceObject);

            $details = json_decode(json_encode($details));
            $view = 'pdf.dispatch.invoice_view';

            return view($view, ['details' => $details]);

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "Invoice"]);
                $this->response['data']['html'] = view($view, ['details' => $details])->render();
                return $this->sendResponse($this->response, 200);
            }

            $path = 'pdf/dispatch/' . str_replace(['-', '/'], '', $invoiceObject->invoice_no) . '.pdf';

            MyPdf::view($view, ['details' => $details])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Invoice Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Invoice pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    public function eWayBill(Request $request)
    {
        try {

            $poId = $request->id ?? '';
            $viewPdf = $request->view_pdf;

            $poDetails = EwayBill::with(['lead', 'rfq', 'rfq.banner', 'rfq.footer', 'rfq.designation', 'invoiceDate'])->find(19);
            $deliveryObj = DeliveryNote::find($poDetails->delivery_note_date);
            $psdObject = PackagingSlipDetail::with('PackagingSlip')
                ->where('packaging_slip_id', $deliveryObj->packaging_date)
                ->first();

            $poObject = PurchaseOrder::where('id', $psdObject->packagingSlip->fk_po_id)
                ->whereRaw('JSON_CONTAINS(po_details, JSON_OBJECT("product_part_id", ?), "$")', [$psdObject->product_part_id])
                ->get();

            dd($poObject);

            $data = json_decode(json_encode($poDetails));

            return view('pdf.dispatch.e_way_bill_view', ['details' => $data]);

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.created', ['module' => "E-Way Bill Pdf"]);
                $this->response['data']['html'] = view('pdf.po.view', ['details' => $data['details']])->render();

                return $this->sendResponse($this->response, 200);
            }

            $path = 'pdf/po/' . str_replace(['-', '/'], '', $poDetails->po_no) . '.pdf';


            MyPdf::view('pdf.po.view', ['details' => $data['details']])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.created', ['module' => "E-Way Bill"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Purchase Order pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function salesOrder(Request $request)
    {
        try {

            $salesOrderId = 12;
            $viewPdf = $request->view_pdf;
            $salesOrderObject = AvlockSalesOrder::with(['po', 'rfq.banner', 'rfq.footer', 'rfq.currencyData', 'lead'])->find($salesOrderId);
            $detail = new SalesOrderResource($salesOrderObject);
            $details = json_decode(json_encode($detail));
            $view = 'pdf.dispatch.sales_order_view';

            return view($view, ['details' => $details]);

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "Delivery Note"]);
                $this->response['data']['html'] = view($view, ['details' => $details])->render();
                return $this->sendResponse($this->response, 200);
            }
            $path = 'pdf/dispatch/' . str_replace(['-', '/'], '', $salesOrderObject->so_no) . '.pdf';

            MyPdf::view($view, ['details' => $details])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Delivery Note Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Delivery Note pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function downloadPdfTender(Request $request)
    {
        try {

            $poId = 1374;
            $viewPdf = 1;

            $poObject = PurchaseOrder::with('tenderQuotation', 'subStage', 'preparedBy', 'tender.division')->find($poId);
            $detail = new TenderPurchaseOrderResource($poObject);
            $data = [
                'details' => json_decode(json_encode($detail)),
            ];

            $view = 'pdf.tender.tender_po';


            return view($view, ['details' => $data['details']]);

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "Purchase Order Pdf"]);
                $this->response['data']['html'] = view($view, ['details' => $data['details']])->render();

                return $this->sendResponse($this->response, 200);
            }

            $path = 'pdf/po/' . str_replace(['-', '/'], '', $poDetails->po_no) . '.pdf';

            MyPdf::view('pdf.po.view', ['details' => $data['details']])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Purchase Order Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Purchase Order pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function tenderQuotation()
    {
        ini_set('memory_limit', '512000000');

        $rfqId = 39;

        $detailsResource = TenderBidding::with(['tender'])->find($rfqId);

        if (!$detailsResource) {
            echo "RFQ not found";
            return;
        }

        $details = new TenderQuotationResource($detailsResource);

        $details = json_decode(json_encode($details));

        return view('pdf.tender.view', ['details' => $details]);

        return pdf()
            ->view('pdf.tender.view', ['details' => $details])
            ->format(Format::A4)
            ->margins(10, 10, 10, 10)
            ->name($details->quotation_no . '.pdf');

        // Pdf::view('pdf.rfq.view', ['details' => $details])
        //     ->format(Format::A4)
        //     ->margins(10, 10, 10, 10)
        //     ->save(storage_path('app/public/uploads/pdf/rfq/' . str_replace(['/', '-'], '', $details->rfq_number) . '.pdf'));
    }


    function tenderTabulation()
    {
        ini_set('memory_limit', '512000000');

        $tabId = 102;

        $detailsResource = Tabulation::with(['tender'])->find($tabId);

        if (!$detailsResource) {
            echo "Tabulation not found";
            return;
        }

        $details = new TabulationResource($detailsResource);

        $details = json_decode(json_encode($details));

        return view('pdf.tender.tabulation', ['details' => $details]);

        return pdf()
            ->view('pdf.tender.view', ['details' => $details])
            ->format(Format::A4)
            ->margins(10, 10, 10, 10)
            ->name($details->quotation_no . '.pdf');

        // Pdf::view('pdf.rfq.view', ['details' => $details])
        //     ->format(Format::A4)
        //     ->margins(10, 10, 10, 10)
        //     ->save(storage_path('app/public/uploads/pdf/rfq/' . str_replace(['/', '-'], '', $details->rfq_number) . '.pdf'));
    }

    public function svrPdf(Request $request)
    {
        try {

            $id = 1306;
            $viewPdf = 1;
            $svr = SalesVisitReport::with('reportSalesPerson', 'division:id,name', 'leadContactPeople:id,customer_name,email,contact_no', 'product', 'state:id,name', 'city:id,name', 'activityType:id,title', 'lead.designation', 'lead.source', 'lead.region', 'rfq.lead')->find($id);

            $details = new SalesVisitReportResource($svr);

            $details = json_decode(json_encode($details));

            // $timestamp = now()->timestamp;
            $fileName = $svr->report_no . '.pdf';

            $view = 'pdf.svrPdf';

            return view($view, ['details' => $details]);

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "Sales Visit Report Pdf"]);
                $this->response['data']['html'] = view($view, ['details' => $data['details']])->render();

                return $this->sendResponse($this->response, 200);
            }

            $path = 'pdf/' . $fileName;

            MyPdf::view('pdf.po.view', ['details' => $data['details']])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));


            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Sales visit Report Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Sales Visit Report Generation Failed: " . $e->getLine());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }
}
