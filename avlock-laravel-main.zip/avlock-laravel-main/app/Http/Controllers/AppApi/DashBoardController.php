<?php

namespace App\Http\Controllers\AppApi;

use App\Http\Controllers\API\AppBaseController;
use Carbon\Carbon;
use App\Models\Task;
use App\Models\Activity;
use App\Models\SalesVisitReport;
use App\Models\Lead;
use App\Models\Rfq;
use App\Models\User;
use App\Models\LoginLog;
use Illuminate\Http\Request;
use App\Events\TaskLogCreated;
use Illuminate\Support\Facades\Log;
use App\Http\Resources\StatusResource;
use App\Http\Resources\ActivityResource;
use App\Http\Resources\SalesVisitReportResource;
use App\Http\Resources\LeadResource;
use App\Http\Resources\RfqListResource;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\ProjectLogResource;
use App\Models\ProjectLog;
use App\Models\UserAttendance;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class DashBoardController extends AppBaseController {

  public function index(Request $request) {
    try {

      if (!$this->isUserRSM) {
        $this->response['error'] = "You Are Not RSM User";
        return $this->sendResponse($this->response, 401);
      }

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $activity = Activity::with('taskType', 'lead', 'rfq')
        ->where('fk_user_id', $this->userId)
        ->orderBy('id', 'desc')->take(5)->get();

      $task = Task::with('statuses', 'taskType', 'lead', 'rfq');
      $task->whereHas('assignedToUsers', function ($query) {
        $query->where('created_by', $this->userId);
        $query->orWhere('fk_user_id', $this->userId);
      });
      $task->orderBy("id", "desc")->take(5)->get();

      $listArray = [
        'tasks' => $task,
        'activities' => ActivityResource::collection($activity),
      ];

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Dashboard Data"]);
      $this->response['data']['list'] = $listArray;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Activity fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function taskList(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $perPage = (isset($request->perPage) && $request->perPage != 'undefined') ? intval($request->perPage) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $perPage;

      $title = $request->title ?? '';

      // $status = Task::orWhere('fk_user_id', $this->userId )->orWhere('created_by', $this->userId )->with('statuses', 'taskType', 'lead', 'rfq')->orderBy("id", "desc");
      $status = Task::with('statuses', 'taskType', 'lead', 'rfq')->orderBy("id", "desc");

      if (!$this->isUserAdmin) {
        $status->where('created_by', $this->userId);
        $status->whereHas('assignedToUsers', function ($query) {
          $query->orWhere('fk_user_id', $this->userId);
        });
      }

      $numRows = $status->count();
      $status = $status->limit($perPage)->offset($offset)->get();

      if ($title) {
        $status->where('title', 'like', '%' . $title . '%');
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Task"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $perPage;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $perPage ? 1 : ceil($numRows / $perPage);
      $this->response['data']['title'] = $title;
      $this->response['data']['list'] = StatusResource::collection($status);
      $this->response['data']['events'] = StatusResource::collection($status);

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Task fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function taskStatList(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }


      $status = Task::where('fk_status_id', 1);
      $pendingTask = $status->count();

      $status = Task::where('fk_status_id', 2);
      $assignTask = $status->count();

      $status = Task::where('fk_status_id', 3);
      $declineTask = $status->count();

      $status = Task::where('fk_status_id', 4);
      $inprocTask = $status->count();

      $status = Task::where('fk_status_id', 4);
      $complTask = $status->count();

      $list = ['pendingTask' => $pendingTask, 'assignTask' => $assignTask, 'declineTask' => $declineTask, 'inprocTask' => $inprocTask, 'complTask' => $complTask];

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Task"]);
      $this->response['data']['page'] = 1;
      $this->response['data']['per_page'] = 5;
      $this->response['data']['num_rows'] = 0;
      $this->response['data']['total_pages'] = 0;
      $this->response['data']['list'] = $list;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Task fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function activityList(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';
      $start = $request->start ?? '';
      $end = $request->end ?? '';
      $taskType = $request->taskType ?? '';

      // $activity = Activity::orWhere('fk_user_id', $this->userId )->orWhere('created_by', $this->userId )->with('taskType', 'lead', 'rfq');
      $activity = Activity::with('taskType', 'lead', 'rfq', 'user');
      if (!$this->isUserAdmin) {
        $activity->where('fk_user_id', $this->userId);
      }
      $num_rows = $activity->count();

      if ($title) {
        $activity->where('title', 'like', '%' . $title . '%');
      }

      if ($start) {
        $activity->where('start', '>=', $this->convertToDatabaseDateForSearch($start));
      }

      if ($end) {
        $activity->where('end', '<=', $this->convertToDatabaseDateForSearch($end));
      }

      if ($taskType) {
        $activity->where('fk_task_type_id', '=', $taskType);
      }

      $activity->where('fk_user_id', '=', $this->userId);

      $result = $activity->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Activity"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['start'] = $start;
      $this->response['data']['end'] = $end;
      $this->response['data']['taskType'] = $taskType;
      $this->response['data']['list'] = ActivityResource::collection($result);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Activity fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function saleVisitList(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $visitDate = $request->visit_date ?? '';
      $reportNo = $request->report_no ?? '';
      $customerName = $request->customer_name ?? '';
      $salesPerson = $request->sales_person ?? '';

      $svr = SalesVisitReport::with('reportSalesPerson', 'product', 'user');

      if (!$this->isUserAdmin) {
        $svr->where('sales_person', $this->userId);
      }
      $num_rows = $svr->count();

      if ($visitDate) {
        $svr->where('visit_date', '>=', $this->convertToDatabaseDateForSearch($visitDate));
      }

      if ($salesPerson) {
        $svr->where('sales_person', '=', $salesPerson);
      }

      if ($customerName) {
        $svr->where('customer_name', 'like', '%' . $customerName . '%');
      }

      if ($reportNo) {
        $svr->where('report_no', 'like', '%' . $reportNo . '%');
      }

      $result = $svr->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Sales Module"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['visit_date'] = $visitDate;
      $this->response['data']['sales_person'] = $salesPerson;
      $this->response['data']['customer_name'] = $customerName;
      $this->response['data']['report_no'] = $reportNo;
      $this->response['data']['list'] = SalesVisitReportResource::collection($result);
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function leadList(REQUEST $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $enquiryDate = $request->enquiry_date ?? '';
      $fkRegionId = $request->fk_region_id ?? '';
      $customerName = $request->customer_name ?? '';
      $company = $request->company ?? '';
      $email = $request->email ?? '';
      $contactNo = $request->contact_no ?? '';
      $fkSourceId = $request->fk_source_id ?? '';
      $SMOPlatform = $request->smo_platform ?? '';
      $adwordsPlatform = $request->adwords_platform ?? '';
      $fkRsmrId = $request->fk_rsmr_id ?? '';
      $fkRsmvId = $request->fk_rsmv_id ?? '';
      $reference = $request->reference ?? '';

      $lead = Lead::with('region', 'source', 'rsmr', 'rsmv', 'designation')->orderBy('id', 'desc');
      $num_rows = $lead->count();

      if ($enquiryDate) {
        $lead->where('enquiry_date', '>=', Carbon::createFromFormat('d/m/Y g:i A', $enquiryDate)->format('Y-m-d H:i:s'));
      }

      if ($fkRegionId) {
        $lead->where('fk_region_id', '=', $fkRegionId);
      }

      if ($customerName) {
        $lead->where('customer_name', 'like', '%' . $customerName . '%');
      }

      if ($company) {
        $lead->where('company', 'like', '%' . $company . '%');
      }

      if ($email) {
        $lead->where('email', 'like', '%' . $email . '%');
      }

      if ($contactNo) {
        $lead->where('contact_no', 'like', '%' . $contactNo . '%');
      }

      if ($fkSourceId) {
        $lead->where('fk_source_id', '=', $fkSourceId);
      }

      if ($SMOPlatform) {
        $lead->where('smo_platform', 'like', '%' . $SMOPlatform . '%');
      }

      if ($adwordsPlatform) {
        $lead->where('adwords_platform', 'like', '%' . $adwordsPlatform . '%');
      }

      if ($fkRsmrId) {
        $lead->where('fk_rsmr_id', '=', $fkRsmrId);
      }

      if ($fkRsmvId) {
        $lead->where('fk_rsmv_id', '=', $fkRsmvId);
      }

      if ($reference) {
        $lead->where('reference', 'like', '%' . $reference . '%');
      }

      $result = $lead->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Lead"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['enquiry_date'] = $enquiryDate;
      $this->response['data']['fk_region_id'] = $fkRegionId;
      $this->response['data']['customer_name'] = $customerName;
      $this->response['data']['company'] = $company;
      $this->response['data']['email'] = $email;
      $this->response['data']['contact_no'] = $contactNo;
      $this->response['data']['fk_source_id'] = $fkSourceId;
      $this->response['data']['smo_platform'] = $SMOPlatform;
      $this->response['data']['adwords_platform'] = $adwordsPlatform;
      $this->response['data']['fk_rsmr_id'] = $fkRsmrId;
      $this->response['data']['fk_rsmv_id'] = $fkRsmvId;
      $this->response['data']['reference'] = $reference;
      $this->response['data']['list'] = LeadResource::collection($result);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Lead fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function projectList(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      // $leadId = $request->lead_id ?? "";
      $rfqNumber = $request->rfq_number ?? "";

      // $lead = Lead::find($leadId);

      // if (!$lead) {
      //   $this->response['error'] = "Invalid lead selected!";
      //   return $this->sendResponse($this->response, 200);
      // }

      $rfqListResource = Rfq::with('product');
      // $rfqListResource->where('lead_id', $lead->id);
      if ($rfqNumber) $rfqListResource->where('rfq_number', 'like', "%" . $rfqNumber . "%");
      $result = $rfqListResource->get();

      $rfqList = RfqListResource::collection($result);

      $this->response['status'] = 1;
      $this->response['data'] = [
        'rfq_number' => $rfqNumber,
        'list' => $rfqList
      ];

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Rfq List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function lastLogin(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $this->userId;

      $userObject = User::find($id);

      if (!$userObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "User"]);
        return $this->sendResponse($this->response, 401);
      }

      $userLog = LoginLog::select('created_at')->where('user_id', $id)->orderBy('id', 'desc')->limit(1)->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "User"]);
      $this->response['data'] = $userLog;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("User fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function attendanceList(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $perPage = (isset($request->perPage) && $request->perPage != 'undefined') ? intval($request->perPage) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $perPage;

      $userAttendance = UserAttendance::with('user')->orderBy("id", "desc");
      $numRows = $userAttendance->count();

      if (!$this->isUserAdmin) {
        $userAttendance->where('fk_user_id', $this->userId);
      }

      $result = $userAttendance->limit($perPage)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "User Attendance"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $perPage;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $perPage ? 1 : ceil($numRows / $perPage);
      $this->response['data']['list'] = $result;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("User attendance fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function projectHistoryList(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $projectLogs = ProjectLog::with('stage', 'subStage', 'po', 'rfq.quotation')->orderBy("id", "desc");

      if (!$this->isUserAdmin) {
        $projectLogs->whereRaw("created_by = " . $this->userId . " OR FIND_IN_SET(?, curr_user_ids) > 0", [$this->userId]);
      }

      $result = $projectLogs->limit(5)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Project Logs"]);

      $this->response['data']['list'] = ProjectLogResource::collection($result);

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Project Log fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function sendNotification(Request $request) {

    $fcmIds = ['your_device_fcm_token'];  // Replace with actual FCM token
    $notificationData = [
      'title' => 'Test Notification',
      'body'  => 'This is a test notification message.',
    ];
    $reminderUserIdArray = []; 

    sendFcmNotification($fcmIds, $notificationData, $reminderUserIdArray);
  }
}
