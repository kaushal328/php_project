<?php

namespace App\Http\Controllers\AppApi;

use PDF;
use Exception;
use Carbon\Carbon;
use App\Models\City;
use App\Models\User;
use App\Models\Activity;
use Illuminate\Http\Request;
use App\Models\SalesVisitReport;
use App\Events\ActivityLogCreated;
use App\Models\SalesVisitReportLog;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use App\Events\SalesVisitReportLogCreated;
use App\Events\TaskLogCreated;
use App\Http\Controllers\API\AppBaseController;
use App\Http\Resources\app\SalesVisitReportResource;
use App\Models\Division;
use App\Models\SvrProduct;
use App\Models\Task;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class SalesVisitReportController extends AppBaseController
{
    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            if (!$this->isUserRSM) {
                $this->response['error'] = "You Are Not RSM User";
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $visitDate = $request->visit_date ?? '';
            $reportNo = $request->report_no ?? '';
            $customerName = $request->customer_name ?? '';
            $salesPerson = $request->sales_person ?? '';
            $rfq = $request->rfq ?? '';
            $search = $request->search ?? '';

            $svr = SalesVisitReport::with(['reportSalesPerson', 'product', 'lead', 'rfq.subStage']);
            $svr->where('sales_person', $this->userId);

            $num_rows = $svr->count();

            if ($visitDate) {
                $svr->where('visit_date', '>=', $this->convertToDatabaseDateForSearch($visitDate));
            }

            if ($salesPerson) {
                $svr->where('sales_person', '=', $salesPerson);
            }

            if ($rfq) {
                $svr->where('fk_rfq_id', $rfq);
            }

            if ($customerName) {
                $svr->where('customer_name', 'like', '%' . $customerName . '%');
            }

            if ($reportNo) {
                $svr->where('report_no', 'like', '%' . $reportNo . '%');
            }

            if ($search) {
                $svr->where('report_no', 'like', '%' . $search . '%');
                $svr->orWhere('customer_name', 'like', '%' . $search . '%');
            }

            $svr->orderBy('visit_date', 'desc');

            $result = $svr->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Sales Module"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['visit_date'] = $visitDate;
            $this->response['data']['sales_person'] = $salesPerson;
            $this->response['data']['customer_name'] = $customerName;
            $this->response['data']['report_no'] = $reportNo;
            $this->response['data']['search'] = $search;
            $this->response['data']['list'] = SalesVisitReportResource::collection($result);
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Sales Report fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            if (!$this->isUserRSM) {
                $this->response['error'] = "You Are Not RSM User";
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $svr = SalesVisitReport::with(['reportSalesPerson', 'state:id,name', 'leadContactPeople:id,customer_name,email,contact_no', 'city:id,name', 'activityType:id,title', 'product', 'lead.designation', 'lead.source', 'lead.region', 'rfq'])->find($id);

            if (!$svr) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Sales Visit Report"]);
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Sales Visit Report"]);
            $this->response['data'] = new SalesVisitReportResource($svr);

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Sales Visit Report fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addUpdate(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateSalesVisitReport($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $svrObject = new SalesVisitReport();
            $id = $request->id;
            $salesPerson = $request->sales_person;
            $taskType = $request->taskType ?? 0;
            $lead = $request->lead ?? 0;
            $rfq = $request->rfq ?? 0;
            $activityType = $request->activity_type ?? 0;
            $customerName = $request->customer_name;
            $formattedDate = Carbon::createFromFormat('d/m/Y g:i A', $request->visit_date ?? now()->format('d/m/Y'));
            $svrMonth = $formattedDate->format('M');
            $monthNumber = $formattedDate->format('n');
            $year = $formattedDate->format('Y');
            $financialYearStart = $monthNumber >= 4 ? $year : $year - 1;
            $shortFinYearStart = substr($financialYearStart, -2);
            $shortFinYearEnd = substr($financialYearStart + 1, -2);
            $visitDate = $formattedDate->format('Y-m-d H:i:s');

            $location = $request->location ?? '';
            $divisionId = $request->division_id ?? '';
            $stateId = $request->state_id ?? '';
            $cityId = $request->city_id ?? '';
            $reasonForVisit = $request->reason_for_visit ?? '';
            $applicationSegments = $request->application_segments ?? [];
            $applicationDetails = $request->application_details ?? '';
            $svrRemark = $request->svr_remark ?? '';
            $annualVolume = $request->annual_volume ?? '';
            $productOfInterest = $request->product_of_interest ?? [];
            $product = $request->product ?? 0;
            $specification = $request->specification ?? '';
            $installationMethod = $request->installation_method ?? '';
            $price = $request->price ?? '';
            $sopAndLifetime = $request->sop_and_lifetime ?? '';
            $industryType = json_encode($request->industry_type ?? []);
            $customerBenefit = $request->customer_benefit ?? '';
            $customerRepresentatives = json_encode($request->customer_representatives ?? []);
            $activityId = $request->activity_id ?? 0;
            $taskId = $request->task_id ?? 0;
            $status = $request->status ?? 1;
            $products = $request->products ?? [];
            $leadAddId = $request->lead_addresses_id;
            $leadContId = $request->lead_contact_people_id;

            // if (empty($products)) {
            //   $this->response['errors'] = ["products" => "Please select atlest One Product!"];
            //   return $this->sendResponse($this->response, 200);
            // }


            $files = [];
            if (isset($request->svr_attachments)) {
                if (count($request->svr_attachments) > 0) {
                    foreach ($request->svr_attachments as $item) {
                        moveFile('svr/files/', $item['filename']);
                        $files[] = ['filename' => $item['filename'], 'path' => $this->fileAccessPath . "/svr/files/" . $item['filename']];
                    }
                }
            }

            $svrAttachment = json_encode($files) ?? null;


            $currentMonth = date('m', strtotime($visitDate)); // Get the current month in two-digit format
            $currentYear = date('Y', strtotime($visitDate));  // Get the current year

            if ($taskType == 1) { // empty rfq if task type is lead. 1 is used as lead in database
                $rfq = 0;
            }

            if ($id) {
                $svrObject = SalesVisitReport::find($id);

                if (!$svrObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Sales Visit Report"]);
                    return $this->sendResponse($this->response, 500);
                }
                $svrObject->first();
                $svrObject->updated_by = $this->userId;
                $reportNo = $request->report_no;


                if ($svrObject->visit_date != $visitDate) {
                    $svrObject->report_no = $request->report_no;
                }

                $this->response['msg'] = __('admin.updated', ['module' => "Sales Visit Report"]);
            } else {
                $svrObject->created_by = $this->userId;
                $recordCount = SalesVisitReport::where('created_by', $this->userId)
                    ->whereYear('visit_date', '=', $currentYear)
                    ->whereMonth('visit_date', '=', $currentMonth)->count();

                $division = Division::find($divisionId);
                if (!$division) {
                    $this->response['error'] = "Please Select Division.";
                    return $this->sendResponse($this->response, 200);
                }

                $baseString = strtoupper('SVR/' . $division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . $svrMonth . '/');
                $svrObject->report_no = generateSeries($baseString, 'sales_visit_reports', 'report_no');

                $this->response['msg'] = __('admin.created', ['module' => "Sales Visit Report"]);
            }

            $svrObject->latitude = $request->header('latitude') ?? '';
            $svrObject->longitude = $request->header('longitude') ?? '';
            $formattedAddress = getFormattedAddress($svrObject->latitude, $svrObject->longitude);
            $svrObject->formatted_address = $formattedAddress ?? '';
            $svrObject->platform_type = 'app';

            $svrObject->sales_person = $salesPerson;
            $svrObject->fk_task_type_id = $taskType;
            $svrObject->fk_lead_id = $lead;
            $svrObject->fk_rfq_id = $rfq;
            $svrObject->fk_activity_type_id = $activityType;
            $svrObject->customer_name = $customerName;
            $svrObject->visit_date = $visitDate;
            $svrObject->location = $location;
            $svrObject->state_id = $stateId;
            $svrObject->city_id = $cityId;
            $svrObject->division_id = $divisionId;
            $svrObject->reason_for_visit = $reasonForVisit;
            $svrObject->application_details = $applicationDetails;
            $svrObject->application_segments = json_encode($applicationSegments);
            $svrObject->svr_remark = $svrRemark;
            $svrObject->annual_volume = $annualVolume;
            // $svrObject->product_of_interest = json_decode($productOfInterest);
            $svrObject->fk_product_id = $product;
            $svrObject->products = json_encode($products);
            $svrObject->specification = $specification;
            $svrObject->installation_method = $installationMethod;
            $svrObject->price = $price;
            $svrObject->sop_and_lifetime = $sopAndLifetime;
            $svrObject->industry_type = $industryType;
            $svrObject->customer_benefit = $customerBenefit;
            $svrObject->customer_representatives = $customerRepresentatives;
            $svrObject->svr_attachments = $svrAttachment;
            $svrObject->lead_addresses_id = $leadAddId;
            $svrObject->lead_contact_people_id = $leadContId;
            $svrObject->status = $status;
            $svrObject->save();
            $lastInsertedId = $svrObject->id;

            $productIds = array_column($productOfInterest, 'product_id');
            $svrProIds = array_column($productOfInterest, 'id');

            if (count($productIds) > 0)
                // Filter out empty and non-numeric values from svrProIds
                $svrProIds = array_filter($svrProIds, 'is_numeric');

            // First, delete the product IDs that are not present in the payload
            SvrProduct::where('svr_id', $lastInsertedId)->whereNotIn('id', $svrProIds)->delete();

            foreach ($productOfInterest as $product) {
                $id = $product['id'] ?? '';
                $productId = $product['product_id'];
                $exist = SvrProduct::where('id', $id)->where('svr_id', $lastInsertedId)
                    ->where('product_id', $productId)
                    ->first();
                if (!$exist) {
                    SvrProduct::create([
                        'svr_id' => $lastInsertedId,
                        'product_id' => $productId,
                    ]);
                } else {
                    if ($exist->trashed()) {
                        SvrProduct::withTrashed()
                            ->where('svr_id', $lastInsertedId)
                            ->where('product_id', $productId)
                            ->restore();
                    }
                }

                $svrProduct = SvrProduct::where('svr_id', $lastInsertedId)
                    ->where('product_id', $productId)
                    ->first();

                // RfqProductLogCreated::dispatch($rfqProduct);
            }


            if ($activityId != 0) {
                $activityObject = Activity::find($activityId);

                if (!$activityObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Activity"]);
                    return $this->sendResponse($this->response, 500);
                }

                $activityObject->fk_svr_id = $lastInsertedId;
                $activityObject->save();
                $activityObject->action = 'updated';
                ActivityLogCreated::dispatch($activityObject);
            }

            if ($taskId != 0) {
                $taskObject = Task::find($taskId);

                if (!$taskObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Task"]);
                    return $this->sendResponse($this->response, 500);
                }

                $taskObject->fk_svr_id = $lastInsertedId;
                $taskObject->save();
                $taskObject->action = 'updated';
                TaskLogCreated::dispatch($taskObject);
            }
            $this->response['status'] = 1;

            $svrObject->action = 'created';
            if ($id) {
                $svrObject->action = 'updated';
            }
            SalesVisitReportLogCreated::dispatch($svrObject);


            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed Creating Sales Visit Report: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Sales Visit Report"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            if (!$this->isUserRSM) {
                $this->response['error'] = "You Are Not RSM User";
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $svrObject = SalesVisitReport::find($id);

            if (!$svrObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Sales Visit Report"]);
                return $this->sendResponse($this->response, 401);
            }

            $svrObject->action = 'deleted';
            SalesVisitReportLogCreated::dispatch($svrObject);

            $svrObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Sales Visit Report"]);
            $this->response['data'] = $svrObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Sales Visit Report deleting failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getLatestSvrDetails(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            if (!$this->isUserRSM) {
                $this->response['error'] = "You Are Not RSM User";
                return $this->sendResponse($this->response, 401);
            }

            $leadId = $request->fk_lead_id;
            $rfqId = $request->fk_rfq_id;

            $latestSvr = SalesVisitReport::where('created_by', $this->userId);

            if ($leadId) {
                $latestSvr->where('fk_lead_id', $leadId);
            }

            if ($rfqId) {
                $latestSvr->where('fk_rfq_id', $rfqId);
            }

            $result = $latestSvr->orderBy('id', 'desc')->first();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Sales Visit Report"]);
            $this->response['data'] = new SalesVisitReportResource($result);

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Sales Visit Report fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getSvrRemark(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            if (!$this->isUserRSM) {
                $this->response['error'] = "You Are Not RSM User";
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $svr = SalesVisitReportLog::where('fk_sales_visit_report_id', $id)->get('svr_remark');

            if (!$svr) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Sales Visit Report Log"]);
                return $this->sendResponse($this->response, 500);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Sales Visit Report Log"]);
            $this->response['data'] = $svr;


            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Sales Visit Report Log fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function cityList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $stateId = $request->state_id ?? '';
            $cityAccordingToState = City::where(['state_id' => $stateId])->get();

            $this->response['status'] = 1;
            $this->response['data']['cityAccordingToState'] = $cityAccordingToState;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Rfq Common List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function validateAddUpdateSalesVisitReport(Request $request)
    {
        return Validator::make(
            $request->all(),
            [
                'sales_person' => 'required|exists:users,id,deleted_at,NULL',
                // 'taskType' => 'nullable|exists:task_types,id,deleted_at,NULL',
                'lead' => 'nullable|required_if:taskType,1,2|exists:leads,id,deleted_at,NULL',
                'rfq' => 'nullable|required_if:taskType,2|exists:rfqs,id,deleted_at,NULL',
                // 'report_no' => 'required',
                // 'customer_name' => 'required',
                'svr_remark' => $request->has('id') ? 'nullable' : 'required',
                'visit_date' => 'required|date_format:d/m/Y g:i A',
                // 'product' => 'nullable|exists:products,id,deleted_at,NULL',

            ],
            [
                'lead.required_if' => 'Please Select Lead if Visit for is set Lead or RFQ.',
                'svr_remark.required' => 'Visit Notes is required',
                'rfq.required_if' => 'Please Select RFQ if Visit for is set RFQ.',
            ]
        )->errors();
    }

    public function downloadPdf(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 500);
            }

            if (!$this->isUserRSM) {
                $this->response['error'] = "You Are Not RSM User";
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            // , 'region', 'source', 'designation'
            $svr = SalesVisitReport::with('reportSalesPerson', 'product', 'leadContactPeople:id,customer_name,email,contact_no', 'lead.designation', 'lead.source', 'lead.region', 'rfq')->find($id);

            if (!$svr) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Sales Visit Report"]);
                return $this->sendResponse($this->response, 500);
            }

            $data = [
                'details' => json_decode(json_encode($svr)),
            ];

            $dompdf = PDF::loadView('pdf.svrPdf', $data);

            $dompdf->setPaper('A4', 'portrait');

            $encryptName = Crypt::encryptString($id);
            $trimLength = substr($encryptName, 0, 6);
            $fileName = $trimLength . '.pdf';
            // Render the PDF
            $dompdf->render();

            $pdfContent = $dompdf->output(); // Get the generated PDF content

            if (!Storage::exists(storage_path('app/public/uploads/pdf/'))) {
                Storage::makeDirectory(storage_path('app/public/uploads/pdf/'));
            }

            file_put_contents(storage_path('app/public/uploads/pdf/' . $fileName), $pdfContent); // Save the PDF to the specified file path

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Sales Visit Report"]);
            $this->response['data'] = $this->fileAccessPath . '/pdf/' . $fileName;
            $this->response['filePath'] = $this->fileAccessPath . '/pdf/' . $fileName;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Sales Visit Report Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }
}
