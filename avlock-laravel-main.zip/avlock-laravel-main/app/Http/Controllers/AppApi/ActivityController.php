<?php

namespace App\Http\Controllers\AppApi;

use App\Events\ActivityLogCreated;
use App\Http\Controllers\API\AppBaseController;
use App\Http\Controllers\Controller;
use App\Http\Resources\app\ActivityResource;
use App\Models\Activity;
use App\Models\SalesVisitReport;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ActivityController extends AppBaseController
{
  public function index(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if (!$this->isUserRSM) {
        $this->response['error'] = "You Are Not RSM User";
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $comment = $request->comment ?? '';
      $taskType = $request->taskType ?? '';
      $customer = $request->customer ?? '';
      $activityType = $request->activity_type ?? '';
      $isPhysicalVisit = $request->is_physical_visit ?? '';
      $rfq = $request->rfq ?? '';

      $startDate = $request->start_date ?? date("Y-m-d");

      $activity = Activity::with(['activityType', 'latestActivityLog', 'leadContactPeople:id,customer_name', 'taskType', 'lead', 'rfq', 'svr'])->where('start_time', 'like', '%' . $startDate . '%')->orderBy('start_time', 'desc');

      // $activity = Activity::with('taskType', 'lead', 'rfq');
      if (!$this->isUserAdmin) {
        $activity->where('fk_user_id', $this->userId);
      }

      if ($customer) {
        $activity->whereHas('lead', function ($q) use ($customer) {
          if ($customer) $q->where(['id' => $customer, 'status' => 1]);
        });
      }

      if ($rfq) {
        $activity->where('fk_rfq_id', $rfq);
      }

      if ($comment) {
        $activity->where('comment', 'like', '%' . $comment . '%');
      }

      if ($taskType) {
        $activity->where('fk_task_type_id', '=', $taskType);
      }

      if ($activityType) {
        $activity->where('fk_activity_type_id', '=', $activityType);
      }

      if ($isPhysicalVisit) {
        $activity->where('is_physical_visit', '=', $isPhysicalVisit);
      }

      $activity->where('fk_user_id', '=', $this->userId);

      $num_rows = $activity->count();
      $result = $activity->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Activity"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['comment'] = $comment;
      $this->response['data']['taskType'] = $taskType;
      $this->response['data']['activity_type'] = $activityType;
      $this->response['data']['is_physical_visit'] = $isPhysicalVisit;
      $this->response['data']['customer'] = $customer;
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['list'] = ActivityResource::collection($result);
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Activity fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if (!$this->isUserRSM) {
        $this->response['error'] = "You Are Not RSM User";
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $activity = Activity::with('activityType', 'taskType', 'leadContactPeople:id,customer_name', 'lead', 'rfq.product', 'svr')->find($id);

      if (!$activity) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Activity"]);
        return $this->sendResponse($this->response, 401);
      }

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Activity"]);
      $this->response['data'] = new ActivityResource($activity);


      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Activity fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if (!$this->isUserRSM) {
        $this->response['error'] = "You Are Not RSM User";
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateActivity($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $activityObject = new Activity();
      $id = $request->id;
      $comment = $request->comment;
      $activityType = $request->activity_type;
      $isPhysicalVisit = $request->is_physical_visit;
      $taskType = $request->taskType ?? 0;
      $lead = $request->lead ?? 0;
      $rfq = $request->rfq ?? 0;
      $activityUser = $request->fk_user_id ?? $this->userId;
      $startTime = date('Y-m-d H:i:s');
      $leadAddId = $request->lead_addresses_id;
      $leadContId = $request->lead_contact_people_id;

      if ($taskType == 1) { // empty rfq if task type is lead. 1 is used as lead in database
        $rfq = 0;
      }

      $files = [];
      if (isset($request->attachment)) {
        if (count($request->attachment) > 0) {
          foreach ($request->attachment as $item) {
            moveFile('activity/files/', $item['filename']);
            $files[] = ['filename' => $item['filename'], 'path' => $this->fileAccessPath . "/activity/files/" . $item['filename']];
          }
        }
      }

      $attachment = json_encode($files) ?? '';
      $status = $request->status ?? 1;

      if ($id) {
        $activityObject = Activity::find($id);

        if (!$activityObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Activity"]);
          return $this->sendResponse($this->response, 401);
        }
        $activityObject->first();
        $activityObject->updated_by = $this->userId;
        $this->response['msg'] = __('admin.updated', ['module' => "Activity"]);
      } else {
        $activityObject->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => "Activity"]);
      }


      $activityObject->latitude = $request->header('latitude') ?? '';
      $activityObject->longitude = $request->header('longitude') ?? '';
      $formattedAddress = getFormattedAddress($activityObject->latitude, $activityObject->longitude);
      $activityObject->formatted_address = $formattedAddress ?? '';
      $activityObject->platform_type = 'app';

      $activityObject->start_time = $startTime;
      $activityObject->comment = $comment;
      $activityObject->fk_activity_type_id = $activityType;
      $activityObject->is_physical_visit = $isPhysicalVisit;
      $activityObject->fk_task_type_id = $taskType;
      $activityObject->fk_lead_id = $lead;
      $activityObject->fk_rfq_id = $rfq;
      $activityObject->fk_user_id = $activityUser;
      $activityObject->attachment = $attachment;
      $activityObject->lead_addresses_id = $leadAddId;
      $activityObject->lead_contact_people_id = $leadContId;
      $activityObject->status = $status;

      if ($isPhysicalVisit == 1) {
        $svr = SalesVisitReport::where('created_by', $this->userId)->where('fk_task_type_id', $taskType)->where('created_at', 'like', '%' . date('Y-m-d') . '%');
        if ($taskType == 1) {
          // if activity type is lead
          $svr->where('fk_lead_id', $lead);
        } else if ($taskType == 2) {
          // if activity type is rfq
          $svr->where('fk_rfq_id', $rfq);
        }

        if ($svr->count() == 1) {
          $todaysSvr = $svr->first();
          if ($todaysSvr) $activityObject->fk_svr_id = $todaysSvr->id;
        }
      }

      $activityObject->save();

      $activityObject->action = 'created';
      if ($id) {
        $activityObject->action = 'updated';
      }
      ActivityLogCreated::dispatch($activityObject);

      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Creating Activity: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Activity"]);
      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if (!$this->isUserRSM) {
        $this->response['error'] = "You Are Not RSM User";
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $activityObject = Activity::find($id);

      if (!$activityObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Activity"]);
        return $this->sendResponse($this->response, 401);
      }

      $activityObject->action = 'deleted';
      ActivityLogCreated::dispatch($activityObject);

      $activityObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Activity"]);
      $this->response['data'] = $activityObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Activity deleting failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function stopActivity(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if (!$this->isUserRSM) {
        $this->response['error'] = "You Are Not RSM User";
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $activity = Activity::find($id);
      // if (!$activity) {
      //   $this->response['error'] = "Something went wrong! Please try again.";
      //   return $this->sendResponse($this->response, 200);
      // }

      // if ($activity->is_physical_visit == 1) {
      //   if (!$activity->fk_svr_id) {
      //     $this->response['error'] = "Please fill up Sales Visit Report first!";
      //     return $this->sendResponse($this->response, 200);
      //   }
      // }

      $activity->end_time = date('Y-m-d H:i:s');
      $activity->save();
      $activity->action = 'stopped';

      ActivityLogCreated::dispatch($activity);

      $this->response['status'] = 1;
      $this->response['msg'] = "Activity stopped successfully.";

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Stopping Activity: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }


  private function validateAddUpdateActivity(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'activity_type' => 'required|exists:activity_types,id,deleted_at,NULL',
        'taskType' => 'nullable|exists:task_types,id,deleted_at,NULL',
        'comment' => 'required_if:taskType,3',
        'lead' => 'nullable|required_if:taskType,1,2|exists:leads,id,deleted_at,NULL',
        'rfq' => 'nullable|required_if:taskType,2|exists:rfqs,id,deleted_at,NULL',
      ],
      [
        'lead.required_if' => 'Please Select Lead if Activity for is set Lead or RFQ.',
        'rfq.required_if' => 'Please Select RFQ if Activity for is set RFQ.',
        'comment' => 'Please enter comment if Activity For field is Other',

      ]
    )->errors();
  }
}
