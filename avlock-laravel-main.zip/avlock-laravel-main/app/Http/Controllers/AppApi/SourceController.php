<?php

namespace App\Http\Controllers\AppApi;

use App\Http\Controllers\API\AppBaseController;
use App\Enums\ValueType;
use App\Http\Controllers\Controller;
use App\Models\Source;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class SourceController extends AppBaseController {
    /**
   * Display a listing of the Source.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $name = $request->name ?? '';
      $status = $request->status ?? '';

      $sourceObject = Source::withoutTrashed()->orderBy("id", "desc");
      $num_rows = $sourceObject->count();

      if ($name) {
        $sourceObject->where('name', 'like', '%' . $name . '%');
      }

      if ($status) {
        $sourceObject->where('status', $status);
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Source"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['name'] = $name;
      $this->response['data']['list'] = $sourceObject->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Source fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(Request $request) {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateSource($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $sourceObject = new Source();
      $id = $request->id;
      $name = $request->name ?? '';
      $status = $request->status ?? 1;

      if ($id) {
        $sourceObject = Source::find($id);

        if (!$sourceObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Source"]);
          return $this->sendResponse($this->response, 500);
        }

        $sourceObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Source"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Source"]);
      }

      $sourceObject->name = $name;
      $sourceObject->status = $status;

      $sourceObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Source: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Source"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $sourceObject = Source::find($id);

      if (!$sourceObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Source"]);
        return $this->sendResponse($this->response, 500);
      }
      $sourceObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Source"]);
      $this->response['data'] = $sourceObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Source fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $sourceObject = Source::find($id);

      if (!$sourceObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Source"]);
        return $this->sendResponse($this->response, 500);
      }

      $sourceObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Source"]);
      $this->response['data'] = $sourceObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Source Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdateSource(Request $request) {
    return Validator::make($request->all(), [
      'name' => 'required|string|unique:parameters,name,' . $request->id . ',id,deleted_at,NULL',
      'status' => 'sometimes|required|integer|in:0,1',
    ])->errors();
  }

}
