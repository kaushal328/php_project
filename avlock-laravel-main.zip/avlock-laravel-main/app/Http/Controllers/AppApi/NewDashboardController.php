<?php

namespace App\Http\Controllers\AppApi;

use Exception;
use App\Models\Rfq;
use App\Models\Lead;
use App\Models\Task;
use App\Models\User;
use App\Models\Region;
use App\Models\Activity;
use App\Models\Industry;
use App\Models\Reminder;
use App\Models\UserRole;
use App\Models\LeadDesignation;
use App\Models\ProjectLog;
use App\Models\ProjectType;
use Illuminate\Http\Request;
use App\Models\PurchaseOrder;
use App\Models\ProjectSegment;
use App\Models\UserAttendance;
use Illuminate\Support\Carbon;
use App\Models\PurchaseInvoice;
use App\Models\MonthlyPlanExcel;
use App\Models\SalesVisitReport;
use App\Models\MasterReportPreset;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\ProjectQuotationTemp;
use App\Models\PurchaseOrderDneInvoice;
use App\Models\PurchaseOrderPdrQuality;
use App\Http\Resources\ActivityResource;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use App\Http\Controllers\API\AppBaseController;
use App\Http\Resources\NewDashboardVisitResource;
use App\Models\Product;
use PhpOffice\PhpSpreadsheet\Writer\Csv;

class NewDashboardController extends AppBaseController
{
  private $piSubStageId = 16;
  private $rfqApproveSubStageId = 22;
  private $poApproveSubStageId = 35;
  private $dnSubStageId = 45;
  private $pdrSubStageId = 46;
  private $deliverySubStageId = 49;

  private $dashboardArray = [
    10 => [ //Management
      'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq'],
      'pending_rfqs' => false,
      'task' => true,
      'reminder' => true,
      'quick_report' => false,
      'day_in_out' => true,
    ],
    2 => [ //Admin
      'day_in_out' => true,
    ],
    11 => [ //Finance
      'basic_counts' => ['po', 'invoice'],
      'pending_rfqs' => false,
      'task' => true,
      'reminder' => true,
      'quick_report' => false,
    ],
    12 => [ //Production
      'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq'],
      'pending_rfqs' => false,
      'task' => true,
      'reminder' => true,
      'quick_report' => false,
    ],
    7 => [ //PSM
      'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq'],
      'pending_rfqs' => true,
      'task' => true,
      'reminder' => true,
      'quick_report' => false,
    ],
    6 => [ //INSIDE_SALES
      'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq'],
      'pending_rfqs' => true,
      'task' => true,
      'reminder' => true,
      'quick_report' => false,
    ],
    8 => [ //QUALITY
      'basic_counts' => ['quotation', 'po', 'invoice', 'pdr', 'delivery_note'],
      'pending_rfqs' => true,
      'task' => true,
      'reminder' => true,
      'quick_report' => false,
    ],
    9 => [ //DISPATCH
      'basic_counts' => ['quotation', 'po', 'invoice', 'pdr', 'delivery_note'],
      'pending_rfqs' => true,
      'task' => true,
      'reminder' => true,
      'quick_report' => false,
    ],
    4 => [ //MARKETING
      'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq'],
      'pending_rfqs' => true,
      'task' => true,
      'reminder' => true,
      'quick_report' => false,
      'visit' => true,
      'statistics' => false,
      'lead' => false,
    ],
    5 => [ //SALES
      'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq', 'pdr', 'delivery_note'],
      'pending_rfqs' => true,
      'task' => true,
      'reminder' => true,
      'quick_report' => false,
      'visit' => true,
      'statistics' => false,
      'day_in_out' => true,
      // 'type_of_client' => true,
      // 'segment' => true,
      // 'industry' => true,
      // 'zone' => true,
    ],
    3 => [
      'task' => true,
      'reminder' => false,
      'day_in_out' => true,
    ],
    'NATIONAL_HEAD' => [
      'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq', 'pdr', 'delivery_note'],
      'task' => false,
      'reminder' => false,
      'quick_report' => false,
      'visit' => false,
      'statistics' => false,
      'type_of_client' => true,
      'segment' => true,
      'industry' => true,
      'zone' => true,
      'lead' => true,
      'day_in_out' => true,
    ]
  ];

  private function getFiscalYearDates()
  {
    $currentMonth = (int)date('m');
    $currentYear = (int)date('Y');

    return [
      'currentMonth' => $currentMonth,
      'fiscalYear' => ($currentMonth >= 1 && $currentMonth <= 3) ? $currentYear - 1 : $currentYear,
    ];
  }

  private function applyFiscalMonthScope($query, $fiscalYear, $currentMonth, $dateColumn)
  {
    return $query->where(function ($q) use ($fiscalYear, $currentMonth, $dateColumn) {
      if ($currentMonth >= 4) {
        $q->whereYear($dateColumn, $fiscalYear)
          ->whereMonth($dateColumn, $currentMonth);
      } else {
        $q->whereYear($dateColumn, $fiscalYear + 1)
          ->whereMonth($dateColumn, $currentMonth);
      }
    });
  }

  private function applyFiscalYearScope($query, $fiscalYear, $dateColumn)
  {
    return $query->where(function ($q) use ($fiscalYear, $dateColumn) {
      $q->where(function ($inner) use ($fiscalYear, $dateColumn) {
        $inner->whereYear($dateColumn, $fiscalYear)
          ->whereMonth($dateColumn, '>=', 4);
      })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
        $inner->whereYear($dateColumn, $fiscalYear + 1)
          ->whereMonth($dateColumn, '<=', 3);
      });
    });
  }

  function index(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $data = [];

      $basicCountResult = [];
      $pendingRfqData = [];
      $taskData = [];
      $reminderData = [];
      $quickReportData = [];
      $visitData = [];
      $statisticsData = [];
      $typeOfClientData = [];
      $industryData = [];
      $segmentData = [];
      $zoneData = [];
      $leadData = [];
      $dayInOutData = [];

      $basicCountReportParams = [];
      $shouldGeneratePendingRfqReport = false;
      $shouldGenerateTaskReport = false;
      $shouldGenerateReminderReport = false;
      $shouldGenerateQuickReport = false;
      $shouldGenerateVisitReport = false;
      $shouldGenerateStatisticsReport = false;
      $shouldGenerateTypeOfClientReport = false;
      $shouldGenerateIndustryReport = false;
      $shouldGenerateSegmentReport = false;
      $shouldGenerateZoneReport = false;
      $shouldGenerateLeadReport = false;
      $shouldGenerateDayInOutReport = false;

      $user = User::find($this->userId);

      $isNationalHead = in_array($user->fk_designation_id, [1]);

      $userRole = UserRole::with('department')->where('fk_user_id', $user->id)->get()->toArray();
      $departmentIds = array_column(array_column($userRole, 'department'), 'id');

      if (!$isNationalHead) {
        foreach ($departmentIds as $departmentId) {
          $basicReportParams = @$this->dashboardArray[$departmentId]['basic_counts'] ?? [];
          if (count($basicReportParams)) {
            $basicCountReportParams = array_merge(array_values($basicReportParams), $basicCountReportParams);
          }

          $pendingRfqReport = @$this->dashboardArray[$departmentId]['pending_rfqs'] ?? false;
          if ($pendingRfqReport) $shouldGeneratePendingRfqReport = true;

          $taskReport = @$this->dashboardArray[$departmentId]['task'] ?? false;
          if ($taskReport) $shouldGenerateTaskReport = true;

          $reminderReport = @$this->dashboardArray[$departmentId]['reminder'] ?? false;
          if ($reminderReport) $shouldGenerateReminderReport = true;

          $quickReport = @$this->dashboardArray[$departmentId]['quick_report'] ?? false;
          if ($quickReport) $shouldGenerateQuickReport = true;

          $visitReport = @$this->dashboardArray[$departmentId]['visit'] ?? false;
          if ($visitReport) $shouldGenerateVisitReport = true;

          $statisticsReport = @$this->dashboardArray[$departmentId]['statistics'] ?? false;
          if ($statisticsReport) $shouldGenerateStatisticsReport = true;

          $typeOfClientReport = @$this->dashboardArray[$departmentId]['type_of_client'] ?? false;
          if ($typeOfClientReport) $shouldGenerateTypeOfClientReport = true;

          $industryReport = @$this->dashboardArray[$departmentId]['industry'] ?? false;
          if ($industryReport) $shouldGenerateIndustryReport = true;

          $segmentReport = @$this->dashboardArray[$departmentId]['segment'] ?? false;
          if ($segmentReport) $shouldGenerateSegmentReport = true;

          $zoneReport = @$this->dashboardArray[$departmentId]['zone'] ?? false;
          if ($zoneReport) $shouldGenerateZoneReport = true;

          $leadReport = @$this->dashboardArray[$departmentId]['lead'] ?? false;
          if ($leadReport) $shouldGenerateLeadReport = true;

          $dayInOutReport = @$this->dashboardArray[$departmentId]['day_in_out'] ?? false;
          if ($dayInOutReport) $shouldGenerateDayInOutReport = true;
        }
      } else {

        $basicReportParams = @$this->dashboardArray['NATIONAL_HEAD']['basic_counts'] ?? [];
        if (count($basicReportParams)) {
          $basicCountReportParams = array_values($basicReportParams);
        }

        $pendingRfqReport = @$this->dashboardArray['NATIONAL_HEAD']['pending_rfqs'] ?? false;
        if ($pendingRfqReport) $shouldGeneratePendingRfqReport = true;

        $taskReport = @$this->dashboardArray['NATIONAL_HEAD']['task'] ?? false;
        if ($taskReport) $shouldGenerateTaskReport = true;

        $reminderReport = @$this->dashboardArray['NATIONAL_HEAD']['reminder'] ?? false;
        if ($reminderReport) $shouldGenerateReminderReport = true;

        $quickReport = @$this->dashboardArray['NATIONAL_HEAD']['quick_report'] ?? false;
        if ($quickReport) $shouldGenerateQuickReport = true;

        $visitReport = @$this->dashboardArray['NATIONAL_HEAD']['visit'] ?? false;
        if ($visitReport) $shouldGenerateVisitReport = true;

        $statisticsReport = @$this->dashboardArray['NATIONAL_HEAD']['statistics'] ?? false;
        if ($statisticsReport) $shouldGenerateStatisticsReport = true;

        $typeOfClientReport = @$this->dashboardArray['NATIONAL_HEAD']['type_of_client'] ?? false;
        if ($typeOfClientReport) $shouldGenerateTypeOfClientReport = true;

        $industryReport = @$this->dashboardArray['NATIONAL_HEAD']['industry'] ?? false;
        if ($industryReport) $shouldGenerateIndustryReport = true;

        $segmentReport = @$this->dashboardArray['NATIONAL_HEAD']['segment'] ?? false;
        if ($segmentReport) $shouldGenerateSegmentReport = true;

        $zoneReport = @$this->dashboardArray['NATIONAL_HEAD']['zone'] ?? false;
        if ($zoneReport) $shouldGenerateZoneReport = true;

        $leadReport = @$this->dashboardArray['NATIONAL_HEAD']['lead'] ?? false;
        if ($leadReport) $shouldGenerateLeadReport = true;

        $dayInOutReport = @$this->dashboardArray['NATIONAL_HEAD']['day_in_out'] ?? false;
        if ($dayInOutReport) $shouldGenerateDayInOutReport = true;
      }

      $basicCountReportParams = array_unique($basicCountReportParams);
      if (count($basicCountReportParams)) {
        $basicCountResult = $this->generateBasicCountReport($basicCountReportParams, $isNationalHead);
        $data['basic_count_data'] = ['title' => 'Counts (' . date("F") . ')', 'result' => $basicCountResult];
      }

      if ($shouldGeneratePendingRfqReport) {
        $pendingRfqData = $this->generatePendingRfqReport($isNationalHead);
        $data['pending_rfq_data'] = ['title' => 'In-Pipeline / Pending RFQ', 'result' => $pendingRfqData];
      }

      if ($shouldGenerateTaskReport) {
        $taskData = $this->generateTaskReport($isNationalHead);
        $data['task_data'] = ['title' => 'Task', 'result' => $taskData];
      }

      if ($shouldGenerateReminderReport) {
        $reminderData = $this->generateReminderReport($isNationalHead);
        $data['reminder_data'] = ['title' => 'Reminder', 'result' => $reminderData];
      }

      if ($shouldGenerateQuickReport) {
        $quickReportData = $this->generateQuickReport($isNationalHead);
        $data['quick_report_data'] = ['title' => 'Quick Report', 'result' => $quickReportData];
      }

      if ($shouldGenerateVisitReport) {
        $visitData = $this->generateVisitDataReport($isNationalHead);
        $data['visit_data'] = ['title' => 'Visit This Month', 'result' => $visitData];
      }

      if ($shouldGenerateStatisticsReport) {
        $statisticsData = $this->generateStatisticsReport($isNationalHead);
        $data['statistics_data'] = ['title' => 'Statistics', 'result' => $statisticsData];
      }

      if ($shouldGenerateTypeOfClientReport) {
        $typeOfClientData = $this->generateTypeOfClientReport($isNationalHead);
        $data['type_of_client_data'] = ['title' => 'Type of Client', 'result' => $typeOfClientData];
      }

      if ($shouldGenerateIndustryReport) {
        $industryData = $this->generateIndustryReport($isNationalHead);
        $data['industry_data'] = ['title' => 'Industry (RFQs)', 'result' => $industryData];
      }

      if ($shouldGenerateSegmentReport) {
        $segmentData = $this->generateSegmentReport($isNationalHead);
        $data['segment_data'] = ['title' => 'Segment (RFQs)', 'result' => $segmentData];
      }

      if ($shouldGenerateZoneReport) {
        $zoneData = $this->generateZoneReport($isNationalHead);
        $data['zone_data'] = ['title' => 'Zone Wise (Leads)', 'result' => $zoneData];
      }

      if ($shouldGenerateLeadReport) {
        $leadData = $this->generateLeadReport($isNationalHead);
        $data['lead_data'] = ['title' => 'Lead List', 'result' => $leadData, 'color' => [
          'RawleadColor' => '#fffd08',
          'PotentialleadColor' => '#04ffff',
          'ProspectleadColor' => '#4d87e9',
          'FinalizedleadColor' => '#d0dfe4',
        ]];
      }

      if ($shouldGenerateDayInOutReport) {
        $dayInOutData = $this->generateDayInOutReport($isNationalHead);
        $data['day_in_out_data'] = ['title' => 'Day In / Day Out', 'result' => $dayInOutData];
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "New Dashboard Data"]);
      $this->response['data'] = $data;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("New Dashboard Data fetching failed: " . $e->getLine());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function generateBasicCountReport($basicCountReportParams = [], $isNationalHead = false)
  {
    $basicCountResult = [];

    $dates = $this->getFiscalYearDates();
    $fiscalYear = $dates['fiscalYear'];
    $currentMonth = $dates['currentMonth'];

    $juniorUserIds = $this->getJuniorIds(true);
    rsort($juniorUserIds);

    // rfq count
    if (in_array('rfq', $basicCountReportParams)) {
      $juniorUserIds = $this->getJuniorIds(true);
      rsort($juniorUserIds);
      $dateColumn = 'rfq_date';

      if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        //From RFQ table
        $rfqFromRfq = Rfq::select('id as rfq_id')->orderBy('id', 'desc');

        $rfqFromRfqThisMonth = clone $rfqFromRfq;
        $rfqFromRfqThisYear = clone $rfqFromRfq;

        $rfqFromRfqThisMonth = $this->applyFiscalMonthScope($rfqFromRfqThisMonth, $fiscalYear, $currentMonth, $dateColumn)->get()->toArray();

        $rfqFromRfqThisYear = $this->applyFiscalYearScope($rfqFromRfqThisYear, $fiscalYear, $dateColumn)->get()->toArray();

        //From Project Logs table
        $rfqFromProjectLogs = ProjectLog::with('rfq')->select('fk_rfq_id as rfq_id')->distinct()->groupBy('fk_rfq_id');
        $rfqFromProjectLogsThisMonth = clone $rfqFromProjectLogs;
        $rfqFromProjectLogsThisYear = clone $rfqFromProjectLogs;

        //THIS WAS BEFORE FISCAL YEAR QUERY
        // $rfqFromProjectLogsThisYear = $rfqFromProjectLogsThisYear->whereHas('rfq', function ($q) {
        //     $q->whereYear('rfq_date', date('Y'));
        // })->get()->pluck('rfq_id')->toArray();

        $rfqFromProjectLogsThisMonth = (clone $rfqFromProjectLogs)
          ->whereHas('rfq', function ($q) use ($fiscalYear, $currentMonth, $dateColumn) {
            return $this->applyFiscalMonthScope($q, $fiscalYear, $currentMonth, $dateColumn);
          })->get()->pluck('rfq_id')->toArray();

        $rfqFromProjectLogsThisYear = (clone $rfqFromProjectLogs)
          ->whereHas('rfq', function ($q) use ($fiscalYear, $dateColumn) {
            return $this->applyFiscalYearScope($q, $fiscalYear, $dateColumn);
          })->get()->pluck('rfq_id')->toArray();

        //Sum up after distinct
        $rfqThisMonth = array_unique(array_column(array_merge($rfqFromRfqThisMonth, $rfqFromProjectLogsThisMonth), 'rfq_id'));
        $rfqThisYear = array_unique(array_column(array_merge($rfqFromRfqThisYear, $rfqFromProjectLogsThisYear), 'rfq_id'));

        $rfqCountThisMonth = RFQ::whereIn('id', $rfqThisMonth)->count();
        $rfqCountThisYear = RFQ::whereIn('id', $rfqThisYear)->count();
      } else if ($this->isUserInsideSale || $this->psmUserRole) {
        //From RFQ table
        // $uid = $this->userId;

        $insideSaleDivisions = User::find($this->userId)->division_ids;
        $divisionIdsArray = explode(',', $insideSaleDivisions);

        $rfqFromRfq = Rfq::where(function ($q) use ($divisionIdsArray) {
          $q->whereIn('division_id', $divisionIdsArray);
        });

        $rfqFromRfqThisMonth = clone $rfqFromRfq;
        $rfqFromRfqThisYear = clone $rfqFromRfq;

        $rfqFromRfqThisMonth = $this->applyFiscalMonthScope($rfqFromRfqThisMonth, $fiscalYear, $currentMonth, $dateColumn)->get()->pluck('id')->toArray();

        $rfqFromRfqThisYear = $this->applyFiscalYearScope($rfqFromRfqThisYear, $fiscalYear, $dateColumn)->get()->pluck('id')->toArray();

        //From Project Logs table
        $rfqFromProjectLogs = ProjectLog::with('rfq')->select('fk_rfq_id as rfq_id')
          ->where(function ($q) use ($juniorUserIds) {
            foreach ($juniorUserIds as $key => $value) {
              $q->orWhereRaw('FIND_IN_SET(?, curr_user_ids)', [$value]);
            }
          })
          ->whereHas('rfq', function ($q) use ($divisionIdsArray) {
            $q->whereIn('division_id', $divisionIdsArray);
          })
          ->distinct()->groupBy('fk_rfq_id');

        $rfqFromProjectLogsThisMonth = clone $rfqFromProjectLogs;
        $rfqFromProjectLogsThisYear = clone $rfqFromProjectLogs;

        $rfqFromProjectLogsThisMonth = $rfqFromProjectLogsThisMonth
          ->whereHas('rfq', function ($q) use ($fiscalYear, $currentMonth, $dateColumn) {
            return $this->applyFiscalMonthScope($q, $fiscalYear, $currentMonth, $dateColumn);
          })->get()->pluck('rfq_id')->toArray();

        $rfqFromProjectLogsThisYear = $rfqFromProjectLogsThisYear
          ->whereHas('rfq', function ($q) use ($fiscalYear, $dateColumn) {
            return $this->applyFiscalYearScope($q, $fiscalYear, $dateColumn);
          })->get()->pluck('rfq_id')->toArray();

        //Sum up after distinct
        $rfqThisMonth = array_unique(array_merge($rfqFromRfqThisMonth, $rfqFromProjectLogsThisMonth));
        $rfqThisYear = array_unique(array_merge($rfqFromRfqThisYear, $rfqFromProjectLogsThisYear));

        $rfqCountThisMonth = RFQ::whereIn('id', $rfqThisMonth)->count();
        $rfqCountThisYear = RFQ::whereIn('id', $rfqThisYear)->count();
      } else {
        //From RFQ table
        // $uid = $this->userId;

        $rfqFromRfq = Rfq::where(function ($q) use ($juniorUserIds) {
          $q->whereIn('created_by', $juniorUserIds)->orWhereIn('rsm_id', $juniorUserIds);
        });


        $rfqFromRfqThisMonth = clone $rfqFromRfq;
        $rfqFromRfqThisYear = clone $rfqFromRfq;

        $rfqFromRfqThisMonth = $this->applyFiscalMonthScope($rfqFromRfqThisMonth, $fiscalYear, $currentMonth, $dateColumn)->get()->pluck('id')->toArray();

        $rfqFromRfqThisYear = $this->applyFiscalYearScope($rfqFromRfqThisYear, $fiscalYear, $dateColumn)->get()->pluck('id')->toArray();

        //From Project Logs table
        $rfqFromProjectLogs = ProjectLog::with('rfq')->select('fk_rfq_id as rfq_id')
          ->where(function ($q) use ($juniorUserIds) {
            foreach ($juniorUserIds as $key => $value) {
              $q->orWhereRaw('FIND_IN_SET(?, curr_user_ids)', [$value]);
            }
          })
          ->distinct()->groupBy('fk_rfq_id');

        $rfqFromProjectLogsThisMonth = clone $rfqFromProjectLogs;
        $rfqFromProjectLogsThisYear = clone $rfqFromProjectLogs;

        $rfqFromProjectLogsThisMonth = $rfqFromProjectLogsThisMonth
          ->whereHas('rfq', function ($q) use ($fiscalYear, $currentMonth, $dateColumn) {
            return $this->applyFiscalMonthScope($q, $fiscalYear, $currentMonth, $dateColumn);
          })->get()->pluck('rfq_id')->toArray();

        $rfqFromProjectLogsThisYear = $rfqFromProjectLogsThisYear
          ->whereHas('rfq', function ($q) use ($fiscalYear, $dateColumn) {
            return $this->applyFiscalYearScope($q, $fiscalYear, $dateColumn);
          })->get()->pluck('rfq_id')->toArray();

        //Sum up after distinct
        $rfqThisMonth = array_unique(array_merge($rfqFromRfqThisMonth, $rfqFromProjectLogsThisMonth));
        $rfqThisYear = array_unique(array_merge($rfqFromRfqThisYear, $rfqFromProjectLogsThisYear));

        $rfqCountThisMonth = RFQ::whereIn('id', $rfqThisMonth)->count();
        $rfqCountThisYear = RFQ::whereIn('id', $rfqThisYear)->count();
      }

      $result = ['title' => 'RFQ', 'this_month' => $rfqCountThisMonth, 'this_year' => $rfqCountThisYear];
      $basicCountResult[] = $result;
    }


    //quotation count
    if (in_array('quotation', $basicCountReportParams)) {
      if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing) {
        $quotationCount = ProjectQuotationTemp::orderBy('id', 'desc');
      } else {
        // $quotationCount = ProjectQuotationTemp::where('prepared_by', $this->userId)->orderBy('id', 'desc');
        $quotationCount = ProjectQuotationTemp::with('purchaseOrder')->where(function ($q) use ($juniorUserIds) {
          $q->whereIn('prepared_by', $juniorUserIds);
          $q->orWhereIn('sales_person', $juniorUserIds);
        });

        if ($this->isUserDispatch) {
          $quotationCount = ProjectQuotationTemp::with('purchaseOrder')->whereHas('purchaseOrder', function ($query) {
            $query->whereNotNull('id');
          })
            ->orderBy('id', 'desc');
        }
      }

      $quotationThisMonth = clone $quotationCount;
      $quotationCountThisMonth = $quotationThisMonth->whereYear('quotation_date', date('Y'))->whereMonth('quotation_date', date('m'))->count();
      $quotationAmountThisMonth = $quotationThisMonth->whereYear('quotation_date', date('Y'))->whereMonth('quotation_date', date('m'))->sum('final_amount_in_inr');

      $quotationThisYear = clone $quotationCount;
      $quotationCountThisYear = $quotationThisYear->whereYear('quotation_date', date('Y'))->count();
      $quotationAmountThisYear = $quotationThisYear->whereYear('quotation_date', date('Y'))->sum('final_amount_in_inr');

      $result = ['title' => 'Quotation', 'this_month' => $quotationCountThisMonth, 'this_year' => $quotationCountThisYear, 'this_month_amount' => 'INR ' . number_format($quotationAmountThisMonth, 2), 'this_year_amount' => 'INR ' . number_format($quotationAmountThisYear, 2)];
      $basicCountResult[] = $result;
    }

    //po count
    if (in_array('po', $basicCountReportParams)) {
      // Determine the base query depending on the user's role
      $dateColumn = 'po_date';
      if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        $poCount = PurchaseOrder::whereHas('rfq', function ($q) {
          $q->whereNotNull('id');
        })
          ->whereHas('lead', function ($q) {
            $q->whereNotNull('id');
          })
          ->where('po_type', 1)->orderBy('id', 'desc');
      } elseif ($this->isUserInsideSale || $this->psmUserRole) {
        $insideSaleDivisions = User::find($this->userId)->division_ids;
        $divisionIdsArray = explode(',', $insideSaleDivisions);

        $poCount = PurchaseOrder::whereHas('rfq', function ($query) use ($divisionIdsArray) {
          $query->whereNotNull('id');
          $query->whereIn('division_id', $divisionIdsArray);
        })
          ->whereHas('lead', function ($q) {
            $q->whereNotNull('id');
          })
          ->where('po_type', 1)->orderBy('id', 'desc');
      } else {

        $poCount = PurchaseOrder::where(function ($query) use ($juniorUserIds) {
          $query->where('prepared_by', $this->userId)
            ->orWhere(function ($q) use ($juniorUserIds) {
              $q->whereIn('prepared_by', $juniorUserIds);
            })
            ->orWhereHas('lead', function ($q) {
              $q->where('created_by', $this->userId)->whereNotNull('id');
            })
            ->orWhereHas('rfq', function ($q) {
              $q->where('created_by', $this->userId)->whereNotNull('id');
              $q->orWhere('rsm_id', $this->userId)->whereNotNull('id');
            });
        })->where('po_type', 1)->orderBy('id', 'desc');
      }

      // Clone the query and filter for the current month and year
      $poCountThisMonthQuery = clone $poCount;

      $poCountThisMonth = $this->applyFiscalMonthScope($poCountThisMonthQuery, $fiscalYear, $currentMonth, $dateColumn)->count();
      $poAmountThisMonth = $this->applyFiscalMonthScope($poCountThisMonthQuery, $fiscalYear, $currentMonth, $dateColumn)->sum('total_basic_value'); //before it was final_amount_in_inr

      // Clone the query and filter for the current year
      $poCountThisYearQuery = clone $poCount;
      $poCountThisYear = $this->applyFiscalYearScope($poCountThisYearQuery, $fiscalYear, $dateColumn)->count();
      $poAmountThisYear = $this->applyFiscalYearScope($poCountThisYearQuery, $fiscalYear, $dateColumn)->sum('total_basic_value'); //before it was final_amount_in_inr

      $result = ['title' => 'Purchase Order', 'this_month' => $poCountThisMonth, 'this_year' => $poCountThisYear, 'this_month_amount' => 'INR ' . formatIndianRupees($poAmountThisMonth, 2), 'this_year_amount' => 'INR ' . formatIndianRupees($poAmountThisYear, 2)];
      $basicCountResult[] = $result;
    }


    //invoice count
    if (in_array('invoice', $basicCountReportParams)) {
      if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        $invoiceCount = PurchaseInvoice::orderBy('id', 'desc');
      } else {
        $invoiceCount = PurchaseInvoice::where('created_by', $this->userId)->orderBy('id', 'desc');
      }

      $invoiceCountThisMonth = clone $invoiceCount;
      $invoiceCountThisMonth = $invoiceCountThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();

      $invoiceCountThisYear = clone $invoiceCount;
      $invoiceCountThisYear = $invoiceCountThisYear->whereYear('updated_at', date('Y'))->count();


      $result = ['title' => 'Invoice', 'this_month' => $invoiceCountThisMonth, 'this_year' => $invoiceCountThisYear];
      $basicCountResult[] = $result;
    }

    //open_rfq count
    if (in_array('rfq', $basicCountReportParams) && in_array('closed_rfq', $basicCountReportParams) && in_array('open_rfq', $basicCountReportParams)) {
      $totalRfqsThisMonth = 0;
      $totalRfqsThisYear = 0;

      foreach ($basicCountResult as $bcr) {
        if ($bcr['title'] == 'RFQ') {
          $totalRfqsThisMonth = $bcr['this_month'];
          $totalRfqsThisYear = $bcr['this_year'];
        }
      }

      if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        $closedRfq = ProjectLog::where('curr_sub_stage_id', $this->deliverySubStageId)->distinct()->groupBy('fk_rfq_id');
        $closedRfqThisMonth = clone $closedRfq;
        $closedRfqThisYear = clone $closedRfq;

        $closedRfqThisMonth = $closedRfqThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
        $closedRfqThisYear = $closedRfqThisYear->whereYear('updated_at', date('Y'))->count();
      } else {
        $closedRfq = ProjectLog::where('curr_sub_stage_id', $this->deliverySubStageId)->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])->distinct()->groupBy('fk_rfq_id');
        $closedRfqThisMonth = clone $closedRfq;
        $closedRfqThisYear = clone $closedRfq;

        $closedRfqThisMonth = $closedRfqThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
        $closedRfqThisYear = $closedRfqThisYear->whereYear('updated_at', date('Y'))->count();
      }

      $result = ['title' => 'Closed RFQ', 'this_month' => $closedRfqThisMonth, 'this_year' => $closedRfqThisYear];
      // $basicCountResult[] = $result;

      $result = ['title' => 'Open RFQ', 'this_month' => (int)$totalRfqsThisMonth - (int)$closedRfqThisMonth, 'this_year' => $totalRfqsThisYear - $closedRfqThisYear];
      // $basicCountResult[] = $result;
    }

    //pdr count
    if (in_array('pdr', $basicCountReportParams)) {
      if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        $pdrCount = PurchaseOrderPdrQuality::orderBy('id', 'desc');
      } else {
        $pdrCount = PurchaseOrderPdrQuality::where('created_by', $this->userId)->orderBy('id', 'desc');
      }

      $pdrCountThisMonth = clone $pdrCount;
      $pdrCountThisYear = clone $pdrCount;

      $pdrCountThisMonth = $pdrCountThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
      $pdrCountThisYear = $pdrCountThisYear->whereYear('updated_at', date('Y'))->count();

      $result = ['title' => 'PDR', 'this_month' => $pdrCountThisMonth, 'this_year' => $pdrCountThisYear];
      $basicCountResult[] = $result;
    }

    //delivery_note count
    if (in_array('delivery_note', $basicCountReportParams)) {
      if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        $dnCount = PurchaseOrderDneInvoice::orderBy('id', 'desc');
      } else {
        $dnCount = PurchaseOrderDneInvoice::where('created_by', $this->userId)->orderBy('id', 'desc');
      }

      $dnCountThisMonth = clone $dnCount;
      $dnCountThisYear = clone $dnCount;

      $dnCountThisMonth = $dnCountThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
      $dnCountThisYear = $dnCountThisYear->whereYear('updated_at', date('Y'))->count();

      $result = ['title' => 'Delivery Note', 'this_month' => $dnCountThisMonth, 'this_year' => $dnCountThisYear];
      $basicCountResult[] = $result;
    }

    return $basicCountResult;
  }

  public function rfqList(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $rfqNumber = $request->rfq_number ?? "";
      $rsmName = $request->rsm_name ?? "";
      $company = $request->company ?? "";
      $customerName = $request->customer_name ?? "";
      $startDate = $request->start_date ?? "";
      $endDate = $request->end_date ?? "";
      $divisionId = $request->division_id ?? "";
      $regionId = $request->region_id ?? "";
      $subStageId = $request->current_stage_id ?? "";
      $dateRange = strtolower($request->date_range);
      $dates = $this->getFiscalYearDates();
      $fiscalYear = $dates['fiscalYear'];
      $dateColumn = 'rfq_date';

      $juniorUserIds = $this->getJuniorIds(true);
      rsort($juniorUserIds);

      if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        $rfqFromRfq = Rfq::select('id')->orderBy('updated_at', 'desc');
        $rfqFromProjectLogs = ProjectLog::with('rfq')->select('fk_rfq_id as id')->distinct()->groupBy('fk_rfq_id');
      } else {
        $rfqFromRfq = Rfq::select('id')->where(function ($query) use ($juniorUserIds) {
          $query->whereIn('rsm_id', $juniorUserIds)
            ->orWhereIn('created_by', $juniorUserIds);
        });

        $rfqFromProjectLogs = ProjectLog::with('rfq')->select('fk_rfq_id as id')
          ->where(function ($q) use ($juniorUserIds) {
            foreach ($juniorUserIds as $key => $value) {
              $q->orWhereRaw('FIND_IN_SET(?, curr_user_ids)', [$value]);
            }
          })
          ->distinct()->groupBy('fk_rfq_id');
      }


      $rfqCount = $this->getRfqCount($rfqFromRfq, $rfqFromProjectLogs);
      $rfqList = $this->getRfqList($rfqCount);


      if ($rfqNumber) {
        $rfqList->where('rfq_number', 'like', "%" . $rfqNumber . "%");
      }

      if ($divisionId) {
        $rfqList->where('division_id', $divisionId);
      }

      if ($rsmName) {
        $rfqList->where('assigned_rsm',  $rsmName);
      }

      if ($company) {
        $rfqList->whereHas('lead', function ($query) use ($company) {
          $query->where('company', 'like', '%' . $company . '%');
        });
      }

      if ($subStageId) {
        $rfqList->where('curr_sub_stage_id', $subStageId);
      }

      if ($startDate && $endDate) {
        $rfqList->whereBetween('created_at', [$startDate, $endDate]);
      } elseif ($startDate) {
        $rfqList->whereDate('created_at', $startDate);
      }

      if ($customerName) {
        $rfqList->whereHas('lead', function ($query) use ($customerName) {
          $query->where('customer_name', 'like', '%' . $customerName . '%');
        });
      }

      if ($regionId) {
        $rfqList->whereHas('lead', function ($query) use ($regionId) {
          $query->where('fk_region_id', $regionId);
        });
      }

      if ($dateRange) {
        if ($dateRange == 'today') {
          $rfqList->whereDate('rfq_date', date('Y-m-d'));
        }
        if ($dateRange == 'yesterday') {
          $rfqList->whereDate('rfq_date', date('Y-m-d', strtotime('-1 day')));
        }
        if ($dateRange == 'last_7_days') {
          $rfqList->whereDate('rfq_date', '>=', date('Y-m-d', strtotime('-7 days')));
          $rfqList->whereDate('rfq_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'last_14_days') {
          $rfqList->whereDate('rfq_date', '>=', date('Y-m-d', strtotime('-14 days')));
          $rfqList->whereDate('rfq_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'last_28_days') {
          $rfqList->whereDate('rfq_date', '>=', date('Y-m-d', strtotime('-28 days')));
          $rfqList->whereDate('rfq_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'this_month') {
          $rfqList->whereMonth('rfq_date', date('m'))->whereYear('rfq_date', date('Y'));
        }

        if ($dateRange == 'last_month') {
          $rfqList->whereMonth('rfq_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('rfq_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
        }

        if ($dateRange == 'this_year') {
          $rfqList->where(function ($query) use ($fiscalYear, $dateColumn) {
            $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
              $inner->whereYear($dateColumn, $fiscalYear)
                ->whereMonth($dateColumn, '>=', 4);
            })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
              $inner->whereYear($dateColumn, $fiscalYear + 1)
                ->whereMonth($dateColumn, '<=', 3);
            });
          });
        }

        if ($dateRange == 'last_year') {
          $rfqList->where(function ($query) use ($fiscalYear, $dateColumn) {
            $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
              $inner->whereYear($dateColumn, $fiscalYear - 1)
                ->whereMonth($dateColumn, '>=', 4);
            })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
              $inner->whereYear($dateColumn, $fiscalYear)
                ->whereMonth($dateColumn, '<=', 3);
            });
          });
        }


        if ($dateRange == 'custom_date') {
          if ($startDate) {
            $rfqList->whereDate('rfq_date', '>=', $startDate);

            if ($endDate) {
              $rfqList->whereDate('rfq_date', '<=', $endDate);
            }
          }
        }
      }

      $num_rows = $rfqList->count();
      $total_pages = ceil($num_rows / $per_page);
      $rfqList = $rfqList->limit($per_page)->offset($offset)->get();


      $showModal = false;
      if ($this->isMarketing) {
        $showModal = true;
      }

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Rfq Lists"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['filePath'] = $filePath ?? '';
      $this->response['data']['total_pages'] = $total_pages;
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['end_date'] = $endDate;
      $this->response['data']['rfq_number'] = $rfqNumber;
      $this->response['data']['rsm_name'] = $rsmName;
      $this->response['data']['company'] = $company;
      $this->response['data']['current_stage_id'] = $subStageId;
      $this->response['data']['customer_name'] = $customerName;
      $this->response['data']['division_id'] = $divisionId;
      $this->response['data']['region_id'] = $regionId;
      $this->response['data']['show_modal'] = $showModal;
      $this->response['data']['date_range'] = $dateRange;
      $this->response['data']['list'] = $rfqList ?? [];

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Dashboard Rfq Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  private function getRfqCount($queryBuilder, $queryPro)
  {
    $rfq = $queryBuilder->get()->pluck('id')->toArray();
    $project = $queryPro->whereHas('rfq')->get()->pluck('id')->toArray();
    return array_unique(array_merge($rfq, $project));
  }

  private function getRfqList($rfqIds)
  {
    $query = RFQ::with('subStage:id,name', 'designation:id,name', 'source:id,name', 'division:id,name', 'products.product', 'products.productPart', 'lead')
      ->whereIn('id', $rfqIds)
      ->orderBy('created_at', 'desc');

    return $query;
  }


  public function purchaseOrderList(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $poType = $request->tab ?? '';
      $company = $request->company ?? '';
      $rsmId = $request->rsm_id ?? '';
      $purchaseOrderNo = $request->po_no ?? '';
      $divisionId = $request->division_id ?? '';
      $regionId = $request->region_id ?? '';
      $startDate = $request->start_date ?? "";
      $endDate = $request->end_date ?? "";
      $dateRange = strtolower($request->date_range) ?? '';
      $dates = $this->getFiscalYearDates();
      $fiscalYear = $dates['fiscalYear'];
      $dateColumn = 'po_date';

      $juniorUserIds = $this->getJuniorIds(true);
      rsort($juniorUserIds);

      if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        $po = PurchaseOrder::with(['preparedBy', 'poDespatchDetail.so', 'lead', 'rfq', 'rfq.currencyData', 'subStage:id,name', 'updatedBy:id,name', 'quotation:id,quotation_no', 'poType'])
          ->whereHas('rfq', function ($q) {
            $q->whereNotNull('id');
          })
          ->whereHas('lead', function ($q) {
            $q->whereNotNull('id');
          })
          ->where('po_type', 1)
          ->orderBy('updated_at', 'desc');
      } elseif ($this->isUserInsideSale || $this->psmUserRole) {
        $insideSaleDivisions = User::find($this->userId)->division_ids;
        $divisionIdsArray = explode(',', $insideSaleDivisions);

        $this->response['data']['dids'] = $divisionIdsArray;

        $po = PurchaseOrder::with(['preparedBy', 'poDespatchDetail', 'rfq.source', 'lead', 'rfq', 'rfq.currencyData', 'subStage:id,name', 'updatedBy:id,name', 'quotation:id,quotation_no', 'poType'])
          ->whereHas('rfq', function ($q) use ($divisionIdsArray) {
            $q->whereNotNull('id');
            $q->whereIn('division_id', $divisionIdsArray);
          })
          ->whereHas('lead', function ($q) {
            $q->whereNotNull('id');
          })
          ->where('po_type', 1)->orderBy('updated_at', 'desc');
      } else {
        $po = PurchaseOrder::with(['preparedBy', 'poDespatchDetail', 'lead', 'rfq', 'rfq.currencyData', 'subStage:id,name', 'updatedBy:id,name', 'quotation:id,quotation_no', 'poType'])
          ->where(function ($query) use ($juniorUserIds) {
            $query->where(function ($subQuery) use ($juniorUserIds) {
              $subQuery->where('prepared_by', $this->userId);
              $subQuery->orWhereIn('prepared_by', $juniorUserIds);
            });
            $query->orWhereHas('lead', function ($q) {
              $q->where('created_by', $this->userId)->whereNotNull('id');
            });
            $query->orWhereHas('rfq', function ($q) {
              $q->where('created_by', $this->userId)->whereNotNull('id');
              $q->orWhere('rsm_id', $this->userId)->whereNotNull('id');
            });
          })
          ->where('po_type', 1)
          ->orderBy('updated_at', 'desc');
      }

      if ($company) {
        $po->whereHas('lead', function ($query) use ($company) {
          $query->where('company', $company);
        });
      }

      if ($regionId) {
        $po->whereHas('lead', function ($query) use ($regionId) {
          $query->where('fk_region_id', $regionId);
        });
      }

      if ($rsmId) {
        $po->whereHas('rfq', function ($query) use ($rsmId) {
          $query->where('rsm_id', $rsmId);
        });
      }

      if ($divisionId) {
        $po->whereHas('rfq', function ($query) use ($divisionId) {
          $query->where('division_id', $divisionId);
        });
      }

      if ($purchaseOrderNo) {
        $po->where('po_no', 'like', '%' . $purchaseOrderNo . '%');
      }

      if ($dateRange) {
        if ($dateRange == 'today') {
          $po->whereDate('po_date', date('Y-m-d'));
        }
        if ($dateRange == 'yesterday') {
          $po->whereDate('po_date', date('Y-m-d', strtotime('-1 day')));
        }
        if ($dateRange == 'last_7_days') {
          $po->whereDate('po_date', '>=', date('Y-m-d', strtotime('-7 days')));
          $po->whereDate('po_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'last_14_days') {
          $po->whereDate('po_date', '>=', date('Y-m-d', strtotime('-14 days')));
          $po->whereDate('po_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'last_28_days') {
          $po->whereDate('po_date', '>=', date('Y-m-d', strtotime('-28 days')));
          $po->whereDate('po_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'this_month') {
          $po->whereMonth('po_date', date('m'))->whereYear('po_date', date('Y'));
        }

        if ($dateRange == 'last_month') {
          $po->whereMonth('po_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('po_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
        }

        if ($dateRange == 'this_year') {
          $po->where(function ($query) use ($fiscalYear, $dateColumn) {
            $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
              $inner->whereYear($dateColumn, $fiscalYear)
                ->whereMonth($dateColumn, '>=', 4);
            })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
              $inner->whereYear($dateColumn, $fiscalYear + 1)
                ->whereMonth($dateColumn, '<=', 3);
            });
          });
        }

        if ($dateRange == 'last_year') {
          $po->where(function ($inner) use ($fiscalYear, $dateColumn) {
            $inner->whereYear($dateColumn, $fiscalYear - 1)
              ->whereMonth($dateColumn, '>=', 4);
          })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
            $inner->whereYear($dateColumn, $fiscalYear)
              ->whereMonth($dateColumn, '<=', 3);
          });
        }

        if ($dateRange == 'custom_date') {
          if ($startDate) {
            $po->whereDate('po_date', '>=', $startDate);

            if ($endDate) {
              $po->whereDate('po_date', '<=', $endDate);
            }
          }
        }
      }

      $num_rows = $po->count();
      $poList = $po->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Purchase Order Lists"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = $poList ?? [];
      $this->response['data']['po_no'] = $purchaseOrderNo;
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['end_date'] = $endDate;
      $this->response['data']['date_range'] = $dateRange;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }


  public function quotationList(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $quotationType = $request->tab;
      $quotationNo = $request->quotation_no ?? '';
      $preparedBy = $request->prepared_by ?? '';
      $salesPerson = $request->sales_person ?? '';
      $divisionId = $request->division ?? '';
      $startDate = $request->start_date;
      $endDate = $request->end_date;
      $quotationStatus = $request->quotation_status ?? '';
      $company = $request->company ?? '';
      $curStageId = $request->current_stage_id ?? '';
      $finalAmount = $request->final_amount ?? '';
      $isExport = $request->is_export ?? 0;
      $dateRange = strtolower($request->date_range);
      $dates = $this->getFiscalYearDates();
      $fiscalYear = $dates['fiscalYear'];
      $dateColumn = 'quotation_date';


      if ($this->isUserAdmin || $this->isManagement || $this->isMarketing) {
        $quotation = ProjectQuotationTemp::with(['salesPerson', 'preparedBy', 'lead.region', 'rfq', 'rfq.division', 'rfq.subStage', 'rfq.designation', 'rfq.currencyData', 'rfq.source'])->orderBy('id', 'desc');
      } else if ($this->isUserInsideSale || $this->psmUserRole) {
        $insideSaleDivisions = User::find($this->userId)->division_ids;
        $divisionIdsArray = explode(',', $insideSaleDivisions);

        $quotation = ProjectQuotationTemp::with(['salesPerson', 'preparedBy', 'lead.region', 'rfq', 'rfq.division', 'rfq.subStage', 'rfq.designation', 'rfq.currencyData', 'rfq.source'])
          ->whereHas('rfq', function ($q) use ($divisionIdsArray) {
            $q->whereIn('division_id', $divisionIdsArray);
          })
          ->orderBy('id', 'desc');
      } else {
        $juniorUserIds = $this->getJuniorIds(true);
        rsort($juniorUserIds);

        $quotation = ProjectQuotationTemp::with(['salesPerson', 'preparedBy', 'lead.region', 'rfq', 'rfq.division', 'rfq.subStage', 'rfq.designation', 'rfq.currencyData', 'rfq.source'])->where(function ($q) use ($juniorUserIds) {
          $q->whereIn('prepared_by', $juniorUserIds);
          $q->orWhereIn('sales_person', $juniorUserIds);
        })
          ->orderBy('id', 'desc');

        if ($this->isUserDispatch) {
          $quotation = ProjectQuotationTemp::with(['purchaseOrder', 'rfq.division', 'salesPerson', 'preparedBy', 'lead.region', 'rfq', 'rfq.subStage', 'rfq.designation', 'rfq.currencyData', 'rfq.source'])->whereHas('purchaseOrder', function ($query) {
            $query->whereNotNull('id');
          })
            ->orderBy('id', 'desc');
        }
      }


      if ($quotationNo) $quotation->where('quotation_no', 'like', '%' . $quotationNo . '%');
      if ($finalAmount) $quotation->where('final_amount', 'like', '%' . $finalAmount . '%');
      if ($quotationStatus) $quotation->where('quotation_status', 'like', '%' . $quotationStatus . '%');

      if ($dateRange) {
        if ($dateRange == 'today') {
          $quotation->whereDate('quotation_date', date('Y-m-d'));
        }
        if ($dateRange == 'yesterday') {
          $quotation->whereDate('quotation_date', date('Y-m-d', strtotime('-1 day')));
        }
        if ($dateRange == 'last_7_days') {
          $quotation->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-7 days')));
          $quotation->whereDate('quotation_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'last_14_days') {
          $quotation->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-14 days')));
          $quotation->whereDate('quotation_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'last_28_days') {
          $quotation->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-28 days')));
          $quotation->whereDate('quotation_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'this_month') {
          $quotation->whereMonth('quotation_date', date('m'))->whereYear('quotation_date', date('Y'));
        }
        if ($dateRange == 'last_month') {
          $quotation->whereMonth('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
        }

        if ($dateRange == 'this_year') {
          $quotation->where(function ($query) use ($fiscalYear, $dateColumn) {
            $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
              $inner->whereYear($dateColumn, $fiscalYear)
                ->whereMonth($dateColumn, '>=', 4);
            })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
              $inner->whereYear($dateColumn, $fiscalYear + 1)
                ->whereMonth($dateColumn, '<=', 3);
            });
          });
        }

        if ($dateRange == 'last_year') {
          $quotation->where(function ($inner) use ($fiscalYear, $dateColumn) {
            $inner->whereYear($dateColumn, $fiscalYear - 1)
              ->whereMonth($dateColumn, '>=', 4);
          })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
            $inner->whereYear($dateColumn, $fiscalYear)
              ->whereMonth($dateColumn, '<=', 3);
          });
        }

        if ($dateRange == 'custom_date') {
          if ($startDate) {
            $quotation->whereDate('quotation_date', '>=', $startDate);

            if ($endDate) {
              $quotation->whereDate('quotation_date', '<=', $endDate);
            }
          }
        }
      }


      if ($preparedBy) {
        $quotation->whereHas('preparedBy', function ($query) use ($preparedBy) {
          $query->where('name', 'like', '%' . $preparedBy . '%');
        });
      }

      if ($salesPerson) {
        $quotation->where('sales_person', $salesPerson);
      }

      if ($divisionId) {
        $quotation->whereHas('rfq', function ($query) use ($divisionId) {
          $query->where('division_id', $divisionId);
        });
      }

      if ($curStageId) {
        $quotation->whereHas('rfq', function ($query) use ($curStageId) {
          $query->where('curr_sub_stage_id', $curStageId);
        });
      }


      if ($company) {
        $quotation->whereHas('lead', function ($query) use ($company) {
          $query->where('company', 'like', '%' . $company . '%');
        });
      }

      if ($quotationType === 'thismonth') {
        $quotationThisMonth = clone $quotation;
        $quotationList = $quotationThisMonth->whereYear('quotation_date', '=', date('Y'))->whereMonth('quotation_date', '=', date('m'));
      } elseif ($quotationType === 'thisyear') {
        $quotationThisYear = clone $quotation;
        $quotationList = $quotationThisYear->whereYear('quotation_date', '=', date('Y'));
      } else {
        $this->response['error'] = 'Invalid quotation type provided.';
        return $this->sendResponse($this->response, 500);
      }

      $num_rows = $quotationList->count();
      $quotation = $quotation->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Quotation Lists"]);
      $this->response['filePath'] = $filePath ?? '';
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['end_date'] = $endDate;
      $this->response['data']['quotation_no'] = $quotationNo;
      $this->response['data']['prepared_by'] = $preparedBy;
      $this->response['data']['quotation_status'] = $quotationStatus;
      $this->response['data']['company'] = $company;
      $this->response['data']['division'] = $divisionId;
      $this->response['data']['sales_person'] = $salesPerson;
      $this->response['data']['final_amount'] = $finalAmount;
      $this->response['data']['current_stage_id'] = $curStageId;
      $this->response['data']['list'] = $quotationList ?? [];

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Dashboard Quotation Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  public function invoiceList(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $piType = $request->tab;
      $startDate = $request->start_date ?? '';
      $endDate = $request->end_date ?? '';
      $piNo = $request->pi_no ?? '';
      $piAmount = $request->pi_amount ?? '';

      if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        $pi = PurchaseInvoice::orderBy('id', 'desc');
      } else {
        $pi = PurchaseInvoice::where('created_by', $this->userId)->orderBy('id', 'desc');
      }

      if ($piNo) {
        $pi->where('pi_no', 'like', "%" . $piNo . "%");
      }

      if ($piAmount) {
        $pi->where('pi_total_amount', 'like', "%" . $piAmount . "%");
      }

      if ($startDate && $endDate) {
        $pi->whereBetween('pi_date', [$startDate, $endDate]);
      } elseif ($startDate) {
        $pi->whereDate('pi_date', $startDate);
      }

      $num_rows = $pi->count();

      if ($piType === 'thismonth') {
        $piThisMonth = clone $pi;
        $piList = $piThisMonth
          ->whereYear('updated_at', '=', date('Y'))
          ->whereMonth('updated_at', '=', date('m'))
          ->limit($per_page)->offset($offset)->get();
      } elseif ($piType === 'thisyear') {
        $piThisYear = clone $pi;
        $piList = $piThisYear
          ->whereYear('updated_at', '=', date('Y'))
          ->limit($per_page)->offset($offset)->get();
      } else {
        $this->response['error'] = 'Invalid purchase invoice type provided.';
        return $this->sendResponse($this->response, 500);
      }

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Invoice Lists"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['pi_no'] = $piNo;
      $this->response['data']['pi_amount'] = $piAmount;
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['end_date'] = $endDate;
      $this->response['data']['list'] = $piList ?? [];

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  public function toggleRfqList()
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      //From RFQ Table
      $rfqFromRfq = Rfq::select('id as rfq_id')->orderBy('id', 'desc');
      $rfqFromRfqThisMonth = clone $rfqFromRfq;
      $rfqFromRfqThisYear = clone $rfqFromRfq;
      $rfqFromRfqThisMonth = $rfqFromRfqThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->toArray(); //7
      $rfqFromRfqThisYear = $rfqFromRfqThisYear->whereYear('updated_at', date('Y'))->get()->toArray(); //25

      //From Project Logs table
      $rfqFromProjectLogs = ProjectLog::select('fk_rfq_id as rfq_id')->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])->distinct()->groupBy('fk_rfq_id');

      $rfqFromProjectLogsThisMonth = $rfqFromProjectLogs->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->toArray(); //6
      $rfqFromProjectLogsThisYear = $rfqFromProjectLogs->whereYear('updated_at', date('Y'))->get()->toArray(); //33

      //Merging Array From Both table
      $rfqCountThisMonthIds = array_unique(array_column(array_merge($rfqFromRfqThisMonth, $rfqFromProjectLogsThisMonth), 'rfq_id'));
      $rfqCountThisYearIds = array_unique(array_column(array_merge($rfqFromRfqThisYear, $rfqFromProjectLogsThisYear), 'rfq_id'));

      //Closed RFQ
      $closedRfq = ProjectLog::where('curr_sub_stage_id', $this->deliverySubStageId)->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])->distinct()->groupBy('fk_rfq_id');

      $rfqMonthArray = $closedRfq->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->toArray();

      $rfqYearArray = $closedRfq->whereYear('updated_at', date('Y'))->get()->toArray();

      //For Array Difference from merged Array and closed Array
      $rfqClosedMonthIds = array_column($rfqMonthArray, 'fk_rfq_id');
      $rfqClosedYearIds = array_column($rfqYearArray, 'fk_rfq_id');

      $diffMonthIds = array_diff($rfqCountThisMonthIds, $rfqClosedMonthIds);
      $diffYearIds = array_diff($rfqCountThisYearIds, $rfqClosedYearIds);

      //Fetching value from diffIds
      $finalRfqMonthList = RFQ::with('subStage:id,name', 'products.product:id,product_name')->whereIn('id', $diffMonthIds)->get();
      $finalRfqYearList = RFQ::with('subStage:id,name', 'products.product:id,product_name')->whereIn('id', $diffYearIds)->get();

      $openRfq = [
        'this_month' => $finalRfqMonthList,
        'this_year' => $finalRfqYearList,
      ];

      $closedRfq = [
        'this_month' => $rfqMonthArray,
        'this_year' => $rfqYearArray,
      ];

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Rfq Lists"]);
      $this->response['data']['open_rfq'] = $openRfq;
      $this->response['data']['closed_rfq'] = $closedRfq;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Dashboard Rfq Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }


  public function purchaseOrderPdrList()
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $pdrCount = PurchaseOrderPdrQuality::where('created_by', $this->userId)->orderBy('id', 'desc');
      $pdrThisMonth = clone $pdrCount;
      $pdrThisYear = clone $pdrCount;

      $pdrThisMonth = $pdrThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get();
      $pdrThisYear = $pdrThisYear->whereYear('updated_at', date('Y'))->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Purchase Order PDR Quality Lists"]);
      $this->response['data']['pdrThisMonth'] = $pdrThisMonth;
      $this->response['data']['pdrThisYear'] = $pdrThisYear;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Dashboard Purchase Order PDR Quality Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function deliveryNoteList()
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $dnCount = PurchaseOrderDneInvoice::where('created_by', $this->userId)->orderBy('id', 'desc');
      $dnThisMonth = clone $dnCount;
      $dnThisYear = clone $dnCount;

      $dnThisMonth = $dnThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get();
      $dnThisYear = $dnThisYear->whereYear('updated_at', date('Y'))->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Purchase Order Delivery Note Lists"]);
      $this->response['data']['dnThisMonth'] = $dnThisMonth;
      $this->response['data']['dnThisYear'] = $dnThisYear;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Dashboard Purchase Order PDR Quality Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }


  function generatePendingRfqReport($isNationalHead = false)
  {
    $pendingRfqData = ProjectLog::with('rfq.products.product', 'rfq.lead', 'subStage')
      ->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])
      ->where('curr_sub_stage_id', '!=', $this->deliverySubStageId)
      ->whereHas('rfq', function ($query) {
        $query->whereHas('lead');
      })
      ->groupBy('fk_rfq_id')->take(6)->get();

    return $pendingRfqData;
  }

  function generateTaskReport($isNationalHead = false)
  {
    $juniorUserIds = $this->getJuniorIds(false);
    rsort($juniorUserIds);

    if ($this->isManagement || $this->isUserAdmin || $this->isMarketing || $this->isUserHr) {
      $taskData = Task::with('assignedToUsers.user', 'lead', 'rfq', 'assignedBy')->take(6)->orderBy('updated_at', 'desc')->get();
    } else {
      $taskData = Task::with('assignedToUsers.user', 'lead', 'rfq', 'assignedBy')
        ->whereHas('assignedToUsers', function ($query) use ($juniorUserIds) {
          $query->whereIn('created_by', $juniorUserIds);
          $query->orWhereIn('fk_user_id', $juniorUserIds);
        })->take(6)->orderBy('updated_at', 'desc')->get();
    }

    return $taskData;
  }

  function taskReport()
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $taskData = Task::with('assignedToUsers.user', 'lead', 'rfq', 'assignedBy')
        ->whereHas('assignedToUsers', function ($query) {
          $query->where('created_by', $this->userId);
          $query->orWhere('fk_user_id', $this->userId);
        })->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Task"]);
      $this->response['data']['list'] = $taskData;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Task Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  function generateReminderReport($isNationalHead = false)
  {
    $reminderData = Reminder::with('reminderUser.user', 'reminderBy')
      ->whereHas('reminderUser', function ($query) {
        $query->where('created_by', $this->userId);
        $query->orWhere('fk_user_id', $this->userId);
      })->take(6)->get();

    return $reminderData;
  }

  function reminderReport()
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $reminderData = Reminder::with('reminderUser.user', 'reminderBy')
        ->whereHas('reminderUser', function ($query) {
          $query->where('created_by', $this->userId);
          $query->orWhere('fk_user_id', $this->userId);
        })->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Reminder"]);
      $this->response['data']['list'] = $reminderData;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Reminder Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  function generateQuickReport($isNationalHead = false)
  {
    $quickReportData = MasterReportPreset::where('created_by', $this->userId)->get();
    return $quickReportData;
  }

  function generateVisitDataReport($isNationalHead = false)
  {
    $visitData = SalesVisitReport::with(['lead', 'rfq'])
      ->where('sales_person', $this->userId)
      ->whereMonth('created_at', date('m'))
      ->whereYear('created_at', date('Y'))
      ->orderBy('created_at', 'desc')->take(6)
      ->get();
    $visitData = NewDashboardVisitResource::collection($visitData);

    return $visitData;
  }

  function saleVisitReport()
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $visitData = SalesVisitReport::with(['lead', 'rfq'])
        ->where('sales_person', $this->userId)
        ->whereMonth('created_at', date('m'))
        ->whereYear('created_at', date('Y'))
        ->orderBy('created_at', 'desc')->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Sales Visit Report"]);
      $this->response['data']['list'] = NewDashboardVisitResource::collection($visitData);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Sales Visit Report Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  function pendingRfq()
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $pendingRfqData = ProjectLog::with('rfq.products.product', 'rfq.lead', 'subStage')
        ->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])
        ->where('curr_sub_stage_id', '!=', $this->deliverySubStageId)
        ->whereHas('rfq', function ($query) {
          $query->whereHas('lead');
        })
        ->groupBy('fk_rfq_id')
        ->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Pending RFQ"]);
      $this->response['data']['list'] = $pendingRfqData;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Pending RFQ Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  function generateStatisticsReport($isNationalHead = false)
  {
    if ($isNationalHead) {
      $plan = MonthlyPlanExcel::where('month', strtolower(date('F')))->where('year', date('Y'))->get();

      $statisticsData['monthlyTarget'] = array_sum(array_column($plan->toArray(), 'target'));

      $statisticsData['achievedTarget'] = PurchaseOrder::where('is_verified', 1)
        ->whereMonth('po_date', date('m'))
        ->whereYear('po_date', date('Y'))
        ->sum('po_details_total');

      $statisticsData['plannedVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->count();

      $statisticsData['actualVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->where('fk_status_id', 5)->count();
    } else {
      $plan = MonthlyPlanExcel::where('rsm_id', $this->userId)
        ->where('month', strtolower(date('F')))
        ->where('year', date('Y'))
        ->get();

      $statisticsData['monthlyTarget'] = array_sum(array_column($plan->toArray(), 'target'));

      $statisticsData['achievedTarget'] = PurchaseOrder::where('prepared_by', $this->userId)
        ->where('is_verified', 1)
        ->whereMonth('po_date', date('m'))
        ->whereYear('po_date', date('Y'))
        ->sum('po_details_total');

      $statisticsData['plannedVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->count();

      $statisticsData['actualVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->where('fk_status_id', 5)->count();
    }

    return $statisticsData;
  }

  function generateTypeOfClientReport($isNationalHead = false)
  {
    $typeOfClientData = ProjectType::withCount('leads')->get();
    return $typeOfClientData;
  }

  function typeOfClientReport()
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $typeOfClientData = ProjectType::with('leads.designation')->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Client Report"]);
      $this->response['data']['list'] = $typeOfClientData;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Client Report Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  function generateIndustryReport($isNationalHead = false)
  {
    $industryList = Industry::select('id', 'name')->get()->toArray();

    foreach ($industryList as &$industry) {
      $rfqs = Rfq::where(function ($query) use ($industry) {
        $query->orWhereJsonContains('industry', ['id' => $industry['id']]);
      })->get()->toArray();

      $industry['rfq_count'] = count($rfqs);
    }

    usort($industryList, function ($object1, $object2) {
      return $object1['rfq_count'] < $object2['rfq_count'];
    });

    $industries = array_slice($industryList, 0, 6);

    return $industries;
  }

  function generateSegmentReport($isNationalHead = false)
  {
    $segmentList = ProjectSegment::select('id', 'name')->where('status', 1)->get()->toArray();

    foreach ($segmentList as &$segment) {
      $rfqs = Rfq::where(function ($query) use ($segment) {
        $query->orWhereJsonContains('project_segments', [$segment['id']]);
      })->get()->toArray();

      $segment['rfq_count'] = count($rfqs);
    }

    usort($segmentList, function ($object1, $object2) {
      return $object1['rfq_count'] < $object2['rfq_count'];
    });

    $segments = array_slice($segmentList, 0, 6);

    return $segments;
  }

  function generateZoneReport($isNationalHead = false)
  {
    $zoneList = Region::select('id', 'name')->withCount('lead')->where('status', 1)->get()->toArray();

    return $zoneList;
  }

  private function generateLeadReport($isNationalHead = false): array
  {

    $rsmUserId = $this->userId;

    $rawLeadCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNull('customer_name')
      ->whereNull('company')
      ->whereNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->with('svr', 'rfqs')
      ->whereDoesntHave('rfqs')
      ->whereDoesntHave('svr')
      ->take(1)->get()->toArray();

    $potentialLeadCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNotNull('customer_name')
      ->whereNotNull('company')
      ->whereNotNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->with('svr', 'rfqs')
      ->whereDoesntHave('rfqs')
      ->whereDoesntHave('svr')
      ->take(1)->get()->toArray();

    $prospectLeadCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNotNull('customer_name')
      ->whereNotNull('company')
      ->whereNotNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->whereHas('svr', function ($query) {
        $query->whereNull('application_details');
      })
      ->with('svr', 'rfqs')
      ->whereDoesntHave('rfqs')
      ->take(1)->get()->toArray();


    $leadFinalizedCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNotNull('customer_name')
      ->whereNotNull('company')
      ->whereNotNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->whereHas('svr', function ($query) {
        $query->whereNotNull('application_details');
      })
      ->with('svr', 'rfqs')
      ->whereHas('rfqs')
      ->take(1)->get()->toArray();

    $data = [
      'rawLeadCount' => $rawLeadCount,
      'potentialLeadCount' => $potentialLeadCount,
      'prospectLeadCount' => $prospectLeadCount,
      'leadFinalizedCount' => $leadFinalizedCount,

    ];
    return $data;
  }

  public function generateDayInOutReport($isNationalHead)
  {
    $juniorUserIds = $this->getJuniorIds(false);
    rsort($juniorUserIds);

    // if (count($juniorUserIds) < 2) {
    //   return [];
    // }

    $todayDate = date('Y-m-d');

    if ($this->isManagement || $this->isUserAdmin || $this->isMarketing || $this->isUserHr) {
      $rsmUsers = UserRole::where('fk_department_id', 5)->get();
    } else {
      $rsmUsers = UserRole::where('fk_department_id', 5)->whereIn('fk_user_id', $juniorUserIds)->get();
    }

    $rsmUserIds = $rsmUsers->map(function ($item) {
      return $item->fk_user_id;
    });

    $userAtt = UserAttendance::with('user:id,name')
      ->whereIn('fk_user_id', $rsmUserIds)
      ->whereDate('attendance_date', $todayDate)
      ->orderBy('created_at', 'desc')
      ->take(5)
      ->get()
      ->toArray();


    foreach ($userAtt as &$user) {
      $activityCount = Activity::where('fk_user_id', $user['fk_user_id'])->whereDate('created_at', $todayDate)->count();
      $user['activity_count'] = $activityCount;
    }

    return $userAtt;
  }

  function zoneReport()
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $zoneList = Region::select('id', 'name')->with('lead')->where('status', 1)->get()->toArray();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Zone Report"]);
      $this->response['data']['list'] = $zoneList;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Zone Report Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  function industryReport()
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $industryList = Industry::select('id', 'name')->get()->toArray();

      foreach ($industryList as &$industry) {
        $rfqs = Rfq::where(function ($query) use ($industry) {
          $query->orWhereJsonContains('industry', ['id' => $industry['id']]);
        })->get()->toArray();

        $industry['rfq_count'] = count($rfqs);
      }

      usort($industryList, function ($object1, $object2) {
        return $object1['rfq_count'] < $object2['rfq_count'];
      });

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Segment Report"]);
      $this->response['data']['list'] = $industryList;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Segment Report Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  function industryReportLists(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $industryId = $request->id;

      $rfqs = Rfq::whereJsonContains('industry', ['id' => $industryId])->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Industry Report"]);
      $this->response['data']['list'] = $rfqs;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Industry Report Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  function segmentReport()
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $segmentList = ProjectSegment::select('id', 'name')->where('status', 1)->get()->toArray();

      foreach ($segmentList as &$segment) {
        $rfqs = Rfq::where(function ($query) use ($segment) {
          $query->orWhereJsonContains('project_segments', [$segment['id']]);
        })->get()->toArray();

        $segment['rfq_count'] = count($rfqs);
      }

      usort($segmentList, function ($object1, $object2) {
        return $object1['rfq_count'] < $object2['rfq_count'];
      });

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Segment Report"]);
      $this->response['data']['list'] = $segmentList;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Segment Report Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  function segmentReportLists(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $segmentId = $request->id;

      $rfqs = Rfq::whereJsonContains('project_segments', [$segmentId])->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Segment Report"]);
      $this->response['data']['list'] = $rfqs;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Segment Report Lists fetching failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  public function leadReport()
  {

    $rsmUserId = $this->userId;

    $rawLeadCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNull('customer_name')
      ->whereNull('company')
      ->whereNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->with('svr', 'rfqs')
      ->whereDoesntHave('rfqs')
      ->whereDoesntHave('svr')
      ->get();

    $potentialLeadCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNotNull('customer_name')
      ->whereNotNull('company')
      ->whereNotNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->with('svr', 'rfqs')
      ->whereDoesntHave('rfqs')
      ->whereDoesntHave('svr')
      ->get();

    $prospectLeadCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNotNull('customer_name')
      ->whereNotNull('company')
      ->whereNotNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->whereHas('svr', function ($query) {
        $query->whereNull('application_details');
      })
      ->with('svr', 'rfqs')
      ->whereDoesntHave('rfqs')
      ->get();

    $leadFinalizedCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNotNull('customer_name')
      ->whereNotNull('company')
      ->whereNotNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->whereHas('svr', function ($query) {
        $query->whereNotNull('application_details');
      })
      ->with('svr', 'rfqs')
      ->whereHas('rfqs')
      ->get();

    $data = [
      'rawLeadCount' => $rawLeadCount,
      'potentialLeadCount' => $potentialLeadCount,
      'prospectLeadCount' => $prospectLeadCount,
      'leadFinalizedCount' => $leadFinalizedCount,

    ];
    return $data;
  }

  public function DayInOut(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $rsmUsers = $request->fk_user_id ?? '';
      $fkRsmId = explode(',', $rsmUsers);
      $fkRsmId = array_filter($fkRsmId, 'strlen');
      $startDate = $request->start_date ?? date('Y-m-d');
      $endDate = $request->end_date;

      $juniorUserIds = $this->getJuniorIds(false);
      rsort($juniorUserIds);

      if ($this->isManagement || $this->isUserAdmin || $this->isMarketing || $this->isUserHr) {
        $rsmUsers = UserRole::where('fk_department_id', 5)->get();
      } else {
        $rsmUsers = UserRole::where('fk_department_id', 5)->whereIn('fk_user_id', $juniorUserIds)->get();
      }

      $rsmUserIds = $rsmUsers->map(function ($item) {
        return $item->fk_user_id;
      });

      $userAtt = UserAttendance::with('user:id,name')
        ->whereIn('fk_user_id', $rsmUserIds)
        ->orderBy('created_at', 'desc');

      if ($startDate && $endDate) {
        $userAtt->whereBetween('attendance_date', [$startDate, $endDate]);
      } else {
        $userAtt->whereDate('attendance_date', $startDate);
      }

      if (!empty($fkRsmId) && !empty($rsmUsers)) {
        $userAtt->whereIn('fk_user_id', $fkRsmId);
      }

      $userAtt = $userAtt->get();

      $num_rows = $userAtt->count();

      foreach ($userAtt as $user) {
        $activityCount = Activity::where('fk_user_id', $user->fk_user_id)->whereDate('created_at', $user->attendance_date)->count();
        $user->activity_count = $activityCount;
      }

      $result = $userAtt->slice($offset)->take($per_page)->values();

      $showButton = false;

      if ($this->isManagement || $this->isUserAdmin || $this->isMarketing) {
        $showButton = true;
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Day In / Day Out"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['end_date'] = $endDate;
      $this->response['data']['selectRsm'] = $showButton;
      $this->response['data']['fk_user_id'] = $fkRsmId;
      $this->response['data']['list'] = $result;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Day In Day Out fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function activityList(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $startDate = $request->start_date ?? date("Y-m-d");
      $userId = $request->fk_user_id ?? '';
      $endDate = $request->end_date;
      $comment = $request->comment ?? '';
      $taskType = $request->taskType ?? '';
      $customer = $request->customer ?? '';
      $rsmId = $request->rsm_id ?? '';
      $activityType = $request->activity_type ?? '';
      $isPhysicalVisit = $request->is_physical_visit ?? '';
      $rfq = $request->rfq ?? '';

      // $rsmUsers = UserRole::where('fk_department_id', 5)->get();
      // $rsmUserIds = $rsmUsers->map(function ($item) {
      //   return $item->fk_user_id;
      // });

      // $userAtt = UserAttendance::with('user:id,name')->whereIn('fk_user_id', $rsmUserIds)->whereBetween('attendance_date', [$startDate, $endDate])->get();

      // $userIds = $userAtt->pluck('fk_user_id')->toArray();

      $activities = Activity::with('activityType', 'createdBy:id,name', 'latestActivityLog', 'taskType', 'lead', 'rfq', 'svr')
        ->where('fk_user_id', $rsmId)
        ->orderBy('start_time', 'desc');

      if ($startDate && $endDate) {
        $activities->whereBetween('created_at', [$startDate, $endDate]);
      } else {
        $activities->whereDate('created_at', $startDate);
      }

      if ($customer) {
        $activities->whereHas('lead', function ($q) use ($customer) {
          if ($customer) $q->where(['id' => $customer, 'status' => 1]);
        });
      }

      if ($rfq) {
        $activities->where('fk_rfq_id', $rfq);
      }

      if ($comment) {
        $activities->where('comment', 'like', '%' . $comment . '%');
      }

      if ($taskType) {
        $activities->where('fk_task_type_id', '=', $taskType);
      }

      if ($activityType) {
        $activities->where('fk_activity_type_id', '=', $activityType);
      }

      if ($isPhysicalVisit) {
        $activities->where('is_physical_visit', '=', $isPhysicalVisit);
      }

      $getDepartment = UserRole::where('fk_user_id', $this->userId)
        ->whereIn('fk_department_id', [2, 4, 3, 10])->get();

      $juniorUserIds = $this->getJuniorIds(true);
      rsort($juniorUserIds);

      if (!$getDepartment->isEmpty() || count($juniorUserIds) > 1) {
        $showRsmFilter = true;
      } else {
        $showRsmFilter = false;
      }

      $num_rows = $activities->count();
      $result = $activities->skip($offset)->take($per_page)->get();


      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Activity"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['end_date'] = $endDate;
      $this->response['data']['task_type'] = $taskType;
      $this->response['data']['activity_type'] = $activityType;
      $this->response['data']['comment'] = $comment;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = ActivityResource::collection($result);
      $this->response['data']['showRsmFilter'] = $showRsmFilter;
      $this->response['data']['rsm_id'] = $rsmId;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Lead fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function exportDayInOut(Request $request)
  {

    try {

      $rsmUsers = $request->fk_user_id ?? '';
      $fkRsmId = explode(',', $rsmUsers);
      $fkRsmId = array_filter($fkRsmId, 'strlen');
      $startDate = $request->start_date ?? date('Y-m-d');
      $endDate = $request->end_date;


      $rsmUsers = UserRole::where('fk_department_id', 5)->get();
      $rsmUserIds = $rsmUsers->map(function ($item) {
        return $item->fk_user_id;
      });

      $userAtt = UserAttendance::with('user:id,name')
        ->whereIn('fk_user_id', $rsmUserIds)
        ->orderBy('created_at', 'desc');

      if ($startDate && $endDate) {
        $userAtt->whereBetween('attendance_date', [$startDate, $endDate]);
      } else {
        $userAtt->whereDate('attendance_date', $startDate);
      }

      if (!empty($fkRsmId) && !empty($rsmUsers)) {
        $userAtt->whereIn('fk_user_id', $fkRsmId);
      }

      $userAtt = $userAtt->get();

      foreach ($userAtt as $user) {
        $activityCount = Activity::where('fk_user_id', $user->fk_user_id)
          ->whereDate('created_at', $user->attendance_date)
          ->count();
        $user->activity_count = $activityCount;
        if ($activityCount === 0) {
          $user->activity_count = 0;
        }
      }

      $spreadsheet = new Spreadsheet();
      $sheet = $spreadsheet->getActiveSheet();
      $headers = ['Sr.No', 'User', 'Day In', 'Day Out', 'Activity'];
      $sheetData = [$headers];

      foreach ($userAtt as $key => $item) {
        $rowData = [
          $key + 1,
          $item->user->name,
          Carbon::parse($item->checkin_time)->format('M d, Y h:i a'),
          Carbon::parse($item->checkout_time)->format('M d, Y h:i a'),
          (string)$item->activity_count,
        ];

        $sheetData[] = $rowData;
      }

      $sheet->fromArray($sheetData, null, 'A1');

      // $filePath = $this->fileAccessPath  . "/dayinout/Day_in_out.xlsx";
      $filePath = "storage/app/public/uploads/dayinout/Day_in_out.xlsx";
      $writer = new Xlsx($spreadsheet);
      $writer->save($filePath);

      $this->response['status'] = 1;
      $this->response['msg'] = "File downloaded successfully";
      $this->response['filePath'] = $filePath;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("File Download failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function exportActivity(Request $request)
  {

    try {

      $startDate = $request->start_date ?? date("Y-m-d");
      $userId = $request->fk_user_id ?? '';
      $endDate = $request->end_date;
      $comment = $request->comment ?? '';
      $taskType = $request->taskType ?? '';
      $customer = $request->customer ?? '';
      $rsmId = $request->rsm_id ?? '';
      $activityType = $request->activity_type ?? '';
      $isPhysicalVisit = $request->is_physical_visit ?? '';
      $rfq = $request->rfq ?? '';

      $activities = Activity::with('activityType', 'latestActivityLog', 'taskType', 'lead', 'rfq', 'svr')
        ->where('fk_user_id', $rsmId)
        ->orderBy('start_time', 'desc');

      if ($startDate && $endDate) {
        $activities->whereBetween('created_at', [$startDate, $endDate]);
      } else {
        $activities->whereDate('created_at', $startDate);
      }

      if ($customer) {
        $activities->whereHas('lead', function ($q) use ($customer) {
          if ($customer) $q->where(['id' => $customer, 'status' => 1]);
        });
      }

      if ($rfq) {
        $activities->where('fk_rfq_id', $rfq);
      }

      if ($comment) {
        $activities->where('comment', 'like', '%' . $comment . '%');
      }

      if ($taskType) {
        $activities->where('fk_task_type_id', '=', $taskType);
      }

      if ($activityType) {
        $activities->where('fk_activity_type_id', '=', $activityType);
      }

      if ($isPhysicalVisit) {
        $activities->where('is_physical_visit', '=', $isPhysicalVisit);
      }

      $result = $activities->get();


      foreach ($result as $res) {
        $attendanceRecord = UserAttendance::where('fk_user_id', $res->fk_user_id)
          ->whereDate('attendance_date', $res->created_at)
          ->first();

        if ($attendanceRecord) {
          $res->checkinTime = $attendanceRecord->checkin_time;
          $res->checkoutTime = $attendanceRecord->checkout_time;
        } else {
          $res->checkinTime = null;
          $res->checkoutTime = null;
        }
      }

      $spreadsheet = new Spreadsheet();
      $sheet = $spreadsheet->getActiveSheet();
      $headers = ['Sr.No', 'DayIn', 'DayOut', 'Activity Type', 'SVR No.', 'Activity For', 'Location', 'Activity Start Time', 'Activity End Time', 'Total Time', 'Status', 'Comment'];
      $sheetData = [$headers];

      foreach ($result as $key => $item) {
        $totalTime = '-';

        if (!empty($item->start_time) && !empty($item->end_time)) {
          $startTime = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->start_time);
          $endTime = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->end_time);

          $duration = $endTime->diff($startTime);

          $hours = $duration->h;
          $minutes = $duration->i;

          $totalTime = "{$hours} hrs {$minutes} min";
        }

        $activityFor = '';
        if ($item->taskType && $item->taskType->code == 'other') {
          $activityFor = 'Other';
        } elseif ($item->taskType && $item->taskType->code == 'lead') {
          $activityFor = $item->lead->company . ' (' . $item->lead->customer_name . ')';
        } elseif ($item->taskType && $item->taskType->code == 'rfq') {
          $activityFor = $item->rfq->customer_name;
        }

        $rowData = [
          $key + 1,
          Carbon::parse($item->checkinTime)->format('M d, Y h:i a'),
          Carbon::parse($item->checkoutTime)->format('M d, Y h:i a'),
          $item->activityType->title,
          $item->svr->report_no ?? '-',
          $activityFor,
          $item->latestActivityLog->location ?? '-',
          Carbon::parse($item->start_time)->format('M d, Y h:i a'),
          Carbon::parse($item->end_time)->format('M d, Y h:i a'),
          $totalTime,
          (!empty($item->end_time) ? 'Completed' : 'Ongoing'),
          $item->comment ?? '-',
        ];

        $sheetData[] = $rowData;
      }

      $sheet->fromArray($sheetData, null, 'A1');

      // $filePath = $this->fileAccessPath  . "/activity/Activity.xlsx";
      $filePath = "storage/app/public/uploads/activity/Activity.xlsx";
      $writer = new Xlsx($spreadsheet);
      $writer->save($filePath);

      $this->response['status'] = 1;
      $this->response['msg'] = "File downloaded successfully";
      $this->response['filePath'] = $filePath;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("File Download failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }
}



// namespace App\Http\Controllers\AppApi;

// use App\Http\Controllers\API\AppBaseController;
// use App\Http\Resources\NewDashboardVisitResource;
// use App\Models\Industry;
// use App\Models\MasterReportPreset;
// use App\Models\MonthlyPlanExcel;
// use App\Models\ProjectLog;
// use App\Models\ProjectSegment;
// use App\Models\ProjectType;
// use App\Models\PurchaseInvoice;
// use App\Models\PurchaseOrder;
// use App\Models\ProjectQuotationTemp;
// use App\Models\PurchaseOrderDneInvoice;
// use App\Models\PurchaseOrderPdrQuality;
// use App\Models\Region;
// use App\Models\Reminder;
// use App\Models\Rfq;
// use App\Models\SalesVisitReport;
// use App\Models\Task;
// use App\Models\User;
// use App\Models\UserRole;
// use Exception;
// use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Log;

// class NewDashboardController extends AppBaseController
// {
//     private $piSubStageId = 16;
//     private $rfqApproveSubStageId = 22;
//     private $poApproveSubStageId = 35;
//     private $dnSubStageId = 45;
//     private $pdrSubStageId = 46;
//     private $deliverySubStageId = 49;

//     private $dashboardArray = [
//         7 => [ //PSM
//             'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq'],
//             'pending_rfqs' => true,
//             'task' => true,
//             'reminder' => true,
//             'quick_report' => false,
//         ],
//         6 => [ //INSIDE_SALES
//             'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq'],
//             'pending_rfqs' => true,
//             'task' => true,
//             'reminder' => true,
//             'quick_report' => false,
//         ],
//         8 => [ //QUALITY
//             'basic_counts' => ['quotation', 'po', 'invoice', 'pdr', 'delivery_note'],
//             'pending_rfqs' => true,
//             'task' => true,
//             'reminder' => true,
//             'quick_report' => false,
//         ],
//         9 => [ //DISPATCH
//             'basic_counts' => ['quotation', 'po', 'invoice', 'pdr', 'delivery_note'],
//             'pending_rfqs' => true,
//             'task' => true,
//             'reminder' => true,
//             'quick_report' => false,
//         ],
//         4 => [ //MARKETING
//             'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq'],
//             'pending_rfqs' => true,
//             'task' => true,
//             'reminder' => true,
//             'quick_report' => false,
//             'visit' => true,
//             'statistics' => false,
//         ],
//         5 => [ //SALES
//             'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq'],
//             'pending_rfqs' => true,
//             'task' => true,
//             'reminder' => true,
//             'quick_report' => false,
//             'visit' => true,
//             'statistics' => false,
//             // 'type_of_client' => true,
//             // 'segment' => true,
//             // 'industry' => true,
//             // 'zone' => true,
//         ],
//         'NATIONAL_HEAD' => [
//             'basic_counts' => ['rfq', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq', 'pdr', 'delivery_note'],
//             'task' => false,
//             'reminder' => false,
//             'quick_report' => false,
//             'visit' => false,
//             'statistics' => false,
//             'type_of_client' => true,
//             'segment' => true,
//             'industry' => true,
//             'zone' => true,
//         ]
//     ];

//     function index(Request $request)
//     {
//         try {
//             if (!$this->userId) {
//                 $this->response['error'] = __('auth.authentication_failed');
//                 return $this->sendResponse($this->response, 401);
//             }

//             $data = [];

//             $basicCountResult = [];
//             $pendingRfqData = [];
//             $taskData = [];
//             $reminderData = [];
//             $quickReportData = [];
//             $visitData = [];
//             $statisticsData = [];
//             $typeOfClientData = [];
//             $industryData = [];
//             $segmentData = [];
//             $zoneData = [];

//             $basicCountReportParams = [];
//             $shouldGeneratePendingRfqReport = false;
//             $shouldGenerateTaskReport = false;
//             $shouldGenerateReminderReport = false;
//             $shouldGenerateQuickReport = false;
//             $shouldGenerateVisitReport = false;
//             $shouldGenerateStatisticsReport = false;
//             $shouldGenerateTypeOfClientReport = false;
//             $shouldGenerateIndustryReport = false;
//             $shouldGenerateSegmentReport = false;
//             $shouldGenerateZoneReport = false;

//             $user = User::find($this->userId);

//             $isNationalHead = in_array($user->fk_designation_id, [1]);

//             $userRole = UserRole::with('department')->where('fk_user_id', $user->id)->get()->toArray();
//             $departmentIds = array_column(array_column($userRole, 'department'), 'id');

//             if (!$isNationalHead) {
//                 foreach ($departmentIds as $departmentId) {
//                     $basicReportParams = @$this->dashboardArray[$departmentId]['basic_counts'] ?? [];
//                     if (count($basicReportParams)) {
//                         $basicCountReportParams = array_merge(array_values($basicReportParams), $basicCountReportParams);
//                     }

//                     $pendingRfqReport = @$this->dashboardArray[$departmentId]['pending_rfqs'] ?? false;
//                     if ($pendingRfqReport) $shouldGeneratePendingRfqReport = true;

//                     $taskReport = @$this->dashboardArray[$departmentId]['task'] ?? false;
//                     if ($taskReport) $shouldGenerateTaskReport = true;

//                     $reminderReport = @$this->dashboardArray[$departmentId]['reminder'] ?? false;
//                     if ($reminderReport) $shouldGenerateReminderReport = true;

//                     $quickReport = @$this->dashboardArray[$departmentId]['quick_report'] ?? false;
//                     if ($quickReport) $shouldGenerateQuickReport = true;

//                     $visitReport = @$this->dashboardArray[$departmentId]['visit'] ?? false;
//                     if ($visitReport) $shouldGenerateVisitReport = true;

//                     $statisticsReport = @$this->dashboardArray[$departmentId]['statistics'] ?? false;
//                     if ($statisticsReport) $shouldGenerateStatisticsReport = true;

//                     $typeOfClientReport = @$this->dashboardArray[$departmentId]['type_of_client'] ?? false;
//                     if ($typeOfClientReport) $shouldGenerateTypeOfClientReport = true;

//                     $industryReport = @$this->dashboardArray[$departmentId]['industry'] ?? false;
//                     if ($industryReport) $shouldGenerateIndustryReport = true;

//                     $segmentReport = @$this->dashboardArray[$departmentId]['segment'] ?? false;
//                     if ($segmentReport) $shouldGenerateSegmentReport = true;

//                     $zoneReport = @$this->dashboardArray[$departmentId]['zone'] ?? false;
//                     if ($zoneReport) $shouldGenerateZoneReport = true;
//                 }
//             } else {
//                 $basicReportParams = @$this->dashboardArray['NATIONAL_HEAD']['basic_counts'] ?? [];
//                 if (count($basicReportParams)) {
//                     $basicCountReportParams = array_values($basicReportParams);
//                 }

//                 $pendingRfqReport = @$this->dashboardArray['NATIONAL_HEAD']['pending_rfqs'] ?? false;
//                 if ($pendingRfqReport) $shouldGeneratePendingRfqReport = true;

//                 $taskReport = @$this->dashboardArray['NATIONAL_HEAD']['task'] ?? false;
//                 if ($taskReport) $shouldGenerateTaskReport = true;

//                 $reminderReport = @$this->dashboardArray['NATIONAL_HEAD']['reminder'] ?? false;
//                 if ($reminderReport) $shouldGenerateReminderReport = true;

//                 $quickReport = @$this->dashboardArray['NATIONAL_HEAD']['quick_report'] ?? false;
//                 if ($quickReport) $shouldGenerateQuickReport = true;

//                 $visitReport = @$this->dashboardArray['NATIONAL_HEAD']['visit'] ?? false;
//                 if ($visitReport) $shouldGenerateVisitReport = true;

//                 $statisticsReport = @$this->dashboardArray['NATIONAL_HEAD']['statistics'] ?? false;
//                 if ($statisticsReport) $shouldGenerateStatisticsReport = true;

//                 $typeOfClientReport = @$this->dashboardArray['NATIONAL_HEAD']['type_of_client'] ?? false;
//                 if ($typeOfClientReport) $shouldGenerateTypeOfClientReport = true;

//                 $industryReport = @$this->dashboardArray['NATIONAL_HEAD']['industry'] ?? false;
//                 if ($industryReport) $shouldGenerateIndustryReport = true;

//                 $segmentReport = @$this->dashboardArray['NATIONAL_HEAD']['segment'] ?? false;
//                 if ($segmentReport) $shouldGenerateSegmentReport = true;

//                 $zoneReport = @$this->dashboardArray['NATIONAL_HEAD']['zone'] ?? false;
//                 if ($zoneReport) $shouldGenerateZoneReport = true;
//             }

//             $basicCountReportParams = array_unique($basicCountReportParams);
//             if (count($basicCountReportParams)) {
//                 $basicCountResult = $this->generateBasicCountReport($basicCountReportParams, $isNationalHead);
//                 $data['basic_count_data'] = ['title' => 'Counts (' . date("F") . ')', 'result' => $basicCountResult];
//             }

//             if ($shouldGeneratePendingRfqReport) {
//                 $pendingRfqData = $this->generatePendingRfqReport($isNationalHead);
//                 $data['pending_rfq_data'] = ['title' => 'In-Pipeline / Pending RFQ', 'result' => $pendingRfqData];
//             }

//             if ($shouldGenerateTaskReport) {
//                 $taskData = $this->generateTaskReport($isNationalHead);
//                 $data['task_data'] = ['title' => 'Task', 'result' => $taskData];
//             }

//             if ($shouldGenerateReminderReport) {
//                 $reminderData = $this->generateReminderReport($isNationalHead);
//                 $data['reminder_data'] = ['title' => 'Reminder', 'result' => $reminderData];
//             }

//             if ($shouldGenerateQuickReport) {
//                 $quickReportData = $this->generateQuickReport($isNationalHead);
//                 $data['quick_report_data'] = ['title' => 'Quick Report', 'result' => $quickReportData];
//             }

//             if ($shouldGenerateVisitReport) {
//                 $visitData = $this->generateVisitDataReport($isNationalHead);
//                 $data['visit_data'] = ['title' => 'Visit This Month', 'result' => $visitData];
//             }

//             if ($shouldGenerateStatisticsReport) {
//                 $statisticsData = $this->generateStatisticsReport($isNationalHead);
//                 $data['statistics_data'] = ['title' => 'Statistics', 'result' => $statisticsData];
//             }

//             if ($shouldGenerateTypeOfClientReport) {
//                 $typeOfClientData = $this->generateTypeOfClientReport($isNationalHead);
//                 $data['type_of_client_data'] = ['title' => 'Type of Client', 'result' => $typeOfClientData];
//             }

//             if ($shouldGenerateIndustryReport) {
//                 $industryData = $this->generateIndustryReport($isNationalHead);
//                 $data['industry_data'] = ['title' => 'Industry (RFQs)', 'result' => $industryData];
//             }

//             if ($shouldGenerateSegmentReport) {
//                 $segmentData = $this->generateSegmentReport($isNationalHead);
//                 $data['segment_data'] = ['title' => 'Segment (RFQs)', 'result' => $segmentData];
//             }

//             if ($shouldGenerateZoneReport) {
//                 $zoneData = $this->generateZoneReport($isNationalHead);
//                 $data['zone_data'] = ['title' => 'Zone Wise (Leads)', 'result' => $zoneData];
//             }

//             $this->response['status'] = 1;
//             $this->response['msg'] =  __('admin.fetched', ['module' => "New Dashboard Data"]);
//             $this->response['data'] = $data;

//             return $this->sendResponse($this->response, 200);
//         } catch (Exception $e) {
//             Log::error("New Dashboard Data fetching failed: " . $e);
//             $this->response['error'] = __('auth.something_went_wrong');
//             return $this->sendResponse($this->response, 500);
//         }
//     }

//     function generateBasicCountReport($basicCountReportParams = [], $isNationalHead = false)
//     {
//         $basicCountResult = [];

//         // rfq count
//         if (in_array('rfq', $basicCountReportParams)) {
//             if ($isNationalHead) {
//                 //From RFQ table
//                 $rfqFromRfq = Rfq::select('id as rfq_id')->orderBy('id', 'desc');
//                 $rfqFromRfqThisMonth = clone $rfqFromRfq;
//                 $rfqFromRfqThisYear = clone $rfqFromRfq;

//                 $rfqFromRfqThisMonth = $rfqFromRfqThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->toArray();
//                 $rfqFromRfqThisYear = $rfqFromRfqThisYear->whereYear('updated_at', date('Y'))->get()->toArray();

//                 //From Project Logs table
//                 $rfqFromProjectLogs = ProjectLog::select('fk_rfq_id as rfq_id')->distinct()->groupBy('fk_rfq_id');
//                 $rfqFromProjectLogsThisMonth = clone $rfqFromProjectLogs;
//                 $rfqFromProjectLogsThisYear = clone $rfqFromProjectLogs;

//                 $rfqFromProjectLogsThisMonth = $rfqFromProjectLogsThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->toArray();
//                 $rfqFromProjectLogsThisYear = $rfqFromProjectLogsThisYear->whereYear('updated_at', date('Y'))->get()->toArray();

//                 //Sum up after distinct
//                 $rfqCountThisMonth = count(array_unique(array_column(array_merge($rfqFromRfqThisMonth, $rfqFromProjectLogsThisMonth), 'rfq_id')));
//                 $rfqCountThisYear = count(array_unique(array_column(array_merge($rfqFromRfqThisYear, $rfqFromProjectLogsThisYear), 'rfq_id')));
//             } else {
//                 //From RFQ table
//                 $rfqFromRfq = Rfq::select('id as rfq_id')->orWhere(['created_by' => $this->userId, 'assigned_rsm' => $this->userId]);
//                 $rfqFromRfqThisMonth = clone $rfqFromRfq;
//                 $rfqFromRfqThisYear = clone $rfqFromRfq;

//                 $rfqFromRfqThisMonth = $rfqFromRfqThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->toArray();
//                 $rfqFromRfqThisYear = $rfqFromRfqThisYear->whereYear('updated_at', date('Y'))->get()->toArray();

//                 //From Project Logs table
//                 $rfqFromProjectLogs = ProjectLog::select('fk_rfq_id as rfq_id')->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])->distinct()->groupBy('fk_rfq_id');
//                 $rfqFromProjectLogsThisMonth = clone $rfqFromProjectLogs;
//                 $rfqFromProjectLogsThisYear = clone $rfqFromProjectLogs;

//                 $rfqFromProjectLogsThisMonth = $rfqFromProjectLogsThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->toArray();
//                 $rfqFromProjectLogsThisYear = $rfqFromProjectLogsThisYear->whereYear('updated_at', date('Y'))->get()->toArray();

//                 //Sum up after distinct
//                 $rfqCountThisMonth = count(array_unique(array_column(array_merge($rfqFromRfqThisMonth, $rfqFromProjectLogsThisMonth), 'rfq_id')));
//                 $rfqCountThisYear = count(array_unique(array_column(array_merge($rfqFromRfqThisYear, $rfqFromProjectLogsThisYear), 'rfq_id')));
//             }

//             $result = ['title' => 'RFQ', 'this_month' => $rfqCountThisMonth, 'this_year' => $rfqCountThisYear];
//             $basicCountResult[] = $result;
//         }

//         //po count
//         if (in_array('po', $basicCountReportParams)) {
//             if ($isNationalHead) {
//                 $poCount = PurchaseOrder::orderBy('id', 'desc');
//             } else {
//                 $poCount = PurchaseOrder::where('prepared_by', $this->userId)->orderBy('id', 'desc');
//             }

//             $poCountThisMonth = clone $poCount;
//             $poCountThisMonth = $poCountThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();

//             $poCountThisYear = clone $poCount;
//             $poCountThisYear = $poCountThisYear->whereYear('updated_at', date('Y'))->count();

//             $result = ['title' => 'Purchase Order', 'this_month' => $poCountThisMonth, 'this_year' => $poCountThisYear];
//             $basicCountResult[] = $result;
//         }

//         //invoice count
//         if (in_array('invoice', $basicCountReportParams)) {
//             if ($isNationalHead) {
//                 $invoiceCount = PurchaseInvoice::orderBy('id', 'desc');
//             } else {
//                 $invoiceCount = PurchaseInvoice::where('created_by', $this->userId)->orderBy('id', 'desc');
//             }

//             $invoiceCountThisMonth = clone $invoiceCount;
//             $invoiceCountThisMonth = $invoiceCountThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();

//             $invoiceCountThisYear = clone $invoiceCount;
//             $invoiceCountThisYear = $invoiceCountThisYear->whereYear('updated_at', date('Y'))->count();


//             $result = ['title' => 'Invoice', 'this_month' => $invoiceCountThisMonth, 'this_year' => $invoiceCountThisYear];
//             $basicCountResult[] = $result;
//         }

//         //open_rfq count
//         if (in_array('rfq', $basicCountReportParams) && in_array('closed_rfq', $basicCountReportParams) && in_array('open_rfq', $basicCountReportParams)) {
//             $totalRfqsThisMonth = 0;
//             $totalRfqsThisYear = 0;

//             foreach($basicCountResult as $bcr) {
//                 if($bcr['title'] == 'RFQ') {
//                     $totalRfqsThisMonth = $bcr['this_month'];
//                     $totalRfqsThisYear = $bcr['this_year'];
//                 }
//             }

//             if($isNationalHead) {
//                 $closedRfq = ProjectLog::where('curr_sub_stage_id', $this->deliverySubStageId)->distinct()->groupBy('fk_rfq_id');
//                 $closedRfqThisMonth = clone $closedRfq;
//                 $closedRfqThisYear = clone $closedRfq;
                
//                 $closedRfqThisMonth = $closedRfqThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
//                 $closedRfqThisYear = $closedRfqThisYear->whereYear('updated_at', date('Y'))->count();
//             }else{
//                 $closedRfq = ProjectLog::where('curr_sub_stage_id', $this->deliverySubStageId)->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])->distinct()->groupBy('fk_rfq_id');
//                 $closedRfqThisMonth = clone $closedRfq;
//                 $closedRfqThisYear = clone $closedRfq;

//                 $closedRfqThisMonth = $closedRfqThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
//                 $closedRfqThisYear = $closedRfqThisYear->whereYear('updated_at', date('Y'))->count();
//             }

//             $result = ['title' => 'Closed RFQ', 'this_month' => $closedRfqThisMonth, 'this_year' => $closedRfqThisYear];
//             $basicCountResult[] = $result;

//             $result = ['title' => 'Open RFQ', 'this_month' => $totalRfqsThisMonth - $closedRfqThisMonth, 'this_year' => $totalRfqsThisYear - $closedRfqThisYear];
//             $basicCountResult[] = $result;
//         }

//         //open count
//         if (in_array('open_rfq', $basicCountReportParams)) {
//             $openRfqCount = 0;
//             $openRfqCountThisMonth = 0;
//             $openRfqCountThisYear = 0;

//             $result = ['title' => 'Open RFQ', 'this_month' => $openRfqCountThisMonth, 'this_year' => $openRfqCountThisYear];
//             $basicCountResult[] = $result;
//         }

//         //pdr count
//         if (in_array('pdr', $basicCountReportParams)) {
//             if ($isNationalHead) {
//                 $pdrCount = PurchaseOrderPdrQuality::orderBy('id', 'desc');
//             } else {
//                 $pdrCount = PurchaseOrderPdrQuality::where('created_by', $this->userId)->orderBy('id', 'desc');
//             }

//             $pdrCountThisMonth = clone $pdrCount;
//             $pdrCountThisYear = clone $pdrCount;

//             $pdrCountThisMonth = $pdrCountThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
//             $pdrCountThisYear = $pdrCountThisYear->whereYear('updated_at', date('Y'))->count();

//             $result = ['title' => 'PDR', 'this_month' => $pdrCountThisMonth, 'this_year' => $pdrCountThisYear];
//             $basicCountResult[] = $result;
//         }

//         //delivery_note count
//         if (in_array('delivery_note', $basicCountReportParams)) {
//             if ($isNationalHead) {
//                 $dnCount = PurchaseOrderDneInvoice::orderBy('id', 'desc');
//             } else {
//                 $dnCount = PurchaseOrderDneInvoice::where('created_by', $this->userId)->orderBy('id', 'desc');
//             }

//             $dnCountThisMonth = clone $dnCount;
//             $dnCountThisYear = clone $dnCount;

//             $dnCountThisMonth = $dnCountThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
//             $dnCountThisYear = $dnCountThisYear->whereYear('updated_at', date('Y'))->count();

//             $result = ['title' => 'Delivery Note', 'this_month' => $dnCountThisMonth, 'this_year' => $dnCountThisYear];
//             $basicCountResult[] = $result;
//         }

//         return $basicCountResult;
//     }

//     public function rfqList(Request $request) {
//       try {
//         if (!$this->userId) {
//           $this->response['error'] = __('auth.authentication_failed');
//           return $this->sendResponse($this->response, 401);
//         }
  
//         $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
//         $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
//         $offset = ($page - 1) * $per_page;
  
//         $rfqNumber = $request->rfq_number ?? "";
//         $rfqType = $request->tab ?? "";
//         $rsmName = $request->rsm_name ?? "";
//         $company = $request->company ?? "";
//         $customerName = $request->customer_name ?? "";
//         $startDate = $request->start_date ?? "";
//         $endDate = $request->end_date ?? "";
//         $divisionId = $request->division_id ?? "";
//         $regionId = $request->region_id ?? "";
//         $subStageId = $request->current_stage_id ?? "";
//         $isExport = $request->is_export ?? 0;
  
//         $juniorUserIds = $this->getJuniorIds(true);
//         rsort($juniorUserIds);
  
//         if ($this->isUserAdmin || $this->isManagement || $this->isMarketing) {
//           $rfqFromRfq = Rfq::select('id')->orderBy('updated_at', 'desc');
//           $rfqFromProjectLogs = ProjectLog::select('fk_rfq_id as id')->distinct()->groupBy('fk_rfq_id');
//         } else {
//           $rfqFromRfq = Rfq::select('id')->where(function ($query) use ($juniorUserIds) {
//             $query->whereIn('rsm_id', $juniorUserIds)
//               ->orWhereIn('rfq_date', $juniorUserIds);
//           });
  
//           $rfqFromProjectLogs = ProjectLog::select('fk_rfq_id as id')
//             ->where(function ($q) use ($juniorUserIds) {
//               foreach ($juniorUserIds as $key => $value) {
//                 $q->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$value]);
//               }
//             })
//             ->distinct()->groupBy('fk_rfq_id');
//         }

  
//         // Filtering based on RFQ type (month or year)
//         if ($rfqType === 'thismonth') {
//           $rfqCount = $this->getRfqCount($rfqFromRfq, $rfqFromProjectLogs, 'thisMonth');
//           $rfqList = $this->getRfqList($rfqCount);
//         } elseif ($rfqType === 'thisyear') {
//           $rfqCount = $this->getRfqCount($rfqFromRfq, $rfqFromProjectLogs, 'thisYear');
//           $rfqList = $this->getRfqList($rfqCount);
//         } else {
//           $this->response['error'] = 'Invalid RFQ type provided.';
//           return $this->sendResponse($this->response, 500);
//         }
  
  
//         if ($rfqNumber) {
//           $rfqList->where('rfq_number', 'like', "%" . $rfqNumber . "%");
//         }
  
//         if ($divisionId) {
//           $rfqList->where('division_id', $divisionId);
//         }
  
//         if ($rsmName) {
//           $rfqList->where('assigned_rsm',  $rsmName);
//         }
  
//         if ($company) {
//           $rfqList->whereHas('lead', function ($query) use ($company) {
//             $query->where('company', 'like', '%' . $company . '%');
//           });
//         }
  
//         if ($subStageId) {
//           $rfqList->where('curr_sub_stage_id', $subStageId);
//         }
  
//         if ($startDate && $endDate) {
//           $rfqList->whereBetween('created_at', [$startDate, $endDate]);
//         } elseif ($startDate) {
//           $rfqList->whereDate('created_at', $startDate);
//         }
  
//         if ($customerName) {
//           $rfqList->whereHas('lead', function ($query) use ($customerName) {
//             $query->where('customer_name', 'like', '%' . $customerName . '%');
//           });
//         }
  
//         if ($regionId) {
//           $rfqList->whereHas('lead', function ($query) use ($regionId) {
//             $query->where('fk_region_id', $regionId);
//           });
//         }
  
//         $num_rows = $rfqList->count();
//         $total_pages = ceil($num_rows / $per_page);
        
//         $rfqList = $rfqList->limit($per_page)->offset($offset)->get();

//         $this->response['status'] = 1;
//         $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Rfq Lists"]);
//         $this->response['data']['page'] = $page;
//         $this->response['data']['per_page'] = $per_page;
//         $this->response['data']['num_rows'] = $num_rows;
//         $this->response['data']['total_pages'] = $total_pages;
//         $this->response['data']['start_date'] = $startDate;
//         $this->response['data']['end_date'] = $endDate;
//         $this->response['data']['rfq_number'] = $rfqNumber;
//         $this->response['data']['rsm_name'] = $rsmName;
//         $this->response['data']['company'] = $company;
//         $this->response['data']['current_stage_id'] = $subStageId;
//         $this->response['data']['customer_name'] = $customerName;
//         $this->response['data']['division_id'] = $divisionId;
//         $this->response['data']['region_id'] = $regionId;
//         $this->response['data']['list'] = $rfqList ?? [];
  
//         return $this->sendResponse($this->response, 200);
//       } catch (\Exception $e) {
//         Log::error("Dashboard Rfq Lists fetching failed: " . $e->getMessage());
//         $this->response['error'] = $e->getMessage();
//         return $this->sendResponse($this->response, 500);
//       }
//     }

//     private function getRfqCount($queryBuilder, $queryPro, $timeFrame) {
//       $queryBuilderClone = clone $queryBuilder;
  
//       if ($timeFrame === 'thisMonth') {
//         $rfq = $queryBuilderClone->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->pluck('id')->toArray();
//         $project = $queryPro->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->pluck('id')->toArray();
//         $rfqThisMonth = array_unique(array_merge($rfq, $project));
//         return $rfqThisMonth;
//       } elseif ($timeFrame === 'thisYear') {
//         $rfq = $queryBuilderClone->whereYear('updated_at', date('Y'))->get()->pluck('id')->toArray();
//         $project = $queryPro->whereYear('updated_at', date('Y'))->get()->pluck('id')->toArray();
//         $rfqThisYear = array_unique(array_merge($rfq, $project));
//         return $rfqThisYear;
//       }
  
//       return [];
//     }

//     private function getRfqList($rfqIds) {
//       $query = RFQ::with('subStage:id,name', 'designation:id,name', 'division:id,name', 'products.product:id,product_name', 'lead')
//         ->whereIn('id', $rfqIds)
//         ->orderBy('created_at', 'desc');
  
//       return $query;
//     }

//     public function quotationList(Request $request) {
//       try {
  
//         if (!$this->userId) {
//           $this->response['error'] = __('auth.authentication_failed');
//           return $this->sendResponse($this->response, 401);
//         }
  
//         $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
//         $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
//         $offset = ($page - 1) * $per_page;
  
//         $quotationType = $request->tab;
//         $quotationNo = $request->quotation_no ?? '';
//         $preparedBy = $request->prepared_by ?? '';
//         $salesPerson = $request->sales_person ?? '';
//         $divisionId = $request->division ?? '';
//         $startDate = $request->start_date;
//         $endDate = $request->end_date;
//         $quotationStatus = $request->quotation_status ?? '';
//         $company = $request->company ?? '';
//         $curStageId = $request->current_stage_id ?? '';
//         $finalAmount = $request->final_amount ?? '';
//         $isExport = $request->is_export ?? 0;
  
  
//         if ($this->isUserAdmin || $this->isManagement || $this->isMarketing) {
//           $quotation = ProjectQuotationTemp::with('salesPerson', 'preparedBy', 'lead', 'rfq', 'rfq.designation', 'rfq.subStage')->orderBy('id', 'desc');
//         } else {
//           $juniorUserIds = $this->getJuniorIds(true);
//           rsort($juniorUserIds);
  
//           $quotation = ProjectQuotationTemp::with('salesPerson', 'preparedBy', 'lead', 'rfq', 'rfq.designation', 'rfq.subStage')->where(function ($q) use ($juniorUserIds) {
//             $q->whereIn('prepared_by', $juniorUserIds);
//             $q->orWhereIn('sales_person', $juniorUserIds);
//           })
//             ->orderBy('id', 'desc');
//         }
  
//         if ($quotationNo) $quotation->where('quotation_no', 'like', '%' . $quotationNo . '%');
//         if ($finalAmount) $quotation->where('final_amount', 'like', '%' . $finalAmount . '%');
//         if ($quotationStatus) $quotation->where('quotation_status', 'like', '%' . $quotationStatus . '%');
  
//         if ($startDate && $endDate) {
//           $quotation->whereBetween('quotation_date', [$startDate, $endDate]);
//         } elseif ($startDate) {
//           $quotation->whereDate('quotation_date', $startDate);
//         }
  
//         if ($preparedBy) {
//           $quotation->whereHas('preparedBy', function ($query) use ($preparedBy) {
//             $query->where('name', 'like', '%' . $preparedBy . '%');
//           });
//         }
  
//         if ($salesPerson) {
//           $quotation->where('sales_person', $salesPerson);
//         }
  
//         if ($divisionId) {
//           $quotation->whereHas('rfq', function ($query) use ($divisionId) {
//             $query->where('division_id', $divisionId);
//           });
//         }
  
//         if ($curStageId) {
//           $quotation->whereHas('rfq', function ($query) use ($curStageId) {
//             $query->where('curr_sub_stage_id', $curStageId);
//           });
//         }
  
  
//         if ($company) {
//           $quotation->whereHas('lead', function ($query) use ($company) {
//             $query->where('company', 'like', '%' . $company . '%');
//           });
//         }
  
//         if ($quotationType === 'thismonth') {
//           $quotationThisMonth = clone $quotation;
//           $quotationList = $quotationThisMonth->whereYear('updated_at', '=', date('Y'))->whereMonth('updated_at', '=', date('m'));
//         } elseif ($quotationType === 'thisyear') {
//           $quotationThisYear = clone $quotation;
//           $quotationList = $quotationThisYear->whereYear('updated_at', '=', date('Y'));
//         } else {
//           $this->response['error'] = 'Invalid quotation type provided.';
//           return $this->sendResponse($this->response, 500);
//         }
  
//         $num_rows = $quotationList->count();
//         $quotationList = $quotationList->limit($per_page)->offset($offset)->get();  
  
//         $this->response['status'] = 1;
//         $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Quotation Lists"]);
//         $this->response['filePath'] = $filePath ?? '';
//         $this->response['data']['page'] = $page;
//         $this->response['data']['per_page'] = $per_page;
//         $this->response['data']['num_rows'] = $num_rows;
//         $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
//         $this->response['data']['start_date'] = $startDate;
//         $this->response['data']['end_date'] = $endDate;
//         $this->response['data']['quotation_no'] = $quotationNo;
//         $this->response['data']['prepared_by'] = $preparedBy;
//         $this->response['data']['quotation_status'] = $quotationStatus;
//         $this->response['data']['company'] = $company;
//         $this->response['data']['division'] = $divisionId;
//         $this->response['data']['sales_person'] = $salesPerson;
//         $this->response['data']['final_amount'] = $finalAmount;
//         $this->response['data']['current_stage_id'] = $curStageId;
//         $this->response['data']['list'] = $quotationList ?? [];
  
//         return $this->sendResponse($this->response, 200);
//       } catch (\Exception $e) {
//         Log::error("Dashboard Quotation Lists fetching failed: " . $e->getMessage());
//         $this->response['error'] = $e->getMessage();
//         return $this->sendResponse($this->response, 500);
//       }
//     }

//     function generatePendingRfqReport($isNationalHead = false)
//     {
//         $pendingRfqData = ProjectLog::with('rfq.products.product', 'subStage')
//             ->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])
//             ->where('curr_sub_stage_id', '!=', $this->deliverySubStageId)
//             ->groupBy('fk_rfq_id')->get();

//         return $pendingRfqData;
//     }

//     function generateTaskReport($isNationalHead = false)
//     {
//         $taskData = Task::with('assignedToUsers.user', 'assignedBy')
//             ->whereHas('assignedToUsers', function ($query) {
//                 $query->where('created_by', $this->userId);
//                 $query->orWhere('fk_user_id', $this->userId);
//             })->take(6)->get();

//         return $taskData;
//     }

//     function generateReminderReport($isNationalHead = false)
//     {
//         $reminderData = Reminder::with('reminderUser.user', 'reminderBy')
//             ->whereHas('reminderUser', function ($query) {
//                 $query->where('created_by', $this->userId);
//                 $query->orWhere('fk_user_id', $this->userId);
//             })->take(6)->get();

//         return $reminderData;
//     }

//     function generateQuickReport($isNationalHead = false)
//     {
//         $quickReportData = MasterReportPreset::where('created_by', $this->userId)->get();
//         return $quickReportData;
//     }

//     function generateVisitDataReport($isNationalHead = false)
//     {
//         $visitData = SalesVisitReport::with(['lead', 'rfq'])
//             ->where('sales_person', $this->userId)
//             ->whereMonth('created_at', date('m'))
//             ->whereYear('created_at', date('Y'))
//             ->orderBy('created_at', 'desc')
//             ->get();
//         $visitData = NewDashboardVisitResource::collection($visitData);

//         return $visitData;
//     }

//     function generateStatisticsReport($isNationalHead = false)
//     {
//         if ($isNationalHead) {
//             $plan = MonthlyPlanExcel::where('month', strtolower(date('F')))->where('year', date('Y'))->get();

//             $statisticsData['monthlyTarget'] = array_sum(array_column($plan->toArray(), 'target'));

//             $statisticsData['achievedTarget'] = PurchaseOrder::where('is_verified', 1)
//                 ->whereMonth('po_date', date('m'))
//                 ->whereYear('po_date', date('Y'))
//                 ->sum('po_details_total');

//             $statisticsData['plannedVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->count();

//             $statisticsData['actualVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->where('fk_status_id', 5)->count();
//         } else {
//             $plan = MonthlyPlanExcel::where('rsm_id', $this->userId)
//                 ->where('month', strtolower(date('F')))
//                 ->where('year', date('Y'))
//                 ->get();

//             $statisticsData['monthlyTarget'] = array_sum(array_column($plan->toArray(), 'target'));

//             $statisticsData['achievedTarget'] = PurchaseOrder::where('prepared_by', $this->userId)
//                 ->where('is_verified', 1)
//                 ->whereMonth('po_date', date('m'))
//                 ->whereYear('po_date', date('Y'))
//                 ->sum('po_details_total');

//             $statisticsData['plannedVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->count();

//             $statisticsData['actualVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->where('fk_status_id', 5)->count();
//         }

//         return $statisticsData;
//     }

//     function generateTypeOfClientReport($isNationalHead = false)
//     {
//         $typeOfClientData = ProjectType::withCount('leads')->get();
//         return $typeOfClientData;
//     }

//     function generateIndustryReport($isNationalHead = false)
//     {
//         $industryList = Industry::select('id', 'name')->get()->toArray();

//         foreach ($industryList as &$industry) {
//             $rfqs = Rfq::where(function ($query) use ($industry) {
//                 $query->orWhereJsonContains('industry', ['id' => $industry['id']]);
//             })->get()->toArray();

//             $industry['rfq_count'] = count($rfqs);
//         }

//         usort($industryList, function ($object1, $object2) {
//             return $object1['rfq_count'] < $object2['rfq_count'];
//         });

//         $industries = array_slice($industryList, 0, 6);

//         return $industries;
//     }

//     function generateSegmentReport($isNationalHead = false)
//     {
//         $segmentList = ProjectSegment::select('id', 'name')->where('status', 1)->get()->toArray();

//         foreach ($segmentList as &$segment) {
//             $rfqs = Rfq::where(function ($query) use ($segment) {
//                 $query->orWhereJsonContains('project_segments', [$segment['id']]);
//             })->get()->toArray();

//             $segment['rfq_count'] = count($rfqs);
//         }

//         usort($segmentList, function ($object1, $object2) {
//             return $object1['rfq_count'] < $object2['rfq_count'];
//         });

//         $segments = array_slice($segmentList, 0, 6);

//         return $segments;
//     }

//     function generateZoneReport($isNationalHead = false)
//     {
//         $zoneList = Region::select('id', 'name')->withCount('lead')->where('status', 1)->get()->toArray();

//         return $zoneList;
//     }
// }
