<?php

namespace App\Http\Controllers\AppApi;

use Exception;
use Carbon\Carbon;
use App\Models\Task;
use App\Models\TaskUser;
use Illuminate\Http\Request;
use App\Events\TaskLogCreated;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Http\Resources\StatusResource;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\API\AppBaseController;
use App\Models\TaskLog;
use App\Models\UserDevice;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class TaskController extends AppBaseController
{
  public function index(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if (!$this->isUserRSM) {
        $this->response['error'] = "You Are Not RSM User";
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $perPage = (isset($request->perPage) && $request->perPage != 'undefined') ? intval($request->perPage) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $perPage;

      $start = $request->start ?? '';
      $end = $request->end ?? '';
      $search = $request->search ?? '';
      $assignStatus = $request->status ?? '';


      $task = Task::with('statuses', 'taskType', 'lead', 'rfq', 'svr')->orderBy("id", "desc");
      $task->whereHas('assignedToUsers', function ($query) {
        $query->where('created_by', $this->userId);
        $query->orWhere('fk_user_id', $this->userId);
      });
      $numRows = $task->count();

      if ($assignStatus) {
        $task->where('fk_status_id', $assignStatus);
      }

      if ($search) {
        $task->where('title', 'like', '%' . $search . '%');
        $task->orWhere('description', 'like', '%' . $search . '%');
      }

      if ($start) {
        $task->where('start', '>=', $this->convertToDatabaseDateForSearch($start));
      }

      if ($end) {
        $task->where('end', '<=', $this->convertToDatabaseDateForSearch($end));
      }

      $task = $task->limit($perPage)->offset($offset)->get();

      //Generate calendar dates start
      $calendarYearMonth = $request->calendar_year_month ?? date("Y-m");
      $formattedData = [];
      $calendar = Task::select('fk_status_id', 'start')->with('statuses')->where('start', 'like', '%' . $calendarYearMonth . '%');

      $calendar->whereHas('assignedToUsers', function ($query) {
        $query->where('created_by', $this->userId);
        $query->orWhere('fk_user_id', $this->userId);
      });


      if ($assignStatus) {
        $calendar->where('fk_status_id', $assignStatus);
      }
      $calendar->get();

      foreach ($calendar as $cal) {
        $startDate = date('Y-m-d', strtotime($cal->start));
        $status_id = $cal->statuses->id;
        $color = $cal->statuses->color_code;
        $status = $cal->statuses->name;

        if (!isset($formattedData[$startDate])) {
          $formattedData[$startDate] = ['dots' => []];
        }

        // Check if the dot entry is already added
        $existingDot = false;
        foreach ($formattedData[$startDate]['dots'] as $dot) {
          if ($dot['id'] === $status_id && $dot['color'] === $color && $dot['status'] === $status) {
            $existingDot = true;
            break;
          }
        }

        // If the dot entry is not already added, add it
        if (!$existingDot) {
          $formattedData[$startDate]['dots'][] = ['id' => $status_id, 'color' => $color, 'status' => $status];
        }
      }
      //Generate calendar dates end

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Task"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $perPage;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $perPage ? 1 : ceil($numRows / $perPage);
      $this->response['data']['search'] = $search;
      $this->response['data']['start'] = $start;
      $this->response['data']['end'] = $end;
      $this->response['data']['status'] = $assignStatus;
      $this->response['data']['calendar_year_month'] = $calendarYearMonth;
      $this->response['data']['calendar'] = $formattedData;
      $this->response['data']['list'] = $task;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Task fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if (!$this->isUserRSM) {
        $this->response['error'] = "You Are Not RSM User";
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $task = Task::with('statuses', 'taskType', 'lead', 'rfq.product')->find($id);

      if (!$task) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Task"]);
        return $this->sendResponse($this->response, 200);
      }

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Task"]);
      $this->response['data'] = $task;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Task fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(Request $request)
  {
    try {

      DB::beginTransaction();

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if (!$this->isUserRSM) {
        $this->response['error'] = "You Are Not RSM User";
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateTask($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $taskObject = new Task();
      $id = $request->id;
      $title = $request->title ?? '';
      $taskType = $request->taskType ?? 0;
      $lead = $request->lead ?? 0;
      $rfq = $request->rfq ?? 0;
      $description = $request->description ?? '';
      $start = Carbon::createFromFormat('d/m/Y H:i', $request->start)->format('Y-m-d H:i:s');
      $end = Carbon::createFromFormat('d/m/Y H:i', $request->end)->format('Y-m-d H:i:s');
      $taskStatus = $request->status ?? '';
      $taskUser = $request->user ?? '';
      $allDay = $request->allDay ?? 0;
      $isPhysicalVisit = $request->is_physical_visit ?? 0;
      $remark = $request->remark ?? '';


      $linkedUser = $request->task_user ?? [];

      if ($taskType == 1) { // empty rfq if task type is lead. 1 is used as lead in database
        $rfq = 0;
      }

      $files = [];
      if (isset($request->attachment)) {
        if (count($request->attachment) > 0) {
          foreach ($request->attachment as $item) {
            moveFile('task/files/', $item['filename']);
            $files[] = ['filename' => $item['filename'], 'path' => $this->fileAccessPath . "/task/files/" . $item['filename']];
          }
        }
      }

      $attachment = json_encode($files) ?? '';

      if ($id) {
        $taskObject = Task::find($id);

        if (!$taskObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Task"]);
          return $this->sendResponse($this->response, 200);
        }

        $taskObject->first();
        $taskObject->updated_by = $this->userId;

        $this->response['msg'] = __('admin.updated', ['module' => "Task"]);
      } else {
        $taskObject->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => "Task"]);
      }

      $taskObject->title = $title;
      $taskObject->fk_task_type_id = $taskType;
      $taskObject->fk_lead_id = $lead;
      $taskObject->fk_rfq_id = $rfq;
      $taskObject->description = $description;
      $taskObject->allDay = $allDay;
      $taskObject->is_physical_visit = $isPhysicalVisit;
      $taskObject->remark = $remark;
      $taskObject->start = $start;
      $taskObject->end = $end;
      $taskObject->fk_status_id = $taskStatus;
      $taskObject->fk_user_id = $taskUser;
      $taskObject->attachment = $attachment;
      $taskObject->task_user = json_encode($linkedUser);

      $taskObject->latitude = $request->header('latitude') ?? '';
      $taskObject->longitude = $request->header('longitude') ?? '';
      $formattedAddress = getFormattedAddress($taskObject->latitude, $taskObject->longitude);
      $taskObject->formatted_address = $formattedAddress ?? '';
      $taskObject->platform_type = 'app';

      $taskObject->save();
      $lastInsertedUserId = $taskObject->id;

      if (count($request->task_user) > 0) {

        TaskUser::where('fk_task_id', $lastInsertedUserId)->forceDelete();

        foreach ($request->task_user as $user) {
          $userId = $user['id'];
          $userName = $user['name'];

          $taskUserObject = new TaskUser();

          if ($userId != "") {
            $taskUserObject->fk_task_id = $lastInsertedUserId;
            $taskUserObject->fk_user_id = $userId;
            $taskUserObject->user_name = $userName;
            $taskUserObject->save();
          }
        }
      }

      $this->response['status'] = 1;

      $taskObject->action = 'created';
      if ($id) {
        $taskObject->action = 'updated';
      }
      TaskLogCreated::dispatch($taskObject);

      //Send Task Notification
      if (!$id && count($request->task_user) > 0) {
        $taskUserIdArray = [];
        foreach ($request->task_user as $user) {
          $taskUserIdArray[] = $user['id'];
        }
      }

      $uniqueTaskUserIdArray = array_unique($taskUserIdArray);
      $uniqueTaskUserIdArray = array_values($uniqueTaskUserIdArray);

      if (!empty($uniqueTaskUserIdArray)) {
        $userFcmData = UserDevice::whereIn('user_id', $taskUserIdArray)->whereNotNull('device_id')->groupBy('device_id')->get();
        if (!empty($userFcmData)) {
          $fcmIds = array();
          $deviceIds = array();
          $i = 0;

          foreach ($userFcmData as $key => $val) {
            array_push($fcmIds, $val->fcm_id);
            array_push($deviceIds, $val->device_id);
          }

          $notificationData = ['title' => "Avlock Task", 'body' => "You have a new task: " . $request->title . ". Assigned by " .   $this->currentUserName . " on " . Carbon::parse($request->start)->format('F j, Y')];

          $devicesData =  array_combine($deviceIds, $fcmIds);
          sendFcmNotification($devicesData, $notificationData, $taskUserIdArray);
        }
      }

      DB::commit();
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Creating Task: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Task"]);
      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if (!$this->isUserRSM) {
        $this->response['error'] = "You Are Not RSM User";
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $taskObject = Task::find($id);

      if (!$taskObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Task"]);
        return $this->sendResponse($this->response, 200);
      }

      $taskObject->action = 'deleted';
      TaskLogCreated::dispatch($taskObject);

      $taskObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Task"]);
      $this->response['data'] = $taskObject;



      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Task Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function changeStatus(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $taskId = $request->id ?? '';
      $statusId = $request->status_id ?? '';

      if ($taskId) {
        $taskObject = Task::find($taskId);

        if (!$taskObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Task Status"]);
          return $this->sendResponse($this->response, 200);
        }

        $taskObject->fk_status_id = $statusId;
        $taskObject->save();

        $taskLogObject = TaskLog::where('fk_task_id', $taskId)->first();

        if (!$taskLogObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Task Status"]);
          return $this->sendResponse($this->response, 200);
        }

        $taskLogObject->fk_status_id = $statusId;
        $taskLogObject->save();
      }

      $this->response['status'] = 1;

      $this->response['msg'] = __('admin.updated', ['module' => "Task Status"]);
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Task Status fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }


  private function validateAddUpdateTask(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'title' => 'required|string',
        'description' => 'required|string',
        'start' => 'required',
        'end' => 'required',
        'status' => 'required|integer|exists:statuses,id',
        'taskType' => 'required|integer|exists:task_types,id',
        'lead' => 'nullable|required_if:taskType,1,2|exists:leads,id,deleted_at,NULL',
        'rfq' => 'nullable|required_if:taskType,2|exists:rfqs,id,deleted_at,NULL',
        // 'user' => 'required|integer|exists:users,id',
      ],
      [
        'lead.required_if' => 'Please Select Lead if Task Type is set Lead or RFQ.',
        'rfq.required_if' => 'Please Select RFQ if Task Type for is set RFQ.',
      ]
    )->errors();
  }
}
