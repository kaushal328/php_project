<?php

namespace App\Http\Controllers\AppApi;

use App\Models\Rfq;
use App\Models\ProjectLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Resources\RfqListResource;
use Illuminate\Support\Facades\Validator;
use App\Events\ProjectQuotationLogCreated;
use App\Http\Resources\ProjectLogResource;
use App\Models\PurchaseOrderPackagingList;
use App\Http\Resources\RfqCustomerResource;
use App\Events\ProjectQuotationLogTempCreated;
use App\Http\Controllers\API\AppBaseController;
use App\Http\Resources\PurchaseOrderLogResource;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ProjectController extends AppBaseController {
  
  function index(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $rfqNumber = $request->rfq_number ?? "";
      $product_id = $request->product_id ?? "";
      $project_type = $request->project_type ?? "";
      $project_segment = $request->project_segment ?? "";
      $customer_name = $request->customer_name ?? "";
      $customer = $request->customer ?? "";

      $rfqListResource = Rfq::with('product', 'lead', 'stage', 'subStage', 'projectType', 'projectSegment')->orderBy('updated_at', 'desc');

      if ($rfqNumber) $rfqListResource->where('rfq_number', 'like', "%" . $rfqNumber . "%");
      if ($product_id) $rfqListResource->where('product_id',  $product_id);
      if ($project_type) $rfqListResource->where('fk_project_type_id',  $project_type);
      if ($project_segment) $rfqListResource->where('fk_project_segment_id',  $project_segment);
      if ($customer_name) $rfqListResource->where('customer_name', 'like', "%" . $customer_name . "%");
      if ($customer) $rfqListResource->where('lead_id', '=', $customer);

      $num_rows = $rfqListResource->count();
      $result = $rfqListResource->limit($per_page)->offset($offset)->get();

      $rfqList = RfqListResource::collection($result);

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Project"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['rfq_number'] = $rfqNumber;
      $this->response['data']['product_id'] = $product_id;
      $this->response['data']['project_type'] = $project_type;
      $this->response['data']['project_segment'] = $project_segment;
      $this->response['data']['customer_name'] = $customer_name;
      $this->response['data']['customer'] = $customer;
      $this->response['data']['list'] = $rfqList;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Project List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function getProjectLogs(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      // $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      // $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      // $offset = ($page - 1) * $per_page;

      $rfqId = $request->rfq_id ?? '';
      $projectObject = Rfq::find($rfqId);

      if (!$projectObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Project"]);
        return $this->sendResponse($this->response, 200);
      }

      $curr_sub_stage_id = $request->curr_sub_stage_id ?? "";

      $projectLogs = ProjectLog::with('stage', 'subStage', 'po', 'rfq.quotation')->where('fk_rfq_id', $rfqId)->orderBy("id", "desc");
      if ($curr_sub_stage_id) $projectLogs->where('curr_sub_stage_id',  $curr_sub_stage_id);


      $num_rows = $projectLogs->count();

      $result = $projectLogs->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Project Logs"]);
      // $this->response['data']['page'] = $page;
      // $this->response['data']['per_page'] = $per_page;
      // $this->response['data']['num_rows'] = $num_rows;
      // $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['curr_sub_stage_id'] = $curr_sub_stage_id;

      $this->response['data']['list'] = ProjectLogResource::collection($result);

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Project Logs fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }
}
