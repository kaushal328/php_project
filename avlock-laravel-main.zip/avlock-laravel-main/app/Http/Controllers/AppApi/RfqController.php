<?php

namespace App\Http\Controllers\AppApi;

use App\Enums\LeadStage;
use App\Http\Controllers\API\AppBaseController;
use Carbon\Carbon;
use App\Events\ProjectLogCreated;
use App\Events\RfqLogCreated;
use App\Events\RfqProductLogCreated;
use App\Http\Controllers\Controller;
use App\Http\Resources\RfqCustomerResource;
use App\Http\Resources\RfqFillDetailsResource;
use App\Http\Resources\RfqListResource;
use App\Http\Resources\RfqSaveResource;
use App\Jobs\SendRfqEmailJob;
use App\Models\Division;
use App\Models\Footer;
use App\Models\Industry;
use App\Models\Lead;
use App\Models\LeadAddresses;
use App\Models\LeadContactPeople;
use App\Models\LeadDesignation;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductParameter;
use App\Models\ProductPart;
use App\Models\ProjectSegment;
use App\Models\ProjectType;
use App\Models\Rfq;
use App\Models\RfqBanner;
use App\Models\RfqProduct;
use App\Models\RfqResponse;
use App\Models\RfqResponseLog;
use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Dompdf\Dompdf;
use Spatie\LaravelPdf\Facades\Pdf as MyPdf;
use Spatie\LaravelPdf\Enums\Format;
use Exception;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\View;
use PDF;

class RfqController extends AppBaseController
{
    function index(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            if (!$this->isUserRSM) {
                $this->response['error'] = "You Are Not RSM User";
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;


            $leadId = $request->lead_id ?? "";
            $rfqNumber = $request->rfq_number ?? "";

            $lead = Lead::find($leadId);

            // if (!$lead) {
            //   $this->response['error'] = "Invalid lead selected!";
            //   return $this->sendResponse($this->response, 200);
            // }

            $juniorUserIds = $this->getJuniorIds(false);
            rsort($juniorUserIds);

            // $rfqListResource = Rfq::with('product', 'lead')->whereIn('rsm_id', $juniorUserIds)->orWhereIn('created_by', $juniorUserIds);
            if ($this->isUserAdmin || $this->isUserInsideSale) {
                $rfqListResource = Rfq::with('product');
            } else {
                $rfqListResource = Rfq::with('product')->where(function ($query) use ($juniorUserIds) {
                    $query->whereIn('rsm_id', $juniorUserIds)
                        ->orWhereIn('created_by', $juniorUserIds);
                });
            }

            if ($leadId) $rfqListResource->Where('lead_id', $leadId);
            if ($rfqNumber) $rfqListResource->where('rfq_number', 'like', "%" . $rfqNumber . "%");
            $rfqListResource->orderBy('created_at', 'desc');

            $num_rows = $rfqListResource->count();
            $result = $rfqListResource->limit($per_page)->offset($offset)->get();

            $rfqList = RfqListResource::collection($result);

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "RFQ"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['lead_id'] = $leadId;
            $this->response['data']['rfq_number'] = $rfqNumber;
            $this->response['data']['list'] = $rfqList;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Rfq List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function get(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $leadId = $request->lead_id ?? "";
            $rfqId = $request->rfq_id ?? "";

            if (!$leadId && !$rfqId) {
                $this->response['error'] = "Please select a valid lead!";
                return $this->sendResponse($this->response, 200);
            }

            $leadCustomerResource = Lead::with(['customer', 'rfq' => function ($q) use ($rfqId) {
                $q->where('id', $rfqId);
            }])->find($leadId);

            if ($leadCustomerResource->rfq && $leadCustomerResource->rfq->industry) {
                $leadCustomerResource->rfq->industry = json_decode($leadCustomerResource->rfq->industry, true);
            }

            if ($leadCustomerResource->rfq && $leadCustomerResource->rfq->product_images) {
                $leadCustomerResource->rfq->product_images = json_decode($leadCustomerResource->rfq->product_images, true);
            }

            $leadCustomer = new RfqCustomerResource($leadCustomerResource);

            if (!$leadCustomer) {
                $this->response['error'] = "Something went wrong! Lead details not found.";
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['data'] = $leadCustomer;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Rfq Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function common_list(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $productCatId = $request->fk_product_category_id ?? '';

            $bannerList = RfqBanner::where('status', 1)->orderBy('title')->get();
            $footerList = Footer::where('status', 1)->orderBy('title')->get();
            $designationList = LeadDesignation::where('status', 1)->orderBy('name')->get();
            $industryList = Industry::where('status', 1)->orderBy('name')->get();
            $productList = Product::where('status', 1)->orderBy('product_name')->get();
            $projectTypeList = ProjectType::where('status', 1)->orderBy('name')->get();
            $divisionList = Division::where('status', 1)->orderBy('name')->get();
            $projectSegmentList = ProjectSegment::where('status', 1)->orderBy('name')->get();
            $productAccordingToCategory = Product::where(['product_category_id' => $productCatId, 'status' => 1])->orderBy('product_name')->get();

            $this->response['status'] = 1;
            $this->response['data'] = [
                'banner_list' => $bannerList,
                'footer_list' => $footerList,
                'designation_list' => $designationList,
                'industry_list' => $industryList,
                'product_list' => $productList,
                'project_type_list' => $projectTypeList,
                'division_list' => $divisionList,
                'project_segment_list' => $projectSegmentList,
                'productAccordingToCategory' => $productAccordingToCategory,
            ];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Rfq Common List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function customer_details(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $leadId = $request->lead_id;
            if (!$leadId) {
                $this->response['error'] = "Please select a valid lead to fill RFQ!";
                return $this->sendResponse($this->response, 200);
            }

            $leadCustomerResource = Lead::with('customer')->find($leadId);
            $leadCustomer = new RfqCustomerResource($leadCustomerResource);

            if (!$leadCustomer) {
                $this->response['error'] = "Something went wrong! Customer details not found.";
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = "1";
            $this->response['data'] = $leadCustomer;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Rfq Customer Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function product_images_list(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $productId = $request->product_id;

            $imagesList = ProductImage::where(['product_id' => $productId, 'status' => 1])->get();

            $this->response['status'] = "1";
            $this->response['data'] = ['list' => $imagesList];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Rfq Product Images fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function property_list(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $productId = $request->product_id;

            $propertyList = ProductParameter::where(['product_id' => $productId, 'status' => 1])->get();

            $this->response['status'] = "1";
            $this->response['data'] = ['list' => $propertyList];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Rfq Product Properties fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function add(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            DB::beginTransaction();

            $leadId = $request->lead_id;
            $rfqId = $request->rfq_id;

            $formattedDate = Carbon::createFromFormat('d/m/Y', $request->rfq_date ?? now()->format('d/m/Y'));
            $rfqMonth = $formattedDate->format('M');
            $monthNumber = $formattedDate->format('n');
            $year = $formattedDate->format('Y');
            $financialYearStart = $monthNumber >= 4 ? $year : $year - 1;
            $shortFinYearStart = substr($financialYearStart, -2);
            $shortFinYearEnd = substr($financialYearStart + 1, -2);
            $rfqDate = $formattedDate->format('Y-m-d');

            $bannerId = $request->banner_id;
            $footerId = $request->footer_id;
            $industry = json_encode($request->industry);
            $fk_product_category_id = $request->fk_product_category_id ?? 0;
            $products = $request->products ?? [];
            $productPlus = $request->productPlus ?? [];
            $fk_project_segment_id = $request->fk_project_segment_id ?? 0;
            $fk_project_type_id = $request->fk_project_type_id ?? 0;
            $division_id = $request->division_id ?? 0;
            $sourceId = $request->fk_source_id;
            $designation_id = $request->designation_id ?? 0;
            $currency = $request->currency ?? null;
            $productImages = json_encode($request->product_images ?? []);
            $productFieldCount = $request->product_field_count;
            $projectSegments = json_encode($request->project_segments ?? []);
            $industry_name = $request->industry_name;
            $noOfPiecesRequired = $request->no_of_pieces_required;
            $customerName = $request->customer_name;
            $address1 = $request->address1;
            $address2 = $request->address2;
            $city = $request->city;
            $pincode = $request->pincode;
            $state = $request->state;
            $contactNo = $request->contact_no;
            $email = $request->email;
            $leadAddId = $request->lead_addresses_id;
            $leadContId = $request->lead_contact_people_id;

            if (!$bannerId) {
                $this->response['error'] = "Please select banner!";
                return $this->sendResponse($this->response, 200);
            }

            if (!$footerId) {
                $this->response['error'] = "Please select footer!";
                return $this->sendResponse($this->response, 200);
            }

            if (!$rfqDate) {
                $this->response['error'] = "Please select RFQ Date!";
                return $this->sendResponse($this->response, 200);
            } else if (strtotime($rfqDate) > strtotime(date('Y-m-d'))) {
                $this->response['error'] = "Future RFQ Date is not allowed!";
                return $this->sendResponse($this->response, 200);
            }

            // if (!$industryId) {
            //     $this->response['error'] = "Please select industry!";
            //     return $this->sendResponse($this->response, 200);
            // }

            if (empty($productPlus)) {
                $this->response['error'] = "Please select atlest One Product!";
                return $this->sendResponse($this->response, 200);
            }

            // Check if any item in the $productPlus array has an empty 'product_id'
            if (!empty($productPlus)) {
                foreach ($productPlus as $product) {
                    if (empty($product['product_id'])) {
                        $this->response['error'] = "Product ID cannot be empty!";
                        return $this->sendResponse($this->response, 200);
                    }
                }
            }

            $lead = Lead::with('rsmUser')->where('id', $leadId)->get();
            $lead = RfqSaveResource::collection($lead)->first();
            if (!$lead) {
                $this->response['error'] = "Something went wrong! Please re-select the lead.";
                return $this->sendResponse($this->response, 200);
            }

            $rsmId = 0;
            $rsmName = '';
            if ($this->isUserRSM) {
                $rsmObject = User::find($this->userId);
                if ($rsmObject) {
                    $rsmId = $rsmObject->id;
                    $rsmName = $rsmObject->name;
                }
            }

            $division = Division::find($division_id);
            if (!$division) {
                $this->response['error'] = "Please Select Division.";
                return $this->sendResponse($this->response, 200);
            }

            $rfq = new Rfq();
            if ($rfqId) $rfq = Rfq::find($rfqId);
            $dbRfqDate = $rfq->rfq_date;

            $rfq->latitude = $request->header('latitude') ?? '';
            $rfq->longitude = $request->header('longitude') ?? '';
            $formattedAddress = getFormattedAddress($rfq->latitude, $rfq->longitude);
            $rfq->formatted_address = $formattedAddress ?? '';
            $rfq->platform_type = 'app';

            $rfq->lead_id = $lead->id;
            $rfq->rfq_date = $rfqDate;
            $rfq->banner_id = $request->banner_id;
            $rfq->footer_id = $request->footer_id;
            $rfq->customer_name = $customerName;
            $rfq->contact_no = $contactNo;
            $rfq->email = $email;
            $rfq->designation_id = $lead->fk_designation_id;
            $rfq->address1 = $address1;
            $rfq->address2 = $address2;
            $rfq->city = $city;
            $rfq->state = $state;
            $rfq->no_of_pieces_required = $noOfPiecesRequired;
            $rfq->pincode = $pincode;
            $rfq->industry = $industry;
            $rfq->industry_name = $industry_name;
            $rfq->fk_project_segment_id = $fk_project_segment_id;
            $rfq->fk_product_category_id = $fk_product_category_id;
            $rfq->fk_project_type_id = $fk_project_type_id;
            $rfq->division_id = $division_id;
            $rfq->fk_source_id = $sourceId;
            $rfq->designation_id = $designation_id;
            $rfq->currency = $currency;
            $rfq->product_images = $productImages;
            $rfq->project_segments = $projectSegments;
            $rfq->product_field_count = $productFieldCount;
            $rfq->rsm_id = $rsmId;
            $rfq->rsm_name = $rsmName;
            $rfq->lead_addresses_id = $leadAddId;
            $rfq->lead_contact_people_id = $leadContId;
            $rfq->rfq_remark = $request->rfq_remark;
            $rfq->assigned_rsm = $rsmId;
            $rfq->assigned_rsm_name = $rsmName;
            if (!$rfqId) {
                $baseString = strtoupper('RFQ/' . $division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . $rfqMonth . '/');
                $rfqNo = generateSeries($baseString, 'rfqs', 'rfq_number');
            } else {

                if ($dbRfqDate !== $rfqDate) {
                    $baseString = strtoupper('RFQ/' . $division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . $rfqMonth . '/');
                    $rfqNo = generateSeries($baseString, 'rfqs', 'rfq_number');
                } else {
                    $rfqNo = $request->rfq_number ?? '';
                }
            }

            $existingRfq = Rfq::where('rfq_number', $rfqNo)->where('id', '!=',  $rfqId)->first();

            if ($existingRfq) {
                $this->response['error'] = "RFQ No already exists.";
                return $this->sendResponse($this->response, 200);
            }

            $rfq->rfq_number = $rfqNo;
            $rfq->created_by = $this->userId;
            $rfq->save();
            $lastInsertedRfqId = $rfq->id;

            $leadObject = Lead::find($leadId);
            $rfqExist = Rfq::where('lead_id', $leadId)->get();

            if ($leadObject) {
                if (!empty($email) && !empty($contactNo) && !empty($application) && $rfqExist->isNotEmpty()) {
                    $leadObject->lead_stage_id = LeadStage::LEADFINALIZED->value;
                    $leadObject->save();
                }
            }

            $productIds = array_column($productPlus, 'product_id');
            $proIds = array_column($productPlus, 'id');

            if (count($productIds) > 0)

                // Filter out empty and non-numeric values from $proIds
                $proIds = array_filter($proIds, 'is_numeric');

            // First, delete the product IDs that are not present in the payload
            RfqProduct::where('rfq_id', $lastInsertedRfqId)->whereNotIn('id', $proIds)->delete();

            foreach ($productPlus as $product) {
                $id = $product['id'] ?? '';
                $productId = $product['product_id'];
                $productPartId = $product['product_part_id'] ?? '';
                $exist = RfqProduct::where('id', $id)->where('rfq_id', $lastInsertedRfqId)
                    ->where('product_id', $productId)
                    ->first();
                if (!$exist) {
                    RfqProduct::create([
                        'rfq_id' => $lastInsertedRfqId,
                        'product_id' => $productId,
                        'product_part_id' => $productPartId,
                    ]);
                } else {
                    if ($exist->trashed()) {
                        RfqProduct::withTrashed()
                            ->where('rfq_id', $lastInsertedRfqId)
                            ->where('product_id', $productId)
                            ->restore();
                    }
                }

                $rfqProduct = RfqProduct::where('rfq_id', $lastInsertedRfqId)
                    ->where('product_id', $productId)
                    ->first();

                $rfqProduct->action = 'created';
                if ($rfqId) {
                    $rfqProduct->action = 'updated';
                }

                RfqProductLogCreated::dispatch($rfqProduct);
            }

            $lastRfq = Rfq::find($lastInsertedRfqId);

            if ($lastRfq) {
                $lastInsertedProjectTypeId = $lastRfq->fk_project_type_id;

                $leadNew = Lead::find($lastRfq->lead_id);

                if ($leadNew) {
                    $leadNew->update(['customer_type' => $lastInsertedProjectTypeId]);
                }
            }

            if ($rfqId) {

                $this->response['status'] = 1;
                $this->response['msg'] = "RFQ updated successfully";
            } else {
                $rfq->action = 'created';
                ProjectLogCreated::dispatch($rfq);
                $this->response['status'] = 1;
                $this->response['msg'] = "RFQ created successfully";
            }

            $rfq->action = 'created';
            if ($rfqId) {
                $rfq->action = 'updated';
            }
            $rfq->action_from = 'rfq';

            $rfq->rsm_id = $rsmId ?? 0;
            $rfq->rsm_name = $rsmName ?? '';
            $rfq->assigned_rsm = $rsmId ?? 0;
            $rfq->assigned_rsm_name = $rsmName ?? '';

            if (empty($rfqId)) {
                $currentUrl = URL::to('/');
                if (!str_contains($currentUrl, 'localhost')) {
                    SendRfqEmailJob::dispatch($lastInsertedRfqId);
                }
            }

            RfqLogCreated::dispatch($rfq);

            DB::commit();


            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("Rfq Save failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function fill_details(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $rfqId = $request->rfq_id ?? '';

            $detailsResource = Rfq::with(['banner', 'lead', 'product', 'rfqResponse', 'designation'])->find($rfqId);
            $details = new RfqFillDetailsResource($detailsResource);

            if (!$details) {
                $this->response['error'] = "RFQ details not found!";
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['data'] = $details;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Rfq Fill Details failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function save_customer_response(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            DB::beginTransaction();

            $rfqResponse = $request->response ?? [];

            if (empty($rfqResponse)) {
                $this->response['error'] = "Please Fill RFQ Response";
                return $this->sendResponse($this->response, 200);
            }

            if (!is_array($rfqResponse)) {
                $this->response['error'] = "Invalid RFQ Response";
                return $this->sendResponse($this->response, 200);
            }

            $rfqId = $request->rfq_id;
            $rfq = Rfq::find($rfqId);
            if (!$rfq) {
                $this->response['error'] = "Something went wrong! Please try again.";
                return $this->sendResponse($this->response, 200);
            }

            $rfq->response_industries = json_encode($request->industries ?? []);
            $rfq->response_other_industries = $request->other_industries;
            $rfq->save();

            $rfq->action = 'updated';
            ProjectLogCreated::dispatch($rfq);

            foreach ($rfqResponse as  $resp) {

                if (!isset($resp['product_qty']) || empty($resp['product_qty']) || $resp['product_qty'] < 0) {
                    $this->response['error'] = "Please Enter Product Quantity For " . $resp['product_name'];
                    return $this->sendResponse($this->response, 200);
                }

                $responseId = $resp['id'];
                $rfqResponse = RfqProduct::find($responseId);

                if (!$rfqResponse) {
                    $this->response['error'] = "Invalid Response Id";
                    return $this->sendResponse($this->response, 200);
                }

                $rfqResponse->response = json_encode($resp['rfq_response_obj'] ?? []);
                $rfqResponse->product_qty = $resp['product_qty'] ?? 0;
                $rfqResponse->is_response_received = 1;
                $rfqResponse->ip = $request->ip();
                $rfqResponse->save();


                $rfqResponse->action = 'response_received';

                RfqProductLogCreated::dispatch($rfqResponse);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = "RFQ details submitted successfully";

            DB::commit();


            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Rfq Save Customer Response failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function assignRsm(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAssignRsm($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $rfqObject = new Rfq();
            $id = $request->id;
            $assignedRsm = $request->assigned_rsm;

            if ($id) {

                $rfqObject = Rfq::find($id);

                if (!$rfqObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "RFQ"]);
                    return $this->sendResponse($this->response, 200);
                }

                $userObject = User::find($assignedRsm);

                if (!$userObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "User"]);
                    return $this->sendResponse($this->response, 200);
                }

                $rfqObject->assigned_rsm = $assignedRsm;
                $rfqObject->assigned_rsm_name = $userObject->name;
                $rfqObject->rsm_id = $assignedRsm;
                $rfqObject->rsm_name = $userObject->name;
                $this->response['msg'] = 'RSM Assign Successfully';
            }

            $rfqObject->save();

            $rfqObject->action = 'updated';
            $rfqObject->action_from = 'rfq';

            RfqLogCreated::dispatch($rfqObject);


            $this->response['status'] = 1;
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed Assigning RSM: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Lead"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    //   public function downloadPdf(Request $request) {
    //     try {

    //       if (!$this->userId) {
    //         $this->response['error'] = __('auth.authentication_failed');
    //         return $this->sendResponse($this->response, 401);
    //       }

    //       $rfqId = $request->rfq_id ?? '';

    //       $detailsResource = Rfq::with(['banner', 'lead', 'product', 'rfqResponse', 'designation'])->find($rfqId);
    //       $details = new RfqFillDetailsResource($detailsResource);

    //       if (!$details) {
    //         $this->response['error'] = "RFQ details not found!";
    //         return $this->sendResponse($this->response, 200);
    //       }

    //       $data = [
    //         'details' => json_decode(json_encode($details)),
    //       ];

    //       $dompdf = PDF::loadView('pdf.rfqPdf', $data);

    //       $dompdf->setPaper('A4', 'portrait');

    //       $encryptName = Crypt::encryptString($rfqId);
    //       $trimLength = substr($encryptName, 0, 6);
    //       $fileName = $trimLength . '.pdf';
    //       // Render the PDF
    //       $dompdf->render();

    //       $pdfContent = $dompdf->output();

    //       file_put_contents(storage_path('app/public/uploads/pdf/' . $fileName), $pdfContent); // Save the PDF to the specified file path

    //       $this->response['status'] = 1;
    //       $this->response['msg'] = __('admin.fetched', ['module' => "RFQ Pdf"]);
    //       $this->response['data'] = $this->fileAccessPath . '/pdf/' . $fileName;
    //       $this->response['filePath'] = 'https://crm.avlock.in/server/public/' . $this->fileAccessPath . '/pdf/' . $fileName;

    //       return $this->sendResponse($this->response, 200);
    //     } catch (Exception $e) {
    //       Log::error("RFQ pdf Generation Failed: " . $e->getMessage());
    //       $this->response['error'] = __('auth.something_went_wrong');
    //       return $this->sendResponse($this->response, 500);
    //     }
    //   }

    public function downloadPdf(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $rfqId = $request->id ?? '';
            $viewPdf = $request->view_pdf;

            $detailsResource = Rfq::with(['banner', 'lead', 'product', 'rfqResponse', 'designation'])->find($rfqId);
            $details = new RfqFillDetailsResource($detailsResource);

            if (!$details) {
                $this->response['error'] = "RFQ details not found!";
                return $this->sendResponse($this->response, 200);
            }

            $data = [
                'details' => json_decode(json_encode($details)),
            ];

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "RFQ Pdf"]);
                $this->response['data']['html'] = view('pdf.rfq.view', ['details' => $data['details']])->render();

                return $this->sendResponse($this->response, 200);
            }

            $path = 'pdf/rfq/' . str_replace(['-', '/'], '', $details->rfq_number) . '.pdf';

            MyPdf::view('pdf.rfq.view', ['details' => $data['details']])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "RFQ Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = 'https://crm.avlock.in/server/public/' . $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("RFQ pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function sendEmail(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $rfqId = $request->rfq_id ?? '';



            $detailsResource = Rfq::with(['banner', 'lead', 'product.parameters', 'rfqResponse', 'designation'])->find($rfqId);
            $details = new RfqFillDetailsResource($detailsResource);

            if (!$details) {
                $this->response['error'] = "RFQ details not found!";
                return $this->sendResponse($this->response, 200);
            }


            $data = [
                'details' => json_decode(json_encode($details)),
            ];

            $toEmail =   $data['details']->email ?? '';

            if ($toEmail == '') {
                $this->response['status'] = 0;
                $this->response['error'] = 'Email Not Found For This RFQ';
                return $this->sendResponse($this->response, 200);
            }

            $encryptName = Crypt::encryptString($rfqId);
            $trimLength = substr($encryptName, 0, 6);
            $fileName = $trimLength . '.pdf';

            if ($fileName) {
                $sourcePath = 'public/uploads/pdf/' . $fileName;

                if (!Storage::exists($sourcePath)) {

                    $dompdf = PDF::loadView('pdf.rfqPdf', $data);

                    $dompdf->setPaper('A4', 'portrait');

                    // Render the PDF
                    $dompdf->render();

                    $pdfContent = $dompdf->output(); // Get the generated PDF content

                    file_put_contents(storage_path('app/public/uploads/pdf/' . $fileName), $pdfContent);
                }
            }
            $filePath = url($this->fileAccessPath . '/pdf/' . $fileName);

            $subject = 'RFQ Details';

            SendRfqEmailJob::dispatch($toEmail, $subject, $filePath);

            // Save the PDF to the specified file path

            $this->response['status'] = 1;
            $this->response['msg'] = "mail Will be sent to this Email : " . $toEmail;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("RFQ pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function productPartLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $productId = $request->product_id ?? '';

            $productPartLists = ProductPart::where(['status' => 1, 'product_id' => $productId])->orderBy('part_no', 'asc')->get();

            $this->response['status'] = 1;
            $this->response['data'] = [
                'productParts' => $productPartLists,
            ];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getLeadAddresses(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $leadId = $request->input('lead_id', '');

            $lead = Lead::find($leadId);
            $leadAddresses = [];

            if ($lead) {
                $leadArray = $lead->toArray();
                $leadAddresses[] = $leadArray;
                $leadAddresses = array_merge($leadAddresses, LeadAddresses::where('lead_id', $leadId)->get()->toArray());
            } else {
                $leadAddresses = LeadAddresses::where('lead_id', $leadId)->get()->toArray();
            }

            $list = $leadAddresses;

            $this->response['status'] = 1;
            $this->response['data']['list'] = $list;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getContactPersons(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $leadId = $request->input('lead_id', '');
            $leadAddressId = $request->input('lead_address_id', '');

            $lead = Lead::where('id', $leadId)->get()->toArray();
            $leadAddresses = [];
            if (!empty($leadAddressId)) {
                $leadAddresses = LeadContactPeople::with('leadAddress')->where(['lead_address_id' => $leadAddressId, 'lead_id' => $leadId])->get()->toArray();
            }

            if (!empty($leadAddresses)) {
                $contactPeople = $leadAddresses;
            } else {
                $contactPeople = $lead;
            }



            $this->response['status'] = 1;
            $this->response['data']['list'] = $contactPeople;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $rfqObject = Rfq::find($id);

            if (!$rfqObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "RFQ"]);
                return $this->sendResponse($this->response, 401);
            }

            $rfqObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "RFQ"]);
            $this->response['data'] = $rfqObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("RFQ deleting failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    private function validateAssignRsm(Request $request)
    {
        return Validator::make(
            $request->all(),
            [
                'id' => 'required',
                'assigned_rsm' => 'required|exists:users,id,deleted_at,NULL',
            ],
            [
                'assigned_rsm.exists' => 'RSM doesn\'t exists with provided id',
            ]
        )->errors();
    }
}
