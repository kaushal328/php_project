<?php

namespace App\Http\Controllers\AppApi;

use App\Models\ActivityType;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\API\AppBaseController;

class ActivityTypeController extends AppBaseController {
  
    /**
   * Display a listing of the Designation.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';
      $status = $request->status ?? '';

      $activityTypeOnject = ActivityType::withoutTrashed()->orderBy("id", "desc");
      $num_rows = $activityTypeOnject->count();

      if ($title) {
        $activityTypeOnject->where('title', 'like', '%' . $title . '%');
      }

      if ($status) {
        $activityTypeOnject->where('status', $status);
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Activity Type"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['list'] = $activityTypeOnject->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Activity Type fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateActivityType($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $activityTypeObject = new ActivityType();
      $id = $request->id;
      $title = $request->title ?? '';
      $status = $request->status ?? 1;

      if ($id) {
        $activityTypeObject = ActivityType::find($id);

        if (!$activityTypeObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Activity Type"]);
          return $this->sendResponse($this->response, 500);
        }

        $activityTypeObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Activity Type"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Activity Type"]);
      }

      $activityTypeObject->title = $title;
      $activityTypeObject->status = $status;

      $activityTypeObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Activity Type: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Activity Type"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $activityTypeObject = ActivityType::find($id);

      if (!$activityTypeObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Activity Type"]);
        return $this->sendResponse($this->response, 500);
      }
      $activityTypeObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Activity Type"]);
      $this->response['data'] = $activityTypeObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Activity Type fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $activityTypeObject = ActivityType::find($id);

      if (!$activityTypeObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Activity Type"]);
        return $this->sendResponse($this->response, 500);
      }

      $activityTypeObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Activity Type"]);
      $this->response['data'] = $activityTypeObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Activity Type Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdateActivityType(Request $request) {
    return Validator::make($request->all(), [
      'title' => 'required|string|unique:activity_types,title,' . $request->id . ',id,deleted_at,NULL',
      'status' => 'sometimes|required|integer|in:0,1',
    ])->errors();
  }


}
