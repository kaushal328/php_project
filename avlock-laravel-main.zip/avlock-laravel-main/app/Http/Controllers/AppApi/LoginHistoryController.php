<?php

namespace App\Http\Controllers\AppApi;

use App\Http\Controllers\API\AppBaseController;
use App\Models\LoginLog;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class LoginHistoryController extends AppBaseController
{
    function index()
    {
        try {

            if (!$this->isUserRSM) {
                $this->response['error'] = "You Are Not RSM User";
                return $this->sendResponse($this->response, 401);
            }

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $list = LoginLog::where(['user_id' => $this->userId])->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  "Login History List";
            $this->response['data']['list'] = $list;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Login history api failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }
}
