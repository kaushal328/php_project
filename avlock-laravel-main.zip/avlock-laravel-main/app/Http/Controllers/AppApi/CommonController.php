<?php

namespace App\Http\Controllers\AppApi;

use Exception;
use App\Models\Rfq;
use App\Models\Lead;
use App\Models\User;
use App\Models\State;
use App\Models\Region;
use App\Models\Status;
use App\Models\Product;
use App\Models\Industry;
use App\Models\TaskType;
use App\Models\Designation;
use App\Models\ActivityType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Http\Controllers\API\AppBaseController;
use App\Models\Country;
use App\Models\Currency;
use App\Models\GstApiLog;
use App\Models\ProductPart;
use App\Models\Source;
use App\Models\SubStage;
use GuzzleHttp\Client;
use Illuminate\Support\Carbon;

class CommonController extends AppBaseController
{

    function common_list(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $taskType = TaskType::select('id', 'name')->where('status', 1)->get();
            $industryList = Industry::select('id', 'name')->where('status', 1)->orderBy('name')->get();
            $productList = Product::select('id', 'product_name as name', 'product_category_id')->where('status', 1)->orderby('product_name')->get();
            $salesPerson = User::select('id', 'name')->where('id', '<>', 1)->orderBy("name", "asc")->get();
            $taskUserList = User::select('id', 'name')->whereNotIn('id', [1, $this->userId])->orderBy("name", "asc")->get();
            $taskStatus = Status::select('id', 'name')->get();
            $leadList = Lead::select('id', 'company', 'contact_no')->get();
            $activityTypeList = ActivityType::where('status', 1)->orderBy('title')->get();


            $rfqList = Rfq::with('product')->where('status', 1);

            if (isset($request->lead) && !empty($request->lead)) {
                $rfqList->where('lead_id', $request->lead);
            }

            $this->response['status'] = 1;
            $this->response['data'] = [
                'task_status' => $taskStatus,
                'task_user' => $taskUserList,
                'sales_person' => $salesPerson,
                'task_type' => $taskType,
                'industry_list' => $industryList,
                'product_list' => $productList,
                'lead_list' => $leadList,
                'rfq_list' => $rfqList->get(),
                'activity_type' => $activityTypeList,

            ];

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Common List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function stateList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $stateList = State::get();

            $this->response['status'] = 1;
            $this->response['data'] = [
                'stateL_list' => $stateList,
            ];

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("State List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function leadLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $company = trim($request->company ?? '');
            $list = [];
            if ($company) {
                $list = Lead::where('status', 1)
                    ->where('company', 'like', '%' . $company . '%')
                    ->take(10)
                    ->orderBy('company')
                    ->get();
            }

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function rfqList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $company = trim($request->input('company', ''));

            $listQuery = Rfq::with(['product', 'lead'])->where('status', 1)->take(10);

            if ($company !== '') {
                $listQuery->whereHas('lead', function ($query) use ($company) {
                    $query->where('company', 'like', $company . '%')->orderBy('company');
                });
            }

            if ($request->filled('lead')) {
                $listQuery->whereIn('lead_id', $request->input('lead'));
            }

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $listQuery->get();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function activityType()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $activityTypeList = ActivityType::where('status', 1)->get();

            $this->response['status'] = 1;
            $this->response['data'] = [
                'activity_type' => $activityTypeList,
            ];

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Activity Type List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    public function uploadAttachments(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            if (!$request->hasFile('files')) {
                $this->response['error'] = __('admin.file_upload_error');
                return $this->sendResponse($this->response, 200);
            }

            $files = [];
            $imageTempPath = 'uploads/temp';

            foreach ($request->file('files') as $index => $file) {
                $extension = $file->extension();

                $tempImageName = uniqid() . '.' . $extension;
                $file->storeAs($imageTempPath, $tempImageName, 'public');

                $files[] = ['filename' => $tempImageName, 'path' => $this->fileAccessPath . '/temp/' . $tempImageName];
            }

            $this->response['status'] = 1;
            $this->response['files'] = $files;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function sourceList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $list = Source::where('status', 1)->orderBy('name')->get();
            $this->response['status'] = 1;
            $this->response['data'] = ['list' => $list];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function designationList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $designationObject = Designation::select('id', 'title')->where('status', 1)->orderBy('title');

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Designation"]);
            $this->response['data']['list'] = $designationObject->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Designation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function regionList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = Region::orderBy('name')->get();

            $this->response['status'] = 1;
            $this->response['data'] = ['list' => $list];
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function subStageList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $list = SubStage::where('status', 1)->orderBy('name');

            if (isset($request->stage) && !empty($request->stage)) {
                $list->where('stage_id', $request->stage);
            }

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list->get();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function productLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $productCatId = $request->product_category_id ?? '';

            $productList = Product::select('id', 'product_name', 'product_category_id')->where('product_category_id', $productCatId)->where('status', 1)->get();

            $this->response['status'] = 1;
            $this->response['data'] = [
                'product_list' => $productList,
            ];

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("State List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function countryList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = Country::get();

            $this->response['status'] = 1;
            $this->response['data'] = ['list' => $list];
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function getGstDetails(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $gst = $request->gst ?? '';
            $company = substr(trim($request->company ?? ''), 0, 4);

            $todaysDate = Carbon::now();
            $currentDate = Carbon::now();

            $pastDate = $currentDate->subDays(30);
            if ($pastDate->month !== $currentDate->month) {
                $pastDate = $pastDate->endOfMonth();
            }

            $formattedPastDate = $pastDate->format('Y-m-d');

            $existingGst = GstApiLog::where('request_payload->gst', $gst)
                ->whereDate('created_at', '>=', $formattedPastDate)
                ->whereDate('created_at', '<=', $todaysDate)->latest()->first();


            if (empty($gst) && empty($company)) {
                $this->response['error'] = 'Please provide either GST or company name.';
                return $this->sendResponse($this->response, 200);
            }

            if (!empty($gst)) {
                if (!preg_match('/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/', $gst)) {
                    $this->response['error'] = 'Invalid GST number format';
                    return $this->sendResponse($this->response, 200);
                }
            }

            $ip = $request->ip();

            $lastHitTime = GstApiLog::where('ip_address', $ip)->latest()->value('created_at');

            if ($lastHitTime && now()->diffInSeconds($lastHitTime) < config('global.API_LIMIT')) {
                return $this->response = ['error' => 'Please wait for 30 seconds before trying again.'];
                return $this->sendResponse($this->response, 429);
            }

            $statusCode = '';
            $msg = '';
            $companyInfo = [];

            if (empty($existingGst)) {
                if (!empty($gst)) {
                    $apiKey = 'cc22d317580bc0fa9486942a5237cc27';
                    $url = "http://sheet.gstincheck.co.in/check/{$apiKey}/{$gst}";

                    $client = new Client();
                    $response = $client->get($url);

                    $statusCode = $response->getStatusCode();
                    $data = $response->getBody()->getContents();
                }
            } else {
                $statusCode = 200;
                $data = $existingGst->response;
            }

            if ($statusCode == 200) {

                GstApiLog::create([
                    'ip_address' => $ip,
                    'request_payload' => json_encode($request->all()),
                    'response' => $data,
                ]);

                $responseData = json_decode($data, true);

                if (isset($responseData['flag']) && $responseData['flag'] === false) {
                    $message = isset($responseData['message']) ? $responseData['message'] : 'GST Number not found';
                    $this->response['error'] = $message;
                    return $this->sendResponse($this->response, 200);
                }

                $companyInfo = [
                    'gstin' => null,
                    'company_name' => null,
                    'address' => null,
                    'state' => null,
                    'city' => null,
                    'pincode' => null,
                ];

                if (isset($responseData['data']['gstin'])) {
                    $companyInfo['gstin'] = $responseData['data']['gstin'];
                }

                if (isset($responseData['data']['tradeNam'])) {
                    $companyInfo['company_name'] = $responseData['data']['tradeNam'];
                }

                if (isset($responseData['data']['pradr']['adr'])) {
                    $address = $responseData['data']['pradr']['adr'];
                    $companyInfo['address'] = $address;
                }

                if (isset($responseData['data']['pradr']['addr']['stcd'])) {
                    $state = $responseData['data']['pradr']['addr']['stcd'];
                    $companyInfo['state'] = $state;
                }

                if (isset($responseData['data']['pradr']['addr']['dst'])) {
                    $city = $responseData['data']['pradr']['addr']['dst'];
                    $companyInfo['city'] = $city;
                }

                if (isset($responseData['data']['pradr']['addr']['pncd'])) {
                    $pincode = $responseData['data']['pradr']['addr']['pncd'];
                    $companyInfo['pincode'] = $pincode;
                }

                $msg = isset($responseData['message']) ? $responseData['message'] : 'GSTIN found.';
            }

            $gstLead = [];
            $companyLeads = [];
            $showButton = false;

            if ($gst) {
                $gstLead = Lead::where('status', 1)->where('gstin', $gst)->get();
                if ($gstLead->isEmpty()) {
                    $showButton = true;
                }
            }

            if ($company) {
                $companyLeads = Lead::where('status', 1)->where('company', 'like', $company . '%')->get();
            }

            $this->response['status'] = 1;
            $this->response['msg'] = $msg;
            $this->response['data']['show_select_button'] = $showButton;
            $this->response['data']['gst'] = $companyInfo;
            $this->response['data']['existing'] = $gstLead;
            $this->response['data']['similar'] = $companyLeads;
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed to retrieve GST details: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Lead"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    public function rsmList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = User::with('roles')->orderBy("name", "asc");
            $list->whereHas('roles', function ($query) {
                $query->where(['fk_department_id' => 5]);
            });

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list->get();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function productListRfq(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $productName = trim($request->product_name ?? '');
            $productId = $request->product_id ?? '';

            $productLists = Product::orderBy('product_name')
                ->when($productName, function ($query, $productName) {
                    return $query->where('product_name', 'like', '%' . $productName . '%')
                        ->where('status', 1);
                })
                ->when($productId, function ($query, $productId) {
                    return $query->where('id', $productId);
                })
                ->orWhere(function ($query) use ($productName, $productId) {
                    if (empty($productName) && empty($productId)) {
                        $query->whereNotNull('product_name');
                    }
                })
                ->whereNull('deleted_at')
                ->take(20)
                ->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $productLists;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function productPartLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $partNo = trim($request->part_no ?? '');
            $productId = $request->product_id ?? '';

            $productPartLists = ProductPart::with('product:id,product_name')
                ->when($partNo, function ($query, $partNo) {
                    return $query->where('part_no', 'like', '%' . $partNo . '%')
                        ->where('status', 1);
                })
                ->when($productId, function ($query, $productId) {
                    return $query->where('product_id', $productId);
                })
                ->orWhere(function ($query) use ($partNo, $productId) {
                    if (empty($partNo) && empty($productId)) {
                        $query->whereNotNull('part_no');
                    }
                })
                ->whereNull('deleted_at')
                ->take(20)
                ->orderBy('part_no')
                ->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $productPartLists;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 200);
        }
    }

    public function newProductPartLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $searchTerm = trim($request->search_term ?? '');

            if (!$searchTerm) {
                $list = [];
            } else {
                $products = Product::selectRaw('product_name, id as product_id, "-" as part_no')
                    ->where('product_name', 'like', '%' . $searchTerm . '%')
                    ->whereNull('deleted_at')
                    ->orderByRaw("CASE WHEN LOWER(product_name) = ? THEN 0 ELSE 1 END", [strtolower($searchTerm)])
                    ->take(20)
                    ->get(['id', 'product_name']);

                $products->map(function ($item) {
                    $item->product = collect([
                        'id' => $item->product_id,
                        'product_name' => $item->product_name
                    ]);
                });

                $parts = ProductPart::with('product:id,product_name')
                    ->where('part_no', 'like', '%' . $searchTerm . '%')
                    ->orWhereHas('product', function ($q) use ($searchTerm) {
                        $q->where('product_name', 'like', '%' . $searchTerm . '%');
                    })
                    ->whereNull('deleted_at')
                    ->orderBy('part_no')
                    ->get();

                // Merging products and parts into the list
                $list = $products->merge($parts);
            }

            $this->response['status'] = 1;
            $this->response['data']['list'] = $list;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 200);
        }
    }

    public function productListsNew(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $searchTerm = trim($request->input('search_item', ''));

            $productLists = Product::select('id', 'product_name')
                ->with(['partNo' => function ($query) use ($searchTerm) {
                    $query->select('id', 'product_id', 'part_no', 'description');
                    if ($searchTerm) {
                        $query->orderByRaw("CASE WHEN part_no = ? THEN 0 ELSE 1 END", [$searchTerm]);
                    }
                }])
                ->where(function ($query) use ($searchTerm) {
                    $query->where('product_name', 'like', '%' . $searchTerm . '%')
                        ->orWhereHas('partNo', function ($query) use ($searchTerm) {
                            $query->where('part_no', 'like', '%' . $searchTerm . '%');
                        });
                })
                ->whereNull('deleted_at')
                ->orderBy('product_name')
                ->take(10)
                ->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $productLists;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getCurrencyList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  "Currency list";
            $this->response['data']['list'] = Currency::where('status', 1)->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("getCurrencyList failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function getFormattedAddress($latitude, $longitude)
    {
        try {
            $client = new Client();

            $response = $client->get('https://maps.googleapis.com/maps/api/geocode/json', [
                'query' => [
                    'latlng' => $latitude . ',' . $longitude,
                    'key' => 'AIzaSyCGx_Fl0yKDXwvqekOgYiU78Th3MAWzOxE',
                ]
            ]);

            $body = json_decode($response->getBody(), true);

            if ($response->getStatusCode() == 200 && $body['status'] == 'OK') {
                return $body['results'][0]['formatted_address'];
            }
        } catch (\Exception $e) {
            Log::error("Geocoding Error: " . $e->getMessage());
            return null;
        }
    }
}
