<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Vendor;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class VendorController extends AppBaseController
{
  /**
   * Display a listing of the Vendor.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $company_name = $request->company_name ?? '';
      $contact_person = $request->contact_person ?? '';
      $mobile = $request->mobile ?? '';
      $email = $request->email ?? '';

      $vendor = Vendor::orderBy("id", "desc");

      if ($company_name) {
        $vendor->where('company_name', 'like', '%' . $company_name . '%');
      }

      if ($contact_person) {
        $vendor->where('contact_person', 'like', '%' . $contact_person . '%');
      }

      if ($mobile) {
        $vendor->where('mobile', 'like', '%' . $mobile . '%');
      }

      if ($email) {
        $vendor->where('email', 'like', '%' . $email . '%');
      }

      $num_rows = $vendor->count();
      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Vendor"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['company_name'] = $company_name;
      $this->response['data']['contact_person'] = $contact_person;
      $this->response['data']['mobile'] = $mobile;
      $this->response['data']['email'] = $email;
      $this->response['data']['list'] = $vendor->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Vendor fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateVendor($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $vendorObject = new Vendor();
      $id = $request->id;
      $company_name = $request->company_name ?? '';
      $contact_person = $request->contact_person ?? '';
      $mobile = $request->mobile ?? '';
      $email = $request->email ?? '';
      $address = $request->address ?? '';
      $gst_no = $request->gst_no ?? '';
      $pan_no = $request->pan_no ?? '';
      $status = $request->status ?? 1;

      if ($id) {
        $vendorObject = Vendor::find($id);

        if (!$vendorObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Vendor"]);
          return $this->sendResponse($this->response, 200);
        }

        $vendorObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Vendor"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Vendor"]);
      }

      $vendorObject->company_name = $company_name;
      $vendorObject->contact_person = $contact_person;
      $vendorObject->mobile = $mobile;
      $vendorObject->email = $email;
      $vendorObject->address = $address;
      $vendorObject->gst_no = $gst_no;
      $vendorObject->pan_no = $pan_no;
      $vendorObject->status = $status;

      $vendorObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Creating Vendor: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Vendor"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $vendorObject = Vendor::find($id);

      if (!$vendorObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Vendor"]);
        return $this->sendResponse($this->response, 200);
      }
      $vendorObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Vendor"]);
      $this->response['data'] = $vendorObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Vendor fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $vendorObject = Vendor::find($id);

      if (!$vendorObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Vendor"]);
        return $this->sendResponse($this->response, 200);
      }

      $vendorObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Vendor"]);
      $this->response['data'] = $vendorObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Vendor Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdateVendor(Request $request)
  {
    return Validator::make($request->all(), [
      'company_name' => 'required|string',
      'email' => 'required|string|email|max:255|unique:vendors,email,' . $request->id . ',id,deleted_at,NULL',
      'mobile' => 'required|string|regex:/^[6-9]\d{9}$/|unique:vendors,mobile,' . $request->id . ',id,deleted_at,NULL',
      'status' => 'sometimes|required|integer|in:0,1',
    ])->errors();
  }
}
