<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\ProductCategory;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ProductCategoryController extends AppBaseController
{
    /**
     * Display a listing of the Product Category.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $category_name = $request->category_name ?? '';

            $productCategory = ProductCategory::select('*', 'status as is_active')->withoutTrashed()->orderBy("category_name");

            if ($category_name) {
                $productCategory->where('category_name', 'like', '%' . $category_name . '%');
            }

            $result = $productCategory->get()->toArray();

            $num_rows = $productCategory->count();
            $treeData = $this->generateTree($result);

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Product Category"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['category_name'] = $category_name;
            $this->response['data']['list'] = $treeData;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Category fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function addUpdate(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateProductCategory($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $productCategoryObject = new ProductCategory();
            $id = $request->id;
            $parent_id = $request->parent_id ?? 0;
            $category_name = $request->category_name;
            $description = $request->description ?? '';
            $image = $request->image;
            $image_thumb = $request->image_thumb;
            $image_alt = $request->image_alt ?? NULL;
            $status = $request->is_active ?? 1;



            if ($id) {
                $productCategoryObject = ProductCategory::find($id);

                if (!$productCategoryObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Product Category"]);
                    return $this->sendResponse($this->response, 401);
                }

                $productCategoryObject->first();
                $this->response['msg'] = __('admin.updated', ['module' => "Product Category"]);
            } else {
                $this->response['msg'] = __('admin.created', ['module' => "Product Category"]);
            }

            $allImages = [];
            $allThumbImages = [];

            foreach ($image as $item) {

                moveFile('product-category/image/', $item['filename']);

                $allImages[] = [
                    'filename' => $item['filename'],
                    'path' => $this->fileAccessPath . "/product-category/image/" . $item['filename'],
                ];
            }

            foreach ($image_thumb as $item) {

                moveFile('product-category/thumb/', $item['filename']);

                $allThumbImages[] = [
                    'filename' => $item['filename'],
                    'path' => $this->fileAccessPath . "/product-category/thumb/" . $item['filename'],
                ];
            }

            $productCategoryObject->parent_id = $parent_id;
            $productCategoryObject->category_name = $category_name;
            $productCategoryObject->description = $description;
            $productCategoryObject->image = json_encode($allImages);
            $productCategoryObject->image_thumb = json_encode($allThumbImages);
            $productCategoryObject->image_alt = $image_alt;
            $productCategoryObject->status = $status;

            $productCategoryObject->save();

            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Product Category: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Product Category"]);

            return $this->sendResponse($this->response, 401);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $productCategoryObject = ProductCategory::select('*', 'status as is_active')->find($id);

            if (!$productCategoryObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product Category"]);
                return $this->sendResponse($this->response, 401);
            }
            $productCategoryObject->first();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Product Category"]);
            $this->response['data'] = $productCategoryObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Category fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $productCategoryObject = ProductCategory::find($id);

            if (!$productCategoryObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product Category"]);
                return $this->sendResponse($this->response, 401);
            }

            $productCategoryObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Product Category"]);
            $this->response['data'] = $productCategoryObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Category Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    private function validateAddUpdateProductCategory(Request $request)
    {
        return Validator::make($request->all(), [
            'parent_id' => 'required|integer',
            'category_name' => 'required|string|unique:product_categories,category_name,' . $request->id . ',id,deleted_at,NULL',
            'image' => 'required',
            'image_thumb' => 'required',
            'status' => 'sometimes|required|integer|in:0,1',
        ])->errors();
    }

    private function generateTree($data, $parentId = 0)
    {
        $tree = [];
        foreach ($data as $item) {
            if ($item['parent_id'] == $parentId) {
                $children = $this->generateTree($data, $item['id']);
                if ($children) {
                    $item['children'] = $children;
                }
                $tree[] = $item;
            }
        }
        return $tree;
    }
}
