<?php

namespace App\Http\Controllers\API;

use Exception;
use App\Models\Activity;
use Illuminate\Http\Request;
use App\Models\UserAttendance;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class UserAttendanceController extends AppBaseController
{

  public function today(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $userAttendanceObject = UserAttendance::where('fk_user_id', $this->userId)
        ->whereDate('attendance_date', now()->format('Y-m-d'))
        ->first();

      $this->response['msg'] = "Attendance for today fetched successfully";
      $this->response['status'] = 1;
      $this->response['data'] = $userAttendanceObject;


      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed To Fetch Today's Attendance: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Attendance"]);

      return $this->sendResponse($this->response, 401);
    }
  }
  public function checkIn(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $yesterday = now()->subDays(1)->toDateString();
      $checkEmptySvr = Activity::with('activityType')->where('is_physical_visit', 1)->whereNull('fk_svr_id')->where('fk_user_id', $this->userId)->whereDate('start_time', $yesterday)->get();

      $isActivityEmpty = $checkEmptySvr->count();

      // if ($isActivityEmpty > 0) {
      //   $activity = $checkEmptySvr->toArray();
      //   $data = [];

      //   foreach ($activity as $value) {
      //     $data[] = [
      //       'title' => $value['activity_type']['title'],
      //     ];
      //   }

      //   $this->response['error'] = 'These Activities Require SVR which needs to be Fill';
      //   $this->response['list'] = $data;
      //   return $this->sendResponse($this->response, 200);
      // }

      $existingAttendance = UserAttendance::where('fk_user_id', $this->userId)
        ->whereDate('attendance_date', now()->format('Y-m-d'))
        ->first();

      // if ($existingAttendance) {
      //   $this->response['error'] = 'You Already Checkin For the day';
      //   return $this->sendResponse($this->response, 200);
      // }

      $userAttendanceObject = new UserAttendance();
      $userAttendanceObject->fk_user_id = $this->userId;
      $userAttendanceObject->checkin_time = now();
      $userAttendanceObject->attendance_date = now();
      $userAttendanceObject->save();

      $this->response['msg'] = "Checkin Successfully";
      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed To Checkin: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Attendance"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function checkOut(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $today = now()->toDateString();
      // Fetch activities that require SVR
      $checkEmptySvr = Activity::with('activityType')
        ->where('is_physical_visit', 1)
        ->whereNull('fk_svr_id')
        ->where('fk_user_id', $this->userId)
        ->whereDate('start_time', $today)
        ->get();

      $numEmptySvr = $checkEmptySvr->count();
      $checkEmpty = '';

      if ($numEmptySvr > 0) {
        $checkEmpty = "$numEmptySvr SVRs need to be filled before checkout.";
      }

      $checkoutAction = $request->checkout_action ?? '';

      if ($checkoutAction === 'checkout') {

        // Check if all activities have been stopped
        // $isEndTimeStop =  Activity::whereNull('end_time')
        //   ->where('fk_user_id', $this->userId)
        //   ->whereDate('start_time', $today)
        //   ->get();

        // $isEndTimeEmpty = $isEndTimeStop->count();

        // if ($isEndTimeEmpty > 0) {
        //   $this->response['error'] = 'Please stop all Activities before checkout.';
        //   return $this->sendResponse($this->response, 200);
        // }

        $existingAttendance = UserAttendance::where('fk_user_id', $this->userId)
          ->whereDate('attendance_date', now()->format('Y-m-d'))
          ->first();

        if (!$existingAttendance) {
          $this->response['error'] = 'You have not checked in for today';
          return $this->sendResponse($this->response, 200);
        }

        // if ($existingAttendance->checkout_time) {
        //   $this->response['error'] = 'You have already checked out for today';
        //   return $this->sendResponse($this->response, 200);
        // }

        // Perform the checkout
        $existingAttendance->checkout_time = now();
        $existingAttendance->save();

        $this->response['msg'] = "Checkout Successful";
        $this->response['status'] = 1;

        return $this->sendResponse($this->response, 200);
      } else {
        if (!empty($checkEmpty)) {
          $this->response['error'] = $checkEmpty;
          return $this->sendResponse($this->response, 200);
        } else {
          $isEndTimeStop =  Activity::whereNull('end_time')
            ->where('fk_user_id', $this->userId)
            ->whereDate('start_time', $today)
            ->get();

          $isEndTimeEmpty = $isEndTimeStop->count();

          if ($isEndTimeEmpty > 0) {
            $this->response['error'] = 'Please stop all Activities before checkout.';
            return $this->sendResponse($this->response, 200);
          }

          // Proceed with the checkout directly
          $existingAttendance = UserAttendance::where('fk_user_id', $this->userId)
            ->whereDate('attendance_date', now()->format('Y-m-d'))
            ->first();

          if (!$existingAttendance) {
            $this->response['error'] = 'You have not checked in for today';
            return $this->sendResponse($this->response, 200);
          }

          // if ($existingAttendance->checkout_time) {
          //   $this->response['error'] = 'You have already checked out for today';
          //   return $this->sendResponse($this->response, 200);
          // }

          // Perform the checkout
          $existingAttendance->checkout_time = now();
          $existingAttendance->save();

          $this->response['msg'] = "Checkout Successful";
          $this->response['status'] = 1;

          return $this->sendResponse($this->response, 200);
        }
      }
    } catch (Exception $e) {
      Log::error("Failed To Checkout " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Attendance"]);
      return $this->sendResponse($this->response, 401);
    }
  }
}
