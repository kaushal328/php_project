<?php

namespace App\Http\Controllers\API;

use App\Enums\ErrorType;
use App\Http\Controllers\Controller;
use App\Models\Designation;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class DesignationController extends AppBaseController
{
    /**
     * Display a listing of the Designation.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $title = $request->title ?? '';
            $status = $request->status ?? '';

            $designation = Designation::with('division')->withoutTrashed()->orderBy("id", "desc");

            if ($title) {
                $designation->where('title', 'like', '%' . $title . '%');
            }

            if ($status) {
                $designation->where('status', $status);
            }
            $num_rows = $designation->count();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Designation"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['title'] = $title;
            $this->response['data']['list'] = $designation->limit($per_page)->offset($offset)->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Designation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function addUpdate(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateDesignation($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $designationObject = new Designation();
            $id = $request->id;
            $title = $request->title ?? '';
            $division_id = $request->division_id ?? null;
            $status = $request->status ?? 1;



            if ($id) {
                $designationObject = Designation::find($id);

                if (!$designationObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Designation"]);
                    return $this->sendResponse($this->response, 401);
                }

                $designationObject->first();
                $designationObject->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "Designation"]);
            } else {
                $designationObject->created_by = $this->userId;
                $this->response['msg'] = __('admin.created', ['module' => "Designation"]);
            }

            $designationObject->title = $title;
            $designationObject->division_id = $division_id;
            $designationObject->status = $status;

            $designationObject->save();

            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Designation: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Designation"]);

            return $this->sendResponse($this->response, 401);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $designationObject = Designation::find($id);

            if (!$designationObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Designation"]);
                return $this->sendResponse($this->response, 401);
            }
            $designationObject->first();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Designation"]);
            $this->response['data'] = $designationObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Designation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $designationObject = Designation::find($id);

            if (!$designationObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Designation"]);
                return $this->sendResponse($this->response, 401);
            }

            $designationObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Designation"]);
            $this->response['data'] = $designationObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Designation Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    private function validateAddUpdateDesignation(Request $request)
    {
        return Validator::make($request->all(), [
            'title' => 'required|string|unique:designations,title,' . $request->id . ',id,deleted_at,NULL',
            // 'division_id' => 'required',
            'status' => 'sometimes|required|integer|in:0,1',
        ])->errors();
    }
}
