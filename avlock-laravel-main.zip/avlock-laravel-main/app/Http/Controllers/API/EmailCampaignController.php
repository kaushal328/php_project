<?php

namespace App\Http\Controllers\API;

use Carbon\Carbon;
use App\Models\EmailData;
use Illuminate\Http\Request;
use App\Models\EmailCampaign;
use App\Imports\EmailDataImport;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Http\Resources\EmailDataResource;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\EmailCampaignResource;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use App\Http\Controllers\API\AppBaseController;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use PHPOpenSourceSaver\JWTAuth\Contracts\Providers\Auth;

class EmailCampaignController extends AppBaseController
{

  public function index(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $campaignId = $request->campaign_id ?? '';
      $title = $request->title ?? '';
      $startDate = $request->start_date ?? '';
      $endDate = $request->end_date ?? '';
      $budget = $request->budget ?? '';

      $emailCampaign = EmailCampaign::withoutTrashed()->orderBy("id", "desc");
      $numRows = $emailCampaign->count();

      if ($campaignId) {
        $emailCampaign->where('campaign_id', 'like', '%' . $campaignId . '%');
      }

      if ($title) {
        $emailCampaign->where('title', 'like', '%' . $title . '%');
      }

      if ($startDate) {
        $emailCampaign->where('start_date', '>=', $this->convertToDatabaseDateForSearch($startDate));
      }

      if ($endDate) {
        $emailCampaign->where('end_date', '<=', $this->convertToDatabaseDateForSearch($endDate));
      }

      if ($budget) {
        $emailCampaign->where('budget', '=', $budget);
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Email Campaign"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $per_page ? 1 : ceil($numRows / $per_page);
      $this->response['data']['campaign_id'] = $campaignId;
      $this->response['data']['title'] = $title;
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['end_date'] = $endDate;
      $this->response['data']['list'] = $emailCampaign->limit($per_page)->offset($offset)->get();
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Email Campaign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateEmailCampaign($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $emailCampaignObject = new EmailCampaign();
      $id = $request->id;
      $title = $request->title;
      $campaignId = $request->campaign_id;
      $startDate = $request->start_date ? Carbon::createFromFormat('d/m/Y g:i A', $request->start_date)->format('Y-m-d H:i:s') : null;
      $endDate = $request->end_date ? Carbon::createFromFormat('d/m/Y g:i A', $request->end_date)->format('Y-m-d H:i:s') : null;
      $budget = $request->budget;
      $status = $request->status;

      if ($id) {
        $emailCampaignObject = EmailCampaign::find($id);

        if (!$emailCampaignObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Email Campaign"]);
          return $this->sendResponse($this->response, 401);
        }

        $emailCampaignObject->first();
        $emailCampaignObject->updated_by = $this->userId;
        $this->response['msg'] = __('admin.updated', ['module' => 'Email Campaign']);
      } else {
        $emailCampaignObject->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => 'Email Campaign']);
      }

      $emailCampaignObject->title = $title;
      $emailCampaignObject->campaign_id = $campaignId;
      $emailCampaignObject->start_date = $startDate;
      $emailCampaignObject->end_date = $endDate;
      $emailCampaignObject->budget = $budget;
      $emailCampaignObject->status = $status;

      $emailCampaignObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Email Campaign: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Email Campaign"]);
      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $emailCampaign = EmailCampaign::withoutTrashed()->find($id);
      $totalData = EmailData::withoutTrashed()->where('fk_email_campaign_id', $id)->count();

      if (!$emailCampaign) {
        $this->response['error'] = __('admin.id_not_found', ['module' => 'Email Campaign']);
        return $this->sendResponse($this->response, 400);
      }

      $emailCampaign->first();
      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => 'Email Campaign']);
      $this->response['data'] = $emailCampaign;
      $this->response['data']['total'] = $totalData;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Email Campaign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $emailCampaign = EmailCampaign::find($id);

      if (!$emailCampaign) {
        $this->response['error'] = __('admin.id_not_found', ['module' => 'Email Campaign']);
        return $this->sendResponse($this->response, 400);
      }

      $emailCampaign->delete();
      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => 'Email Campaign']);
      $this->response['data'] = $emailCampaign;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Email Campign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addReport(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddReport($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      // $emailCampaignObject = new EmailCampaign();
      // $totalEmailSent = $request->total_email_sent;
      // $totalEmailDelivered = $request->total_email_delivered;
      // $totalEmailOpened = $request->total_email_opened;
      // $totalEmailClicked = $request->total_email_clicked;
      // $totalEmailBounced = $request->total_email_bounced;
      // $totalEmailFailed = $request->total_email_failed;
      
      $id = $request->id;
      $totalData = $request->total_data;
      $delivered = $request->delivered;
      $DeliveryRate = $request->delivery_rate;
      $opens = $request->opens;
      $openRate = $request->open_rate;
      $enquireNow = $request->enquire_now;
      $facebook = $request->facebook;
      $twitter = $request->twitter;
      $instagram = $request->instagram;
      $linkedin = $request->linkedin;
      $pinterest = $request->pinterest;
      $website = $request->website;
      $totalClicks = $request->total_clicks;
      $clicks = $request->clicks;
      $clickToOpenRate = $request->click_to_open_rate;
      $unsubscribe = $request->unsubscribe;
      $unsubscribeRate = $request->unsubscribe_rate;
      $bounce = $request->bounce;
      $bounceRate = $request->bounce_rate;
      $reportDate = $request->report_date ? Carbon::createFromFormat('d/m/Y g:i A', $request->report_date)->format('Y-m-d H:i:s') : null;
      
      if ($id) {
        $emailCampaignObject = EmailCampaign::find($id);
        
        if (!$emailCampaignObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Email Campaign"]);
          return $this->sendResponse($this->response, 401);
        }

        $emailCampaignObject->first();
        // $emailCampaignObject->total_email_sent = $totalEmailSent;
        // $emailCampaignObject->total_email_delivered = $totalEmailDelivered;
        // $emailCampaignObject->total_email_opened = $totalEmailOpened;
        // $emailCampaignObject->total_email_clicked = $totalEmailClicked;
        // $emailCampaignObject->total_email_bounced = $totalEmailBounced;
        // $emailCampaignObject->total_email_failed = $totalEmailFailed;
        
        $emailCampaignObject->report_date = $reportDate;
        $emailCampaignObject->total_data = $totalData;
        $emailCampaignObject->delivered = $delivered;
        $emailCampaignObject->delivery_rate = $DeliveryRate;
        $emailCampaignObject->opens = $opens;
        $emailCampaignObject->open_rate = $openRate;
        $emailCampaignObject->enquire_now = $enquireNow;
        $emailCampaignObject->facebook = $facebook;
        $emailCampaignObject->twitter = $twitter;
        $emailCampaignObject->instagram = $instagram;
        $emailCampaignObject->linkedin = $linkedin;
        $emailCampaignObject->pinterest = $pinterest;
        $emailCampaignObject->website = $website;
        $emailCampaignObject->total_clicks = $totalClicks;
        $emailCampaignObject->clicks = $clicks;
        $emailCampaignObject->click_to_open_rate = $clickToOpenRate;
        $emailCampaignObject->unsubscribe = $unsubscribe;
        $emailCampaignObject->unsubscribe_rate = $unsubscribeRate;
        $emailCampaignObject->bounce = $bounce;
        $emailCampaignObject->bounce_rate = $bounceRate;
        $emailCampaignObject->updated_by = $this->userId;

        $emailCampaignObject->save();
        $this->response['msg'] = __('admin.updated', ['module' => "Email Campaign"]);
      }

      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Report: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Email Campaign"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function listData(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $fkEmailCampaignId = $request->email_campaign_id ?? '';
      $name = $request->name ?? '';
      $address = $request->address ?? '';
      $city = $request->city ?? '';
      $mobile = $request->mobile ?? '';
      $email = $request->email ?? '';


      $emailDataObject = EmailData::with('campaign');
      $numRows = $emailDataObject->count();

      if ($fkEmailCampaignId) {
        $emailDataObject->whereHas('campaign', function ($query) use ($fkEmailCampaignId) {
          $query->where('fk_email_campaign_id', $fkEmailCampaignId);
        });
      }

      if ($name) {
        $emailDataObject->where('name', 'like', '%' . $name . '%');
      }

      if ($address) {
        $emailDataObject->where('address', 'like', '%' . $address . '%');
      }

      if ($city) {
        $emailDataObject->where('city', 'like', '%' . $city . '%');
      }

      if ($mobile) {
        $emailDataObject->where('mobile', 'like', '%' . $mobile . '%');
      }

      if ($email) {
        $emailDataObject->where('email', 'like', '%' . $email . '%');
      }

      $emailDataObject = $emailDataObject->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Email Campaign"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $per_page ? 1 : ceil($numRows / $per_page);
      $this->response['data']['email_campaign_id'] = $fkEmailCampaignId;
      $this->response['data']['name'] = $name;
      $this->response['data']['address'] = $address;
      $this->response['data']['city'] = $city;
      $this->response['data']['email'] = $email;
      $this->response['data']['mobile'] = $mobile;
      $this->response['data']['list'] = EmailCampaignResource::collection($emailDataObject);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Email Data fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addData(REQUEST $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $files = $request->excel ?? [];

      $validationErrors = $this->validateAddData($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }
      foreach ($files as $item) {

        $filePath = storage_path('app/public/uploads/temp/' . $item['filename']);
        $sourcePath = 'public/uploads/temp/' .  $item['filename'];

        if (!Storage::exists($sourcePath)) {

          $this->response['error'] = __('admin.file_not_found', ['file' => $item['filename']]);
          return $this->sendResponse($this->response, 401);
        }

        $spreadsheet = IOFactory::load($filePath);
        $sheetNames = $spreadsheet->getSheetNames();
        $dataRecords = [];

        foreach ($sheetNames as $sheetName) {
          $worksheet = $spreadsheet->getSheetByName($sheetName);
          $cellIterator = $worksheet->getRowIterator()->current()->getCellIterator();
          $cellIterator->setIterateOnlyExistingCells(true);

          $headers = [];
          foreach ($cellIterator as $cell) {
            if ($cell->getValue() != '') {
              $headers[] = $cell->getValue();
            }
          }

          if (array_values($headers) != array_values(config('global.EMAIL_DATA_HEADER_FORMAT'))) {
            $this->response['error'] = __('admin.excel_format_error', ['file' => $item['filename'], 'sheet' => $sheetName]);
            return $this->sendResponse($this->response, 200);
          }


          $highestRow = $worksheet->getHighestRow();
          $dataRecords = [];

          for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
            $dataRecords[] = $rowData[$row];
          }
        }

        foreach ($dataRecords as $data) {
          EmailData::create([
            'name' => convertToCamelCase($data['A']),
            'mobile' => $data['B'],
            'email' => $data['C'],
            'address' => convertToCamelCase($data['D']),
            'city' => convertToCamelCase($data['E']),
            'fk_email_campaign_id' => $id
          ]);
        }

        $this->response['status'] = 1;
        $this->response['msg'] = __('admin.created', ['module' => "Email Data"]);
        return $this->sendResponse($this->response, 200);
      }
    } catch (\Exception $e) {
      Log::error("Failed Creating Excel Data: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Email Data"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function addDataSingle(REQUEST $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddDataSingle($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $EmailData = new EmailData();
      $id = $request->id;
      $email_campaign_id = $id;
      $name = $request->name;
      $address = $request->address;
      $city = $request->city;
      $email = $request->email;
      $mobile = $request->mobile;

      if ($id) {
        $EmailData = new EmailData();

        if (!$EmailData) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Email Data"]);
          return $this->sendResponse($this->response, 401);
        }

        $EmailData->fk_email_campaign_id = $email_campaign_id;
        $EmailData->name = $name;
        $EmailData->address = $address;
        $EmailData->city = $city;
        $EmailData->email = $email;
        $EmailData->mobile = $mobile;
      }

      $EmailData->save();
      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.created', ['module' => "Email Data"]);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Email Data: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Email Data"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function deleteData(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $EmailData = EmailData::find($id);

      if (!$EmailData) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Email Data"]);
        return $this->sendResponse($this->response, 401);
      }

      $EmailData->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Email Data"]);
      $this->response['data'] = $EmailData;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Email Data deleting failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddData(REQUEST $request)
  {
    return Validator::make(
      $request->all(),
      [
        'id' => 'required|exists:email_campaigns,id,deleted_at,NULL',
        'excel' => 'required',
      ],
      [
        'id.exists' => "Campaign doesn't exists with provided id",
      ]
    )->errors();
  }

  private function validateAddDataSingle(REQUEST $request)
  {
    return Validator::make(
      $request->all(),
      [
        'id' => 'required|exists:email_campaigns,id,deleted_at,NULL',
        'name' => 'required',
        'address' => 'required',
        'city' => 'required',
        'email' => 'required',
        'mobile' => 'required',
      ],
      [
        'id.exists' => "Email Campaign doesn't exists with provided id",
      ]
    )->errors();
  }

  private function validateAddReport(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        // 'total_email_sent' => 'nullable|integer',
        // 'total_email_delivered' => 'nullable|integer',
        // 'total_email_opened' => 'nullable|integer',
        // 'total_email_clicked' => 'nullable|integer',
        // 'total_email_bounced' => 'nullable|integer',
        // 'total_email_failed' => 'nullable|integer',
        
        'report_date' => 'nullable|date_format:d/m/Y g:i A',
        'total_data' => 'nullable|integer',
        'delivered' => 'nullable|integer',
        'delivery_rate' => 'nullable|numeric',
        'opens' => 'nullable|integer',
        'open_rate' => 'nullable|numeric',
        'enquire_now' => 'nullable|integer',
        'facebook' => 'nullable|integer',
        'twitter' => 'nullable|integer',
        'instagram' => 'nullable|integer',
        'linkedin' => 'nullable|integer',
        'pinterest' => 'nullable|integer',
        'website' => 'nullable|integer',
        'total_clicks' => 'nullable|integer',
        'clicks' => 'nullable|integer',
        'click_to_open_rate' => 'nullable|numeric',
        'unsubscribe' => 'nullable|integer',
        'unsubscribe_rate' => 'nullable|numeric',
        'bounce' => 'nullable|integer',
        'bounce_rate' => 'nullable|numeric',
      ],
      [
        // 'total_email_sent.integer' => 'Invalid Total value',
        // 'total_email_delivered.integer' => 'Invalid Total value',
        // 'total_email_opened.integer' => 'Invalid Total value',
        // 'total_email_clicked.integer' => 'Invalid Total value',
        // 'total_email_bounced.integer' => 'Invalid Total value',
        // 'total_email_failed.integer' => 'Invalid Total value',
        'report_date.date_format' => 'Invalid Date Format',
      ]
    )->errors();
  }

  private function validateAddUpdateEmailCampaign(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'campaign_id' => 'required',
        'title' => 'required|string|unique:email_campaigns,title,' . $request->id . ',id,deleted_at,NULL',
        'start_date' => 'required|date_format:d/m/Y g:i A',
        'end_date' => 'required|date_format:d/m/Y g:i A|after:start_date',
        'budget' => 'sometimes|required|numeric',
        'status' => 'sometimes|required|integer|in:0,1',
      ],
      [
        'title.unique' => 'Title already exist',
        'start_date.date_format' => 'Invalid Date Format',
        'end_date.date_format' => 'Invalid Date Format',
      ]
    )->errors();
  }
}
