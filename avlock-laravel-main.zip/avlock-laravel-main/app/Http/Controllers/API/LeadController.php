<?php

namespace App\Http\Controllers\API;

use Exception;
use Carbon\Carbon;
use App\Models\Rfq;
use App\Models\Lead;
use App\Models\User;
use App\Models\Region;
use App\Models\Source;
use App\Enums\Monogram;
use App\Models\SmsData;
use App\Models\EmailData;
use App\Models\Designation;
use App\Models\BookpostData;
use App\Models\SfcEmailData;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Http\Resources\LeadResource;
use App\Events\CreditLimitLogCreated;
use App\Http\Resources\SmsDataResource;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\DataCampaignResource;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use App\Http\Controllers\API\AppBaseController;
use App\Models\GstApiLog;
use App\Enums\LeadStage;
use App\Models\LeadAddresses;
use App\Models\LeadContactPeople;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use GuzzleHttp\Client;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use PhpOffice\PhpSpreadsheet\Writer\Csv;

class LeadController extends AppBaseController
{

    public function index(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $enquiryDate = $request->enquiry_date ?? '';
            $fkRegionId = $request->region ?? '';
            $customerName = $request->customer_name ?? '';
            $companyName = $request->company_name ?? '';
            $email = $request->email ?? '';
            $contactNo = $request->contact_no ?? '';
            $fkSourceId = $request->source ?? '';
            $SMOPlatform = $request->smo_platform ?? '';
            $adwordsPlatform = $request->adwords_platform ?? '';
            $fkRsmrId = $request->fk_rsmr_id ?? '';
            $fkRsmvId = $request->rsm ?? '';
            $reference = $request->reference ?? '';
            $division = $request->division ?? '';
            $isClient = $request->is_client;
            $designation = $request->designation;
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';
            $isExport = $request->is_export;

            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            $userObject = User::find($this->userId);
            if ($userObject) {
                $divisionIds = $userObject->division_ids ?? '';
                $divisionIdsArray = explode(',', $divisionIds);
            }

            if ($this->isMarketing || $this->isManagement || $this->isUserAdmin || $this->isUserInsideSale) {
                $lead = Lead::with('division', 'region', 'source', 'rfq', 'rsmr', 'rsmv', 'designation', 'rfqCount', 'activityCount', 'assignedRsm', 'leadStage')->orderBy('id', 'desc');
                if ($this->isUserInsideSale && !empty($divisionIdsArray) && !$this->isUserAdmin) {
                    $lead->where(function ($q) use ($divisionIdsArray) {
                        $q->whereNull('division_id');
                        $q->orWhereIn('division_id', $divisionIdsArray);
                    });
                }
            } else {
                $lead = Lead::with('division', 'region', 'rfq', 'source', 'rsmr', 'rsmv', 'designation', 'rfqCount', 'activityCount', 'assignedRsm', 'leadStage')
                    ->where(function ($q) use ($juniorUserIds) {
                        $q->whereIn('created_by', $juniorUserIds);
                        $q->orWhereIn('assigned_rsm', $juniorUserIds);
                        $q->orWhereIn('fk_rsmr_id', $juniorUserIds);
                        $q->orWhereIn('fk_rsmv_id', $juniorUserIds);
                    })
                    ->orderBy('id', 'desc');
            }

            if ($isClient == 'true') {
                $lead->where('is_client', 1);
            }

            if ($division) {
                $lead->where('division_id', $division);
            }


            if ($enquiryDate) {
                $lead->where('enquiry_date', '>=', Carbon::createFromFormat('d/m/Y', $enquiryDate)->format('Y-m-d H:i:s'));
            }

            if ($fkRegionId) {
                $lead->where('fk_region_id', '=', $fkRegionId);
            }

            if ($customerName) {
                $lead->where('customer_name', 'like', '%' . $customerName . '%');
            }

            if ($companyName) {
                $lead->where('company', 'like', '%' . $companyName . '%');
            }

            if ($email) {
                $lead->where('email', 'like', '%' . $email . '%');
            }

            if ($contactNo) {
                $lead->where('contact_no', 'like', '%' . $contactNo . '%');
            }

            if ($fkSourceId) {
                $lead->where('fk_source_id', '=', $fkSourceId);
            }

            if ($SMOPlatform) {
                $lead->where('smo_platform', 'like', '%' . $SMOPlatform . '%');
            }

            if ($adwordsPlatform) {
                $lead->where('adwords_platform', 'like', '%' . $adwordsPlatform . '%');
            }

            if ($fkRsmrId) {
                $lead->where('fk_rsmr_id', '=', $fkRsmrId);
            }

            if ($fkRsmvId) {
                $lead->where('fk_rsmv_id', '=', $fkRsmvId);
            }

            if ($reference) {
                $lead->where('reference', 'like', '%' . $reference . '%');
            }

            if ($designation) {
                $lead->whereHas('designation', function ($query) use ($designation) {
                    $query->where('title', '%' . $designation . '%');
                });
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $lead->whereDate('created_at', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $lead->whereDate('created_at', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $lead->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                    $lead->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $lead->whereDate('created_at', '>=', date('Y-m-d', strtotime('-14 days')));
                    $lead->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $lead->whereDate('created_at', '>=', date('Y-m-d', strtotime('-28 days')));
                    $lead->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $lead->whereMonth('created_at', date('m'))->whereYear('created_at', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $lead->whereMonth('created_at', date('m', strtotime('-1 month')));
                }
                if ($dateRange == 'this_year') {
                    $lead->whereYear('created_at', date('Y'));
                }
                if ($dateRange == 'last_year') {
                    $lead->whereYear('created_at', date('Y', strtotime('-1 year')));
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $lead->whereDate('created_at', '>=', $startDate);

                        if ($endDate) {
                            $lead->whereDate('created_at', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $lead->count();
            $total_pages = ceil($num_rows / $per_page);
            if ($isExport == 1) {
                $result = $lead->get();
            } else {
                $result = $lead->limit($per_page)->offset($offset)->get();
            }

            if ($isExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                $headers = ['Sr.No', 'Company', 'GSTIN', 'Contact Person', 'Email', 'Mobile', 'Is Export', 'Address 1', 'Address 2', 'Pincode', 'City', 'State', 'Application', 'Description', 'Alternate Email 1', 'Alternate Email 2', 'Alternate Contact 1', 'Alternate contact 2',  'Designation', 'RSM', 'Region', 'Source', 'Division', 'RFQS', 'Activities'];
                $sheetData = [$headers];

                foreach ($result as $key => $item) {
                    $rfqCount = is_null($item->rfq_count) ? 0 : count($item->rfq_count);
                    $activityCount = is_null($item->activityCount) ? 0 : count($item->activityCount);
                    $designationIds = $item->designations ? $item->designations : [];
                    $designations = $designationIds ? Designation::whereIn('id', $designationIds)->get()->implode('title', ', ') : '';

                    $rowData = [
                        $key + 1,
                        $item->company ?? '',
                        $item->gstin ?? '',
                        $item->customer_name ?? '',
                        $item->email ?? '',
                        $item->contact_no ?? '',
                        ($item->is_export == 1) ? 'Yes' : 'No',
                        $item->address1 ?? '',
                        $item->address2 ?? '',
                        $item->pincode ?? '',
                        $item->city ?? '',
                        $item->state ?? '',
                        $item->application ?? '',
                        $item->description ?? '',
                        $item->alt_email_one ?? '',
                        $item->alt_email_two ?? '',
                        $item->alt_contact_one ?? '',
                        $item->alt_contact_two ?? '',
                        $designations ?? '',
                        ($item->assignedRsm) ? $item->assignedRsm->name : '',
                        ($item->region) ? $item->region->name : '',
                        ($item->source) ? $item->source->name : '',
                        ($item->division) ? $item->division->name : '',
                        $rfqCount,
                        $activityCount,
                    ];
                    $sheetData[] = $rowData;
                }

                $sheet->fromArray($sheetData, null, 'A1');

                $store = "storage/app/public/uploads/lead/lead_list.csv";
                $filePath = "storage/uploads/lead/lead_list.csv";
                $writer = new Csv($spreadsheet);
                $writer->save($store);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Lead " . $isClient]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['total_pages'] = $total_pages;
            $this->response['filePath'] = $filePath ?? '';
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['enquiry_date'] = $enquiryDate;
            $this->response['data']['fk_region_id'] = $fkRegionId;
            $this->response['data']['customer_name'] = $customerName;
            $this->response['data']['company'] = $companyName;
            $this->response['data']['email'] = $email;
            $this->response['data']['contact_no'] = $contactNo;
            $this->response['data']['fk_source_id'] = $fkSourceId;
            $this->response['data']['smo_platform'] = $SMOPlatform;
            $this->response['data']['adwords_platform'] = $adwordsPlatform;
            $this->response['data']['fk_rsmr_id'] = $fkRsmrId;
            $this->response['data']['fk_rsmv_id'] = $fkRsmvId;
            $this->response['data']['reference'] = $reference;
            $this->response['data']['jids'] = $juniorUserIds;
            $this->response['data']['showRsm'] = true;
            $this->response['data']['list'] = LeadResource::collection($result);
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Lead fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function rawLead(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $enquiryDate = $request->enquiry_date ?? '';
            $fkRegionId = $request->fk_region_id ?? '';
            $customerName = $request->customer_name ?? '';
            $company = $request->company ?? '';
            $email = $request->email ?? '';
            $contactNo = $request->contact_no ?? '';
            $fkSourceId = $request->fk_source_id ?? '';
            $SMOPlatform = $request->smo_platform ?? '';
            $adwordsPlatform = $request->adwords_platform ?? '';
            $fkRsmrId = $request->fk_rsmr_id ?? '';
            $fkRsmvId = $request->fk_rsmv_id ?? '';
            $reference = $request->reference ?? '';
            $isClient = $request->is_client;

            $lead = Lead::with('region', 'source', 'rsmr', 'rsmv', 'designation', 'rfqCount', 'activityCount', 'svr', 'rfqs')
                ->whereNotNull('contact_no')
                ->whereNotNull('email')
                ->whereNull('customer_name')
                ->whereNull('company')
                ->whereNull('address1')
                ->where('assigned_rsm', $this->userId)
                ->whereDoesntHave('rfqs')
                ->whereDoesntHave('svr')->orderBy('id', 'desc');
            $num_rows = $lead->count();

            if ($isClient == 'true') {
                $lead->where('is_client', 1);
            }

            if ($enquiryDate) {
                $lead->where('enquiry_date', '>=', Carbon::createFromFormat('d/m/Y g:i A', $enquiryDate)->format('Y-m-d H:i:s'));
            }

            if ($fkRegionId) {
                $lead->where('fk_region_id', '=', $fkRegionId);
            }

            if ($customerName) {
                $lead->where('customer_name', 'like', '%' . $customerName . '%');
            }

            if ($company) {
                $lead->where('company', 'like', '%' . $company . '%');
            }

            if ($email) {
                $lead->where('email', 'like', '%' . $email . '%');
            }

            if ($contactNo) {
                $lead->where('contact_no', 'like', '%' . $contactNo . '%');
            }

            if ($fkSourceId) {
                $lead->where('fk_source_id', '=', $fkSourceId);
            }

            if ($SMOPlatform) {
                $lead->where('smo_platform', 'like', '%' . $SMOPlatform . '%');
            }

            if ($adwordsPlatform) {
                $lead->where('adwords_platform', 'like', '%' . $adwordsPlatform . '%');
            }

            if ($fkRsmrId) {
                $lead->where('fk_rsmr_id', '=', $fkRsmrId);
            }

            if ($fkRsmvId) {
                $lead->where('fk_rsmv_id', '=', $fkRsmvId);
            }

            if ($reference) {
                $lead->where('reference', 'like', '%' . $reference . '%');
            }

            $result = $lead->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Lead" . $isClient]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['enquiry_date'] = $enquiryDate;
            $this->response['data']['fk_region_id'] = $fkRegionId;
            $this->response['data']['customer_name'] = $customerName;
            $this->response['data']['company'] = $company;
            $this->response['data']['email'] = $email;
            $this->response['data']['contact_no'] = $contactNo;
            $this->response['data']['fk_source_id'] = $fkSourceId;
            $this->response['data']['smo_platform'] = $SMOPlatform;
            $this->response['data']['adwords_platform'] = $adwordsPlatform;
            $this->response['data']['fk_rsmr_id'] = $fkRsmrId;
            $this->response['data']['fk_rsmv_id'] = $fkRsmvId;
            $this->response['data']['reference'] = $reference;
            $this->response['data']['list'] = LeadResource::collection($result);
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Lead fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function potentialLead(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $enquiryDate = $request->enquiry_date ?? '';
            $fkRegionId = $request->fk_region_id ?? '';
            $customerName = $request->customer_name ?? '';
            $company = $request->company ?? '';
            $email = $request->email ?? '';
            $contactNo = $request->contact_no ?? '';
            $fkSourceId = $request->fk_source_id ?? '';
            $SMOPlatform = $request->smo_platform ?? '';
            $adwordsPlatform = $request->adwords_platform ?? '';
            $fkRsmrId = $request->fk_rsmr_id ?? '';
            $fkRsmvId = $request->fk_rsmv_id ?? '';
            $reference = $request->reference ?? '';
            $isClient = $request->is_client;

            $lead = Lead::with('region', 'source', 'rsmr', 'rsmv', 'designation', 'rfqCount', 'activityCount', 'svr', 'rfqs')->whereNotNull('contact_no')
                ->whereNotNull('email')
                ->whereNotNull('customer_name')
                ->whereNotNull('company')
                ->whereNotNull('address1')
                ->where('assigned_rsm', $this->userId)
                ->whereDoesntHave('rfqs')
                ->whereDoesntHave('svr')->orderBy('id', 'desc');
            $num_rows = $lead->count();

            if ($isClient == 'true') {
                $lead->where('is_client', 1);
            }

            if ($enquiryDate) {
                $lead->where('enquiry_date', '>=', Carbon::createFromFormat('d/m/Y g:i A', $enquiryDate)->format('Y-m-d H:i:s'));
            }

            if ($fkRegionId) {
                $lead->where('fk_region_id', '=', $fkRegionId);
            }

            if ($customerName) {
                $lead->where('customer_name', 'like', '%' . $customerName . '%');
            }

            if ($company) {
                $lead->where('company', 'like', '%' . $company . '%');
            }

            if ($email) {
                $lead->where('email', 'like', '%' . $email . '%');
            }

            if ($contactNo) {
                $lead->where('contact_no', 'like', '%' . $contactNo . '%');
            }

            if ($fkSourceId) {
                $lead->where('fk_source_id', '=', $fkSourceId);
            }

            if ($SMOPlatform) {
                $lead->where('smo_platform', 'like', '%' . $SMOPlatform . '%');
            }

            if ($adwordsPlatform) {
                $lead->where('adwords_platform', 'like', '%' . $adwordsPlatform . '%');
            }

            if ($fkRsmrId) {
                $lead->where('fk_rsmr_id', '=', $fkRsmrId);
            }

            if ($fkRsmvId) {
                $lead->where('fk_rsmv_id', '=', $fkRsmvId);
            }

            if ($reference) {
                $lead->where('reference', 'like', '%' . $reference . '%');
            }

            $result = $lead->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Lead" . $isClient]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['enquiry_date'] = $enquiryDate;
            $this->response['data']['fk_region_id'] = $fkRegionId;
            $this->response['data']['customer_name'] = $customerName;
            $this->response['data']['company'] = $company;
            $this->response['data']['email'] = $email;
            $this->response['data']['contact_no'] = $contactNo;
            $this->response['data']['fk_source_id'] = $fkSourceId;
            $this->response['data']['smo_platform'] = $SMOPlatform;
            $this->response['data']['adwords_platform'] = $adwordsPlatform;
            $this->response['data']['fk_rsmr_id'] = $fkRsmrId;
            $this->response['data']['fk_rsmv_id'] = $fkRsmvId;
            $this->response['data']['reference'] = $reference;
            $this->response['data']['list'] = LeadResource::collection($result);
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Lead fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function prospectLead(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $enquiryDate = $request->enquiry_date ?? '';
            $fkRegionId = $request->fk_region_id ?? '';
            $customerName = $request->customer_name ?? '';
            $company = $request->company ?? '';
            $email = $request->email ?? '';
            $contactNo = $request->contact_no ?? '';
            $fkSourceId = $request->fk_source_id ?? '';
            $SMOPlatform = $request->smo_platform ?? '';
            $adwordsPlatform = $request->adwords_platform ?? '';
            $fkRsmrId = $request->fk_rsmr_id ?? '';
            $fkRsmvId = $request->fk_rsmv_id ?? '';
            $reference = $request->reference ?? '';
            $isClient = $request->is_client;

            $lead = Lead::with('region', 'source', 'rsmr', 'rsmv', 'designation', 'rfqCount', 'activityCount', 'svr', 'rfqs')->whereNotNull('contact_no')
                ->whereNotNull('email')
                ->whereNotNull('customer_name')
                ->whereNotNull('company')
                ->whereNotNull('address1')
                ->where('assigned_rsm', $this->userId)
                ->whereHas('svr', function ($query) {
                    $query->whereNull('application_details');
                })
                ->whereDoesntHave('rfqs')->orderBy('id', 'desc');
            $num_rows = $lead->count();

            if ($isClient == 'true') {
                $lead->where('is_client', 1);
            }

            if ($enquiryDate) {
                $lead->where('enquiry_date', '>=', Carbon::createFromFormat('d/m/Y g:i A', $enquiryDate)->format('Y-m-d H:i:s'));
            }

            if ($fkRegionId) {
                $lead->where('fk_region_id', '=', $fkRegionId);
            }

            if ($customerName) {
                $lead->where('customer_name', 'like', '%' . $customerName . '%');
            }

            if ($company) {
                $lead->where('company', 'like', '%' . $company . '%');
            }

            if ($email) {
                $lead->where('email', 'like', '%' . $email . '%');
            }

            if ($contactNo) {
                $lead->where('contact_no', 'like', '%' . $contactNo . '%');
            }

            if ($fkSourceId) {
                $lead->where('fk_source_id', '=', $fkSourceId);
            }

            if ($SMOPlatform) {
                $lead->where('smo_platform', 'like', '%' . $SMOPlatform . '%');
            }

            if ($adwordsPlatform) {
                $lead->where('adwords_platform', 'like', '%' . $adwordsPlatform . '%');
            }

            if ($fkRsmrId) {
                $lead->where('fk_rsmr_id', '=', $fkRsmrId);
            }

            if ($fkRsmvId) {
                $lead->where('fk_rsmv_id', '=', $fkRsmvId);
            }

            if ($reference) {
                $lead->where('reference', 'like', '%' . $reference . '%');
            }

            $result = $lead->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Lead" . $isClient]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['enquiry_date'] = $enquiryDate;
            $this->response['data']['fk_region_id'] = $fkRegionId;
            $this->response['data']['customer_name'] = $customerName;
            $this->response['data']['company'] = $company;
            $this->response['data']['email'] = $email;
            $this->response['data']['contact_no'] = $contactNo;
            $this->response['data']['fk_source_id'] = $fkSourceId;
            $this->response['data']['smo_platform'] = $SMOPlatform;
            $this->response['data']['adwords_platform'] = $adwordsPlatform;
            $this->response['data']['fk_rsmr_id'] = $fkRsmrId;
            $this->response['data']['fk_rsmv_id'] = $fkRsmvId;
            $this->response['data']['reference'] = $reference;
            $this->response['data']['list'] = LeadResource::collection($result);
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Lead fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function qualifiedLead(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $enquiryDate = $request->enquiry_date ?? '';
            $fkRegionId = $request->fk_region_id ?? '';
            $customerName = $request->customer_name ?? '';
            $company = $request->company ?? '';
            $email = $request->email ?? '';
            $contactNo = $request->contact_no ?? '';
            $fkSourceId = $request->fk_source_id ?? '';
            $SMOPlatform = $request->smo_platform ?? '';
            $adwordsPlatform = $request->adwords_platform ?? '';
            $fkRsmrId = $request->fk_rsmr_id ?? '';
            $fkRsmvId = $request->fk_rsmv_id ?? '';
            $reference = $request->reference ?? '';
            $isClient = $request->is_client;

            $lead = Lead::with('region', 'source', 'rsmr', 'rsmv', 'designation', 'rfqCount', 'activityCount', 'svr', 'rfqs')->whereNotNull('contact_no')
                ->whereNotNull('email')
                ->whereNotNull('customer_name')
                ->whereNotNull('company')
                ->whereNotNull('address1')
                ->where('assigned_rsm', $this->userId)
                ->whereHas('svr', function ($query) {
                    $query->whereNotNull('application_details');
                })
                ->whereDoesntHave('rfqs')->orderBy('id', 'desc');
            $num_rows = $lead->count();

            if ($isClient == 'true') {
                $lead->where('is_client', 1);
            }

            if ($enquiryDate) {
                $lead->where('enquiry_date', '>=', Carbon::createFromFormat('d/m/Y g:i A', $enquiryDate)->format('Y-m-d H:i:s'));
            }

            if ($fkRegionId) {
                $lead->where('fk_region_id', '=', $fkRegionId);
            }

            if ($customerName) {
                $lead->where('customer_name', 'like', '%' . $customerName . '%');
            }

            if ($company) {
                $lead->where('company', 'like', '%' . $company . '%');
            }

            if ($email) {
                $lead->where('email', 'like', '%' . $email . '%');
            }

            if ($contactNo) {
                $lead->where('contact_no', 'like', '%' . $contactNo . '%');
            }

            if ($fkSourceId) {
                $lead->where('fk_source_id', '=', $fkSourceId);
            }

            if ($SMOPlatform) {
                $lead->where('smo_platform', 'like', '%' . $SMOPlatform . '%');
            }

            if ($adwordsPlatform) {
                $lead->where('adwords_platform', 'like', '%' . $adwordsPlatform . '%');
            }

            if ($fkRsmrId) {
                $lead->where('fk_rsmr_id', '=', $fkRsmrId);
            }

            if ($fkRsmvId) {
                $lead->where('fk_rsmv_id', '=', $fkRsmvId);
            }

            if ($reference) {
                $lead->where('reference', 'like', '%' . $reference . '%');
            }

            $result = $lead->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Lead" . $isClient]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['enquiry_date'] = $enquiryDate;
            $this->response['data']['fk_region_id'] = $fkRegionId;
            $this->response['data']['customer_name'] = $customerName;
            $this->response['data']['company'] = $company;
            $this->response['data']['email'] = $email;
            $this->response['data']['contact_no'] = $contactNo;
            $this->response['data']['fk_source_id'] = $fkSourceId;
            $this->response['data']['smo_platform'] = $SMOPlatform;
            $this->response['data']['adwords_platform'] = $adwordsPlatform;
            $this->response['data']['fk_rsmr_id'] = $fkRsmrId;
            $this->response['data']['fk_rsmv_id'] = $fkRsmvId;
            $this->response['data']['reference'] = $reference;
            $this->response['data']['list'] = LeadResource::collection($result);
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Lead fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function finalizedLead(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $enquiryDate = $request->enquiry_date ?? '';
            $fkRegionId = $request->fk_region_id ?? '';
            $customerName = $request->customer_name ?? '';
            $company = $request->company ?? '';
            $email = $request->email ?? '';
            $contactNo = $request->contact_no ?? '';
            $fkSourceId = $request->fk_source_id ?? '';
            $SMOPlatform = $request->smo_platform ?? '';
            $adwordsPlatform = $request->adwords_platform ?? '';
            $fkRsmrId = $request->fk_rsmr_id ?? '';
            $fkRsmvId = $request->fk_rsmv_id ?? '';
            $reference = $request->reference ?? '';
            $isClient = $request->is_client;

            $lead = Lead::with('region', 'source', 'rsmr', 'rsmv', 'designation', 'rfqCount', 'activityCount', 'svr', 'rfqs')->whereNotNull('contact_no')
                ->whereNotNull('email')
                ->whereNotNull('customer_name')
                ->whereNotNull('company')
                ->whereNotNull('address1')
                ->where('assigned_rsm', $this->userId)
                ->whereHas('svr', function ($query) {
                    $query->whereNotNull('application_details');
                })
                ->whereHas('rfqs')->orderBy('id', 'desc');
            $num_rows = $lead->count();

            if ($isClient == 'true') {
                $lead->where('is_client', 1);
            }

            if ($enquiryDate) {
                $lead->where('enquiry_date', '>=', Carbon::createFromFormat('d/m/Y g:i A', $enquiryDate)->format('Y-m-d H:i:s'));
            }

            if ($fkRegionId) {
                $lead->where('fk_region_id', '=', $fkRegionId);
            }

            if ($customerName) {
                $lead->where('customer_name', 'like', '%' . $customerName . '%');
            }

            if ($company) {
                $lead->where('company', 'like', '%' . $company . '%');
            }

            if ($email) {
                $lead->where('email', 'like', '%' . $email . '%');
            }

            if ($contactNo) {
                $lead->where('contact_no', 'like', '%' . $contactNo . '%');
            }

            if ($fkSourceId) {
                $lead->where('fk_source_id', '=', $fkSourceId);
            }

            if ($SMOPlatform) {
                $lead->where('smo_platform', 'like', '%' . $SMOPlatform . '%');
            }

            if ($adwordsPlatform) {
                $lead->where('adwords_platform', 'like', '%' . $adwordsPlatform . '%');
            }

            if ($fkRsmrId) {
                $lead->where('fk_rsmr_id', '=', $fkRsmrId);
            }

            if ($fkRsmvId) {
                $lead->where('fk_rsmv_id', '=', $fkRsmvId);
            }

            if ($reference) {
                $lead->where('reference', 'like', '%' . $reference . '%');
            }

            $result = $lead->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Lead" . $isClient]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['enquiry_date'] = $enquiryDate;
            $this->response['data']['fk_region_id'] = $fkRegionId;
            $this->response['data']['customer_name'] = $customerName;
            $this->response['data']['company'] = $company;
            $this->response['data']['email'] = $email;
            $this->response['data']['contact_no'] = $contactNo;
            $this->response['data']['fk_source_id'] = $fkSourceId;
            $this->response['data']['smo_platform'] = $SMOPlatform;
            $this->response['data']['adwords_platform'] = $adwordsPlatform;
            $this->response['data']['fk_rsmr_id'] = $fkRsmrId;
            $this->response['data']['fk_rsmv_id'] = $fkRsmvId;
            $this->response['data']['reference'] = $reference;
            $this->response['data']['list'] = LeadResource::collection($result);
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Lead fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function leadDash(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $enquiryDate = $request->enquiry_date ?? '';
            $fkRegionId = $request->fk_region_id ?? '';
            $customerName = $request->customer_name ?? '';
            $company = $request->company ?? '';
            $email = $request->email ?? '';
            $contactNo = $request->contact_no ?? '';
            $fkSourceId = $request->fk_source_id ?? '';
            $SMOPlatform = $request->smo_platform ?? '';
            $adwordsPlatform = $request->adwords_platform ?? '';
            $fkRsmrId = $request->fk_rsmr_id ?? '';
            $fkRsmvId = $request->fk_rsmv_id ?? '';
            $reference = $request->reference ?? '';
            $isClient = $request->is_client;

            $lead = Lead::with('region', 'source', 'rsmr', 'rsmv', 'designation', 'rfqCount', 'activityCount')->where('assigned_rsm', $this->userId)->orderBy('id', 'desc');
            $num_rows = $lead->count();

            if ($isClient == 'true') {
                $lead->where('is_client', 1);
            }

            if ($enquiryDate) {
                $lead->where('enquiry_date', '>=', Carbon::createFromFormat('d/m/Y g:i A', $enquiryDate)->format('Y-m-d H:i:s'));
            }

            if ($fkRegionId) {
                $lead->where('fk_region_id', '=', $fkRegionId);
            }

            if ($customerName) {
                $lead->where('customer_name', 'like', '%' . $customerName . '%');
            }

            if ($company) {
                $lead->where('company', 'like', '%' . $company . '%');
            }

            if ($email) {
                $lead->where('email', 'like', '%' . $email . '%');
            }

            if ($contactNo) {
                $lead->where('contact_no', 'like', '%' . $contactNo . '%');
            }

            if ($fkSourceId) {
                $lead->where('fk_source_id', '=', $fkSourceId);
            }

            if ($SMOPlatform) {
                $lead->where('smo_platform', 'like', '%' . $SMOPlatform . '%');
            }

            if ($adwordsPlatform) {
                $lead->where('adwords_platform', 'like', '%' . $adwordsPlatform . '%');
            }

            if ($fkRsmrId) {
                $lead->where('fk_rsmr_id', '=', $fkRsmrId);
            }

            if ($fkRsmvId) {
                $lead->where('fk_rsmv_id', '=', $fkRsmvId);
            }

            if ($reference) {
                $lead->where('reference', 'like', '%' . $reference . '%');
            }

            $result = $lead->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Lead" . $isClient]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['enquiry_date'] = $enquiryDate;
            $this->response['data']['fk_region_id'] = $fkRegionId;
            $this->response['data']['customer_name'] = $customerName;
            $this->response['data']['company'] = $company;
            $this->response['data']['email'] = $email;
            $this->response['data']['contact_no'] = $contactNo;
            $this->response['data']['fk_source_id'] = $fkSourceId;
            $this->response['data']['smo_platform'] = $SMOPlatform;
            $this->response['data']['adwords_platform'] = $adwordsPlatform;
            $this->response['data']['fk_rsmr_id'] = $fkRsmrId;
            $this->response['data']['fk_rsmv_id'] = $fkRsmvId;
            $this->response['data']['reference'] = $reference;
            $this->response['data']['list'] = LeadResource::collection($result);
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Lead fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function addUpdate(REQUEST $request)
    {
        try {
            DB::beginTransaction();

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateLead($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $taxPayerType = null;
            $taxDuration = null;

            if (!empty($request->gstin)) {
                $gstLog = GstApiLog::where('request_payload->gst', 'LIKE', '%' . $request->gstin . '%')->latest()->first();
                if ($gstLog && $gstLog->response) {
                    $gstDecode = json_decode($gstLog->response, true);
                    $taxPayerType = $gstDecode['data']['dty'];
                }
                $taxDuration = null;
            }

            if (!empty($request->gstin)) {
                $gstLog = GstApiLog::where('request_payload->gst', 'LIKE', '%' . $request->gstin . '%')->latest()->first();

                if ($gstLog && !empty($gstLog->response)) {
                    $gstDecode = json_decode($gstLog->response, true);

                    if (isset($gstDecode['data']) && isset($gstDecode['data']['dty'])) {
                        $taxPayerType = $gstDecode['data']['dty'];
                    } else {
                        $this->response['error'] = 'Invalid GST number. Please enter a valid GSTIN.';
                        return $this->sendResponse($this->response, 200);
                    }
                }

                // else {

                //     $this->response['error'] = 'GST number not found in records. Please verify and try again.';
                //     return $this->sendResponse($this->response, 200);
                // }

                $taxDuration = null;
            }

            $addresses = $request->addresses ?? [];

            $leadObject = new Lead();
            $id = $request->id;
            $enquiryDate = Carbon::createFromFormat('d/m/Y', $request->enquiry_date)->format('Y-m-d H:i:s');
            $fkRegionId = $request->fk_region_id;
            $divisionId = $request->division_id ?? null;
            $isExport = $request->is_export ?? null;
            $countryId = $request->country_id ?? null;
            $gstin = $request->gstin;
            $company = $request->company;
            $defaultAddressId = $request->default_address_id ?? NULL;
            $defaultContactPersonId = $request->default_contact_person_id ?? NULL;
            $address1 = $request->address1 ?? NULL;
            $address2 = $request->address2;
            $city = $request->city;
            $pincode = $request->pincode;
            $state = $request->state;
            $isShippingSame = $request->is_shipping_same;
            $shippingAddress1 = $request->shipping_address1;
            $shippingAddress2 = $request->shipping_address2;
            $shippingCity = $request->shipping_city;
            $shippingPincode = $request->shipping_pincode;
            $shippingState = $request->shipping_state;
            $application = $request->application;
            $description = $request->description;
            $fkDesignationId = $request->fk_designation_id ?? 0;
            $monogram = $request->monogram;
            $customerName = $request->customer_name;
            $designations = $request->designations ?? [];
            $email = $request->email;
            $altEmailOne = $request->alt_email_one;
            $altEmailTwo = $request->alt_email_two;
            $contactNo = $request->contact_no;
            $altContactOne = $request->alt_contact_one;
            $altContactTwo = $request->alt_contact_two;
            $fkSourceId = $request->fk_source_id;
            $smoPlatform = $request->smo_platform;
            $adwordsPlatform = $request->adwords_platform;
            $fkRsmrId = $request->fk_rsmr_id ?? 0;
            $fkRsmvId = $request->fk_rsmv_id ?? 0;
            $reference = $request->reference;
            $status = 1;

            if (!empty($gstin)) {
                $existingLead = Lead::where('gstin', $gstin)->where('id', '!=', $id)->first();

                if ($existingLead) {
                    $this->response = ['errors' => ['gstin' => 'GSTIN already exist']];
                    return $this->sendResponse($this->response, 200);
                }
            }

            if ($id) {
                $leadObject = Lead::find($id);

                if (!$leadObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Lead"]);
                    return $this->sendResponse($this->response, 200);
                }
                $leadObject->first();
                $leadObject->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "Lead"]);
            } else {
                $leadObject->latitude = $request->header('x-user-latitude') ?? '';
                $leadObject->longitude = $request->header('x-user-longitude') ?? '';
                $formattedAddress = getFormattedAddress($leadObject->latitude, $leadObject->longitude);
                $leadObject->formatted_address = $formattedAddress ?? '';
                $leadObject->platform_type = 'web';

                $leadObject->created_by = $this->userId;
                $this->response['msg'] = __('admin.created', ['module' => "Lead"]);
            }


            $leadObject->enquiry_date = $enquiryDate;
            $leadObject->fk_region_id = $fkRegionId;
            $leadObject->division_id = $divisionId;
            $leadObject->is_export = $isExport;
            $leadObject->country_id = $countryId;
            $leadObject->gstin = $gstin;
            $leadObject->tax_payer_type = $taxPayerType;
            $leadObject->tax_duration = $taxDuration;
            $leadObject->customer_name = $customerName;
            $leadObject->company = $company;
            // $leadObject->address1 = $address1;
            // $leadObject->address2 = $address2;
            // $leadObject->city = $city;
            // $leadObject->pincode = $pincode;
            // $leadObject->state = $state;
            $leadObject->is_shipping_same = $isShippingSame;
            if ($isShippingSame == 1) {
                $leadObject->shipping_address1 = $address1;
                $leadObject->shipping_address2 = $address2;
                $leadObject->shipping_pincode = $pincode;
                $leadObject->shipping_city = $city;
                $leadObject->shipping_state = $state;
            } else {
                $leadObject->shipping_address1 = $shippingAddress1;
                $leadObject->shipping_address2 = $shippingAddress2;
                $leadObject->shipping_pincode = $shippingPincode;
                $leadObject->shipping_city = $shippingCity;
                $leadObject->shipping_state = $shippingState;
            }
            $leadObject->application = $application;
            $leadObject->description = $description;
            $leadObject->fk_designation_id = $fkDesignationId;
            $leadObject->designations = $designations;
            $leadObject->email = $email;
            $leadObject->alt_email_one = $altEmailOne;
            $leadObject->alt_email_two = $altEmailTwo;
            $leadObject->alt_contact_one = $altContactOne;
            $leadObject->alt_contact_two = $altContactTwo;
            $leadObject->contact_no = $contactNo;
            $leadObject->monogram = $monogram;
            $leadObject->fk_source_id = $fkSourceId;
            $leadObject->smo_platform = $smoPlatform;
            $leadObject->adwords_platform = $adwordsPlatform;
            $leadObject->fk_rsmr_id = $fkRsmrId;
            $leadObject->fk_rsmv_id = $fkRsmvId;
            $leadObject->reference = $reference;
            $leadObject->status = $status;

            $hasEmailOrContact = false;
            $hasApplication = !empty($application);

            foreach ($addresses as $address) {
                if (!empty($address['contact_person'])) {
                    foreach ($address['contact_person'] as $contact) {
                        if (!empty($contact['email']) || !empty($contact['contact_no'])) {
                            $hasEmailOrContact = true;
                            break 2;
                        }
                    }
                }
            }

            if (!$hasEmailOrContact) {
                $leadObject->lead_stage_id = LeadStage::RAWLEAD->value;
            } elseif ($hasEmailOrContact && $hasApplication) {
                $leadObject->lead_stage_id = LeadStage::QUALIFIEDLEAD->value;
            } elseif ($hasEmailOrContact) {
                $leadObject->lead_stage_id = LeadStage::POTENTIALLEAD->value;
            }


            // if (empty($addresses[0]['contact_person'][0]['email']) && empty($addresses[0]['contact_person'][0]['contact_no'])) {
            //     $leadObject->lead_stage_id = LeadStage::RAWLEAD->value;
            // } elseif (!empty($addresses[0]['contact_person'][0]['email']) || !empty($addresses[0]['contact_person'][0]['conatct_no']) && !empty($application)) {
            //     $leadObject->lead_stage_id = LeadStage::QUALIFIEDLEAD->value;
            // } elseif (!empty($addresses[0]['contact_person'][0]['email']) || !empty($addresses[0]['contact_person'][0]['contact_no'])) {
            //     $leadObject->lead_stage_id = LeadStage::POTENTIALLEAD->value;
            // }


            if ($this->isUserRSM) {
                $leadObject->assigned_rsm = $this->userId;
            }
            $leadObject->save();
            $lastLeadId = $leadObject->id;

            $addressesIds = array_column($addresses, 'id');
            $contactPersons = array_column($addresses, 'contact_person');
            $flattenedContactPersons = array_merge(...$contactPersons);
            $contactPersonIds = array_column($flattenedContactPersons, 'id');


            LeadAddresses::where('lead_id', $lastLeadId)->whereNotIn('id', $addressesIds)->delete();
            LeadContactPeople::where('lead_id', $lastLeadId)->whereNotIn('id', $contactPersonIds)->delete();

            if (!empty($addresses) && !empty($addresses[0]['address1'])) {
                foreach ($addresses as $key => $addressData) {
                    // Check if leadAddress ID exists, update or create a new record accordingly
                    if (!empty($addressData['id'])) {
                        $leadAddress = LeadAddresses::find($addressData['id']);
                    } else {
                        $leadAddress = new LeadAddresses();
                        $leadAddress->lead_id = $lastLeadId;
                    }
                    $leadAddress->is_default = $addressData['is_default'];
                    $leadAddress->address1 = $addressData['address1'] ?? '';
                    $leadAddress->address2 = $addressData['address2'] ?? '';
                    $leadAddress->pincode = $addressData['pincode'] ?? '';
                    $leadAddress->city = $addressData['city'] ?? '';
                    $leadAddress->state = $addressData['state'] ?? '';
                    $leadAddress->is_shipping_same = $addressData['is_shipping_same'];
                    if ($addressData['is_shipping_same'] == 1) {
                        $leadAddress->shipping_address1 = $addressData['address1'] ?? '';
                        $leadAddress->shipping_address2 = $addressData['address2'] ?? '';
                        $leadAddress->shipping_pincode = $addressData['pincode'] ?? '';
                        $leadAddress->shipping_city = $addressData['city'] ?? '';
                        $leadAddress->shipping_state = $addressData['state'] ?? '';
                    } else {
                        $leadAddress->shipping_address1 = $addressData['shipping_address1'] ?? '';
                        $leadAddress->shipping_address2 = $addressData['shipping_address2'] ?? '';
                        $leadAddress->shipping_pincode = $addressData['shipping_pincode'] ?? '';
                        $leadAddress->shipping_city = $addressData['shipping_city'] ?? '';
                        $leadAddress->shipping_state = $addressData['shipping_state'] ?? '';
                    }

                    $leadAddress->save();
                    $lastLeadAddId = $leadAddress->id;

                    if ($addressData['is_default'] == 1) {
                        $addressVal = [
                            'address1' => $addressData['address1'],
                            'address2' => $addressData['address2'],
                            'pincode' => $addressData['pincode'],
                            'city' => $addressData['city'],
                            'state' => $addressData['state'],
                        ];

                        Lead::where('id', $lastLeadId)->update($addressVal); // save this address to lead table
                    }

                    // Check if contact person ID exists, update or create a new record accordingly
                    if (!empty($addressData['contact_person']) && is_array($addressData['contact_person'])) {

                        foreach ($addressData['contact_person'] as $key => $contactData) {
                            if (!empty($contactData['customer_name'])) {
                                if (!empty($contactData['id'])) {
                                    $leadContactPerson = LeadContactPeople::find($contactData['id']);
                                } else {
                                    $leadContactPerson = new LeadContactPeople();
                                }
                                $leadContactPerson->lead_id = $lastLeadId;
                                $leadContactPerson->lead_address_id = $lastLeadAddId;

                                // Handle designations as an array
                                if (is_string($contactData['designations'])) {
                                    $designations = json_decode($contactData['designations'], true);
                                } else {
                                    $designations = $contactData['designations'];
                                }
                                $leadContactPerson->designations = $designations;
                                $leadContactPerson->monogram = $contactData['monogram'] ?? '';
                                $leadContactPerson->customer_name = $contactData['customer_name'] ?? '';
                                $leadContactPerson->email = $contactData['email'] ?? '';
                                $leadContactPerson->contact_no = $contactData['contact_no'] ?? '';
                                $leadContactPerson->alt_email_one = $contactData['alt_email_one'] ?? '';
                                $leadContactPerson->alt_email_two = $contactData['alt_email_two'] ?? '';
                                $leadContactPerson->alt_contact_one = $contactData['alt_contact_one'] ?? '';
                                $leadContactPerson->alt_contact_two = $contactData['alt_contact_two'] ?? '';
                                $leadContactPerson->save();

                                if ($addressData['is_default'] == 1 && $key == 0) {
                                    // save this contact to lead table
                                    $leadContactVal = [
                                        'designation' => $designations,
                                        'monogram' => $contactData['monogram'],
                                        'customer_name' => $contactData['customer_name'],
                                        'email' => $contactData['email'],
                                        'contact_no' => $contactData['contact_no'],
                                        'alt_email_one' => $contactData['alt_email_one'],
                                        'alt_email_two' => $contactData['alt_email_two'],
                                        'alt_contact_one' => $contactData['alt_contact_one'],
                                        'alt_contact_two' => $contactData['alt_contact_two'],
                                    ];

                                    Lead::where('id', $lastLeadId)->update($leadContactVal);
                                }

                                // Debugging
                                Log::debug('Designations saved: ' . json_encode($leadContactPerson->designations));
                            }
                        }
                    }
                }
            }


            $this->response['status'] = 1;
            $this->response['last_lead_id'] = $lastLeadId;
            DB::commit();
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating Lead: " . $e);
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            Log::error("Record Not Found: " . $e);
            $this->response['error'] = __('admin.record_not_found', ['module' => "Lead"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    public function updateCreditLimit(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateUpdateCreditLimit($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $id = $request->id;
            $leadObject = Lead::find($id);

            if (!$leadObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Lead"]);
                return $this->sendResponse($this->response, 200);
            }
            $credit_limit = $request->credit_limit ?? 0;

            $leadObject->credit_limit = $credit_limit;
            $leadObject->save();

            $leadObject->action = 'updated';

            CreditLimitLogCreated::dispatch($leadObject);

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.updated', ['module' => "Credit Limit"]);

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed Updateing Credit Limit: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Lead"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $lead = Lead::with('region', 'source', 'rsmr', 'rfq', 'rsmv', 'assignedRsm', 'country:id,name', 'leadStage')->find($id);
            $mobile = $lead->contact_no ?? '';
            $email = $lead->email ?? '';

            if (!$lead) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Lead"]);
                return $this->sendResponse($this->response, 500);
            }

            $SMSData = SmsData::with('campaign');

            if ($email) {
                $SMSData->where('email', 'like', '%' . $email . '%');
            }

            if ($mobile) {
                $SMSData->orWhere('mobile', 'like', '%' . $mobile . '%');
            }

            $leadInSMSCampaign = $SMSData->groupBy('fk_sms_campaign_id')->get();


            $EmailData = EmailData::with('campaign');

            if ($email) {
                $EmailData->where('email', 'like', '%' . $email . '%');
            }

            if ($mobile) {
                $EmailData->orWhere('mobile', 'like', '%' . $mobile . '%');
            }

            $leadInEmailCampaign = $EmailData->groupBy('fk_email_campaign_id')->get();


            $SFCEmailData = SfcEmailData::with('campaign');

            if ($email) {
                $SFCEmailData->where('email', 'like', '%' . $email . '%');
            }

            if ($mobile) {
                $SFCEmailData->orWhere('mobile', 'like', '%' . $mobile . '%');
            }

            $leadInSFCEmailCampaign = $SFCEmailData->groupBy('fk_sfc_email_campaign_id')->get();


            $bookPostData = BookpostData::with('campaign');

            if ($email) {
                $bookPostData->where('email', 'like', '%' . $email . '%');
            }

            if ($mobile) {
                $bookPostData->orWhere('mobile', 'like', '%' . $mobile . '%');
            }

            $leadInBookpostCampaign = $bookPostData->groupBy('fk_bookpost_campaign_id')->get();



            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Lead"]);
            $this->response['data'] = new LeadResource($lead);
            $this->response['leadInSMSCampaign'] = DataCampaignResource::collection($leadInSMSCampaign);
            $this->response['leadInEmailCampaign'] = DataCampaignResource::collection($leadInEmailCampaign);
            $this->response['leadInSFCEmailCampaign'] = DataCampaignResource::collection($leadInSFCEmailCampaign);
            $this->response['leadInBookpostCampaign'] = DataCampaignResource::collection($leadInBookpostCampaign);

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Lead fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function leadInCampaigns(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $mobile = $request->contact_no ?? '';
            $email = $request->email ?? '';

            $SMSData = SmsData::with('campaign');

            if ($email) {
                $SMSData->where('email', 'like', '%' . $email . '%');
            }

            if ($mobile) {
                $SMSData->orWhere('mobile', 'like', '%' . $mobile . '%');
            }

            $leadInSMSCampaign = $SMSData->groupBy('fk_sms_campaign_id')->get();


            $EmailData = EmailData::with('campaign');

            if ($email) {
                $EmailData->where('email', 'like', '%' . $email . '%');
            }

            if ($mobile) {
                $EmailData->orWhere('mobile', 'like', '%' . $mobile . '%');
            }

            $leadInEmailCampaign = $EmailData->groupBy('fk_email_campaign_id')->get();


            $SFCEmailData = SfcEmailData::with('campaign');

            if ($email) {
                $SFCEmailData->where('email', 'like', '%' . $email . '%');
            }

            if ($mobile) {
                $SFCEmailData->orWhere('mobile', 'like', '%' . $mobile . '%');
            }

            $leadInSFCEmailCampaign = $SFCEmailData->groupBy('fk_sfc_email_campaign_id')->get();


            $bookPostData = BookpostData::with('campaign');

            if ($email) {
                $bookPostData->where('email', 'like', '%' . $email . '%');
            }

            if ($mobile) {
                $bookPostData->orWhere('mobile', 'like', '%' . $mobile . '%');
            }

            $leadInBookpostCampaign = $bookPostData->groupBy('fk_bookpost_campaign_id')->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Lead In Campaign"]);
            $this->response['leadInSMSCampaign'] = DataCampaignResource::collection($leadInSMSCampaign);
            $this->response['leadInEmailCampaign'] = DataCampaignResource::collection($leadInEmailCampaign);
            $this->response['leadInSFCEmailCampaign'] = DataCampaignResource::collection($leadInSFCEmailCampaign);
            $this->response['leadInBookpostCampaign'] = DataCampaignResource::collection($leadInBookpostCampaign);
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Lead In Campaign fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getMonogram(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Monogram"]);
            $this->response['data']['list'] = Monogram::getListForHTML();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Monogram fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $leadObject = Lead::find($id);

            if (!$leadObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Lead"]);
                return $this->sendResponse($this->response, 401);
            }

            $leadObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Lead"]);
            $this->response['data'] = $leadObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Lead deleting failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }


    public function importLead(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $files = $request->excel ?? [];

            $highestRow = 0;
            foreach ($files as $item) {

                $filePath = storage_path('app/public/uploads/temp/' . $item['filename']);
                $sourcePath = 'public/uploads/temp/' .  $item['filename'];

                if (!Storage::exists($sourcePath)) {

                    $this->response['error'] = __('admin.file_not_found', ['file' => $item['filename']]);
                    return $this->sendResponse($this->response, 401);
                }

                $spreadsheet = IOFactory::load($filePath);
                $sheetNames = $spreadsheet->getSheetNames();
                $dataRecords = [];

                foreach ($sheetNames as $sheetName) {
                    $worksheet = $spreadsheet->getSheetByName($sheetName);
                    $cellIterator = $worksheet->getRowIterator()->current()->getCellIterator();
                    $cellIterator->setIterateOnlyExistingCells(true);

                    $headers = [];
                    foreach ($cellIterator as $cell) {
                        if ($cell->getValue() != '') {
                            $headers[] = $cell->getValue();
                        }
                    }

                    if (array_values($headers) != array_values(config('global.LEAD_HEADER_FORMAT'))) {
                        $this->response['error'] = __('admin.excel_format_error', ['file' => $item['filename'], 'sheet' => $sheetName]);
                        return $this->sendResponse($this->response, 200);
                    }

                    // $highestRow = $worksheet->getHighestRow();
                    $highestRow = max($highestRow, $worksheet->getHighestRow());
                    $dataRecords = [];

                    for ($row = 2; $row <= $highestRow; $row++) {
                        $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
                        if (!empty(array_filter($rowData[$row]))) {
                            $dataRecords[] = $rowData[$row];
                        }
                    }
                }

                foreach ($dataRecords as $data) {

                    if (isset($data['A']) && !empty($data['A'])) {
                        $region = $data['A'];
                        $regionId = Region::where(DB::raw('LOWER(name)'), strtolower($region))->value('id');
                    }

                    if (isset($data['B']) && !empty($data['B'])) {
                        $enquiryDate = Carbon::createFromFormat('d/m/Y g:i A', $data['B'])->format('Y-m-d H:i:s');
                    }

                    if (isset($data['C']) && !empty($data['C'])) {
                        $customerName = $data['C'];
                    }

                    if (isset($data['D']) && !empty($data['D'])) {
                        $company = $data['D'];
                    }

                    if (isset($data['E']) && !empty($data['E'])) {
                        $address1 = convertToCamelCase($data['E']);
                    }

                    if (isset($data['F']) && !empty($data['F'])) {
                        $address2 = convertToCamelCase($data['F']);
                    }

                    if (isset($data['G']) && !empty($data['G'])) {
                        $city = convertToCamelCase($data['G']);
                    }

                    if (isset($data['H']) && !empty($data['H'])) {
                        $pincode = convertToCamelCase($data['H']);
                    }

                    if (isset($data['I']) && !empty($data['I'])) {
                        $state = convertToCamelCase($data['I']);
                    }

                    if (isset($data['J']) && !empty($data['J'])) {
                        $application = convertToCamelCase($data['J']);
                    }

                    if (isset($data['K']) && !empty($data['K'])) {
                        $description = convertToCamelCase($data['K']);
                    }

                    if (isset($data['L']) && !empty($data['L'])) {
                        $designation = $data['L'];
                        $designationId = Designation::where(DB::raw('LOWER(title)'), strtolower($designation))->value('id');
                    }

                    if (isset($data['M']) && !empty($data['M'])) {
                        $email = $data['M'];
                    }

                    if (isset($data['N']) && !empty($data['N'])) {
                        $contactNo = $data['N'];
                    }

                    if (isset($data['P']) && !empty($data['P'])) {
                        $SMOPlatform = $data['P'];
                    }

                    if (isset($data['K']) && !empty($data['K'])) {
                        $description = convertToCamelCase($data['K']);
                    }

                    if (isset($data['O']) && !empty($data['O'])) {
                        $source = $data['O'];
                        $sourceId = Source::where(DB::raw('LOWER(name)'), strtolower($source))->value('id');
                    }

                    if (isset($data['R']) && !empty($data['R'])) {
                        $RSM = $data['R'];
                        $RSMId = User::where(DB::raw('LOWER(name)'), strtolower($RSM))->value('id');
                    }

                    if (isset($data['S']) && !empty($data['S'])) {
                        $RSV = $data['S'];
                        $RSVId = User::where(DB::raw('LOWER(name)'), strtolower($RSV))->value('id');
                    }

                    if (isset($data['Q']) && !empty($data['Q'])) {
                        $adwordsPlatform = convertToCamelCase($data['Q']);
                    }

                    if (isset($data['T']) && !empty($data['T'])) {
                        $reference = convertToCamelCase($data['T']);
                    }


                    Lead::create([
                        'fk_region_id' => $regionId,
                        'enquiry_date' => $enquiryDate,
                        'customer_name' => $customerName,
                        'company' => $company,
                        'address1' => $address1,
                        'address2' => $address2,
                        'city' => $city,
                        'pincode' => $pincode,
                        'state' => $state,
                        'application' => $application,
                        'description' => $description,
                        'fk_designation_id' => $designationId,
                        'email' => $email,
                        'contact_no' => $contactNo,
                        'fk_source_id' => $sourceId,
                        'smo_platform' => $SMOPlatform,
                        'adwords_platform' => $adwordsPlatform,
                        'fk_rsmr_id' => $RSMId,
                        'fk_rsmv_id' => $RSVId,
                        'reference' => $reference,
                    ]);
                }

                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.created', ['module' => "Lead Data"]);
                return $this->sendResponse($this->response, 200);
            }
        } catch (Exception $e) {
            Log::error("Failed Creating Excel Lead Data: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function assignRsm(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAssignRsm($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $leadObject = new Lead();
            $id = $request->id;
            $assignedRsm = $request->assigned_rsm;

            if ($id) {

                $leadObject = Lead::find($id);

                if (!$leadObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Lead"]);
                    return $this->sendResponse($this->response, 200);
                }

                $userObject = User::find($assignedRsm);

                if (!$userObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "User"]);
                    return $this->sendResponse($this->response, 200);
                }

                $leadObject->assigned_rsm = $assignedRsm;
                $this->response['msg'] = 'RSM Assign Successfully';
            }

            $leadObject->save();

            $this->response['status'] = 1;
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed Assigning RSM: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Lead"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getPincodeDetails(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $pincode = $request->pincode ?? '';

            if (empty($pincode)) {
                $this->response['error'] = 'Pincode is required';
                return $this->sendResponse($this->response, 500);
            }

            $apiKey = 'AIzaSyCGx_Fl0yKDXwvqekOgYiU78Th3MAWzOxE';
            $url = "https://maps.googleapis.com/maps/api/geocode/json?key={$apiKey}&address={$pincode}";

            $client = new Client(['verify' => false]);
            $response = $client->get($url);

            $statusCode = $response->getStatusCode();
            $data = $response->getBody()->getContents();

            if ($statusCode == 200) {
                $data = json_decode($data, TRUE);

                if (isset($data['results']) && !empty($data['results'])) {
                    $result = $data['results'][0];

                    $pincodeData = [
                        'address' => $result['formatted_address'],
                        'city' => null,
                        'state' => null,
                    ];

                    foreach ($result['address_components'] as $component) {
                        if (in_array('locality', $component['types'])) {
                            $pincodeData['city'] = $component['long_name'];
                        }

                        if (in_array('administrative_area_level_1', $component['types'])) {
                            $pincodeData['state'] = $component['long_name'];
                        }
                    }

                    $this->response['status'] = 1;
                    $this->response['data'] = $pincodeData;
                    return $this->sendResponse($this->response, 200);
                }
            }
        } catch (Exception $e) {
            Log::error("Failed to retrieve data from Google Maps API: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Lead"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getGstDetails(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $gst = $request->gst ?? '';

            if (!empty($gst)) {
                if (!preg_match('/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/', $gst)) {
                    $this->response['error'] = 'Invalid GST number format';
                    return $this->sendResponse($this->response, 200);
                }
            }

            // $apiKey = '574560ca751807a090be84576442ac0b';
            // $url = "http://sheet.gstincheck.co.in/check/{$apiKey}/{$gst}";

            // $client = new Client();
            // $response = $client->get($url);

            // $statusCode = $response->getStatusCode();
            // $data = $response->getBody()->getContents();

            $statusCode = 200;
            $data = '{
        "flag": true,
        "message": "GSTIN  found.",
        "data": {
          "ntcrbs": "SPO",
          "adhrVFlag": "No",
          "lgnm": "CENTRAL WAREHOUSING CORPORATION",
          "stj": "State - Gujarat,Division - Division - 1,Range - Range - 3,Unit - Ghatak 10 (Ahmedabad) (Jurisdictional Office)",
          "dty": "Regular",
          "cxdt": "",
          "gstin": "24AAACC1206D1ZM",
          "nba": [
            "Bonded Warehouse",
            "Service Provision",
            "Recipient of Goods or Services",
            "Warehouse / Depot",
            "Input Service Distributor (ISD)"
          ],
          "ekycVFlag": "No",
          "cmpRt": "NA",
          "rgdt": "01/07/2017",
          "ctb": "CORPORATION",
          "pradr": {
            "adr": "CENTRAL WAREHOUSING CORPORATION, MAHALAXMI CHAR RASTA, PALDI, Ahmedabad, Gujarat, 380007",
            "addr": {
              "flno": "",
              "lg": "",
              "loc": "PALDI",
              "pncd": "380007",
              "bnm": "CENTRAL WAREHOUSING CORPORATION",
              "city": "",
              "lt": "",
              "stcd": "Gujarat",
              "bno": "0",
              "dst": "Ahmedabad",
              "st": "MAHALAXMI CHAR RASTA"
            }
          },
          "sts": "Active",
          "tradeNam": "CENTRAL WARE HOUSING CORP.LTD.",
          "isFieldVisitConducted": "Yes",
          "ctj": "State - CBIC,Zone - AHMEDABAD,Commissionerate - AHMEDABAD SOUTH,Division - DIVISION-VII - SATELLITE,Range - RANGE V",
          "einvoiceStatus": "Yes",
          "lstupdt": "",
          "adadr": [],
          "ctjCd": "",
          "errorMsg": null,
          "stjCd": ""
        }
      }';

            if ($statusCode == 200) {
                $responseData = json_decode($data, true);

                if (isset($responseData['flag']) && $responseData['flag'] === false) {
                    $message = isset($responseData['message']) ? $responseData['message'] : 'GST Number not found';
                    $this->response['error'] = $message;
                    return $this->sendResponse($this->response, 200);
                }

                $companyInfo = [
                    'gstin' => null,
                    'company_name' => null,
                    'address' => null,
                ];

                if (isset($responseData['data']['gstin'])) {
                    $companyInfo['gstin'] = $responseData['data']['gstin'];
                }

                if (isset($responseData['data']['pradr']['addr']['bnm'])) {
                    $companyInfo['company_name'] = $responseData['data']['pradr']['addr']['bnm'];
                }
                if (isset($responseData['data']['pradr']['adr'])) {
                    $address = $responseData['data']['pradr']['adr'];
                    $companyInfo['address'] = $address;
                }

                $msg = isset($responseData['message']) ? $responseData['message'] : 'GSTIN found.';

                $this->response['status'] = 1;
                $this->response['msg'] = $msg;
                $this->response['data'] = $companyInfo;
                return $this->sendResponse($this->response, 200);
            } else {
                $this->response['error'] = 'Failed to retrieve GST details';
                return $this->sendResponse($this->response, 200);
            }
        } catch (Exception $e) {
            Log::error("Failed to retrieve GST details: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Lead"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getLeadDetail(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $gst = $request->gst ?? '';
            $company = substr(trim($request->company ?? ''), 0, 4);

            $gstLead = null;
            $companyLeads = null;

            if (empty($gst) && empty($company)) {
                $this->response['error'] = 'Please provide either GST or company name.';
                return $this->sendResponse($this->response, 200);
            }

            if ($gst) {
                $gstLead = Lead::where('status', 1)->where('gstin', $gst)->first();
                if (!$gstLead) {
                    $this->response['error'] = 'No lead found with the provided GST.';
                }
            }

            if ($company) {
                $companyLeads = Lead::where('status', 1)->where('company', 'like', $company . '%')->get();
                if ($companyLeads->isEmpty()) {
                    $companyLeads = null;
                    $this->response['error'] = 'No leads found with the provided company name.';
                }
            }

            $this->response['status'] = 1;
            $this->response['data']['gst'] = $gstLead;
            $this->response['data']['company'] = $companyLeads;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addAddressModal(Request $request)
    {
        try {
            DB::beginTransaction();

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $address1 = $request->address1 ?? '';
            $address2 = $request->address2 ?? '';
            $pincode = $request->pincode ?? '';
            $city = $request->city ?? '';
            $state = $request->state ?? '';
            $isShippingSame = $request->is_shipping_same ?? '';
            $name = $request->customer_name ?? '';
            $contactNo = $request->contactNo ?? '';
            $email = $request->email ?? '';

            // shipping address based on is_shipping_same flag
            if ($isShippingSame == 1) {
                $shippingAddress1 = $address1;
                $shippingAddress2 = $address2;
                $shippingPincode = $pincode;
                $shippingCity = $city;
                $shippingState = $state;
            } else {
                $shippingAddress1 = $request->shipping_address1 ?? '';
                $shippingAddress2 = $request->shipping_address2 ?? '';
                $shippingPincode = $request->shipping_pincode ?? '';
                $shippingCity = $request->shipping_city ?? '';
                $shippingState = $request->shipping_state ?? '';
            }


            if ($id) {
                $leadObject = Lead::find($id);

                if (!$leadObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Lead"]);
                    return $this->sendResponse($this->response, 200);
                }
                $leadObject->first();

                // Only update lead object if address1 is empty
                if (empty($leadObject->address1)) {
                    $leadObject->address1 = $address1;
                    $leadObject->address2 = $address2;
                    $leadObject->pincode = $pincode;
                    $leadObject->city = $city;
                    $leadObject->state = $state;
                    $leadObject->shipping_address1 = $shippingAddress1;
                    $leadObject->shipping_address2 = $shippingAddress2;
                    $leadObject->shipping_pincode = $shippingPincode;
                    $leadObject->shipping_city = $shippingCity;
                    $leadObject->shipping_state = $shippingState;
                    $leadObject->is_shipping_same = $isShippingSame;
                    $leadObject->name = $name;
                    $leadObject->contact_no = $contactNo;
                    $leadObject->email = $email;
                    $leadObject->save();

                    $this->response['msg'] = __('admin.updated', ['module' => "Lead"]);
                }
            }

            $leadAddresses = new LeadAddresses();
            $leadAddresses->lead_id = $id;
            $leadAddresses->address1 = $address1;
            $leadAddresses->address2 = $address2;
            $leadAddresses->pincode = $pincode;
            $leadAddresses->city = $city;
            $leadAddresses->state = $state;
            $leadAddresses->shipping_address1 = $shippingAddress1;
            $leadAddresses->shipping_address2 = $shippingAddress2;
            $leadAddresses->shipping_pincode = $shippingPincode;
            $leadAddresses->shipping_city = $shippingCity;
            $leadAddresses->shipping_state = $shippingState;
            $leadAddresses->is_shipping_same = $isShippingSame;
            $leadAddresses->save();

            $leadContactPeople = new LeadContactPeople();
            $leadContactPeople->lead_id = $id;
            $leadContactPeople->lead_address_id = $leadAddresses->id;
            $leadContactPeople->customer_name = $name;
            $leadContactPeople->email = $email;
            $leadContactPeople->contact_no = $contactNo;
            $leadContactPeople->save();

            $this->response['status'] = 1;
            DB::commit();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating Lead Address Confirmation: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Lead Address"]);
            return $this->sendResponse($this->response, 500);
        }
    }
    private function validateAssignRsm(Request $request)
    {
        return Validator::make(
            $request->all(),
            [
                'id' => 'required',
                'assigned_rsm' => 'required|exists:users,id,deleted_at,NULL',
            ],
            [
                'assigned_rsm.exists' => 'RSM doesn\'t exists with provided id',
            ]
        )->errors();
    }


    private function validateAddUpdateLead(Request $request)
    {
        return Validator::make(
            $request->all(),
            [
                'enquiry_date' => 'required|date_format:d/m/Y',
                // 'fk_region_id' => 'required|exists:regions,id,deleted_at,NULL',
                'fk_region_id' => 'required_if:is_export,0',
                // 'customer_name' => 'required',
                'company' => 'required',
                // 'pincode' => 'required',
                // 'division_id' => 'required',
                // 'email' => [
                //   'required', Rule::unique('leads')->where(function ($query) use ($request) {
                //     return $query->where('city', $request->input('city'));
                //   })->ignore($request->id),
                // ],

                // 'contact_no' => [
                //   'required', 'numeric',
                //   Rule::unique('leads')->where(function ($query) use ($request) {
                //     return $query->where('city', $request->input('city'));
                //   })->ignore($request->id),
                // ],

                // 'fk_source_id' => 'required|exists:sources,id,deleted_at,NULL',
                // 'smo_platform' => 'required_if:fk_source_id,3',
                // 'adwords_platform' => 'required_if:fk_source_id,4',
                // 'fk_rsmr_id' => 'nullable|required_if:fk_source_id,9',
                // 'fk_rsmv_id' => 'nullable|required_if:fk_source_id,10',
                // 'reference' => 'required_if:fk_source_id,11',
            ],
            [
                'enquiry_date.date_format' => 'Invalid Date Format',
                'fk_region_id.required_if' => 'Region is required.',
                // 'division_id.required' => 'Division is required.',
                // 'smo_platform.required_if' => 'This field is required when Source is SMO',
                // 'adwords_platform.required_if' => 'This field is required when Source is Adwords',
                // 'fk_rsmr_id.exists' => 'RSM Research doesn\'t exists with provided id',
                // 'fk_rsmv_id.exists' => 'RSM Visit doesn\'t exists with provided id',
                // 'fk_rsmr_id.required_if' => 'This field is required when Source is RSM Research',
                // 'fk_rsmv_id.required_if' => 'This field is required when Source is RSM Research',
                // 'reference.required_if' => 'This field is required when Source is Reference',
            ]
        )->errors();
    }

    private function validateUpdateCreditLimit(Request $request)
    {
        return Validator::make(
            $request->all(),
            [
                'credit_limit' => [
                    'required',
                    'numeric', // Ensure the input is numeric
                    // 'regex:/^\d+(\.\d{1,2})?$/', // Allows decimal up to two places
                    'min:0.01', // Minimum value
                    // 'max:9999999.99', // Maximum value (adjust as needed)
                ],

            ]
        )->errors();
    }
}
