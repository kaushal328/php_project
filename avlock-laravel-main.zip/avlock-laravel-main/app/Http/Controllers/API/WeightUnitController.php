<?php

namespace App\Http\Controllers\API;

use App\Enums\ErrorType;
use App\Http\Controllers\Controller;
use App\Models\WeightUnit;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class WeightUnitController extends AppBaseController
{

    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $title = $request->title ?? '';

            $WeightUnit = WeightUnit::orderBy("id", "desc");

            if ($title) {
                $WeightUnit->where('title', 'like', '%' . $title . '%');
            }

            $num_rows = $WeightUnit->count();
            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "WeightUnit"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['title'] = $title;
            $this->response['data']['list'] = $WeightUnit->limit($per_page)->offset($offset)->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("WeightUnit fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addUpdate(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateWeightUnit($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $WeightUnitObject = new WeightUnit();
            $id = $request->id;
            $title = $request->title ?? '';



            if ($id) {
                $WeightUnitObject = WeightUnit::find($id);

                if (!$WeightUnitObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "WeightUnit"]);
                    return $this->sendResponse($this->response, 200);
                }

                $WeightUnitObject->first();
                $this->response['msg'] = __('admin.updated', ['module' => "WeightUnit"]);
            } else {
                $this->response['msg'] = __('admin.created', ['module' => "WeightUnit"]);
            }

            $WeightUnitObject->title = $title;
            $WeightUnitObject->save();

            $this->response['status'] = 1;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating WeightUnit: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "WeightUnit"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $WeightUnitObject = WeightUnit::find($id);

            if (!$WeightUnitObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "WeightUnit"]);
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "WeightUnit"]);
            $this->response['data'] = $WeightUnitObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("WeightUnit fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $WeightUnitObject = WeightUnit::find($id);

            if (!$WeightUnitObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "WeightUnit"]);
                return $this->sendResponse($this->response, 200);
            }

            $WeightUnitObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "WeightUnit"]);
            $this->response['data'] = $WeightUnitObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("WeightUnit Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function validateAddUpdateWeightUnit(Request $request)
    {
        return Validator::make($request->all(), [
            'title' => 'required|string|unique:weight_units,title,' . $request->id . ',id,deleted_at,NULL',
        ])->errors();
    }
}
