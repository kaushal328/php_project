<?php

namespace App\Http\Controllers\API;

use Exception;
use Carbon\Carbon;
use App\Models\Reminder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Http\Resources\ReminderResource;
use App\Models\ReminderUser;
use App\Models\User;
use App\Models\UserDevice;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ReminderController extends AppBaseController
{

  function index(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $taskType = $request->task_type ?? '';
      $lead = $request->lead ?? '';
      $startDate = $request->start_date ?? "";
      $endDate = $request->end_date ?? "";
      $dateRange = strtolower($request->date_range) ?? '';

      $reminders = Reminder::with('taskType', 'Remminderlead', 'Remminderfq', 'reminderUser')->orderBy('reminder_time', 'asc');

      if (!$this->isUserAdmin) {
        $reminders->whereHas('reminderUser', function ($query) {
          $query->where('created_by', $this->userId);
          $query->orWhere('fk_user_id', $this->userId);
        });
      }



      if ($taskType) $reminders->where('task_type', $taskType);

      if ($lead) $reminders->where('lead', $lead);

      if ($dateRange) {
        if ($dateRange == 'today') {
          $reminders->whereDate('reminder_time', date('Y-m-d'));
        }
        if ($dateRange == 'yesterday') {
          $reminders->whereDate('reminder_time', date('Y-m-d', strtotime('-1 day')));
        }
        if ($dateRange == 'last_7_days') {
          $reminders->whereDate('reminder_time', '>=', date('Y-m-d', strtotime('-7 days')));
          $reminders->whereDate('reminder_time', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'last_14_days') {
          $reminders->whereDate('reminder_time', '>=', date('Y-m-d', strtotime('-14 days')));
          $reminders->whereDate('reminder_time', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'last_28_days') {
          $reminders->whereDate('reminder_time', '>=', date('Y-m-d', strtotime('-28 days')));
          $reminders->whereDate('reminder_time', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'this_month') {
          $reminders->whereMonth('reminder_time', date('m'))->whereYear('reminder_time', date('Y'));
        }
        if ($dateRange == 'last_month') {
          $reminders->whereMonth('reminder_time', date('m', strtotime('-1 month')));
        }
        if ($dateRange == 'this_year') {
          $reminders->whereYear('reminder_time', date('Y'));
        }
        if ($dateRange == 'last_year') {
          $reminders->whereYear('reminder_time', date('Y', strtotime('-1 year')));
        }

        if ($dateRange == 'custom_date') {
          if ($startDate) {
            $reminders->whereDate('reminder_time', '>=', $startDate);

            if ($endDate) {
              $reminders->whereDate('reminder_time', '<=', $endDate);
            }
          }
        }
      }

      $num_rows = $reminders->count();
      $result = $reminders->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Reminders"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['task_type'] = $taskType;
      $this->response['data']['lead'] = $lead;
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['end_date'] = $endDate;
      $this->response['data']['date_range'] = $dateRange;
      $this->response['data']['list'] = ReminderResource::collection($result);

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Reminders fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function get(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $reminders = Reminder::with('taskType', 'Remminderlead', 'Remminderfq')->find($id);

      if (!$reminders) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Reminder"]);
        return $this->sendResponse($this->response, 401);
      }

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Reminder"]);
      $this->response['data'] = new ReminderResource($reminders);

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Reminder fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  function addUpdate(Request $request)
  {
    try {

      DB::beginTransaction();

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateReminder($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $reminderObject = new Reminder();
      $id = $request->id;
      $forMe = $request->for_me;
      $taskType = $request->taskType ?? 0;
      $lead = $request->lead ?? 0;
      $rfq = $request->rfq ?? 0;
      $reminderTime = Carbon::createFromFormat('d/m/Y g:i A', $request->reminder_time)->format('Y-m-d H:i:s');
      $comment = $request->comment;

      if ($taskType == 1) {
        $rfq = 0;
      }

      if ($id) {
        $reminderObject = Reminder::find($id);

        if (!$reminderObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Reminder"]);
          return $this->sendResponse($this->response, 401);
        }

        $reminderObject->first();
        $reminderObject->updated_by = $this->userId;

        $this->response['msg'] = __('admin.updated', ['module' => "Reminder"]);
      } else {
        $reminderObject->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => "Reminder"]);
      }


      $reminderObject->latitude = $request->header('x-user-latitude') ?? '';
      $reminderObject->longitude = $request->header('x-user-longitude') ?? '';
      $formattedAddress = getFormattedAddress($reminderObject->latitude, $reminderObject->longitude);
      $reminderObject->formatted_address = $formattedAddress ?? '';
      $reminderObject->platform_type = 'web';
      $reminderObject->task_type = $taskType;
      $reminderObject->for_me = $forMe;
      $reminderObject->lead = $lead;
      $reminderObject->rfq = $rfq;
      $reminderObject->comment = $comment;
      $reminderObject->reminder_time = $reminderTime;
      $reminderObject->save();

      $lastInsertedUserId = $reminderObject->id;

      ReminderUser::where('fk_reminder_id', $lastInsertedUserId)->forceDelete();

      $reminderUser = new ReminderUser();

      if ($request->for_me === 1) {
        $currUser = User::find($this->userId);
        $reminderUser->fk_reminder_id = $lastInsertedUserId;
        $reminderUser->fk_user_id = $currUser->id;
        $reminderUser->user_name = $currUser->name;
        $reminderUser->save();
      } else {

        if (count($request->reminder_user) > 0) {
          ReminderUser::where('fk_reminder_id', $lastInsertedUserId)->forceDelete();

          foreach ($request->reminder_user as $user) {
            $userId = $user['id'];
            $userName = $user['name'];

            $reminderUser = new ReminderUser();

            if ($userId != "") {
              $reminderUser->fk_reminder_id = $lastInsertedUserId;
              $reminderUser->fk_user_id = $userId;
              $reminderUser->user_name = $userName;
              $reminderUser->save();
            }
          }
        }
      }

      // Send Reminder Notification
      if (!$id && count($request->reminder_user) > 0) {

        $reminderUserIdArray = [];
        foreach ($request->reminder_user as $user) {
          $reminderUserIdArray[] = $user['id'];
        }

        $uniqueReminderUserIdArray = array_unique($reminderUserIdArray);
        $uniqueReminderUserIdArray = array_values($uniqueReminderUserIdArray);

        if (!empty($uniqueReminderUserIdArray)) {

          $userFcmData = UserDevice::whereIn('user_id', $reminderUserIdArray)->whereNotNull('device_id')->groupBy('device_id')->get();
          // echo '<pre>';
          // print_r($userFcmData);
          // die;
          if (!empty($userFcmData)) {
            $fcmIds = array();
            $deviceIds = array();
            $i = 0;
            foreach ($userFcmData as $key => $val) {
              array_push($fcmIds, $val->fcm_id);
              array_push($deviceIds, $val->device_id);
            }

            $notificationData = ['title' => "Avlock Reminder", 'body' => "You Have a reminder from " . $this->currentUserName . " for " . Carbon::createFromFormat('d/m/Y g:i A', $request->reminder_time)->format('F j, Y')];

            $devicesData =  array_combine($deviceIds, $fcmIds);
            sendFcmNotification($devicesData, $notificationData, $reminderUserIdArray);
          }
        }
      }

      DB::commit();

      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Creating Reminder: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $reminderObject = Reminder::find($id);

      if (!$reminderObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Reminder"]);
        return $this->sendResponse($this->response, 401);
      }

      $reminderObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Reminder"]);
      $this->response['data'] = $reminderObject;



      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Reminder Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdateReminder(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'comment' => 'required|string',
        'reminder_user' => 'required_unless:for_me,1',
        'reminder_time' => 'required|date_format:d/m/Y g:i A',
        'taskType' => 'required|integer|exists:task_types,id',
        'lead' => 'nullable|required_if:taskType,1|exists:leads,id,deleted_at,NULL',
        'rfq' => 'nullable|required_if:taskType,2|exists:rfqs,id,deleted_at,NULL',
      ],
      [
        'lead.required_if' => 'You have selected "Lead" from the "For" dropdown. Please select a lead before proceeding.',
        'rfq.required_if' => 'You have selected "RFQ" from the "For" dropdown. Please select a RFQ before proceeding.',
        'reminder_user.required_unless' => 'User is required unless for me is checked.',
      ]
    )->errors();
  }
}
