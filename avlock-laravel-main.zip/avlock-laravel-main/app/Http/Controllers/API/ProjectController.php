<?php

namespace App\Http\Controllers\API;

use Exception;
use Carbon\Carbon;
use App\Models\Rfq;
use App\Models\Lead;
use App\Models\Task;
use App\Models\User;
use App\Models\Stage;
use App\Enums\Charges;
use App\Enums\PoStatus;
use App\Models\EvaBill;
use App\Models\SubStage;
use App\Models\TaskUser;
use App\Models\UserRole;
use App\Enums\ClientType;
use App\Models\Department;
use App\Models\ProjectLog;
use App\Events\PoLogCreated;
use Illuminate\Http\Request;
use App\Events\RfqLogCreated;
use App\Models\PurchaseOrder;
use App\Models\RfqAttachment;
use App\Enums\QuotationStatus;
use App\Models\CreditLimitLog;
use App\Models\PurchaseInvoice;
use App\Models\PurchaseOrderLr;
use App\Models\ProjectQuotation;
use App\Models\PurchaseOrderLog;
use App\Models\ProjectSegment;
use App\Models\PurchaseOrderRnr;
use App\Events\ProjectLogCreated;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Models\ProjectQuotationTemp;
use App\Events\CreditLimitLogCreated;
use App\Models\PurchaseOrderEInvoice;
use App\Models\PurchaseInvoicePayment;
use App\Models\PurchaseOrderAgreement;
use App\Models\PurchaseOrderLabelling;
use App\Http\Resources\RfqListResource;
use App\Models\PurchaseOrderDneInvoice;
use App\Models\PurchaseOrderPdrQuality;
use Illuminate\Support\Facades\Validator;
use App\Events\ProjectQuotationLogCreated;
use App\Http\Resources\ProjectLogResource;
use App\Models\PurchaseOrderPackagingList;
use App\Http\Resources\RfqCustomerResource;
use App\Events\ProjectQuotationLogTempCreated;
use App\Http\Resources\PurchaseOrderLogResource;
use App\Jobs\SendStageChangeNotification;
use App\Models\AvlockPurchaseInvoice;
use App\Models\PoDespatchDetail;
use App\Models\ProjectLost;
use Hamcrest\Arrays\IsArray;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;
use PhpOffice\PhpSpreadsheet\Writer\Csv;

class ProjectController extends AppBaseController
{
    function index(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $rfqNumber = $request->rfq_number ?? "";
            $product_id = $request->product_id ?? "";
            $project_type = $request->project_type ?? "";
            $project_segment = $request->project_segment ?? "";
            $customer_name = $request->customer_name ?? "";
            $rsmId = $request->rsm ?? "";
            $division_id = $request->division_id ?? "";
            $customer = $request->customer ?? "";
            $companyName = $request->company_name ?? "";
            $quotationNo = $request->quotation_no ?? "";
            $isExport = $request->is_export ?? "";
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';

            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            $insideSaleUsers = UserRole::where('fk_user_id', $this->userId)->with('user')->first();

            if ($insideSaleUsers && $insideSaleUsers->user && $insideSaleUsers->user->division_ids) {
                $divisionIds = explode(',', $insideSaleUsers->user->division_ids);
                $divisionIds = array_filter($divisionIds);
                $divisionIds = array_unique($divisionIds);
            } else {
                $divisionIds = [];
            }


            // $divisionIds = $insideSaleUsers->map(function ($insideUser) {
            //   return explode(',', $insideUser->user->division_ids);
            // })->flatten()->filter()->unique()->toArray();
            // dd($divisionIds);

            $rfqListResource = Rfq::with('product', 'lead', 'stage', 'subStage', 'projectType', 'projectSegment', 'purchaseOrder.subStage', 'quotationTemp');

            if ($this->isMarketing || $this->isManagement || $this->isUserAdmin || $this->isUserInsideSale || $this->isUserDispatch) {
                $rfqListResource->orderBy('updated_at', 'desc');
                if ($this->isUserInsideSale && !empty($divisionIds) && !$this->isUserAdmin) {
                    $rfqListResource->where(function ($q) use ($divisionIds) {
                        $q->whereIn('division_id', $divisionIds)
                            ->orWhere('created_by', $this->userId);
                    });
                }
                if ($this->isUserDispatch && !$this->isUserAdmin && !$this->isManagement && $this->isMarketing && $this->isUserInsideSale) {
                    $rfqListResource->whereHas('purchaseOrder', function ($query) {
                        $query->whereNotNull('id');
                    });
                }
            } else {
                $loggedInUserId = $this->userId;
                $rfqListResource->where(function ($q) use ($juniorUserIds, $loggedInUserId, $divisionIds) {
                    $q->whereIn('rsm_id', $juniorUserIds)
                        ->whereIn('division_id', $divisionIds)
                        ->orWhereIn('created_by', $juniorUserIds)
                        ->orWhereHas('stageLogs', function ($q) use ($loggedInUserId) {
                            $q->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$loggedInUserId]);
                        });
                })->orderBy('updated_at', 'desc');
            }

            if ($customer) {
                $rfqListResource->where('lead_id', $customer);
            }

            if ($rfqNumber) {
                $rfqListResource->where('rfq_number', 'like', "%" . $rfqNumber . "%");
            }

            if ($product_id) {
                $rfqListResource->whereHas('product', function ($q) use ($product_id) {
                    $q->where('product_id', $product_id);
                });
            }

            if ($division_id) {
                $rfqListResource->where('division_id', $division_id);
            }

            if ($project_type) {
                $rfqListResource->where('fk_project_type_id', $project_type);
            }

            if ($project_segment) {
                $rfqListResource->where('fk_project_segment_id', $project_segment);
            }

            if ($customer_name) {
                $rfqListResource->where('customer_name', 'like', "%" . $customer_name . "%");
            }

            if ($rsmId) {
                $rfqListResource->where('rsm_id', $rsmId);
            }

            if ($companyName) {
                $rfqListResource->whereHas('lead', function ($query) use ($companyName) {
                    $query->where('company', $companyName);
                });
            }

            if ($quotationNo) {
                $rfqListResource->whereHas('quotationTemp', function ($query) use ($quotationNo) {
                    $query->where('quotation_no', $quotationNo);
                });
            }


            if ($dateRange) {
                if ($dateRange == 'today') {
                    $rfqListResource->whereDate('created_at', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $rfqListResource->whereDate('created_at', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $rfqListResource->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                    $rfqListResource->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $rfqListResource->whereDate('created_at', '>=', date('Y-m-d', strtotime('-14 days')));
                    $rfqListResource->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $rfqListResource->whereDate('created_at', '>=', date('Y-m-d', strtotime('-28 days')));
                    $rfqListResource->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $rfqListResource->whereMonth('created_at', date('m'))->whereYear('created_at', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $rfqListResource->whereMonth('created_at', date('m', strtotime('-1 month')));
                }
                if ($dateRange == 'this_year') {
                    $rfqListResource->whereYear('created_at', date('Y'));
                }
                if ($dateRange == 'last_year') {
                    $rfqListResource->whereYear('created_at', date('Y', strtotime('-1 year')));
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $rfqListResource->whereDate('created_at', '>=', $startDate);

                        if ($endDate) {
                            $rfqListResource->whereDate('created_at', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $rfqListResource->count();
            if ($isExport == 1) {
                $result = $rfqListResource->get();
            } else {
                $result = $rfqListResource->limit($per_page)->offset($offset)->get();
            }

            $rfqList = RfqListResource::collection($result);

            if ($isExport == 1) {
                $now = Carbon::now();
                $currentDate = $now->format('d/m/Y');

                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                $headers = ['Sr.No', 'RSM', 'Date', 'Company Name', 'Application Segment', 'Segment', 'Avlock No', 'Item Description', 'Update on ' . $currentDate];
                $sheetData = [$headers];

                foreach ($rfqList as $key => $item) {

                    $createdAt = $item->created_at;
                    $date = Carbon::parse($createdAt);
                    $formattedDate = $date->format('d/m/y');

                    $company = isset($item->lead) ? $item->lead->company : '';
                    $application = isset($item->lead) ? $item->lead->application : '';
                    $description = isset($item->lead) ? $item->lead->description : '';
                    $projectSegmentIds = json_decode($item->project_segments) ?? [];
                    $projectSegement = ProjectSegment::whereIn('id', $projectSegmentIds)->get()->implode('name', ', ');

                    $rowData = [
                        $key + 1,
                        $item->rsm_name ?? '',
                        $formattedDate ?? '',
                        $company,
                        $application,
                        $projectSegement,
                        $item->rfq_number ?? '',
                        $description,
                        $item->comments ?? '',
                    ];
                    $sheetData[] = $rowData;
                }

                $sheet->fromArray($sheetData, null, 'A1');

                $date = Carbon::today()->format('Y-m-d');
                $store = "storage/app/public/uploads/project/project_list_" . $date . ".csv";
                $filePath = "storage/uploads/project/project_list_" . $date . ".csv";
                $writer = new Csv($spreadsheet);
                $writer->save($store);
            }


            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Project"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['filePath'] = $filePath ?? '';
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['rfq_number'] = $rfqNumber;
            $this->response['data']['quotation_no'] = $quotationNo;
            $this->response['data']['product_id'] = $product_id;
            $this->response['data']['project_type'] = $project_type;
            $this->response['data']['project_segment'] = $project_segment;
            $this->response['data']['customer_name'] = $customer_name;
            $this->response['data']['customer'] = Lead::select('id', 'company')->find($customer);
            $this->response['data']['list'] = $rfqList;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function get(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $leadId = $request->lead_id ?? "";
            $rfqId = $request->rfq_id ?? "";
            $poId = $request->po_id ?? "";

            if (!$leadId && !$rfqId) {
                $this->response['error'] = "Please select a valid lead!";
                return $this->sendResponse($this->response, 200);
            }

            $leadCustomerResource = Lead::with(['customer', 'rfq' => function ($q) use ($rfqId) {
                $q->where('id', $rfqId);
            }])->find($leadId);

            if ($poId) {
                $leadCustomerResource->rfq->po_id = $poId;
            }

            $leadCustomer = new RfqCustomerResource($leadCustomerResource);

            if (!$leadCustomer) {
                $this->response['error'] = "Something went wrong! Project details not found.";
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['data'] = $leadCustomer;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function updateStage(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateUpdateStage($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $id = $request->rfq_id;

            if (!$id) {
                $this->response['error'] = "Project Id is require";
                return $this->sendResponse($this->response, 200);
            }

            $projectObject = Rfq::with('division')->find($id);

            if (!$projectObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project"]);
                return $this->sendResponse($this->response, 200);
            }

            $curr_sub_stage_id = $request->curr_sub_stage_id;
            $currUser = $request->curr_user;

            $uniqueArray = [];
            foreach ($currUser as $item) {
                if (!in_array($item['id'], array_column($uniqueArray, 'id'))) {
                    $uniqueArray[] = $item;
                }
            }

            $curr_user = json_encode($uniqueArray);

            $comments = $request->comments ?? '';
            $commUsers = $request->comm_user ?? [];

            $uniqueCommArray = [];
            foreach ($commUsers as $item) {
                if (!in_array($item['id'], array_column($uniqueCommArray, 'id'))) {
                    $uniqueCommArray[] = $item;
                }
            }

            $comm_user = json_encode($uniqueCommArray);

            // Add Comments to Task
            if (!empty($comments)) {
                $taskObject = new Task();
                $taskObject->title = $comments;
                $taskObject->description = $comments;
                $taskObject->start = Carbon::now()->toDateTimeString();
                $taskObject->end = Carbon::now()->addDays(2)->toDateTimeString();
                $taskObject->fk_task_type_id = 2;
                $taskObject->fk_rfq_id = $id;
                $taskObject->fk_lead_id = $request->lead_id;
                $taskObject->task_user = $comm_user;
                $taskObject->fk_status_id = 2;
                $taskObject->fk_type_task_id = 5;
                $taskObject->created_by = $this->userId;
                $taskObject->save();
                $lastInsertedUserId = $taskObject->id;

                if (count($commUsers) > 0) {

                    TaskUser::where('fk_task_id', $lastInsertedUserId)->forceDelete();

                    foreach ($commUsers as $user) {
                        $userId = $user['id'];
                        $userName = $user['name'];

                        $taskUserObject = new TaskUser();

                        if ($userId != "") {
                            $taskUserObject->fk_task_id = $lastInsertedUserId;
                            $taskUserObject->fk_user_id = $userId;
                            $taskUserObject->user_name = $userName;
                            $taskUserObject->save();
                        }
                    }
                }
            }
            //End Add to Task

            $files = [];
            if (isset($request->attachments)) {
                if (count($request->attachments) > 0) {
                    foreach ($request->attachments as $item) {
                        moveFile('project/files/', $item['filename']);
                        $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                    }
                }
            }

            $attachments = json_encode($files) ?? '';

            $ids = '';

            if (!empty($request->curr_user)) {
                $ids = implode(',', array_column($uniqueArray, 'id'));
            }

            $commUsersIds = '';
            if (!empty($request->comm_user)) {
                $commUsersIds = implode(',', array_column($uniqueCommArray, 'id'));
            }

            $subStageObject = SubStage::find($curr_sub_stage_id);

            if (!$subStageObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Stage"]);
                return $this->sendResponse($this->response, 200);
            }

            $curr_stage_id = $subStageObject->stage_id;
            $stageActionDepartments = $subStageObject->action_departments ?? '';

            $actionDepartmentIds = [];
            if ($stageActionDepartments != '') {
                $actionDepartmentIds = explode(",", $stageActionDepartments);
            }


            $user = UserRole::with('user', 'department')->whereIn('fk_department_id', $actionDepartmentIds)->groupBy('fk_user_id')->get();

            if ($user->isEmpty()) {
                $this->response["error"] = "Current Stage has no user";
                return $this->sendResponse($this->response, 200);
            }

            $userObjectNew = User::find($this->userId);
            $divisionHeadIds = json_decode($userObjectNew->division_head_ids, true);
            $isDivisionHead = !empty($divisionHeadIds) && is_array($divisionHeadIds) && count($divisionHeadIds) > 0;

            $canChangeStage = false;

            if ($user->contains('user.id', $this->userId) || $isDivisionHead) {
                $canChangeStage = true;
            }

            if (!$canChangeStage) {
                $this->response["error"] = "You Cant change stage";
                return $this->sendResponse($this->response, 200);
            }

            // if (!$user->contains('user.id', $this->userId) && !$isDivisionHead) {
            //     $this->response["error"] = "You Cant change stage";
            //     return $this->sendResponse($this->response, 200);
            // }

            $stageToDepartments = $subStageObject->to_departments ?? '';

            $toDepartmentIds = [];
            if ($stageToDepartments != '') {
                $toDepartmentIds = explode(",", $stageToDepartments);
            }
            $toDepartments = Department::whereIn('id', $toDepartmentIds)->pluck('title')->toArray();
            $currentToUserDepartments = UserRole::whereIn('fk_user_id', array_column($request->curr_user, 'id'))
                ->with('department')
                ->groupBy('fk_department_id')
                ->get()->toArray();

            $departmentTitles = [];

            foreach ($currentToUserDepartments as $userDepartment) {
                // Assuming that 'department' is the name of the relationship in the UserRole model
                $departmentTitles[] = $userDepartment['department']['title'];
            }

            // echo '<pre>';
            // print_r($toDepartments);
            // print_r(array_unique($departmentTitles));
            // print_r(array_column($request->curr_user, 'id'));
            // die;


            $allDepartmentUSerFound = true;

            foreach ($toDepartments as $department) {

                if (!in_array($department, $departmentTitles)) {
                    $allDepartmentUSerFound = false;
                    break;
                }
            }

            // if (!$allDepartmentUSerFound) {
            //   $this->response["errors"] =  ["curr_user" => "Select Atleast One User from Each Department"];
            //   return $this->sendResponse($this->response, 200);
            // }

            if ($curr_sub_stage_id == 22) { //RFQ Approved Process

                $rfq_approved_requirements = $request->rfq_approved_requirements ?? [];

                if (empty($rfq_approved_requirements)) {
                    $this->response["errors"] = ["rfq_approved_requirements" => "Please Fill the Require Details"];
                    return $this->sendResponse($this->response, 200);
                }

                $allEmpty = false;

                foreach ($rfq_approved_requirements as $key => $item) {
                    if (empty($item['part_no'])) {
                        $allEmpty = true;
                        break;
                    }
                }

                if ($allEmpty) {
                    $this->response["error"] =  "Part No. cannot be empty";
                    return $this->sendResponse($this->response, 200);
                }

                $rfq_approved_requirements = json_encode($rfq_approved_requirements);
                $projectObject->rfq_approved_requirements = $rfq_approved_requirements;

                //Credit limit
                $leadId = $request->lead_id;
                $creditLimit = $request->credit_limit;
                $creditDays = $request->credit_days;
                $clientType = $request->client_type;

                if (!$leadId) {
                    $this->response['error'] = "Please select a valid lead!";
                    return $this->sendResponse($this->response, 200);
                }

                $leadObject = Lead::find($leadId);

                if (!$leadObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => 'Lead']);
                    return $this->sendResponse($this->response, 400);
                }

                $leadObject->first();

                $action = 'created';
                if ($leadObject->is_client == 1) {
                    $action = 'updated';
                }

                $leadObject->credit_limit = $creditLimit;
                $leadObject->credit_days = $creditDays;
                $leadObject->client_type = $clientType ?? 0;
                $isClient = 1;
                $leadObject->is_client = $isClient;
                $leadObject->save();

                $leadObject->action = $action;

                CreditLimitLogCreated::dispatch($leadObject);
            }

            // Check If quotation is created or not
            if ($curr_sub_stage_id == 23) {
                $checkRfq = Rfq::find($id);

                if (!$checkRfq) {
                    $this->response["error"] = "RFQ not found";
                    return $this->sendResponse($this->response, 404);
                }

                if (empty($checkRfq->email) && empty($checkRfq->contact_no)) {
                    $this->response["error"] = "Please fill in either the contact number or email in the RFQ form.";
                    return $this->sendResponse($this->response, 200);
                }

                $projectQuotationTempFound = ProjectQuotationTemp::where('fk_rfq_id', $id)->first();
                if (!$projectQuotationTempFound) {

                    $projectQuotationTempObject = new ProjectQuotationTemp();
                    $fk_rfq_id = $id;
                    $fk_lead_id = $projectObject->lead_id;
                    $salesPerson = $projectObject->rsm_id;
                    $quotationDate = Carbon::now();
                    $rfqObject = RFQ::with('lead')->find($fk_rfq_id);

                    $lastEntry = ProjectQuotationTemp::latest('id')->first();
                    $lastId = $lastEntry ? $lastEntry->id : 0;
                    //$quotationNo = generateUniqueNumber($lastId, "AVL-Q");

                    $currentMonth = date('n'); // Get the current month number (1-12)
                    $currentYear = date('Y'); // Get the full current year

                    // Determine the financial year
                    $financialYearStart = $currentMonth >= 4 ? $currentYear : $currentYear - 1;
                    $financialYearEnd = $financialYearStart + 1;

                    // Format the financial year (last two digits)
                    $shortFinYearStart = substr($financialYearStart, -2);
                    $shortFinYearEnd = substr($financialYearEnd, -2);

                    if ($rfqObject && $rfqObject->lead && $rfqObject->lead->is_export == 1) {
                        $baseString = strtoupper('EXP/QTN/' . $projectObject->division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . date('M') . '/');
                    } else {
                        $baseString = strtoupper('QTN/' . $projectObject->division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . date('M') . '/');
                    }

                    $quotationNo = generateSeries($baseString, 'project_quotation_temps', 'quotation_no');

                    $existingQuotation = ProjectQuotationTemp::where('quotation_no', $quotationNo)->first();

                    if ($existingQuotation) {
                        $this->response['error'] = "Quotation No already exists.";
                        return $this->sendResponse($this->response, 200);
                    }

                    $projectQuotationTempObject->sales_person = $salesPerson;
                    $projectQuotationTempObject->fk_rfq_id = $fk_rfq_id;
                    $projectQuotationTempObject->fk_lead_id = $fk_lead_id;
                    $projectQuotationTempObject->quotation_date = $quotationDate;
                    $projectQuotationTempObject->quotation_no = $quotationNo;
                    $projectQuotationTempObject->prepared_by = $this->userId;
                    $projectQuotationTempObject->quotation_status = QuotationStatus::INITIATED;
                    $projectQuotationTempObject->is_revised = 0;
                    $projectQuotationTempObject->is_sent_to_client = 0;

                    $projectQuotationTempObject->save();

                    $projectQuotationTempObject->action = 'created';
                    ProjectQuotationLogTempCreated::dispatch($projectQuotationTempObject);


                    // $this->response["error"] = "Please Create Quotation";
                    // return $this->sendResponse($this->response, 200);
                }
            }

            if ($curr_sub_stage_id == 37) { // for Agreement Upload

                $validationErrors = $this->validateAgreement($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $agreementDate = Carbon::createFromFormat('d/m/Y g:i A', $request->agreement_date)->format('Y-m-d H:i:s');
                $agreementNo = $request->agreement_no;
                $agreement_ramark = $request->agreement_ramark ?? '';

                $agreementObject = new PurchaseOrderAgreement();
                $agreement_id = $request->agreement_id ?? 0;

                if ($agreement_id != 0) {
                    $agreementObject = PurchaseOrderAgreement::find($agreement_id);

                    if (!$agreementObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Agreement"]);
                        return $this->sendResponse($this->response, 401);
                    }
                    $agreementObject->first();
                }

                // $agreementObject->fk_po_id = $fk_po_id;
                // $agreementObject->fk_quotation_id = $fk_quotation_id;
                $agreementObject->fk_rfq_id = $id;
                $agreementObject->fk_lead_id = $request->lead_id;
                $agreementObject->agreement_no = $agreementNo;
                $agreementObject->agreement_date = $agreementDate;
                $agreementObject->remark = $agreement_ramark;

                $agreementObject->save();
            }


            if ($curr_sub_stage_id == 26) { // Lar Entered
                $projectQuotationTempFound = ProjectQuotationTemp::where('fk_rfq_id', $id)->first();
                if (!$projectQuotationTempFound) {
                    $this->response["error"] = "Please Create Quotation";
                    return $this->sendResponse($this->response, 200);
                }

                $requirements = $projectQuotationTempFound->requirements ? json_decode($projectQuotationTempFound->requirements) : [];

                if (empty($requirements)) {
                    $this->response["error"] = "Please Fill the Quotation Requirement";
                    return $this->sendResponse($this->response, 200);
                }

                // $larEmpty = false;

                // foreach ($requirements as $key => $item) {
                //   if (empty($item->available) || empty($item->rate)) {
                //     $larEmpty = true;
                //     break;
                //   }
                // }

                // if ($larEmpty) {
                //   $this->response["error"] = "Please Fill the LAR Of Every Part";
                //   return $this->sendResponse($this->response, 200);
                // }


                $projectQuotationTempFound->quotation_status = QuotationStatus::LAR_ENTERED;
                $projectQuotationTempFound->save();
                $projectQuotationTempFound->action = 'updated';

                ProjectQuotationLogTempCreated::dispatch($projectQuotationTempFound);


                // TERMS FINALIZE
                $projectQuotationTempFound = ProjectQuotationTemp::where('fk_rfq_id', $id)->first();
                if (!$projectQuotationTempFound) {
                    $this->response["error"] = "Please Create Quotation";
                    return $this->sendResponse($this->response, 200);
                }

                $quotationTerms = $projectQuotationTempFound->quotation_terms ? json_decode($projectQuotationTempFound->quotation_terms) : [];

                // if (empty($quotationTerms)) {
                //   $this->response["error"] = "Please Add Atleast One Term For Quotation";
                //   return $this->sendResponse($this->response, 200);
                // }


                $projectQuotationTempFound->quotation_status = QuotationStatus::TERMS_FINALISED;
                $projectQuotationTempFound->save();
                $projectQuotationTempFound->action = 'updated';

                ProjectQuotationLogTempCreated::dispatch($projectQuotationTempFound);
            }


            if ($curr_sub_stage_id == 26) { //QUOTATION PREPARED
                $projectQuotationTempFound = ProjectQuotationTemp::where('fk_rfq_id', $id)->first();
                if (!$projectQuotationTempFound) {
                    $this->response["error"] = "Please Create Quotation";
                    return $this->sendResponse($this->response, 200);
                }
                $projectQuotationTempFound->quotation_status = QuotationStatus::PREPARED;
                $projectQuotationTempFound->save();

                $projectQuotationFound = ProjectQuotation::where('fk_project_quotation_temp_id', $projectQuotationTempFound->id)->first();
                if (!$projectQuotationFound) {
                    $projectQuotation = new ProjectQuotation();

                    $lastEntry = ProjectQuotation::latest('id')->first();
                    $lastId = $lastEntry ? $lastEntry->id : 0;
                    //$quotationNo = generateUniqueNumber($lastId, "AVL-Q");

                    $baseString = strtoupper('QTN/' . $projectObject->division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . date('M') . '/');
                    $quotationNo = generateSeries($baseString, 'project_quotation_temps', 'quotation_no');

                    $projectQuotation->fk_project_quotation_temp_id = $projectQuotationTempFound->id;
                    $projectQuotation->sales_person = $projectQuotationTempFound->sales_person;
                    $projectQuotation->fk_rfq_id = $projectQuotationTempFound->fk_rfq_id;
                    $projectQuotation->fk_lead_id = $projectQuotationTempFound->fk_lead_id;
                    $projectQuotation->salutation = $projectQuotationTempFound->salutation;
                    $projectQuotation->requirements = $projectQuotationTempFound->requirements;
                    $projectQuotation->requirement_total = $projectQuotationTempFound->requirement_total;
                    $projectQuotation->special_notes = $projectQuotationTempFound->special_notes;
                    $projectQuotation->quotation_terms = $projectQuotationTempFound->quotation_terms;
                    $projectQuotation->bank_details = $projectQuotationTempFound->bank_details;
                    $projectQuotation->quotation_status = QuotationStatus::PREPARED;
                    $projectQuotation->quotation_date = Carbon::now();
                    $projectQuotation->quotation_no = $quotationNo;
                    $projectQuotation->prepared_by = $this->userId;
                    $projectQuotation->created_by = $this->userId;
                    $projectQuotation->save();

                    $projectQuotation->action = 'created';

                    ProjectQuotationLogCreated::dispatch($projectQuotation);
                }
                $projectQuotationTempFound->action = 'updated';
                ProjectQuotationLogTempCreated::dispatch($projectQuotationTempFound);
            }

            if ($curr_sub_stage_id == 27) { // SENT TO CLIENT
                $projectQuotationTempFound = ProjectQuotationTemp::where('fk_rfq_id', $id)->first();
                if (!$projectQuotationTempFound) {
                    $this->response["error"] = "Please Create Quotation";
                    return $this->sendResponse($this->response, 200);
                }

                $projectQuotationFound = ProjectQuotation::where('fk_rfq_id', $id)->first();
                if (!$projectQuotationFound) {
                    $this->response["error"] = "Please Create Quotation";
                    return $this->sendResponse($this->response, 200);
                }

                $projectQuotationFound->quotation_status = QuotationStatus::SENT_TO_CLIENT;
                $projectQuotationFound->is_sent_to_client = 1;
                $projectQuotationFound->save();
                $projectQuotationFound->action = 'updated';

                // Update $projectQuotationTempFound separately
                $projectQuotationTempFound->is_sent_to_client = 1;
                $projectQuotationTempFound->save();

                // Dispatch events
                ProjectQuotationLogCreated::dispatch($projectQuotationFound);
                ProjectQuotationLogTempCreated::dispatch($projectQuotationTempFound);
            }

            if ($curr_sub_stage_id == 57) { //Project Lost
                $projectLostId = $request->project_lost_id ?? null;
                $projectObject->project_lost_id = $projectLostId;

                $projectQuotationTempObj = ProjectQuotationTemp::where('fk_rfq_id', $id)->first();
                if (!$projectQuotationTempObj) {
                    $this->response["error"] = "Quotation Not Found";
                    return $this->sendResponse($this->response, 200);
                }
                $projectQuotationTempObj->project_lost_id = $projectLostId;
                $projectQuotationTempObj->save();
            }

            // if ($curr_sub_stage_id == 34 && $curr_sub_stage_id != $projectObject->curr_sub_stage_id) { // When Po Received . second condition is for not creating again when
            // if ($curr_sub_stage_id == 34) {

            //     $validationErrors = $this->validateAddUpdatePurchaseOrder($request);

            //     if (count($validationErrors)) {
            //         Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
            //         $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
            //         return $this->sendResponse($this->response, 200);
            //     }

            //     $quotationId = $request->quotation_id; //this is the id of temp Quotation Table

            //     $quotationObject = ProjectQuotation::where('fk_project_quotation_temp_id', $quotationId)->first();

            //     if (!$quotationObject) {
            //         $this->response['error'] = __('admin.id_not_found', ['module' => "Quotation"]);
            //         return $this->sendResponse($this->response, 200);
            //     }


            //     $fk_rfq_id = $quotationObject->fk_rfq_id;
            //     $fk_lead_id = $quotationObject->fk_lead_id;
            //     $poDate = $request->po_date ? Carbon::createFromFormat('d/m/Y', $request->po_date)->format('Y-m-d H:i:s') : '';
            //     $poDetails = $request->po_details ?? [];
            //     $serviceDetails = $request->service_details ?? [];
            //     $po_details_total = $request->po_details_total;
            //     $poNo = $request->po_no;

            //     if ($serviceDetails) {
            //         $serviceTotal = array_reduce($serviceDetails, function ($carry, $item) {
            //             return $carry + (is_array($item) && isset($item['total_amount']) ? intval($item['total_amount']) : 0);
            //         }, 0);
            //     }

            //     if (empty($poDetails)) {
            //         $this->response["errors"] = ["po_details" => "Please Fill the Purchase Order Details"];
            //         return $this->sendResponse($this->response, 200);
            //     }

            //     $rfqObject = Rfq::find($fk_rfq_id);

            //     $isCurrencyUsd = $rfqObject->currency ?? null;

            //     if ($isCurrencyUsd) {
            //         $usdToInrRateResponse = getUsdToInrRate();
            //         if (isset($usdToInrRateResponse['error']) && !empty($usdToInrRateResponse['error'])) {
            //             $this->response['error'] = $usdToInrRateResponse['error'];
            //             return $this->sendResponse($this->response, 200);
            //         }

            //         $usdToInrRate = $usdToInrRateResponse['data'];

            //         $finalAmountInInr = $po_details_total * floatval($usdToInrRate);
            //     }

            //     $poDetailsEmpty = false;

            //     foreach ($poDetails as $key => $item) {
            //         if (empty($item['product_id']) || empty($item['part_no']) || empty($item['qty']) || empty($item['rate'])) {
            //             $poDetailsEmpty = true;
            //             break;
            //         }
            //     }

            //     if ($poDetailsEmpty) {
            //         $this->response["errors"] = ["po_details" => "Please fill all Purchase Order Details"];
            //         return $this->sendResponse($this->response, 200);
            //     }

            //     $serviceDetails = json_encode($serviceDetails);
            //     $poDetails = json_encode($poDetails);

            //     $poObject = new PurchaseOrder();
            //     $poId = $request->po_id ?? 0;

            //     if ($poId != 0) {
            //         $poObject = PurchaseOrder::find($poId);

            //         if (!$poObject) {
            //             $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
            //             return $this->sendResponse($this->response, 200);
            //         }
            //         $poObject->first();
            //         $poObject->updated_by = $this->userId;
            //     } else {
            //         $poObject->created_by = $this->userId;
            //     }


            //     $poObject->fk_quotation_id = $quotationId;
            //     $poObject->fk_rfq_id = $fk_rfq_id;
            //     $poObject->fk_lead_id = $fk_lead_id;
            //     $poObject->po_date = $poDate;
            //     $poObject->po_no = $poNo;
            //     $poObject->po_details = $poDetails;
            //     $poObject->service_details = $serviceDetails;
            //     $poObject->service_total = $serviceTotal ?? 0;
            //     $poObject->po_details_total = $po_details_total;
            //     $poObject->final_amount_in_inr = $finalAmountInInr;
            //     $poObject->prepared_by = $this->userId;
            //     $poObject->po_status = PoStatus::ACTIVE;
            //     $poObject->curr_stage_id = $curr_stage_id;
            //     $poObject->curr_sub_stage_id = $curr_sub_stage_id;
            //     $poObject->curr_user = $curr_user;
            //     $poObject->curr_user_ids = $ids;
            //     $poObject->comm_users = $comm_user;
            //     $poObject->comm_user_ids = $commUsersIds;
            //     $poObject->attachments = $attachments;
            //     $poObject->comments = $comments;

            //     $poObject->save();

            //     $poObject->action = 'created';
            //     if ($poId != 0) {
            //         $poObject->action = 'updated';
            //     }

            //     PoLogCreated::dispatch($poObject);
            // }


            if ($curr_sub_stage_id > 34 && $curr_sub_stage_id !== 37 && $curr_sub_stage_id !== 57) {

                $quotationId = $request->quotation_id; //this is the id of temp Quotation Table
                $poId = $request->po_id;

                $quotationObject = ProjectQuotation::where('fk_project_quotation_temp_id', $quotationId)->first();

                if (!$quotationObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Quotation"]);
                    return $this->sendResponse($this->response, 200);
                }

                $poObject = PurchaseOrder::where('id', $poId)->first();
                if (!$poObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                    return $this->sendResponse($this->response, 200);
                }

                $fk_po_id = $poId;
                $fk_quotation_id = $quotationId;
                $fk_rfq_id = $quotationObject->fk_rfq_id;
                $fk_lead_id = $quotationObject->fk_lead_id;

                if ($curr_sub_stage_id == 40) { // Credit Client Confirm Not
                    $leadObject = Lead::where('id', $projectObject->lead_id)->first();

                    if (!$leadObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Lead"]);
                        return $this->sendResponse($this->response, 200);
                    }


                    if ($leadObject->client_type == ClientType::CREDIT->value) {
                        if ($leadObject->credit_limit > 0) {
                            $creditLimit = $leadObject->credit_limit ?? 0;

                            $sumOfInvoices = PurchaseInvoice::where('fk_lead_id', $leadObject->id)
                                ->sum('pi_total_amount');


                            $sumOfInvoicePayments = PurchaseInvoicePayment::where('fk_lead_id', $leadObject->id)
                                ->sum('payment_amount');

                            $pending = $sumOfInvoices - $sumOfInvoicePayments;
                            $pendingCreditLimit = max(0, $creditLimit - $pending);


                            // if ((float)$poObject->po_details_total > $pendingCreditLimit) {
                            //   $this->response['error'] = 'Your Purchase Order Amount : ' . $poObject->po_details_total . ' Exceeding the Credit limit : ' . $pendingCreditLimit;
                            //   return $this->sendResponse($this->response, 200);
                            // }
                        }
                    }
                }

                // if ($curr_sub_stage_id == 41) { // For Purchase Invoice
                //   $validationErrors = $this->validatePi($request);
                //   if (count($validationErrors)) {
                //     Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                //     $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                //     return $this->sendResponse($this->response, 200);
                //   }

                //   $pi_date = Carbon::createFromFormat('d/m/Y g:i A', $request->pi_date)->format('Y-m-d H:i:s');
                //   // $pi_no = $request->pi_no;
                //   $pi_details = $request->pi_details ?? [];
                //   $pi_total_amount = $request->pi_total_amount;
                //   $pi_remark = $request->pi_remark;


                //   if (empty($pi_details)) {
                //     $this->response["errors"] = ["pi_details" => "Please Fill the Purchase Invoice Details"];
                //     return $this->sendResponse($this->response, 200);
                //   }

                //   $poDetailsEmpty = false;

                //   foreach ($pi_details as $key => $item) {
                //     if (empty($item['part_no']) || empty($item['qty']) || empty($item['rate'])) {
                //       $poDetailsEmpty = true;
                //       break;
                //     }
                //   }

                //   if ($poDetailsEmpty) {
                //     $this->response["errors"] = ["pi_details" => "Please fill all Sales Order Details"];
                //     return $this->sendResponse($this->response, 200);
                //   }


                //   $pi_details = json_encode($pi_details);
                //   $piObject = new PurchaseInvoice();

                //   $lastEntry = PurchaseInvoice::latest('id')->first();
                //   $lastId = $lastEntry ? $lastEntry->id : 0;
                //   $pi_no = generateUniqueNumber($lastId, "AVL-PI");

                //   $piObject->fk_po_id = $fk_po_id;
                //   $piObject->fk_quotation_id = $fk_quotation_id;
                //   $piObject->fk_rfq_id = $fk_rfq_id;
                //   $piObject->fk_lead_id = $fk_lead_id;
                //   $piObject->pi_no = $pi_no;
                //   $piObject->pi_date = $pi_date;
                //   $piObject->pi_details = $pi_details;
                //   $piObject->pi_total_amount = $pi_total_amount;
                //   $piObject->pi_total_amount_paid =  $piObject->pi_total_amount_paid ?? 0;
                //   $piObject->pi_total_amount_pending =  max(0, $pi_total_amount - ($piObject->pi_total_amount_paid ?? 0));
                //   $piObject->payment_done =  $piObject->pi_total_amount_pending > 0  ?  0 : 1;

                //   $piObject->remark = $pi_remark;
                //   $piObject->save();
                // }

                // if ($curr_sub_stage_id == 43) { // Packaging List
                //     $validationErrors = $this->validatePackagingList($request);

                //     if (count($validationErrors)) {
                //         Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                //         $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                //         return $this->sendResponse($this->response, 200);
                //     }

                //     $packaging_date = Carbon::createFromFormat('d/m/Y g:i A', $request->packaging_date)->format('Y-m-d H:i:s');
                //     $packaging_no = $request->packaging_no;
                //     $packaging_ramark = $request->packaging_ramark;

                //     $poPackagingListObject = new PurchaseOrderPackagingList();
                //     $packaging_id = $request->packaging_id ?? 0;

                //     if ($packaging_id != 0) {
                //         $poPackagingListObject = PurchaseOrderPackagingList::find($packaging_id);

                //         if (!$poPackagingListObject) {
                //             $this->response['error'] = __('admin.id_not_found', ['module' => "Packaging List"]);
                //             return $this->sendResponse($this->response, 401);
                //         }
                //         $poPackagingListObject->first();
                //     }

                //     $poPackagingListObject->fk_po_id = $fk_po_id;
                //     $poPackagingListObject->fk_quotation_id = $fk_quotation_id;
                //     $poPackagingListObject->fk_rfq_id = $fk_rfq_id;
                //     $poPackagingListObject->fk_lead_id = $fk_lead_id;
                //     $poPackagingListObject->packaging_no = $packaging_no;
                //     $poPackagingListObject->packaging_date = $packaging_date;
                //     $poPackagingListObject->remark = $packaging_ramark;
                //     $poPackagingListObject->save();
                // }

                // if ($curr_sub_stage_id == 44) { // for Labelling
                //     $validationErrors = $this->validateLabelling($request);

                //     if (count($validationErrors)) {
                //         Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                //         $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                //         return $this->sendResponse($this->response, 200);
                //     }

                //     $label_date = Carbon::createFromFormat('d/m/Y g:i A', $request->label_date)->format('Y-m-d H:i:s');
                //     $label_no = $request->label_no;
                //     $label_ramark = $request->label_ramark;

                //     $poLabellingObject = new PurchaseOrderLabelling();
                //     $label_id = $request->label_id ?? 0;

                //     if ($label_id != 0) {
                //         $poLabellingObject = PurchaseOrderLabelling::find($label_id);

                //         if (!$poLabellingObject) {
                //             $this->response['error'] = __('admin.id_not_found', ['module' => "Labelling"]);
                //             return $this->sendResponse($this->response, 401);
                //         }
                //         $poLabellingObject->first();
                //     }

                //     $poLabellingObject->fk_po_id = $fk_po_id;
                //     $poLabellingObject->fk_quotation_id = $fk_quotation_id;
                //     $poLabellingObject->fk_rfq_id = $fk_rfq_id;
                //     $poLabellingObject->fk_lead_id = $fk_lead_id;
                //     $poLabellingObject->label_no = $label_no;
                //     $poLabellingObject->label_date = $label_date;
                //     $poLabellingObject->remark = $label_ramark;
                //     $poLabellingObject->save();
                // }

                // if ($curr_sub_stage_id == 45) { // for DN Invoice
                //     $validationErrors = $this->validateDneInvoice($request);

                //     if (count($validationErrors)) {
                //         Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                //         $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                //         return $this->sendResponse($this->response, 200);
                //     }

                //     $dne_invoice_date = Carbon::createFromFormat('d/m/Y g:i A', $request->dne_invoice_date)->format('Y-m-d H:i:s');
                //     $dne_invoice_no = $request->dne_invoice_no;
                //     $dne_invoice_remark = $request->dne_invoice_remark;

                //     $poDneInvoiceObject = new PurchaseOrderDneInvoice();
                //     $dne_invoice_id = $request->dne_invoice_id ?? 0;

                //     if ($dne_invoice_id != 0) {
                //         $poDneInvoiceObject = PurchaseOrderDneInvoice::find($dne_invoice_id);

                //         if (!$poDneInvoiceObject) {
                //             $this->response['error'] = __('admin.id_not_found', ['module' => "DN/E Invoice"]);
                //             return $this->sendResponse($this->response, 401);
                //         }
                //         $poDneInvoiceObject->first();
                //     }

                //     $poDneInvoiceObject->fk_po_id = $fk_po_id;
                //     $poDneInvoiceObject->fk_quotation_id = $fk_quotation_id;
                //     $poDneInvoiceObject->fk_rfq_id = $fk_rfq_id;
                //     $poDneInvoiceObject->fk_lead_id = $fk_lead_id;
                //     $poDneInvoiceObject->dne_invoice_no = $dne_invoice_no;
                //     $poDneInvoiceObject->dne_invoice_date = $dne_invoice_date;
                //     $poDneInvoiceObject->remark = $dne_invoice_remark;
                //     $poDneInvoiceObject->save();
                // }

                // if ($curr_sub_stage_id == 54) { // When E-Invoice Prepared Uploaded

                //     $validationErrors = $this->validateEInvoice($request);

                //     if (count($validationErrors)) {
                //         Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                //         $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                //         return $this->sendResponse($this->response, 200);
                //     }

                //     $eInvoiceDate = Carbon::createFromFormat('d/m/Y g:i A', $request->e_invoice_date)->format('Y-m-d H:i:s');
                //     $eInvoiceNo = $request->e_invoice_no;
                //     $eInvoiceRemark = $request->e_invoice_remark ?? '';
                //     $invoiceChargesDetail = $request->invoice_charges_detail ?? [];

                //     $poEInvoiceObject = new PurchaseOrderEInvoice();
                //     $eInvoiceId = $request->eInvoiceId ?? 0;

                //     if ($eInvoiceId != 0) {
                //         $poEInvoiceObject = PurchaseOrderEInvoice::find($eInvoiceId);
                //         $poEInvoiceObject->updated_by = $this->userId;
                //         if (!$poEInvoiceObject) {
                //             $this->response['error'] = __('admin.id_not_found', ['module' => "E Invoice"]);
                //             return $this->sendResponse($this->response, 401);
                //         }
                //         $poEInvoiceObject->first();
                //     }

                //     $poEInvoiceObject->fk_po_id = $fk_po_id;
                //     $poEInvoiceObject->fk_quotation_id = $fk_quotation_id;
                //     $poEInvoiceObject->fk_rfq_id = $fk_rfq_id;
                //     $poEInvoiceObject->fk_lead_id = $fk_lead_id;
                //     $poEInvoiceObject->e_invoice_date = $eInvoiceDate;
                //     $poEInvoiceObject->e_invoice_no = $eInvoiceNo;
                //     $poEInvoiceObject->remark = $eInvoiceRemark;
                //     $poEInvoiceObject->invoice_charges_detail = json_encode($invoiceChargesDetail);
                //     $poEInvoiceObject->created_by = $this->userId;
                //     $poEInvoiceObject->save();
                // }

                // if ($curr_sub_stage_id == 53) { // for EVA Bill
                //     $validationErrors = $this->validateEVABill($request);

                //     if (count($validationErrors)) {
                //         Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                //         $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                //         return $this->sendResponse($this->response, 200);
                //     }

                //     $eva_bill_date = Carbon::createFromFormat('d/m/Y g:i A', $request->eva_bill_date)->format('Y-m-d H:i:s');
                //     $eva_bill_no = $request->eva_bill_no;

                //     $evaBillObject = new EvaBill();
                //     $evaBillId = $request->eva_bill_id ?? 0;

                //     if ($evaBillId != 0) {
                //         $evaBillObject = EvaBill::find($evaBillId);

                //         if (!$evaBillObject) {
                //             $this->response['error'] = __('admin.id_not_found', ['module' => "EVA Bill"]);
                //             return $this->sendResponse($this->response, 401);
                //         }
                //         $evaBillObject->first();
                //     }

                //     $evaBillObject->fk_po_id = $fk_po_id;
                //     $evaBillObject->fk_quotation_id = $fk_quotation_id;
                //     $evaBillObject->fk_rfq_id = $fk_rfq_id;
                //     $evaBillObject->fk_lead_id = $fk_lead_id;
                //     $evaBillObject->eva_bill_no = $eva_bill_no;
                //     $evaBillObject->eva_bill_date = $eva_bill_date;
                //     $evaBillObject->save();
                // }

                if ($curr_sub_stage_id == 46) { // for Quality Report
                    $validationErrors = $this->validateQualityReport($request);

                    if (count($validationErrors)) {
                        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                        return $this->sendResponse($this->response, 200);
                    }

                    $quality_report_date = Carbon::createFromFormat('d/m/Y g:i A', $request->quality_report_date)->format('Y-m-d H:i:s');
                    $quality_report_no = $request->quality_report_no;
                    $quality_rmtc_no = $request->quality_rmtc_no;
                    $quality_report_ramark = $request->quality_report_ramark;

                    $poPdrQualityObject = new PurchaseOrderPdrQuality();
                    $quality_report_id = $request->quality_report_id ?? 0;

                    if ($quality_report_id != 0) {
                        $poPdrQualityObject = PurchaseOrderPdrQuality::find($quality_report_id);

                        if (!$poPdrQualityObject) {
                            $this->response['error'] = __('admin.id_not_found', ['module' => "PDR /Quality"]);
                            return $this->sendResponse($this->response, 401);
                        }
                        $poPdrQualityObject->first();
                    }

                    $poPdrQualityObject->fk_po_id = $fk_po_id;
                    $poPdrQualityObject->fk_quotation_id = $fk_quotation_id;
                    $poPdrQualityObject->fk_rfq_id = $fk_rfq_id;
                    $poPdrQualityObject->fk_lead_id = $fk_lead_id;
                    $poPdrQualityObject->quality_report_no = $quality_report_no;
                    $poPdrQualityObject->quality_rmtc_no = $quality_rmtc_no;
                    $poPdrQualityObject->quality_report_date = $quality_report_date;
                    $poPdrQualityObject->remark = $quality_report_ramark;
                    $poPdrQualityObject->save();
                }

                if ($curr_sub_stage_id == 56) {
                    $invoiceObj = AvlockPurchaseInvoice::where('fk_po_id', $fk_po_id)->first();
                    if (is_null($invoiceObj)) {
                        $this->response['error'] = "The invoice needs to be generated first.";
                        return $this->sendResponse($this->response, 200);
                    }
                }

                // if ($curr_sub_stage_id == 47) { // for LR
                //     $validationErrors = $this->validateLr($request);

                //     if (count($validationErrors)) {
                //         Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                //         $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                //         return $this->sendResponse($this->response, 200);
                //     }

                //     $lr_date = Carbon::createFromFormat('d/m/Y g:i A', $request->lr_date)->format('Y-m-d H:i:s');
                //     $lr_no = $request->lr_no;
                //     $lr_ramark = $request->lr_ramark;

                //     $poLrObject = new PurchaseOrderLr();
                //     $lr_id = $request->lr_id ?? 0;

                //     if ($lr_id != 0) {
                //         $poLrObject = PurchaseOrderLr::find($lr_id);

                //         if (!$poLrObject) {
                //             $this->response['error'] = __('admin.id_not_found', ['module' => "LR"]);
                //             return $this->sendResponse($this->response, 401);
                //         }
                //         $poLrObject->first();
                //     }

                //     $poLrObject->fk_po_id = $fk_po_id;
                //     $poLrObject->fk_quotation_id = $fk_quotation_id;
                //     $poLrObject->fk_rfq_id = $fk_rfq_id;
                //     $poLrObject->fk_lead_id = $fk_lead_id;
                //     $poLrObject->lr_no = $lr_no;
                //     $poLrObject->lr_date = $lr_date;
                //     $poLrObject->remark = $lr_ramark;
                //     $poLrObject->save();
                // }


                $attachments = json_encode($files) ?? '';

                $poObject->curr_stage_id = $curr_stage_id;
                $poObject->curr_sub_stage_id = $curr_sub_stage_id;
                $poObject->curr_user = $curr_user;
                $poObject->curr_user_ids = $ids;
                $poObject->comm_users = $comm_user;
                $poObject->comm_user_ids = $commUsersIds;
                if (empty($poObject)) {
                    $poObject->attachments = $attachments;
                }
                $poObject->comments = $comments;
                $poObject->is_verified = 1;
                $poObject->updated_by = $this->userId;
                $poObject->save();

                $poObject->action = 'updated';

                PoLogCreated::dispatch($poObject);
            }


            if ($curr_sub_stage_id == 39) { //When material planning initiated
                $dispatchDetail = PoDespatchDetail::where('po_id', $poObject->id)->get();

                if ($dispatchDetail->isEmpty()) {
                    $this->response['error'] = 'Please fill dispatch detail.';
                    return $this->sendResponse($this->response, 200);
                }
            }

            if ($curr_sub_stage_id == 49) { // When Delivery Confirmation

                $validationErrors = $this->validateDeliveryConfirmation($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $deliveryDate = Carbon::createFromFormat('d/m/Y g:i A', $request->delivery_date)->format('Y-m-d H:i:s');
                $recievedBy = $request->recieved_by;

                $poDneInvoiceObject = new PurchaseOrderDneInvoice();
                $dne_invoice_id = $request->dne_invoice_id ?? 0;

                if ($dne_invoice_id != 0) {
                    $poDneInvoiceObject = PurchaseOrderDneInvoice::find($dne_invoice_id);

                    if (!$poDneInvoiceObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Delivery Confirmation"]);
                        return $this->sendResponse($this->response, 401);
                    }
                    $poDneInvoiceObject->first();
                }

                $poDneInvoiceObject->delivery_date = $deliveryDate;
                $poDneInvoiceObject->recieved_by = $recievedBy;
                $poDneInvoiceObject->updated_by = $this->userId;
                $poDneInvoiceObject->save();
            }

            // if ($curr_sub_stage_id == 55) { // When R Note Received

            //   $validationErrors = $this->validateRnote($request);

            //   if (count($validationErrors)) {
            //     Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
            //     $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
            //     return $this->sendResponse($this->response, 200);
            //   }

            //   $rnDate = Carbon::createFromFormat('d/m/Y g:i A', $request->rn_date)->format('Y-m-d H:i:s');
            //   $rnNo = $request->rn_no;
            //   $rnRemark = $request->rn_remark ?? '';

            //   $rnObject = new PurchaseOrderRnr();
            //   $rnId = $request->rn_id ?? 0;

            //   if ($rnId != 0) {
            //     $rnObject = PurchaseOrderRnr::find($rnId);

            //     if (!$rnObject) {
            //       $this->response['error'] = __('admin.id_not_found', ['module' => "R Note received"]);
            //       return $this->sendResponse($this->response, 401);
            //     }
            //     $rnObject->first();
            //   }

            //   $rnObject->fk_po_id = $fk_po_id;
            //   $rnObject->fk_quotation_id = $fk_quotation_id;
            //   $rnObject->fk_rfq_id = $fk_rfq_id;
            //   $rnObject->fk_lead_id = $fk_lead_id;
            //   $rnObject->rn_date = $rnDate;
            //   $rnObject->rn_no = $rnNo;
            //   $rnObject->remark = $rnRemark;
            //   $rnObject->updated_by = $this->userId;
            //   $rnObject->save();
            // }


            // if ($curr_sub_stage_id == 49) { // When Delivery Confirmation

            //   $quotationId = $request->quotation_id;

            //   $quotationObject = ProjectQuotation::find($quotationId);

            //   if (!$quotationObject) {
            //     $this->response['error'] = __('admin.id_not_found', ['module' => "Quotation"]);
            //     return $this->sendResponse($this->response, 200);
            //   }

            //   $activePo = PurchaseOrder::where('fk_quotation_id', $quotationId)->where('po_status', PoStatus::ACTIVE)->first();
            //   if ($activePo) {
            //     $activePo->po_status = PoStatus::DELIVERY_CONFIRMED;
            //     $activePo->save();
            //     $activePo->action = 'updated';

            //     PoLogCreated::dispatch($activePo);
            //   }
            // }

            // if ($curr_sub_stage_id == 50) { // When PO Not Match

            //   $quotationId = $request->quotation_id;

            //   $quotationObject = ProjectQuotation::find($quotationId);

            //   if (!$quotationObject) {
            //     $this->response['error'] = __('admin.id_not_found', ['module' => "Quotation"]);
            //     return $this->sendResponse($this->response, 200);
            //   }

            //   $activePo = PurchaseOrder::where('fk_quotation_id', $quotationId)->where('po_status', PoStatus::ACTIVE)->first();
            //   if ($activePo) {
            //     $activePo->po_status = PoStatus::PO_NOT_MATCH;
            //     $activePo->save();
            //     $activePo->action = 'updated';

            //     PoLogCreated::dispatch($activePo);
            //   }
            // }
            $projectObject->curr_stage_id = $curr_stage_id;
            $projectObject->curr_sub_stage_id = $curr_sub_stage_id;
            $projectObject->curr_user = $curr_user;
            $projectObject->curr_user_ids = $ids;
            $projectObject->comm_users = $comm_user;
            $projectObject->comm_user_ids = $commUsersIds;
            $projectObject->attachments = $attachments;
            $projectObject->comments = $comments;
            $projectObject->updated_by = $this->userId;
            $projectObject->fk_po_id = $request->po_id ?? 0;

            if ($curr_sub_stage_id == 8) {
                $projectObject->fk_supplier_id = $request->fk_supplier_id;
            }


            $projectObject->save();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.updated', ['module' => "Project"]);

            $projectObject->action = 'updated';
            $projectObject->action_from = 'project';

            RfqLogCreated::dispatch($projectObject);
            ProjectLogCreated::dispatch($projectObject);

            $requestData = $request->all();
            $ids = explode(',', $ids);

            // Send Email Notification
            $currentUrl = URL::to('/');
            if (!str_contains($currentUrl, 'localhost')) {
                SendStageChangeNotification::dispatch($ids, $requestData);
            }

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed Updating Project: " . $e);
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e);
            $this->response['error'] = __('admin.record_not_found', ['module' => "Project"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    public function getAttachments(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $rfqId = $request->rfq_id ?? '';
            $projectObject = Rfq::find($rfqId);

            if (!$projectObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project"]);
                return $this->sendResponse($this->response, 401);
            }

            $projectAttachments = RfqAttachment::where('rfq_id', $rfqId)->orderBy("id", "desc");
            $num_rows = $projectAttachments->count();

            $result = $projectAttachments->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Project Attachment"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['list'] = $result;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project Attachments fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function getProjectLogs(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            // $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            // $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            // $offset = ($page - 1) * $per_page;

            $rfqId = $request->rfq_id ?? '';
            $projectObject = Rfq::find($rfqId);

            if (!$projectObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project"]);
                return $this->sendResponse($this->response, 200);
            }

            $curr_sub_stage_id = $request->curr_sub_stage_id ?? "";

            $projectLogs = ProjectLog::with('stage', 'subStage', 'po', 'rfq.quotation')->where('fk_rfq_id', $rfqId)->orderBy("id", "desc");
            if ($curr_sub_stage_id) $projectLogs->where('curr_sub_stage_id',  $curr_sub_stage_id);


            $num_rows = $projectLogs->count();

            $result = $projectLogs->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Project Logs"]);
            // $this->response['data']['page'] = $page;
            // $this->response['data']['per_page'] = $per_page;
            // $this->response['data']['num_rows'] = $num_rows;
            // $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['curr_sub_stage_id'] = $curr_sub_stage_id;

            $this->response['data']['list'] = ProjectLogResource::collection($result);

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project Logs fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function getPoLogs(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            // $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            // $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            // $offset = ($page - 1) * $per_page;

            $rfqId = $request->rfq_id ?? '';
            $projectObject = Rfq::find($rfqId);

            if (!$projectObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project"]);
                return $this->sendResponse($this->response, 200);
            }

            $poId = $request->po_id ?? "";
            $curr_sub_stage_id = $request->curr_sub_stage_id ?? "";

            $poLogs = PurchaseOrderLog::with('stage', 'subStage')->where('fk_rfq_id', $rfqId)->orderBy("id", "desc");
            if ($poId) $poLogs->where('fk_po_id',  $poId);
            if ($curr_sub_stage_id) $poLogs->where('curr_sub_stage_id',  $curr_sub_stage_id);


            $num_rows = $poLogs->count();

            $result = $poLogs->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Purchase Order Logs"]);
            // $this->response['data']['page'] = $page;
            // $this->response['data']['per_page'] = $per_page;
            // $this->response['data']['num_rows'] = $num_rows;
            // $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['curr_sub_stage_id'] = $curr_sub_stage_id;

            $this->response['data']['list'] = PurchaseOrderLogResource::collection($result);

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project Logs fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function getProjectLost(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }


            $projectLostObj = ProjectLost::get();

            if (!$projectLostObj) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project Lost"]);
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Project Lost"]);
            $this->response['data']['list'] = $projectLostObj;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project Logs fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function getStageToDepartments(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $subStageId = $request->stage ?? '';
            $subStageObject = SubStage::find($subStageId);

            if (!$subStageObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Stage"]);
                return $this->sendResponse($this->response, 200);
            }
            $toDepartmentIds = [];
            $toDepartments = $subStageObject->to_departments ?? '';
            if ($toDepartments != '') {
                $toDepartmentIds = array_merge($toDepartmentIds, explode(",", $toDepartments));
            }

            $selectDepartment = Department::whereIn('id', $toDepartmentIds)->get()->toArray();
            $toDepartmentString = implode(', ', array_column($selectDepartment, 'title'));

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Stage Departments"]);
            $this->response['data']['to_department_string'] = $toDepartmentString;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Stage Department fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getLatestComment(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $rfqId = $request->fk_rfq_id;
            $leadId = $request->lead_id;
            $projectObject = ProjectLog::where(['fk_rfq_id' => $rfqId, 'lead_id' => $leadId])->orderBy('updated_at', 'desc')->get(['id', 'comments', 'comm_users', 'updated_at', 'updated_by']);

            $stageComments = [];

            foreach ($projectObject as $project) {
                $formattedDate = $project->updated_at->format('Y-m-d H:i:s') ?? '';
                $comments = $project->comments;

                $commUsers = json_decode($project->comm_users, true);
                $userName = [];

                if (is_array($commUsers)) {
                    foreach ($commUsers as $user) {
                        $userName[] = $user['name'] ?? '';
                    }
                }

                $userNameString = implode(', ', $userName);

                if (!empty($comments)) {
                    $stageComments[] = [
                        'user' => $userNameString,
                        'comment' => $comments,
                        'date' => $formattedDate,
                    ];
                }
            }

            if (!$projectObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project Log Comment"]);
                return $this->sendResponse($this->response, 500);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Project Log Comment"]);
            $this->response['data'] = $stageComments;


            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project Log Comment fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getClientType(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Client Type"]);
            $this->response['data']['list'] = ClientType::getListForHTML();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Client Type fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getCharges(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Charges"]);
            // $this->response['data']['list'] = Charges::getListForHTML();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Charges fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function skipSubStage(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $stageId = $request->stage_id ?? '';
            $rfqId = $request->rfq_id ?? '';
            $isSkip = $request->is_skip ?? 0;
            $subStageObject = SubStage::find($stageId);

            if (!$subStageObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Sub Stage"]);
                return $this->sendResponse($this->response, 401);
            }

            $rfq = Rfq::find($rfqId);

            if (!$rfq) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "RFQ"]);
                return $this->sendResponse($this->response, 401);
            }

            if ($isSkip == 1) {
                if ($subStageObject) {
                    $currSubstageOrder = $subStageObject->order;
                    $currStageId = $subStageObject->stage_id;
                    $nextSubStageOrder = $currSubstageOrder + 1;

                    $nextSubStage = SubStage::where(['status' => 1, 'order' => $nextSubStageOrder, 'stage_id' => $currStageId])->orWhere(['id' => $rfq->curr_sub_stage_id])->orderBy('order', 'asc')->get();
                    $message = $subStageObject->name ? $subStageObject->name . ' stage has been skipped.' : 'Stage has been skipped.';
                }
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Sub Satge"]);
            $this->response['data']['list'] = $nextSubStage ?? [];
            $this->response['data']['message'] = $message ?? '';

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Charges fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function validateUpdateStage(Request $request)
    {
        return Validator::make($request->all(), [
            // 'curr_stage_id' => 'required',
            'curr_sub_stage_id' => 'required',
            'curr_user' => in_array($request->curr_sub_stage_id, [17, 18, 27, 32, 33, 51]) ? '' : 'required', // not require when project heading towards client
            'fk_supplier_id' => in_array($request->curr_sub_stage_id, [8]) ? 'required' : '', // Supplier is require when Supplier Selection By PSM
            // 'credit_limit' => [
            //   'required_if:curr_sub_stage_id,22', // Require credit_limit if curr_sub_stage_id is RFQ Approved
            //   'not_in:0',
            // ],
            // 'credit_days' => [
            //   'required_if:curr_sub_stage_id,22', // Require credit_limit if curr_sub_stage_id is RFQ Approved
            // ],
            'client_type' => [
                'required_if:curr_sub_stage_id,22', // Require client_type if curr_sub_stage_id RFQ Approved
            ],
            // 'attachments' => in_array($request->curr_sub_stage_id, [34, 37, 41, 43, 44, 45, 46, 47]) ? 'required' : '',
            'attachments' => in_array($request->curr_sub_stage_id, config('global.ATTACHMENT_REQUIRED_STAGE')) ? 'required' : '',
        ], [
            'fk_supplier_id.required' => "Please Select Supplier",
            'credit_days.required_if' => "Credit Days is required",
            'client_type.required_if' => "Client Type is required",
            'credit_limit.not_in' => "Credit Limit Cannot Be Zero",
        ])->errors();
    }

    private function validateAddUpdatePurchaseOrder(Request $request)
    {
        return Validator::make($request->all(), [
            'po_date' => 'required|date_format:d/m/Y',
            'po_no' => 'required',

        ])->errors();
    }

    private function validateAgreement(Request $request)
    {
        return Validator::make($request->all(), [
            'agreement_date' => 'required|date_format:d/m/Y g:i A',
            'agreement_no' => 'required',

        ])->errors();
    }

    private function validatePi(Request $request)
    {
        return Validator::make($request->all(), [
            'pi_date' => 'required|date_format:d/m/Y g:i A',
            // 'agreement_no' => 'required',

        ])->errors();
    }

    private function validatePackagingList(Request $request)
    {
        return Validator::make($request->all(), [
            'packaging_date' => 'required|date_format:d/m/Y g:i A',
            'packaging_no' => 'required',

        ])->errors();
    }

    private function validateLabelling(Request $request)
    {
        return Validator::make($request->all(), [
            'label_date' => 'required|date_format:d/m/Y g:i A',
            'label_no' => 'required',

        ])->errors();
    }

    private function validateDneInvoice(Request $request)
    {
        return Validator::make($request->all(), [
            'dne_invoice_date' => 'required|date_format:d/m/Y g:i A',
            'dne_invoice_no' => 'required',
        ])->errors();
    }

    private function validateEInvoice(Request $request)
    {
        return Validator::make($request->all(), [
            'e_invoice_date' => 'required|date_format:d/m/Y g:i A',
            'e_invoice_no' => 'required',
            'invoice_charges_detail.*.id' => 'required|distinct|numeric',
            'invoice_charges_detail.*.amount' => 'required|numeric',
        ], [
            'invoice_charges_detail.*.id.required' => "Invoice charges is required",
            'invoice_charges_detail.*.id.distinct' => "Invoice charges already added",
            'invoice_charges_detail.*.amount.required' => "Amount is required",
        ])->errors();
    }

    private function validateEVABill(Request $request)
    {
        return Validator::make($request->all(), [
            'eva_bill_date' => 'required|date_format:d/m/Y g:i A',
            'eva_bill_no' => 'required',
        ])->errors();
    }

    private function validateQualityReport(Request $request)
    {
        return Validator::make($request->all(), [
            'quality_report_date' => 'required|date_format:d/m/Y g:i A',
            'quality_report_no' => 'required',
            'quality_rmtc_no' => 'required',

        ])->errors();
    }

    private function validateLr(Request $request)
    {
        return Validator::make($request->all(), [
            'lr_date' => 'required|date_format:d/m/Y g:i A',
            'lr_no' => 'required',

        ])->errors();
    }

    private function validateDeliveryConfirmation(Request $request)
    {
        return Validator::make($request->all(), [
            'delivery_date' => 'required|date_format:d/m/Y g:i A',
            'recieved_by' => 'required',

        ])->errors();
    }

    private function validateRnote(Request $request)
    {
        return Validator::make($request->all(), [
            'rn_date' => 'required|date_format:d/m/Y g:i A',
            'rn_no' => 'required',

        ])->errors();
    }
}
