<?php

namespace App\Http\Controllers\API;

use App\Models\DeliveryConfirmation;
use App\Models\Division;
use App\Models\PurchaseOrder;
use App\Models\Rfq;
use App\Models\Tender;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;

class DeliveryConfirmationController extends AppBaseController
{
    function index(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $salesOrderNo = $request->so_no ?? "";
            $dcNo = $request->dc_no ?? "";
            $receivedBy = $request->received_by ?? "";
            $poId = $request->po_id ?? "";


            $dcObject = DeliveryConfirmation::with('so.dispatch')->where('po_id', $poId);

            if ($receivedBy) {
                $dcObject->where('received_by', 'like', '%' . $receivedBy . '%');
            }

            if ($dcNo) {
                $dcObject->where('delivery_confirmation_no', 'like', '%' . $dcNo . '%');
            }

            if ($salesOrderNo) {
                $dcObject->whereHas('so', function ($q) use ($salesOrderNo) {
                    $q->where('so_no', 'like', '%' . $salesOrderNo . '%');
                });
            }

            $num_rows = $dcObject->count();
            $result = $dcObject->limit($per_page)->offset($offset)->get();


            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Delivery Confirmation"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['dc_no'] = $dcNo;
            $this->response['data']['received_by'] = $receivedBy;
            $this->response['data']['so_no'] = $salesOrderNo;
            $this->response['data']['list'] = $result;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Delivery Confirmation List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function get(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $dcId = $request->dc_id ?? "";

            if (!$dcId) {
                $this->response['error'] = "Please select a valid Delivery Confirmation!";
                return $this->sendResponse($this->response, 200);
            }

            $dcObject = DeliveryConfirmation::with('so')->find($dcId);

            if (!$dcObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Delivery Confirmation"]);
                return $this->sendResponse($this->response, 200);
            }


            $this->response['status'] = 1;
            $this->response['data'] = $dcObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Delivery Confirmation Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function addUpdate(Request $request)
    {
        try {

            DB::beginTransaction();

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateDeliveryConfirmation($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $dcObject = new DeliveryConfirmation();
            $id = $request->id;
            $poId = $request->po_id;
            $formattedDate = Carbon::createFromFormat('d/m/Y', $request->dc_date);
            $odMonth = $formattedDate->format('M');
            $dcDate = $formattedDate->format('Y-m-d H:i:s');
            $monthNumber = $formattedDate->format('n');
            $year = $formattedDate->format('Y');
            $financialYearStart = $monthNumber >= 4 ? $year : $year - 1;
            $shortFinYearStart = substr($financialYearStart, -2);
            $shortFinYearEnd = substr($financialYearStart + 1, -2);

            $yourDcNo = $request->your_dc_no ?? '';
            $salesOrderId = $request->sales_order_id ?? '';
            $receivedBy = $request->received_by ?? '';
            $receivedDate = Carbon::createFromFormat('d/m/Y', $request->received_date)->format('Y-m-d H:i:s');
            $poType = $request->po_type ?? '';


            $poObject = PurchaseOrder::find($poId);
            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            if ($poType === 1) {
                $rfqObject = Rfq::find($poObject->fk_rfq_id);
                $division = Division::find($rfqObject->division_id);
            } else {
                $tenderObject = Tender::find($poObject->fk_tender_id);
                $division = Division::find($tenderObject->division_id);
            }

            if (!$division) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Division"]);
                return $this->sendResponse($this->response, 200);
            }


            if (!$division) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Division"]);
                return $this->sendResponse($this->response, 200);
            }

            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }



            if ($id) {
                $dcObject = DeliveryConfirmation::find($id);

                if (!$dcObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Delivery Confirmation"]);
                    return $this->sendResponse($this->response, 200);
                }
                $dcObject->first();

                $this->response['msg'] = __('admin.updated', ['module' => "Delivery Confirmation"]);
            } else {
                $baseString = strtoupper('DC/' . $division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . $odMonth . '/');
                $dcObject->delivery_confirmation_no = generateSeries($baseString, 'delivery_confirmations', 'delivery_confirmation_no');
                $this->response['msg'] = __('admin.created', ['module' => "Delivery Confirmation"]);
            }


            $dcObject->sales_order_id = $salesOrderId;
            $dcObject->po_id = $poId;
            $dcObject->po_type = $poType;
            $dcObject->dc_date = $dcDate;
            $dcObject->your_dc_no = $yourDcNo;
            $dcObject->received_by = $receivedBy;
            $dcObject->received_date = $receivedDate;
            $dcObject->save();

            $this->response['status'] = 1;
            DB::commit();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating Delivery Confirmation: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Delivery Confirmation"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $dcObject = DeliveryConfirmation::find($id);

            if (!$dcObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Delivery Confirmation"]);
                return $this->sendResponse($this->response, 500);
            }

            $dcObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Delivery Confirmation"]);
            $this->response['data'] = $dcObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Delivery Confirmation deleting failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function validateAddUpdateDeliveryConfirmation(Request $request)
    {
        return Validator::make($request->all(), [
            'dc_date' => 'required|date_format:d/m/Y',
            'received_date' => 'required|date_format:d/m/Y',
        ])->errors();
    }
}
