<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\BiddingConsigneeRequirment;
use App\Models\BiddingProductRequirment;
use App\Models\CommonTnc;
use App\Models\Tender;
use App\Models\TenderBidding;
use App\Models\TenderConsigneeRequirment;
use App\Models\TenderProductRequirement;
use App\Models\TenderQuotation;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use PhpParser\Node\Stmt\TryCatch;

class TenderQuotationController extends AppBaseController
{

    public function get(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $tenderId = $request->tender_id ?? '';
            $tender = Tender::with(['products.product', 'products.consignee.unitData', 'currentSubStage', 'subStageUsers'])->find($tenderId);

            if (!$tender) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender"]);
                return $this->sendResponse($this->response, 500);
            }

            $tenderBidding = TenderBidding::where(['tender_id' => $tenderId])->first();
            $biddingProReq = BiddingProductRequirment::where(['tender_id' => $tenderId])->get();
            $divisionId = $tender->division_id ?? '';
            $tnc = CommonTnc::where(['division_id' => $divisionId, 'is_tender' => 0, 'status' => 1])->first();

            $data = [];
            $data['tender'] = $tender ?? '';
            $data['bidding_quotation_id'] = $tenderBidding->id ?? '';
            $data['bidding_quotation_number'] = $tenderBidding->quotation_no ?? '';
            $data['bidding_quotation_date'] = $tenderBidding->quotation_date ?? '';
            $biddingProducts = [];

            if (!empty($biddingProReq)) {
                foreach ($biddingProReq as $key => $tpr) {
                    $id = $tpr->id ?? '';
                    $productId = $tpr->product_id ?? '';
                    $productPartId = $tpr->product_part_id ?? '';
                    $partNo = $tpr->part_no ?? '';
                    $qty = $tpr->qty ?? '';
                    $description = $tpr->description ?? '';
                    $avlockDescription = $tpr->avlock_description ?? '';
                    $rate = $tpr->rate ?? '';

                    $biddingConReq = BiddingConsigneeRequirment::where(['tender_id' => $tenderId, 'product_id' => $id])->get();
                    $biddingConsignee = [];
                    foreach ($biddingConReq as $ckey => $tcr) {
                        $conId = $tcr->id ?? null;
                        $name = $tcr->name ?? '';
                        $conQty = $tcr->qty ?? 0;
                        $conUnit = $tcr->unit ?? 0;
                        $deliveryPeriod = $tcr->delivery_period ?? null;

                        $biddingConsignee[] = [
                            'id' => $conId,
                            'name' => $name,
                            'qty' => $conQty,
                            'unit' => $conUnit,
                            'delivery_period' => $deliveryPeriod,
                        ];
                    }

                    $biddingProducts[] = [
                        'id' => $id,
                        'product_id' => $productId,
                        'product_part_id' => $productPartId,
                        'part_no' => $partNo,
                        'qty' => $qty,
                        'description' => $description,
                        'avlock_description' => $avlockDescription,
                        'rate' => $rate,
                        'consignee' => $biddingConsignee,
                    ];
                }
            }
            $data['bidding_products'] = $biddingProducts;

            $tenderQuotation = TenderQuotation::where(['tender_id' => $tenderId])->first();
            $tenderProReq = TenderProductRequirement::where(['tender_id' => $tenderId])->get();
            $data['quotation_id'] = $tenderQuotation->id ?? '';
            $data['quotation_number'] = $tenderQuotation->quotation_no ?? '';
            $data['quotation_date'] = $tenderQuotation->quotation_date ?? '';
            $data['bidding_standard_term'] = isset($tenderBidding->terms) ? $tenderBidding->terms : ($tnc->terms ?? '');

            $products = [];

            if (!empty($tenderProReq)) {
                foreach ($tenderProReq as $key => $tpr) {
                    $id = $tpr->id ?? '';
                    $productId = $tpr->product_id ?? '';
                    $productPartId = $tpr->product_part_id ?? '';
                    $partNo = $tpr->part_no ?? '';
                    $qty = $tpr->qty ?? '';
                    $description = $tpr->description ?? '';
                    $avlockDescription = $tpr->avlock_description ?? '';
                    $rate = $tpr->rate ?? '';

                    $tenderConReq = TenderConsigneeRequirment::where(['tender_id' => $tenderId, 'product_id' => $id])->get();
                    $consignee = [];
                    foreach ($tenderConReq as $ckey => $tcr) {
                        $conId = $tcr->id ?? null;
                        $name = $tcr->name ?? '';
                        $conQty = $tcr->qty ?? 0;
                        $deliveryPeriod = $tcr->delivery_period ?? null;
                        $unit = $tcr->unit ?? '';

                        $consignee[] = [
                            'id' => $conId,
                            'name' => $name,
                            'qty' => $conQty,
                            'unit' => $unit,
                            'delivery_period' => $deliveryPeriod,
                        ];
                    }

                    $products[] = [
                        'id' => $id,
                        'product_id' => $productId,
                        'product_part_id' => $productPartId,
                        'part_no' => $partNo,
                        'qty' => $qty,
                        'description' => $description,
                        'avlock_description' => $avlockDescription,
                        'rate' => $rate,
                        'consignee' => $consignee,
                    ];
                }
            }
            $data['products_new'] = $products;

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Tender Quotation"]);
            $this->response['data'] = $data;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender Quotation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addUpdate(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateBiddingSubmitted($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $tenderBiddingId = $request->bidding_quotation_id;
            $biddingQuotationdate = $request->bidding_quotation_date;
            $biddingQuotationNumber = $request->bidding_quotation_number;
            $biddingstandardTerm = $request->bidding_standard_term;
            $biddingProducts = $request->bidding_products ?? [];
            $tenderId = $request->tender_id ?? '';
            $userIds = $request->user_ids ?? [];
            $from = $request->from ?? '';
            $subStageId = $request->sub_stage_id ?? [];

            $totalBidValue = array_reduce($biddingProducts, function ($carry, $product) {
                return $carry + ($product['basic_value'] ?? 0);
              }, 0);

            $tenderBidding = new TenderBidding();

            if ($tenderBiddingId != 0) {
                $tenderBidding = TenderBidding::find($tenderBiddingId);

                if (!$tenderBidding) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Bidding"]);
                    return $this->sendResponse($this->response, 500);
                }
                $tenderBidding->updated_by = $this->userId;
            } else {
                $tenderBidding->created_by = $this->userId;
            }

            $usersForTask = User::with('designation')->whereIn('id', $userIds)->get();

            $userDesignation = [];
            foreach ($usersForTask as $ut) {
                $designation = $ut->designation->title;
                $name = $ut->name . ' ' . '(' . $designation . ')';
                $userDesignation[] = [
                    "id" => $ut->id,
                    "name" => $name,
                ];
            }

            $tenderBidding->tender_id = $request->tender_id;
            $tenderBidding->quotation_no = $biddingQuotationNumber;
            $tenderBidding->quotation_date = Carbon::createFromFormat('d/m/Y', $biddingQuotationdate)->format('Y-m-d');
            $tenderBidding->total_bid_value = $totalBidValue;
            $tenderBidding->terms = $biddingstandardTerm;
            if ($from == 'quotationForm') {
                $tenderBidding->user_ids = json_encode($userIds);
                $tenderBidding->users = json_encode($userDesignation);
            }
            $tenderBidding->save();

            $tenderBidding->action = 'created';
            if ($tenderBiddingId) {
                $tenderBidding->action = 'updated';
            }

            //SAVE BIDDING PRODUCTS & CONSIGNEE
            $biddingProductIds = array_column($biddingProducts, 'product_id');
            $biddingProId = array_column($biddingProducts, 'id');

            if (count($biddingProductIds) > 0) {
                // Filter out empty and non-numeric values from $biddingProId
                $biddingProId = array_filter($biddingProId, 'is_numeric');
            }

            // get the product IDs that are not present in the payload
            $tenderProductsToDelete = BiddingProductRequirment::where('tender_id', $tenderId)
                ->whereNotIn('id', $biddingProId)
                ->get();

            // Extract the IDs of the products to be deleted
            $tenderProductIdsToDelete = $tenderProductsToDelete->pluck('id');

            // Delete consignees related to the products to be deleted
            BiddingConsigneeRequirment::where('tender_id', $tenderId)
                ->whereIn('product_id', $tenderProductIdsToDelete)
                ->delete();

            // delete the product IDs that are not present in the payload
            BiddingProductRequirment::where('tender_id', $tenderId)
                ->whereNotIn('id', $biddingProId)
                ->delete();

            foreach ($biddingProducts as $product) {
                $tenderReqId = $product['id'] ?? null;
                $biddingProId = $product['product_id'] ?? null;
                $tenderProPartId = $product['product_part_id'] ?? null;
                $tenderPartNo = $product['part_no'] ?? null;
                $tenderDesc = $product['description'] ?? null;
                $tenderAvlockDesc = $product['avlock_description'] ?? null;
                $tenderQty = $product['qty'];
                $tenderRate = $product['rate'];
                $consignee = $product['consignee'] ?? [];

                $BiddingProductRequirment = BiddingProductRequirment::firstOrNew(
                    ['id' => $tenderReqId, 'tender_id' => $tenderId],
                    ['product_id' => $biddingProId]
                );

                $BiddingProductRequirment->product_id = $biddingProId;
                $BiddingProductRequirment->product_part_id = $tenderProPartId;
                $BiddingProductRequirment->part_no = $tenderPartNo;
                $BiddingProductRequirment->description = $tenderDesc;
                $BiddingProductRequirment->avlock_description = $tenderAvlockDesc;
                $BiddingProductRequirment->qty = $tenderQty;
                $BiddingProductRequirment->rate = $tenderRate;

                if ($BiddingProductRequirment->trashed()) {
                    $BiddingProductRequirment->restore();
                }

                $BiddingProductRequirment->save();

                foreach ($consignee as $singleConsignee) {
                    $conId = $singleConsignee['id'] ?? null;
                    $conProId = $BiddingProductRequirment->id;
                    $conName = $singleConsignee['name'] ?? null;
                    $conQty = $singleConsignee['qty'] ?? null;
                    $conDeliveryPeriod = $singleConsignee['delivery_period'] ?? null;
                    $conUnit = $singleConsignee['unit'] ?? null;

                    $BiddingConsigneeRequirment = BiddingConsigneeRequirment::firstOrNew(['id' => $conId, 'tender_id' => $tenderId], ['product_id' => $conProId]);

                    $BiddingConsigneeRequirment->name = $conName;
                    $BiddingConsigneeRequirment->qty = $conQty;
                    $BiddingConsigneeRequirment->delivery_period = $conDeliveryPeriod;
                    $BiddingConsigneeRequirment->unit = $conUnit;

                    if ($BiddingConsigneeRequirment->trashed()) {
                        $BiddingConsigneeRequirment->restore();
                    }

                    $BiddingConsigneeRequirment->save();
                }
            }

            if ($from == 'quotationForm') {
                $tenderObj = Tender::find($tenderId);
                $tenderObj->sub_stage_user_ids = $userIds;
                $tenderObj->sub_stage_id = $subStageId;
                $tenderObj->save();
            }


            $this->response['status'] = 1;
            $this->response['msg'] = $tenderBiddingId ? 'Tender Quotation Updated Succesfully' : 'Tender Quotation Created Succesfully';
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Tender Quotation: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $tenderBiddingObj = TenderBidding::find($id);

            if (!$tenderBiddingObj) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender bidding"]);
                return $this->sendResponse($this->response, 500);
            }

            $tenderBiddingObj->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Tender bidding"]);
            $this->response['data'] = $tenderBiddingObj;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender bidding Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }



    private function validateBiddingSubmitted(Request $request)
    {
        return Validator::make($request->all(), [
            'bidding_quotation_date' => 'required|date_format:d/m/Y',
            'bidding_standard_term' => 'required',
        ], [
            'bidding_standard_term.required' => 'Standard Term is Required',
        ])->errors();
    }
}
