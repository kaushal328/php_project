<?php

namespace App\Http\Controllers\API;

use App\Models\Supplier;
use App\Models\Machinery;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class MachineryController extends AppBaseController
{

  public function index(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $machinery = Machinery::withoutTrashed()->orderBy("id", "desc");
      $num_rows = $machinery->count();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Machinery"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = $machinery->limit($per_page)->offset($offset)->get();;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Machinery fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateMachinery($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $machineryObject = new Machinery();
      $id = $request->id;
      $supplierId = $request->supplier_id;
      $machineryNumber = $request->machinery_number;
      $machineryName = $request->machinery_name;
      $make = $request->make;
      $yearOfMake = $request->year_of_make;
      $operationsCarried = $request->operations_carried;
      $bookedForHrs = $request->booked_for_hrs;
      $remarks = $request->remarks;
      $status = $request->status ?? 1;

      if ($id) {
        $machineryObject = Machinery::find($id);

        if (!$machineryObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Machinery"]);
          return $this->sendResponse($this->response, 401);
        }

        $machineryObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Machinery"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Machinery"]);
      }

      $machineryObject->supplier_id = $supplierId;
      $machineryObject->machinery_number = $machineryNumber;
      $machineryObject->machinery_name = $machineryName;
      $machineryObject->make = $make;
      $machineryObject->year_of_make = $yearOfMake;
      $machineryObject->operations_carried = $operationsCarried;
      $machineryObject->booked_for_hrs = $bookedForHrs;
      $machineryObject->remarks = $remarks;
      $machineryObject->status = $status;

      $machineryObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Machinery: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Machinery"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $id = $request->id ?? '';
      $machineryObject = Machinery::find($id);

      if (!$machineryObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Machinery"]);
        return $this->sendResponse($this->response, 401);
      }

      $machineryObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Machinery"]);
      $this->response['data']['list'] = $machineryObject;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Machinery fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function getMachinery(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $supplierId = $request->supplier_id ?? '';
      $supplierObject = Supplier::find($supplierId);

      if (!$supplierObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Machinery"]);
        return $this->sendResponse($this->response, 401);
      }

      $machinery = Machinery::where('supplier_id', $supplierId)->withoutTrashed()->orderBy("id", "desc");
      $num_rows = $machinery->count();

      $result = $machinery->limit($per_page)->offset($offset)->get();

      $supplierObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Machinery"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = $result;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Machinery fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $machineryObject = Machinery::find($id);

      if (!$machineryObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Machinery"]);
        return $this->sendResponse($this->response, 401);
      }

      $machineryObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Machinery"]);
      $this->response['data'] = $machineryObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Machinery Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddUpdateMachinery(Request $request)
  {
    return Validator::make($request->all(), [
      'machinery_number' => 'required',
      'machinery_name' => 'required',
    ])->errors();
  }
}
