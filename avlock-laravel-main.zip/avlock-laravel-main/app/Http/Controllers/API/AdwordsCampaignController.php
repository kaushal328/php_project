<?php

namespace App\Http\Controllers\API;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\AdwordsCampaign;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class AdwordsCampaignController extends AppBaseController {
    
  public function index(REQUEST $request) {

    try {
      
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $platform = $request->platform ?? '';
      $title = $request->title ?? '';
      $campaign_id = $request->campaign_id ?? '';
      $start_date = $request->start_date ?? '';
      $end_date = $request->end_date ?? '';
      $budget = $request->end_date ?? '';

      $adword = AdwordsCampaign::withoutTrashed()->orderBy("id", "desc");
      $num_rows = $adword->count();

      if ($campaign_id) {
        $adword->where('campaign_id', 'like', '%' . $campaign_id . '%');
      }

      if ($platform) {
        $adword->where('platform', 'like', '%' . $platform . '%');
      }

      if ($title) {
        $adword->where('title', 'like', '%' . $title . '%');
      }

      if ($start_date) {
        $adword->where('start_date', '>=', $this->convertToDatabaseDateForSearch($start_date));
      }

      if ($end_date) {
        $adword->where('end_date', '<=', $this->convertToDatabaseDateForSearch($end_date));
      }

      if ($budget) {
        $adword->where('budget', $budget);
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Adwords Campaign"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['platform'] = $platform;
      $this->response['data']['title'] = $title;
      $this->response['data']['campaign_id'] = $campaign_id;
      $this->response['data']['start_date'] = $start_date;
      $this->response['data']['end_date'] = $end_date;
      $this->response['data']['list'] = $adword->limit($per_page)->offset($offset)->get();
      return $this->sendResponse($this->response, 200);

    } catch (\Exception $e) {
      Log::error("Adwords Campaign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(REQUEST $request) {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateAdwordCampaign($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $adwordCampaign = new AdwordsCampaign();
      $id = $request->id;
      $platform = $request->platform;
      $title = $request->title;
      $campaign_id = $request->campaign_id;
      $startDate = $request->start_date;
      $start_date = $startDate ? Carbon::createFromFormat('d/m/Y g:i A', $startDate)->format('Y-m-d H:i:s') : null;
      $endDate = $request->end_date;
      $end_date = $endDate ? Carbon::createFromFormat('d/m/Y g:i A', $endDate)->format('Y-m-d H:i:s') : null;
      $budget = $request->budget;
      $status = $request->status;

      if ($id) {
        $adwordCampaign = AdwordsCampaign::find($id);

        if (!$adwordCampaign) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Adword Campaign"]);
          return $this->sendResponse($this->response, 401);
        }

        $adwordCampaign->first();
        $adwordCampaign->updated_by = $this->userId;
        $this->response['msg'] = __('admin.updated', ['module' => "Adword Campaign"]);
      } else {
        $adwordCampaign->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => "Adword Campaign"]);
      }

      $adwordCampaign->platform = $platform;
      $adwordCampaign->title = $title;
      $adwordCampaign->campaign_id = $campaign_id;
      $adwordCampaign->start_date = $start_date;
      $adwordCampaign->end_date = $end_date;
      $adwordCampaign->budget = $budget;
      $adwordCampaign->status = $status;

      $adwordCampaign->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);

    } catch (\Exception $e) {
      Log::error("Failed Creating Adword Campaign: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Adword Campaign"]);
      return $this->sendResponse($this->response, 401);
    }

  }

  public function get(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $adwordCampaignObject = AdwordsCampaign::withoutTrashed()->find($id);
      
      if (!$adwordCampaignObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Adwords Campaign"]);
        return $this->sendResponse($this->response, 401);
      }
      $adwordCampaignObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Adwords Campaign"]);
      $this->response['data'] = $adwordCampaignObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Adwords Campaign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $adwordCampaignObject = AdwordsCampaign::find($id);

      if (!$adwordCampaignObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Adwords Campaign"]);
        return $this->sendResponse($this->response, 401);
      }
      
      $adwordCampaignObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Adwords Campaign"]);
      $this->response['data'] = $adwordCampaignObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Adwords Campign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addReport(REQUEST $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddReport($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $AdwordsCampaign = new AdwordsCampaign();
      $id = $request->id;
      $total_enquiry_received = $request->total_enquiry_received;
      $report_date = $request->report_date ? Carbon::createFromFormat('d/m/Y g:i A', $request->report_date)->format('Y-m-d H:i:s') : null;

      if ($id) {
        $AdwordsCampaign = AdwordsCampaign::find($id);
        
        if (!$AdwordsCampaign) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Adwords Campaign"]);
          return $this->sendResponse($this->response, 401);
        }

        $AdwordsCampaign->first(); 
        $AdwordsCampaign->total_enquiry_received = $total_enquiry_received;
        $AdwordsCampaign->report_date = $report_date;

        $this->response['msg'] = __('admin.updated', ['module' => "Adwords Campaign"]);
      }
      $AdwordsCampaign->save();

      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);

    } catch (\Exception $e) {
      Log::error("Failed Creating Adwords: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Adwords"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddReport(Request $request) {
    return Validator::make($request->all(), [
      'id' => 'required',
      'total_enquiry_received' => 'nullable|integer',
      'report_date' => 'nullable|date_format:d/m/Y g:i A',
    ],
    [
      'total_enquiry_received.integer' => 'Insert only integer Total value',

      'report_date.date' => 'Invalid Date Format',
      'report_date.date_format' => 'Invalid Date Format',
    ])->errors();
  }

  private function validateAddUpdateAdwordCampaign(Request $request) {
    return Validator::make($request->all(), [
      'platform' => 'required|string|in:Google',
      'title' => 'required',
      'campaign_id' => 'required|unique:adwords_campaigns,campaign_id,' . $request->id . ',id,deleted_at,NULL',
      'start_date' => 'required|date_format:d/m/Y g:i A',
      'end_date' => 'required|date_format:d/m/Y g:i A|after:start_date',
      'budget' => 'sometimes|required|integer',
      'status' => 'sometimes|required|integer|in:0,1',
    ],
    [
      'campaign_id.unique' => 'Campaign Id already exists',
      'platform.in' => 'Invalid Platform',
      'start_date.date' => 'Invalid Date Format',
      'start_date.date_format' => 'Invalid Date Format',
      'end_date.date' => 'Invalid Date Format',
      'end_date.date_format' => 'Invalid Date Format',
      'end_date.after' => 'End Date should be greater than Start Date',
    ])->errors();
  }
}
