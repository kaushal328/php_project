<?php

namespace App\Http\Controllers\API;

use App\Models\Exhibition;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Http\Resources\ExhibitionResource;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Carbon\Carbon;

class ExhibitionController extends AppBaseController
{

  public function index(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';
      $description = $request->description ?? '';
      $city = $request->city ?? '';
      $country_id = $request->country_id ?? '';
      $contact_number = $request->contact_number ?? '';
      $contact_email = $request->contact_email ?? '';
      $venue = $request->venue ?? '';
      $exhibition_status = $request->exhibition_status ?? '';
      $city = $request->city ?? '';
      $start_date = $request->start_date ?? '';
      $end_date = $request->end_date ?? '';
      $status = $request->status ?? '';

      $Exhibition = Exhibition::with('countryName')->orderBy("id", "desc");

      if ($title) {
        $Exhibition->where('title', 'like', '%' . $title . '%');
      }

      if ($description) {
        $Exhibition->where('description', 'like', '%' . $description . '%');
      }

      if ($city) {
        $Exhibition->where('city', 'like', '%' . $city . '%');
      }

      if ($country_id) {
        $Exhibition->where('country_id', $country_id);
      }

      if ($contact_number) {
        $Exhibition->where('contact_number', 'like', '%' . $contact_number . '%');
      }

      if ($contact_email) {
        $Exhibition->where('contact_email', 'like', '%' . $contact_email . '%');
      }

      if ($venue) {
        $Exhibition->where('venue', 'like', '%' . $venue . '%');
      }

      if ($exhibition_status) {
        $Exhibition->where('exhibition_status', 'like', '%' . $exhibition_status . '%');
      }

      if ($start_date) {
        $Exhibition->where('start_date', '>=', $this->convertToDatabaseDateForSearch($start_date));
      }

      if ($end_date) {
        $Exhibition->where('end_date', '<=', $this->convertToDatabaseDateForSearch($end_date));
      }

      if ($status) {
        $Exhibition->where('status', $status);
      }

      $num_rows = $Exhibition->count();

      $Exhibition = $Exhibition->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Exhibition"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['description'] = $description;
      $this->response['data']['city'] = $city;
      $this->response['data']['country_id '] = $country_id;
      $this->response['data']['contact_number'] = $contact_number;
      $this->response['data']['contact_email'] = $contact_email;
      $this->response['data']['venue'] = $venue;
      $this->response['data']['exhibition_status'] = $exhibition_status;
      $this->response['data']['start_date'] = $start_date;
      $this->response['data']['end_date'] = $end_date;
      $this->response['data']['status'] = $status;
      $this->response['data']['list'] = ExhibitionResource::collection($Exhibition);

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Exhibition fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $exhibitionResource = Exhibition::with(['countryName'])->find($id);
      $exhibition = new ExhibitionResource($exhibitionResource);

      if (!$exhibition) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Exhibition"]);
        return $this->sendResponse($this->response, 401);
      }

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Exhibition"]);
      $this->response['data'] = $exhibition;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Exhibition fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function approved_list(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';
      $description = $request->description ?? '';
      $city = $request->city ?? '';
      $country_id = $request->country_id ?? '';
      $contact_number = $request->contact_number ?? '';
      $contact_email = $request->contact_email ?? '';
      $venue = $request->venue ?? '';
      $exhibition_status = $request->exhibition_status ?? '';
      $city = $request->city ?? '';
      $start_date = $request->start_date ?? '';
      $end_date = $request->end_date ?? '';
      $status = $request->status ?? '';

      $Exhibition = Exhibition::with('countryName')->where('exhibition_status', "Approved");


      if ($title) {
        $Exhibition->where('title', 'like', '%' . $title . '%');
      }

      if ($description) {
        $Exhibition->where('description', 'like', '%' . $description . '%');
      }

      if ($city) {
        $Exhibition->where('city', 'like', '%' . $city . '%');
      }

      if ($country_id) {
        $Exhibition->where('country_id', $country_id);
      }

      if ($contact_number) {
        $Exhibition->where('contact_number', 'like', '%' . $contact_number . '%');
      }

      if ($contact_email) {
        $Exhibition->where('contact_email', 'like', '%' . $contact_email . '%');
      }

      if ($venue) {
        $Exhibition->where('venue', 'like', '%' . $venue . '%');
      }

      if ($exhibition_status) {
        $Exhibition->where('exhibition_status', 'like', '%' . $exhibition_status . '%');
      }

      if ($start_date) {
        $Exhibition->where('start_date', '>=', $this->convertToDatabaseDateForSearch($start_date));
      }

      if ($end_date) {
        $Exhibition->where('end_date', '>=', $this->convertToDatabaseDateForSearch($end_date));
      }

      if ($status) {
        $Exhibition->where('status', $status);
      }

      $num_rows = $Exhibition->count();
      $Exhibition = $Exhibition->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Exhibition"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['description'] = $description;
      $this->response['data']['city'] = $city;
      $this->response['data']['country_id '] = $country_id;
      $this->response['data']['contact_number'] = $contact_number;
      $this->response['data']['contact_email'] = $contact_email;
      $this->response['data']['venue'] = $venue;
      $this->response['data']['exhibition_status'] = $exhibition_status;
      $this->response['data']['start_date'] = $start_date;
      $this->response['data']['end_date'] = $end_date;
      $this->response['data']['status'] = $status;
      $this->response['data']['list'] = ExhibitionResource::collection($Exhibition);

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Exhibition fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function pending_list(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';
      $description = $request->description ?? '';
      $city = $request->city ?? '';
      $country_id = $request->country_id ?? '';
      $contact_number = $request->contact_number ?? '';
      $contact_email = $request->contact_email ?? '';
      $venue = $request->venue ?? '';
      $exhibition_status = $request->exhibition_status ?? '';
      $city = $request->city ?? '';
      $start_date = $request->start_date ?? '';
      $end_date = $request->end_date ?? '';
      $status = $request->status ?? '';

      $Exhibition = Exhibition::with('countryName')->where('exhibition_status', "Pending");


      if ($title) {
        $Exhibition->where('title', 'like', '%' . $title . '%');
      }

      if ($description) {
        $Exhibition->where('description', 'like', '%' . $description . '%');
      }

      if ($city) {
        $Exhibition->where('city', 'like', '%' . $city . '%');
      }

      if ($country_id) {
        $Exhibition->where('country_id', $country_id);
      }

      if ($contact_number) {
        $Exhibition->where('contact_number', 'like', '%' . $contact_number . '%');
      }

      if ($contact_email) {
        $Exhibition->where('contact_email', 'like', '%' . $contact_email . '%');
      }

      if ($venue) {
        $Exhibition->where('venue', 'like', '%' . $venue . '%');
      }

      if ($exhibition_status) {
        $Exhibition->where('exhibition_status', 'like', '%' . $exhibition_status . '%');
      }

      if ($start_date) {
        $Exhibition->where('start_date', '>=', $this->convertToDatabaseDateForSearch($start_date));
      }

      if ($end_date) {
        $Exhibition->where('end_date', '>=', $this->convertToDatabaseDateForSearch($end_date));
      }

      if ($status) {
        $Exhibition->where('status', $status);
      }

      $num_rows = $Exhibition->count();
      $Exhibition = $Exhibition->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Exhibition"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['description'] = $description;
      $this->response['data']['city'] = $city;
      $this->response['data']['country_id '] = $country_id;
      $this->response['data']['contact_number'] = $contact_number;
      $this->response['data']['contact_email'] = $contact_email;
      $this->response['data']['venue'] = $venue;
      $this->response['data']['exhibition_status'] = $exhibition_status;
      $this->response['data']['start_date'] = $start_date;
      $this->response['data']['end_date'] = $end_date;
      $this->response['data']['status'] = $status;
      $this->response['data']['list'] = ExhibitionResource::collection($Exhibition);

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Exhibition fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateExhibition($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $allImages = [];

      if (!empty($request->images)) {
        foreach ($request->images as $key => $img) {

          $toPath = 'exhibition';
          moveFile($toPath, $img['filename']);

          $allImages[] = (object) [
            "filename" => $img['filename'],
            "path" => $this->fileAccessPath . "/" . $toPath . "/" . $img['filename']
          ];
        }
      }

      $EXHIBITION = new Exhibition();
      $id = $request->id;
      $title = $request->title ?? 0;
      $description = $request->description ?? 0;
      $images = $allImages ?? [];
      $city = $request->city ?? 0;
      $country_id = $request->country_id ?? 0;
      $contact_number = $request->contact_number ?? 0;
      $contact_email = $request->contact_email ?? 0;
      $venue = $request->venue ?? 0;
      $exhibition_status = $request->exhibition_status ?? 0;
      $start_date = Carbon::createFromFormat('d/m/Y g:i A', $request->start_date)->format('Y-m-d H:i:s');
      $end_date = Carbon::createFromFormat('d/m/Y g:i A', $request->end_date)->format('Y-m-d H:i:s');
      $status = $request->status ?? 0;

      if ($id) {
        $EXHIBITION = Exhibition::find($id);

        if (!$EXHIBITION) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Exhibition"]);
          return $this->sendResponse($this->response, 401);
        }

        $EXHIBITION->first();
        $EXHIBITION->updated_by = $this->userId;

        $this->response['msg'] = __('admin.updated', ['module' => "Exhibition"]);
      } else {

        $EXHIBITION->created_by = $this->userId;

        $this->response['msg'] = __('admin.created', ['module' => "Exhibition"]);
      }

      $EXHIBITION->title = $title;
      $EXHIBITION->description = $description;
      $EXHIBITION->images = json_encode($images);
      $EXHIBITION->city = $city;
      $EXHIBITION->country_id = $country_id;
      $EXHIBITION->contact_number = $contact_number;
      $EXHIBITION->contact_email = $contact_email;
      $EXHIBITION->venue = $venue;
      $EXHIBITION->exhibition_status = $exhibition_status;
      $EXHIBITION->start_date = $start_date;
      $EXHIBITION->end_date = $end_date;
      $EXHIBITION->status = $status;
      $EXHIBITION->save();

      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Exhibition: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Exhibition"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $exhibition = Exhibition::find($id);

      if (!$exhibition) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Exhibition"]);
        return $this->sendResponse($this->response, 401);
      }

      $exhibition->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Exhibition"]);
      $this->response['data'] = $exhibition;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Exhibition Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddUpdateExhibition(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'title' => 'required',
        'description' => 'required',
        'city' => 'required',
        'country_id' => 'required',
        'contact_number' => 'required',
        'contact_email' => 'required',
        'venue' => 'required',
        'exhibition_status' => 'required',
        'start_date' => 'required|date_format:d/m/Y g:i A',
        'end_date' => 'required|date_format:d/m/Y g:i A|after:start_date',
        'status' => 'sometimes|required|integer|in:0,1',
      ],
      [
        'start_date.date_format'  => 'Invalid Date Format',
        'end_date.date_format'  => 'Invalid Date Format'
      ]
    )->errors();
  }
}
