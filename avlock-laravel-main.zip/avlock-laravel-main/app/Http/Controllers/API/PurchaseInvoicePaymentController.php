<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Resources\PurchaseInvoicePaymentResource;
use App\Models\Lead;
use App\Models\PurchaseInvoice;
use App\Models\PurchaseInvoicePayment;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class PurchaseInvoicePaymentController extends AppBaseController
{
  function index(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $fk_pi_id = $request->fk_pi_id ?? "";
      $fk_lead_id = $request->lead ?? "";
      $payment_date = $request->payment_date ?? '';
      $payment_amount = $request->payment_amount ?? '';

      $piPaymentObject = PurchaseInvoicePayment::orderBy('id', 'desc');

      if ($fk_lead_id) $piPaymentObject->where("fk_lead_id", $fk_lead_id);
      if ($fk_pi_id) $piPaymentObject->whereRaw("FIND_IN_SET(?, fk_pi_id) > 0", [$fk_pi_id]);
      if ($payment_date) $piPaymentObject->where('payment_date', '>=', $this->convertToDatabaseDateForSearch($payment_date));
      if ($payment_amount) $piPaymentObject->where('payment_amount', 'like', '%' . $payment_amount . '%');

      $num_rows = $piPaymentObject->count();

      $result = $piPaymentObject->limit($per_page)->offset($offset)->get();
      $piPaymentList = PurchaseInvoicePaymentResource::collection($result);

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Purchase Invoice"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['fk_pi_id'] = $fk_pi_id;
      $this->response['data']['payment_date'] = $payment_date;
      $this->response['data']['payment_amount'] = $payment_amount;
      $this->response['data']['list'] = $piPaymentList;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Purchase Payment Invoice List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function pipDash(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $fk_pi_id = $request->fk_pi_id ?? "";
      $fk_lead_id = $request->lead ?? "";
      $payment_date = $request->payment_date ?? '';
      $payment_amount = $request->payment_amount ?? '';

      $piPaymentObject = PurchaseInvoicePayment::with('lead')
      ->whereHas('lead', function ($query) {
        $query->where('assigned_rsm', $this->userId);
      })->orderBy('id', 'desc');

      if ($fk_lead_id) $piPaymentObject->where("fk_lead_id", $fk_lead_id);
      if ($fk_pi_id) $piPaymentObject->whereRaw("FIND_IN_SET(?, fk_pi_id) > 0", [$fk_pi_id]);
      if ($payment_date) $piPaymentObject->where('payment_date', '>=', $this->convertToDatabaseDateForSearch($payment_date));
      if ($payment_amount) $piPaymentObject->where('payment_amount', 'like', '%' . $payment_amount . '%');

      $num_rows = $piPaymentObject->count();

      $result = $piPaymentObject->limit($per_page)->offset($offset)->get();
      $piPaymentList = PurchaseInvoicePaymentResource::collection($result);

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Purchase Invoice"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['fk_pi_id'] = $fk_pi_id;
      $this->response['data']['payment_date'] = $payment_date;
      $this->response['data']['payment_amount'] = $payment_amount;
      $this->response['data']['list'] = $piPaymentList;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Purchase Payment Invoice List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function get(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $piId = $request->pi_id ?? "";

      if (!$piId) {
        $this->response['error'] = "Please select a valid Purchase Invoice!";
        return $this->sendResponse($this->response, 200);
      }

      $piPaymentObject = PurchaseInvoicePayment::find($piId);

      if (!$piPaymentObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Invoice"]);
        return $this->sendResponse($this->response, 200);
      }


      $this->response['status'] = 1;
      $this->response['data'] = new PurchaseInvoicePaymentResource($piPaymentObject);

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Purchase Invoice Payment Details fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }


  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdatePurchaseInvoice($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $leadId = $request->lead;

      $leadObject = Lead::find($leadId);

      if (!$leadObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Lead"]);
        return $this->sendResponse($this->response, 200);
      }

      $piPaymentObject = new PurchaseInvoicePayment();
      $purchaseInvoices = $request->purchase_invoices ?? [];

      $payment_date = Carbon::createFromFormat('d/m/Y g:i A', $request->payment_date)->format('Y-m-d H:i:s');
      $payment_amount = $request->payment_amount;
      $remark = $request->remark;

      $fk_pi_id = '';

      if (!empty($purchaseInvoices)) {
        $purchaseInvoiceIdsArray = array_column($purchaseInvoices, 'id');

        $sumOfInvoices = PurchaseInvoice::whereIn('id', $purchaseInvoiceIdsArray)
          ->sum('pi_total_amount_pending');

        if (count($purchaseInvoices) == 1 && $payment_amount > $sumOfInvoices) {
          $this->response['errors'] = ['payment_amount' => "Payment Amount Should not greater than the Total invoice amount you selected i.e. " .  $sumOfInvoices];
          return $this->sendResponse($this->response, 200);
        }

        if ($sumOfInvoices != $payment_amount && count($purchaseInvoices) > 1) {
          $this->response['errors'] = ['payment_amount' => "Payment Amount Should be equal to Total the invoice amount you selected i.e. " .  $sumOfInvoices];
          return $this->sendResponse($this->response, 200);
        }

        $fk_pi_id = implode(',', $purchaseInvoiceIdsArray);
      }


      $piPaymentObject->fk_pi_id = $fk_pi_id;
      $piPaymentObject->fk_lead_id = $leadId;
      $piPaymentObject->payment_date = $payment_date;
      $piPaymentObject->payment_amount = $payment_amount;
      $piPaymentObject->remark = $remark;
      $piPaymentObject->created_by = $this->userId;

      $piPaymentObject->save();

      if (!empty($purchaseInvoices)) {
        $purchaseInvoiceIdsArray = array_column($purchaseInvoices, 'id');


        if (count($purchaseInvoices) == 1) {
          PurchaseInvoice::whereIn('id', $purchaseInvoiceIdsArray)
            ->update([
              'pi_total_amount_paid' => DB::raw('pi_total_amount_paid + ' . $payment_amount),
              'pi_total_amount_pending' => DB::raw('pi_total_amount - pi_total_amount_paid '),
              'payment_done' => DB::raw("CASE WHEN pi_total_amount_pending = 0 THEN 1 ELSE 0 END"),

            ]);
        } else {
          PurchaseInvoice::whereIn('id', $purchaseInvoiceIdsArray)
            ->update([
              'payment_done' => 1,
              'pi_total_amount_paid' => DB::raw('pi_total_amount'),
              'pi_total_amount_pending' => 0,
            ]);
        }
      }

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.created', ['module' => "Purchase Invoice Payment"]);

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Creating Purchase Invoice: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Purchase Invoice"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdatePurchaseInvoice(Request $request)
  {
    return Validator::make($request->all(), [
      'payment_date' => 'required|date_format:d/m/Y g:i A',
      'purchase_invoices' => 'required',
      'payment_amount' => [
        'required',
        'numeric', // Ensure the input is numeric
        // 'regex:/^\d+(\.\d{1,2})?$/', // Allows decimal up to two places
        'min:0.01', // Minimum value
        // 'max:9999999.99', // Maximum value (adjust as needed)
      ],

    ])->errors();
  }
}
