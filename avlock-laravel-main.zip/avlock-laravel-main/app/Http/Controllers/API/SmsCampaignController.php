<?php

namespace App\Http\Controllers\API;

use DateTime;
use Carbon\Carbon;
use App\Models\SmsData;
use App\Models\SmsCampaign;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Imports\SmsDataImport;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\SmsCampaignResource;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\IOFactory;

class SmsCampaignController extends AppBaseController
{

  public function index(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';
      $campaign_id = $request->campaign_id ?? '';
      $start_date = $request->start_date ?? '';
      $end_date = $request->end_date ?? '';
      $budget = $request->end_date ?? '';


      $smsCampaign = SmsCampaign::withoutTrashed()->orderBy("id", "desc");
      $num_rows = $smsCampaign->count();

      if ($campaign_id) {
        $smsCampaign->where('campaign_id', 'like', '%' . $campaign_id . '%');
      }

      if ($title) {
        $smsCampaign->where('title', 'like', '%' . $title . '%');
      }

      if ($start_date) {
        $smsCampaign->where('start_date', '>=', $this->convertToDatabaseDateForSearch($start_date));
      }

      if ($end_date) {
        $smsCampaign->where('end_date', '<=', $this->convertToDatabaseDateForSearch($end_date));
      }

      if ($budget) {
        $smsCampaign->where('budget', $budget);
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "SMS Campaign"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['campaign_id'] = $campaign_id;
      $this->response['data']['start_date'] = $start_date;
      $this->response['data']['end_date'] = $end_date;
      $this->response['data']['list'] = $smsCampaign->limit($per_page)->offset($offset)->get();
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SMS Campaign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateSmsCampaign($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $smsCampaignObject = new SmsCampaign();
      $id = $request->id;
      $title = $request->title;
      $campaign_id = $request->campaign_id;
      $start_date = Carbon::createFromFormat('d/m/Y g:i A', $request->start_date)->format('Y-m-d H:i:s');
      $end_date = Carbon::createFromFormat('d/m/Y g:i A', $request->end_date)->format('Y-m-d H:i:s');
      $budget = $request->budget;
      $status = $request->status;

      if ($id) {
        $smsCampaignObject = SmsCampaign::find($id);

        if (!$smsCampaignObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "SMS Campaign"]);
          return $this->sendResponse($this->response, 401);
        }

        $smsCampaignObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "SMS Campaign"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "SMS Campaign"]);
      }

      $smsCampaignObject->title = $title;
      $smsCampaignObject->campaign_id = $campaign_id;
      $smsCampaignObject->start_date = $start_date;
      $smsCampaignObject->end_date = $end_date;
      $smsCampaignObject->budget = $budget;
      $smsCampaignObject->status = $status;

      $smsCampaignObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating SMS Campaign: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "SMS Campaign"]);
      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $smsCampaignObject = SmsCampaign::withoutTrashed()->find($id);

      $totalData = SmsData::withoutTrashed()->where('fk_sms_campaign_id', $id)->count();

      if (!$smsCampaignObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "SMS Campaign"]);
        return $this->sendResponse($this->response, 401);
      }
      $smsCampaignObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "SMS Campaign"]);
      $this->response['data'] = $smsCampaignObject;
      $this->response['data']['total_data'] = $totalData;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SMS Campaign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $smsCampaignObject = SmsCampaign::find($id);

      if (!$smsCampaignObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "SMS Campaign"]);
        return $this->sendResponse($this->response, 401);
      }

      $smsCampaignObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "SMS Campaign"]);
      $this->response['data'] = $smsCampaignObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SMS Campign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }


  public function addReport(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddReport($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $smsCampaignObject = new SmsCampaign();
      $id = $request->id;
      $total_sms_sent = $request->total_sms_sent;
      $total_sms_delivered = $request->total_sms_delivered;
      $total_sms_failed = $request->total_sms_failed;
      $total_sms_frozen = $request->total_sms_frozen;
      $report_date = $request->report_date ? Carbon::createFromFormat('d/m/Y g:i A', $request->report_date)->format('Y-m-d H:i:s') : null;

      if ($id) {
        $smsCampaignObject = SmsCampaign::find($id);

        if (!$smsCampaignObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "SMS Campaign"]);
          return $this->sendResponse($this->response, 401);
        }

        $smsCampaignObject->first();
        $smsCampaignObject->total_sms_sent = $total_sms_sent;
        $smsCampaignObject->total_sms_delivered = $total_sms_delivered;
        $smsCampaignObject->total_sms_failed = $total_sms_failed;
        $smsCampaignObject->total_sms_frozen = $total_sms_frozen;
        $smsCampaignObject->report_date = $report_date;

        $this->response['msg'] = __('admin.updated', ['module' => "SMS Campaign"]);
      }

      $smsCampaignObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating SMS Report: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Role"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function listData(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $sms_campaign_id = $request->sms_campaign_id ?? '';
      $name = $request->name ?? '';
      $address = $request->address ?? '';
      $city = $request->city ?? '';
      $mobile = $request->mobile ?? '';
      $email = $request->email ?? '';

      $SMSData = SmsData::with('campaign');
      $num_rows = $SMSData->count();

      if ($sms_campaign_id) {
        $SMSData->whereHas('campaign', function ($query) use ($sms_campaign_id) {
          $query->where('fk_sms_campaign_id', $sms_campaign_id);
        });
      }

      if ($name) {
        $SMSData->where('name', 'like', '%' . $name . '%');
      }

      if ($address) {
        $SMSData->where('address', 'like', '%' . $address . '%');
      }

      if ($city) {
        $SMSData->where('city', 'like', '%' . $city . '%');
      }

      if ($mobile) {
        $SMSData->where('mobile', 'like', '%' . $mobile . '%');
      }

      if ($email) {
        $SMSData->where('email', 'like', '%' . $email . '%');
      }


      $SMSData = $SMSData->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['model' => 'SMS Campaign']);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['sms_campaign_id'] = $sms_campaign_id;
      $this->response['data']['address'] = $address;
      $this->response['data']['city'] = $city;
      $this->response['data']['name'] = $name;
      $this->response['data']['mobile'] = $mobile;
      $this->response['data']['email'] = $email;
      $this->response['data']['list'] = SmsCampaignResource::collection($SMSData);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SMS Data fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addDataSingle(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddDataSingle($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $SMSData = new SmsData();
      $id = $request->id;
      $sms_campaign_id = $id;
      $name = $request->name;
      $address = $request->address;
      $city = $request->city;
      $email = $request->email;
      $mobile = $request->mobile;

      if ($id) {
        $SMSData = new SmsData();

        if (!$SMSData) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "SMS Data"]);
          return $this->sendResponse($this->response, 401);
        }

        $SMSData->fk_sms_campaign_id = $sms_campaign_id;
        $SMSData->name = $name;
        $SMSData->address = $address;
        $SMSData->city = $city;
        $SMSData->email = $email;
        $SMSData->mobile = $mobile;
      }

      $SMSData->save();
      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.created', ['module' => "SMS Data"]);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating SMS Data: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "SMS Data"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function addData(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $files = $request->excel ?? [];

      $validationErrors = $this->validateAddData($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }



      foreach ($files as $item) {

        $filePath = storage_path('app/public/uploads/temp/' . $item['filename']);
        $sourcePath = 'public/uploads/temp/' .  $item['filename'];

        if (!Storage::exists($sourcePath)) {

          $this->response['error'] = __('admin.file_not_found', ['file' => $item['filename']]);
          return $this->sendResponse($this->response, 401);
        }

        $spreadsheet = IOFactory::load($filePath);
        $sheetNames = $spreadsheet->getSheetNames();
        $dataRecords = [];

        foreach ($sheetNames as $sheetName) {
          $worksheet = $spreadsheet->getSheetByName($sheetName);
          $cellIterator = $worksheet->getRowIterator()->current()->getCellIterator();
          $cellIterator->setIterateOnlyExistingCells(true);

          $headers = [];
          foreach ($cellIterator as $cell) {
            if ($cell->getValue() != '') {
              $headers[] = $cell->getValue();
            }
          }

          if (array_values($headers) != array_values(config('global.CAMPAIGN_DATA_HEADER_FORMAT'))) {
            $this->response['error'] = __('admin.excel_format_error', ['file' => $item['filename'], 'sheet' => $sheetName]);
            return $this->sendResponse($this->response, 200);
          }



          $highestRow = $worksheet->getHighestRow();
          $dataRecords = [];

          for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
            $dataRecords[] = $rowData[$row];
          }
        }

        foreach ($dataRecords as $data) {
          SmsData::create([
            'name' => convertToCamelCase($data['A']),
            'mobile' => $data['B'],
            'email' => $data['C'],
            'address' => convertToCamelCase($data['D']),
            'city' => convertToCamelCase($data['E']),
            'fk_sms_campaign_id' => $id
          ]);
        }

        $this->response['status'] = 1;
        $this->response['msg'] = __('admin.created', ['module' => "SMS Data"]);
        return $this->sendResponse($this->response, 200);
      }
    } catch (\Exception $e) {
      Log::error("Failed Creating Excel Data: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function deleteData(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $SMSData = SmsData::find($id);

      if (!$SMSData) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "SMS Data"]);
        return $this->sendResponse($this->response, 401);
      }

      $SMSData->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "SMS Data"]);
      $this->response['data'] = $SMSData;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SMS Data deleting failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }


  private function validateAddUpdateSmsCampaign(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'title' => 'required|string|unique:sms_campaigns,title,' . $request->id . ',id,deleted_at,NULL',
        'campaign_id' => 'required|string|unique:sms_campaigns,campaign_id,' . $request->id . ',id,deleted_at,NULL',
        'start_date' => 'required|date_format:d/m/Y g:i A',
        'end_date' => 'required|date_format:d/m/Y g:i A|after:start_date',
        'budget' => 'sometimes|required|numeric',
        'status' => 'sometimes|required|integer|in:0,1',
      ],
      [
        'title.unique' => 'Campaign name already exist',
        'campaign_id.unique' => 'Campaign ID already exist'
      ]
    )->errors();
  }

  private function validateAddReport(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'total_sms_sent' => 'nullable|numeric|integer',
        'total_sms_delivered' => 'nullable|numeric|integer',
        'total_sms_failed' => 'nullable|numeric|integer',
        'report_date' => 'nullable|date_format:d/m/Y g:i A',
        // 'report_date' => ['nullable', 'date', 'date_format:d/m/Y g:i A'],
      ],
      [
        'total_sms_sent.numeric' => 'Invalid Total value',
        'total_sms_sent.integer' => 'Insert only integer Total value',

        'total_sms_delivered.numeric' => 'Invalid Total value',
        'total_sms_delivered.integer' => 'Insert only integer Total value',

        'total_sms_failed.numeric' => 'Invalid Total value',
        'total_sms_failed.integer' => 'Insert only integer Total value',
      ]
    )->errors();
  }

  private function validateAddDataSingle(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'id' => 'required|exists:sms_campaigns,id,deleted_at,NULL',
        'name' => 'required',
        'address' => 'required',
        'city' => 'required',
        'email' => 'required',
        'mobile' => 'required',
      ],
      [
        'id.exists' => "Campaign doesn't exists with provided id",
      ]
    )->errors();
  }

  private function validateAddData(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'id' => 'required|exists:sms_campaigns,id,deleted_at,NULL',
        'excel' => 'required',
      ],
      [
        'id.exists' => "Campaign doesn't exists with provided id",
      ]
    )->errors();
  }
}
