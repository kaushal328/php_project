<?php

namespace App\Http\Controllers\API;

use App\Enums\QuotationStatus;
use App\Events\ProjectQuotationLogCreated;
use App\Events\ProjectQuotationLogTempCreated;
use App\Http\Controllers\Controller;
use App\Http\Resources\ProjectQuotationResource;
use App\Http\Resources\PurchaseOrderResource;
use App\Jobs\SendQuotationEmailJob;
use App\Models\Lead;
use App\Models\ProductParameter;
use App\Models\ProjectLog;
use App\Models\CommonReference;
use App\Models\CommonSalutation;
use App\Models\CommonSpecialNote;
use App\Models\CommonTnc;
use App\Models\Currency;
use App\Models\LeadContactPeople;
use App\Models\LeadDesignation;
use App\Models\ProjectQuotation;
use App\Models\ProjectQuotationLog;
use App\Models\ProjectQuotationLogTemp;
use App\Models\ProjectQuotationTemp;
use App\Models\ProjectQuotationTerm;
use App\Models\PurchaseOrder;
use App\Models\QuotationRequirement;
use App\Models\QuotationService;
use App\Models\Rfq;
use App\Models\RfqProduct;
use App\Models\RfqResponse;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\URL;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Spatie\LaravelPdf\Enums\Format;
use Spatie\LaravelPdf\Facades\Pdf as MyPdf;

use PDF;
use PhpOffice\PhpSpreadsheet\Calculation\DateTimeExcel\Current;

class ProjectQuotationController extends AppBaseController
{

    function index(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $fk_rfq_id = $request->fk_rfq_id ?? "";
            $fk_lead_id = $request->fk_lead_id ?? "";
            $quotation_date = $request->quotation_date ?? '';
            $quotation_no = $request->quotation_no ?? '';
            $sales_person = $request->sales_person ?? "";
            $prepared_by = $request->prepared_by ?? "";

            $quotationObject = ProjectQuotationTemp::with('salesPerson', 'preparedBy', 'lead', 'rfq', 'rfq.designation');

            if ($fk_rfq_id) $quotationObject->where('fk_rfq_id',  $fk_rfq_id);
            if ($fk_lead_id) $quotationObject->where('fk_lead_id',  $fk_lead_id);
            if ($quotation_date) $quotationObject->where('quotation_date', '>=', $this->convertToDatabaseDateForSearch($quotation_date));
            if ($quotation_no) $quotationObject->where('quotation_no', 'like', '%' . $quotation_no . '%');
            if ($sales_person) $quotationObject->where('sales_person',  $sales_person);
            if ($prepared_by) $quotationObject->where('prepared_by',  $prepared_by);

            $quotationObject->groupBy('fk_rfq_id');

            $num_rows = $quotationObject->count();
            $result = $quotationObject->orderBy('updated_at', 'desc')->limit($per_page)->offset($offset)->get();

            $QuotationList = ProjectQuotationResource::collection($result);

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Quotation"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['fk_rfq_id'] = $fk_rfq_id;
            $this->response['data']['fk_lead_id'] = $fk_lead_id;
            $this->response['data']['quotation_date'] = $quotation_date;
            $this->response['data']['quotation_no'] = $quotation_no;
            $this->response['data']['sales_person'] = $sales_person;
            $this->response['data']['prepared_by'] = $prepared_by;
            $this->response['data']['list'] = $QuotationList;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Quotation List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    function get(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $quotationId = $request->quotation_id ?? "";

            if (!$quotationId) {
                $this->response['error'] = "Please select a valid Quotation!";
                return $this->sendResponse($this->response, 200);
            }

            $quotationObjectTemp = ProjectQuotationTemp::with('salesPerson.designation', 'preparedBy', 'lead.source', 'rfq.source', 'rfq.rsm', 'rfq.product', 'rfq.currencyData', 'rfq.designation')->find($quotationId);


            if (!$quotationObjectTemp) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Quotation"]);
                return $this->sendResponse($this->response, 200);
            }

            $quotation = new ProjectQuotationResource($quotationObjectTemp);

            $this->response['status'] = 1;
            $this->response['data'] = $quotation;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Quotation Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    function getQuotationHistory(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $quotationId = $request->quotation_id ?? "";

            $quotationObjectTemp = ProjectQuotationLogTemp::with(['salesPerson.designation', 'preparedBy', 'lead.source', 'rfq', 'rfq.source', 'rfq.rsm', 'rfq.product', 'rfq.currencyData', 'rfq.designation'])->where('fk_quotation_id', $quotationId)->get();

            if (!$quotationObjectTemp) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Quotation"]);
                return $this->sendResponse($this->response, 200);
            }


            $this->response['status'] = 1;
            $this->response['data']['list'] = $quotationObjectTemp;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Quotation Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function getFinal(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $quotationId = $request->quotation_id ?? "";

            if (!$quotationId) {
                $this->response['error'] = "Please select a valid Quotation!";
                return $this->sendResponse($this->response, 200);
            }

            $quotationObjectTemp = ProjectQuotation::with('salesPerson.designation', 'preparedBy', 'lead.source', 'rfq.product', 'rfq.designation', 'rfq.currencyData')
                ->where('fk_project_quotation_temp_id', $quotationId)
                ->latest()
                ->first();


            if (!$quotationObjectTemp) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Quotation"]);
                return $this->sendResponse($this->response, 200);
            }

            $quotation = new ProjectQuotationResource($quotationObjectTemp);

            $this->response['status'] = 1;
            $this->response['data'] = $quotation;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Quotation Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function getRfqDetails(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $rfqId = $request->rfq_id ?? "";

            if (!$rfqId) {
                $this->response['error'] = "Please select a valid RFQ!";
                return $this->sendResponse($this->response, 200);
            }

            $rfqObject = Rfq::with('lead', 'designation', 'lead.region', 'lead.source', 'source:id,name', 'subStage', 'product.product', 'rfqResponse', 'rsm:id,name')->find($rfqId);


            if (!$rfqObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "RFQ"]);
                return $this->sendResponse($this->response, 200);
            }

            $rfqObject->response_qty = 0;

            $rfqProduct = RfqProduct::where('rfq_id', $rfqId)->get()->toArray();
            if (!empty($rfqProduct)) {
                $totalResponseQty = 0;

                foreach ($rfqProduct as $rfqResponse) {
                    $qty = (int)($rfqResponse['product_qty'] ?? 0);
                    $totalResponseQty += $qty;
                }

                $rfqObject->response_qty  = $totalResponseQty;
            }

            $poList = PurchaseOrder::with('agreement', 'packaging', 'labelling', 'dneInvoice', 'qualityReport', 'lr', 'purchaseInvoice', 'stage', 'subStage')->where('fk_rfq_id', $rfqId)->get();
            $rfqObject->po_list = PurchaseOrderResource::collection($poList);
            $lastLog = ProjectLog::where('fk_rfq_id', $rfqId)
                ->latest()
                ->first();

            if ($lastLog) {
                $rfqObject->last_log_date = $lastLog->created_at;
            }

            $checkRfqResponse = RfqProduct::where('rfq_id', $rfqId)->where('is_response_received', 1)->count();
            $showChangeStageButton = true;
            $actionMsg = '';

            if ($checkRfqResponse == 0) {
                $actionMsg = 'RFQ Response Not Received';
                $showChangeStageButton = false;
            }
            if ($rfqObject->assigned_rsm == 0) {
                $actionMsg = 'Please Assign RSM';
                $showChangeStageButton = false;
            }


            $rfqObject->action_msg = $actionMsg;
            $rfqObject->show_change_stage_button = $showChangeStageButton;

            $designationLeadContactId = $rfqObject?->lead_contact_people_id ?? null;
            $desgIds = $designationLeadContactId ? LeadContactPeople::find($designationLeadContactId) : null;
            $designations = $desgIds && is_array($desgIds->designations)  ? LeadDesignation::whereIn('id', $desgIds->designations)->pluck('name')->implode(', ')  : '';

            $this->response['status'] = 1;
            $this->response['data'] = $rfqObject;
            $this->response['data']['leadDesg'] = $designations;
            $this->response['data']['lead_contact_person'] = $desgIds->customer_name ?? '';
            $this->response['data']['lead_email'] = $desgIds->email ?? '';
            $this->response['data']['lead_contact_no'] = $desgIds->contact_no ?? '';

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Quotation Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }
    public function addUpdate(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $projectQuotationTempObject = new ProjectQuotationTemp();
            $id = $request->id;
            $fk_rfq_id = $request->fk_rfq_id;
            $salesPerson = $request->sales_person;
            $salutation = $request->salutation;
            $reference = $request->reference;
            $terms = $request->terms;


            $validationErrors = $this->validateAddUpdateQuotation($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }


            $rfqObject = Rfq::with('division:id,name')->find($fk_rfq_id);

            if (!$rfqObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "RFQ"]);
                return $this->sendResponse($this->response, 200);
            }

            $currencyId = $rfqObject->currency ?? null;


            $fk_lead_id = $rfqObject->lead_id;
            $setName = $request->set_name;
            $setValue = $request->set_value ?? null;
            $formattedDate = Carbon::createFromFormat('d/m/Y', $request->quotation_date ?? Carbon::now()->format('d/m/Y'));
            if (!empty($request->quotation_revision)) {
                $qtnRevDate = Carbon::createFromFormat('d/m/Y', $request->quotation_revision ?? Carbon::now()->format('Y-m-d'));
            }

            $qtnMonth = $formattedDate->format('M');
            $monthNumber = $formattedDate->format('n');
            $year = $formattedDate->format('Y');
            $financialYearStart = $monthNumber >= 4 ? $year : $year - 1;
            $shortFinYearStart = substr($financialYearStart, -2);
            $shortFinYearEnd = substr($financialYearStart + 1, -2);
            $quotationDate = $formattedDate->format('Y-m-d');

            $duration = $request->duration;
            $durationDate = Carbon::createFromFormat('d/m/Y', $request->quotation_date);
            $durationDate->addDays($duration);
            if ($duration) {
                $durationDateFormatted = $durationDate->format('Y-m-d H:i:s');
            } else {
                $durationDateFormatted = NULL;
            }

            if (empty($request->requirements) && empty($request->services)) {
                $this->response["error"] = "Please select atleast one Requirement Or Service";
                return $this->sendResponse($this->response, 200);
            }


            $requirementsEmpty = false;
            foreach ($request->requirements as $key => $item) {
                if (empty($item['unit'])) {
                    $requirementsEmpty = true;
                    break;
                }
            }

            if ($requirementsEmpty) {
                $this->response["error"] = "Please fill unit in Requirements";
                return $this->sendResponse($this->response, 200);
            }

            $requirements = json_encode($request->requirements ?? []);
            $serviceDetail = json_encode($request->services ?? []);
            $specialNotes = $request->special_notes;
            $cgst = $request->cgst;
            $sgst = $request->sgst;
            $igst = $request->igst;
            $cgstValue = $sgstValue = $igstValue = 0;
            $quotationTerms = json_encode($request->quotation_terms ?? []);

            $sumOfService = array_reduce($request->services, function ($carry, $item) {
                return $carry + (is_array($item) && isset($item['total_amount']) ? floatval($item['total_amount']) : 0);
            }, 0);

            $sumOfRequirements = array_reduce($request->requirements, function ($carry, $item) {
                return $carry + (is_array($item) && isset($item['total_amount']) ? floatval($item['total_amount']) : 0);
            }, 0);

            $serviceTotal = $sumOfService;
            $requirementTotal = $sumOfRequirements;
            $totalBasicValue = !empty($setValue) ? $setValue * $sumOfRequirements : $sumOfRequirements;

            $finalAmount = $totalBasicValue + $serviceTotal;

            $currency = Currency::find($currencyId);


            if ($currency) {
                $currencyToInrRateResponse = getCurrencyToInrRate($currency->title);
                if (isset($currencyToInrRateResponse['error']) && !empty($currencyToInrRateResponse['error'])) {
                    $this->response['error'] = $currencyToInrRateResponse['error'];
                    return $this->sendResponse($this->response, 200);
                }

                $currencyToInrRate = $currencyToInrRateResponse['data'];

                $totalBasicValueInInr = $finalAmount * floatval($currencyToInrRate);
            }

            if ($cgst > 0) $cgstValue = ($finalAmount * floatval($cgst)) / 100;
            if ($sgst > 0) $sgstValue = ($finalAmount * floatval($sgst)) / 100;
            if ($igst > 0) $igstValue = ($finalAmount * floatval($igst)) / 100;

            $finalAmount = $finalAmountInInr = $finalAmount + $cgstValue + $sgstValue + $igstValue;

            if ($currency) {
                $currencyToInrRateResponse = getCurrencyToInrRate($currency->title);
                if (isset($currencyToInrRateResponse['error']) && !empty($currencyToInrRateResponse['error'])) {
                    $this->response['error'] = $currencyToInrRateResponse['error'];
                    return $this->sendResponse($this->response, 200);
                }

                $currencyToInrRate = $currencyToInrRateResponse['data'];

                $finalAmountInInr = $finalAmount * floatval($currencyToInrRate);
            }

            if ($id) {
                $projectQuotationTempObject = ProjectQuotationTemp::with('rfq.division')->find($id);

                $checkPo = PurchaseOrder::where('fk_quotation_id', $id)->first();

                if ($checkPo) {
                    $this->response['error'] = "PO already generated! Cannot edit quotation.";
                    return $this->sendResponse($this->response, 200);
                }

                if (!$projectQuotationTempObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Quotation"]);
                    return $this->sendResponse($this->response, 200);
                }
                $projectQuotationTempObject->first();
                $projectQuotationTempObject->updated_by = $this->userId;

                $pqtl = ProjectQuotationLogTemp::where('fk_quotation_id', $id)
                    ->latest('created_at')
                    ->first();

                // $quotationNo = $projectQuotationTempObject->quotation_no;
                $quotationNo = $request->quotation_no;

                if (!empty($projectQuotationTempObject) && $projectQuotationTempObject->is_sent_to_client == 1) {
                    // if (strtotime($projectQuotationTempObject->quotation_date) != strtotime($request->quotation_date)) {
                    if (true) {
                        if ($requirements != $projectQuotationTempObject->requirements || $serviceDetail != $projectQuotationTempObject->service_detail || $cgst != $projectQuotationTempObject->cgst || $igst != $projectQuotationTempObject->igst || $sgst != $projectQuotationTempObject->sgst) {

                            $yearRange = $shortFinYearStart . '-' . $shortFinYearEnd;
                            $currentQuotationNo = $quotationNo;

                            $quotationNoParts = explode('/', $currentQuotationNo);
                            if (count($quotationNoParts) == 5 || count($quotationNoParts) == 6) {
                                $quotationNoParts[count($quotationNoParts) - 3] = $yearRange;
                                $quotationNoParts[count($quotationNoParts) - 2] = strtoupper($qtnMonth);

                                $quotationNo = implode('/', $quotationNoParts);

                                if (!str_starts_with($currentQuotationNo, 'REV')) {
                                    $quotationNo = 'REV/' . $quotationNo;
                                    $projectQuotationTempObject->is_revised = 1;
                                }
                            }
                        }
                    } else {
                        if (!str_starts_with($projectQuotationTempObject->quotation_no, 'REV')) {
                            $quotationNo = 'REV/' . $quotationNo;
                            $projectQuotationTempObject->is_revised = 1;
                        }
                    }
                }

                $this->response['msg'] = __('admin.updated', ['module' => "Quotation"]);
            } else {

                $projectQuotationTempObject->created_by = $this->userId;
                $projectQuotationTempObject->prepared_by = $this->userId;
                $projectQuotationTempObject->quotation_status = QuotationStatus::INITIATED;

                if ($rfqObject->lead) {
                    if ($rfqObject->lead->is_export == 1) {
                        $baseString = strtoupper('EXP/' . 'QTN/' . $rfqObject->division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . $qtnMonth . '/');
                    }
                } else {
                    $baseString = strtoupper('QTN/' . $rfqObject->division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . $qtnMonth . '/');
                }

                $quotationNo = generateSeries($baseString, 'project_quotation_temps', 'quotation_no');

                $this->response['msg'] = __('admin.created', ['module' => "Quotation"]);
            }

            $existingQuotation = ProjectQuotationTemp::where('quotation_no', $quotationNo)->where('id', '!=',  $id)->first();

            if ($existingQuotation) {
                $this->response['error'] = "Quotation No already exists.";
                return $this->sendResponse($this->response, 200);
            }

            $projectQuotationTempObject->sales_person = $salesPerson;
            $projectQuotationTempObject->salutation = $salutation;
            $projectQuotationTempObject->fk_rfq_id = $fk_rfq_id;
            $projectQuotationTempObject->fk_lead_id = $fk_lead_id;
            $projectQuotationTempObject->quotation_date = $quotationDate;
            $projectQuotationTempObject->quotation_revision_date = $qtnRevDate ?? NULL;
            $projectQuotationTempObject->duration = $duration;
            $projectQuotationTempObject->set_name = $setName;
            $projectQuotationTempObject->set_value = $setValue;
            $projectQuotationTempObject->reference = $reference;
            $projectQuotationTempObject->duration_date = $durationDateFormatted;
            $projectQuotationTempObject->quotation_no = $quotationNo;
            // $projectQuotationTempObject->set_name = $setName;
            // $projectQuotationTempObject->set_value = $setValue;
            $projectQuotationTempObject->requirements = $requirements;
            $projectQuotationTempObject->requirement_total = $requirementTotal;
            $projectQuotationTempObject->service_detail = $serviceDetail;
            $projectQuotationTempObject->service_total = $serviceTotal;
            $projectQuotationTempObject->requirement_total = $requirementTotal;
            $projectQuotationTempObject->total_basic_value = $totalBasicValue;
            $projectQuotationTempObject->total_basic_value_in_inr = $totalBasicValueInInr ?? 0;
            $projectQuotationTempObject->final_amount = $finalAmount;
            $projectQuotationTempObject->final_amount_in_inr = $finalAmountInInr;
            $projectQuotationTempObject->special_notes = $specialNotes;
            $projectQuotationTempObject->cgst = $cgst;
            $projectQuotationTempObject->cgst_value = $cgstValue;
            $projectQuotationTempObject->sgst = $sgst;
            $projectQuotationTempObject->sgst_value = $sgstValue;
            $projectQuotationTempObject->igst = $igst;
            $projectQuotationTempObject->igst_value = $igstValue;
            $projectQuotationTempObject->quotation_terms = $quotationTerms;
            $projectQuotationTempObject->terms = $terms;

            $projectQuotationTempObject->save();
            $lastInsertedId = $projectQuotationTempObject->id;


            $proIds = array_column($request->requirements, 'id');
            $proIds = array_filter($proIds, 'is_numeric');

            QuotationRequirement::where('fk_quotation_id', $lastInsertedId)
                ->whereNotIn('id', $proIds)
                ->delete();

            if (!empty($request->requirements) && is_array($request->requirements)) {
                foreach ($request->requirements as $req) {
                    if (!empty($req['id'])) {
                        $quotationReqObj = QuotationRequirement::find($req['id']);
                    } else {
                        $quotationReqObj = new QuotationRequirement();
                        $quotationReqObj->fk_quotation_id = $lastInsertedId;
                    }

                    $quotationReqObj->product_id = isset($req['product_id']) ? $req['product_id'] : '';
                    $quotationReqObj->product_part_id = isset($req['part_noId']) ? $req['part_noId'] : '';
                    $quotationReqObj->part_no = isset($req['part_no']) ? $req['part_no'] : '';
                    $quotationReqObj->product_name = isset($req['product_name']) ? $req['product_name'] : '';
                    $quotationReqObj->description = isset($req['description']) ? $req['description'] : '';
                    $quotationReqObj->cust_description = isset($req['cust_description']) ? $req['cust_description'] : '';
                    $quotationReqObj->hsn = isset($req['hsn']) ? $req['hsn'] : '';
                    $quotationReqObj->unit = isset($req['unit']) ? $req['unit'] : '';
                    $quotationReqObj->qty = isset($req['qty']) ? $req['qty'] : '';
                    $quotationReqObj->rate = isset($req['rate']) ? $req['rate'] : '';
                    $quotationReqObj->moq = isset($req['moq']) ? $req['moq'] : '';
                    $quotationReqObj->number_of_days = isset($req['number_of_days']) ? $req['number_of_days'] : '';
                    $quotationReqObj->lead_time = isset($req['lead_time']) && !empty($req['lead_time'])
                        ? Carbon::createFromFormat('d/m/Y h:i A', $req['lead_time'])->format('Y-m-d')
                        : null;
                    $quotationReqObj->available = isset($req['available']) ? $req['available'] : '';
                    $quotationReqObj->material_per_lot_dispatch = isset($req['material_per_lot_dispatch']) ? $req['material_per_lot_dispatch'] : '';
                    $quotationReqObj->total_amount = isset($req['total_amount']) ? $req['total_amount'] : '';
                    $quotationReqObj->save();
                }
            }

            //Service Detail Store
            $proServiceIds = array_column($request->services, 'id');
            $proServiceIds = array_filter($proServiceIds, 'is_numeric');

            QuotationService::where('fk_quotation_id', $lastInsertedId)
                ->whereNotIn('id', $proIds)
                ->delete();

            if (!empty($request->services) && is_array($request->services)) {
                foreach ($request->services as $serReq) {
                    if (!empty($serReq['id'])) {
                        $quotationServiceObj = QuotationService::find($serReq['id']);
                    } else {
                        $quotationServiceObj = new QuotationService();
                        $quotationServiceObj->fk_quotation_id = $lastInsertedId;
                    }

                    $quotationServiceObj->part_no = isset($serReq['part_no']) ? $serReq['part_no'] : '';
                    $quotationServiceObj->hsn = isset($serReq['hsn']) ? $serReq['hsn'] : '';
                    $quotationServiceObj->label = isset($serReq['label']) ? $serReq['label'] : '';
                    $quotationServiceObj->set_name = isset($serReq['set_name']) ? $serReq['set_name'] : '';
                    $quotationServiceObj->qty = isset($serReq['qty']) ? $serReq['qty'] : '';
                    $quotationServiceObj->rate = isset($serReq['rate']) ? $serReq['rate'] : '';
                    $quotationServiceObj->total_amount = isset($serReq['total_amount']) ? $serReq['total_amount'] : '';
                    $quotationServiceObj->save();
                }
            }


            //this code used to be in condition below
            $projectQuotation = new ProjectQuotation();

            $projectQuotation->sales_person = $salesPerson;
            $projectQuotation->salutation = $salutation;
            $projectQuotation->fk_project_quotation_temp_id = $lastInsertedId;
            $projectQuotation->fk_rfq_id = $fk_rfq_id;
            $projectQuotation->fk_lead_id = $fk_lead_id;
            $projectQuotation->quotation_date = $quotationDate;
            $projectQuotation->quotation_revision_date = $qtnRevDate ?? NULL;
            $projectQuotation->duration = $duration;
            $projectQuotation->set_name = $setName;
            $projectQuotation->set_value = $setValue;
            $projectQuotation->reference = $reference;
            $projectQuotation->duration_date = $durationDateFormatted;
            $projectQuotation->quotation_no = $quotationNo;
            // $projectQuotation->set_name = $setName;
            // $projectQuotation->set_value = $setValue;
            $projectQuotation->requirements = $requirements;
            $projectQuotation->requirement_total = $requirementTotal;
            $projectQuotation->service_detail = $serviceDetail;
            $projectQuotation->service_total = $serviceTotal;
            $projectQuotation->total_basic_value = $totalBasicValue;
            $projectQuotation->final_amount = $finalAmount;
            $projectQuotation->final_amount_in_inr = $finalAmountInInr;
            $projectQuotation->special_notes = $specialNotes;
            $projectQuotation->cgst = $cgst;
            $projectQuotation->cgst_value = $cgstValue;
            $projectQuotation->sgst = $sgst;
            $projectQuotation->sgst_value = $sgstValue;
            $projectQuotation->igst = $igst;
            $projectQuotation->igst_value = $igstValue;
            $projectQuotation->quotation_terms = $quotationTerms;

            // Save the changes
            $projectQuotation->save();



            // if (!empty($id)) {
            //   // Retrieve the ProjectQuotation record based on the condition
            //   $projectQuotation = ProjectQuotation::where('fk_project_quotation_temp_id', $id)->first();

            //   if ($projectQuotation) {
            //     // Update the fields
            //     $projectQuotation->sales_person = $salesPerson;
            //     $projectQuotation->salutation = $salutation;
            //     $projectQuotation->fk_rfq_id = $fk_rfq_id;
            //     $projectQuotation->fk_lead_id = $fk_lead_id;
            //     $projectQuotation->quotation_date = $quotationDate;
            //     $projectQuotation->duration = $duration;
            //     $projectQuotation->duration_date = $durationDateFormatted;
            //     $projectQuotation->quotation_no = $quotationNo;
            //     // $projectQuotation->set_name = $setName;
            //     // $projectQuotation->set_value = $setValue;
            //     $projectQuotation->requirements = $requirements;
            //     $projectQuotation->requirement_total = $requirementTotal;
            //     $projectQuotation->final_amount = $finalAmount;
            //     $projectQuotation->special_notes = $specialNotes;
            //     $projectQuotation->cgst = $cgst;
            //     $projectQuotation->sgst = $sgst;
            //     $projectQuotation->igst = $igst;
            //     $projectQuotation->quotation_terms = $quotationTerms;

            //     // Save the changes
            //     $projectQuotation->save();
            //   }
            // }

            $projectQuotationTempObject->action = 'created';
            if ($id) {
                $projectQuotationTempObject->action = 'updated';
            }
            ProjectQuotationLogTempCreated::dispatch($projectQuotationTempObject);

            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed Creating Quotation: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Quotation"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    public function downloadPdf(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $viewPdf = $request->view_pdf;
            $quotationId = $request->quotation_id ?? "";
            $from = $request->from ?? "";

            if ($from === 'quotationHistory') {
                $quotationObject = ProjectQuotationLogTemp::with(['salesPerson.designation', 'rfq', 'rfq.leadContactPeople', 'preparedBy', 'lead.source', 'rfq.rsm', 'rfq.rsm.designation', 'rfq.source', 'rfq.currencyData', 'rfq.designation', 'rfq.banner', 'rfq.footer'])->find($quotationId);
            } else {
                $quotationObject = ProjectQuotationTemp::with(['salesPerson.designation', 'rfq.leadContactPeople', 'preparedBy', 'lead.source', 'rfq.rsm', 'rfq.rsm.designation', 'rfq.source', 'rfq.currencyData', 'rfq.designation', 'rfq.banner', 'rfq.footer'])->find($quotationId);
            }

            if (!$quotationObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Quotation"]);
                return $this->sendResponse($this->response, 200);
            }

            if (is_null($quotationObject->rfq)) {
                $this->response['error'] = 'RFQ is missing. Please verify the RFQ associated with this quotation.';
                return $this->sendResponse($this->response, 200);
            }

            if (is_null($quotationObject->rfq->division_id)) {
                $this->response['error'] = 'Division is missing. Please verify the RFQ associated with this quotation.';
                return $this->sendResponse($this->response, 200);
            }

            $quotation = new ProjectQuotationResource($quotationObject);

            $data = [
                'details' => json_decode(json_encode($quotation)),
            ];

            switch ($quotationObject->rfq->division_id) {
                case 1:
                    $view = 'pdf.quotation.he';
                    break;
                case 2:
                    $view = 'pdf.quotation.le';
                    break;
                case 4:
                    $view = 'pdf.quotation.sfc';
                    break;
                case 5:
                    $view = 'pdf.quotation.ad';
                    break;
                default:
                    $view = 'pdf.quotation.le';
                    break;
            }

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "Quotation Pdf"]);
                $this->response['data']['html'] = view($view, ['details' => $data['details']])->render();
                return $this->sendResponse($this->response, 200);
            }

            $qtnNo = str_replace(['-', '/'], '_', $quotationObject->quotation_no);
            $qtnNo = str_replace('QTN_', 'QTN', $qtnNo);
            $path = 'pdf/quotation/' . str_replace(['-', '/'], ' ', $qtnNo) . ' ' . date("Ymd") . '.pdf';

            MyPdf::view($view, ['details' => $data['details']])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Quotation Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Quotation PDF Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    public function sendEmail(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $quotationId = $request->quotation_id ?? "";

            if (!$quotationId) {
                $this->response['error'] = "Please select a valid Quotation!";
                return $this->sendResponse($this->response, 200);
            }

            $quotationObject = ProjectQuotationTemp::with('salesPerson', 'preparedBy', 'lead', 'rfq', 'rfq.designation')->find($quotationId);

            if (!$quotationObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Quotation"]);
                return $this->sendResponse($this->response, 200);
            }

            $quotation = new ProjectQuotationResource($quotationObject);

            $data = [
                'details' => json_decode(json_encode($quotation)),
            ];

            $toEmail =   $data['details']->rfq->email ?? '';

            if ($toEmail == '') {
                $this->response['status'] = 0;
                $this->response['error'] = 'Email Not Found For This Project';
                return $this->sendResponse($this->response, 200);
            }

            $encryptName = Crypt::encryptString($quotationId);
            $trimLength = substr($encryptName, 0, 6);
            $fileName = $trimLength . '.pdf';

            if ($fileName) {
                $sourcePath = 'public/uploads/pdf/quotation/' . $fileName;

                if (!Storage::exists($sourcePath)) {

                    $dompdf = PDF::loadView('pdf.quotation_pdf', $data);

                    $dompdf->setPaper('A4', 'portrait');

                    // Render the PDF
                    $dompdf->render();

                    $pdfContent = $dompdf->output(); // Get the generated PDF content

                    file_put_contents(storage_path('app/public/uploads/pdf/quotation/' . $fileName), $pdfContent);
                }
            }
            $filePath = url($this->fileAccessPath . '/pdf/quotation/' . $fileName);

            $subject = 'Quotation';

            SendQuotationEmailJob::dispatch($toEmail, $subject, $filePath);

            // Save the PDF to the specified file path

            $this->response['status'] = 1;
            $this->response['msg'] = "mail Will be sent to this Email : " . $toEmail;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Quotation pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function terms()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            // $list = ProjectQuotationTerm::select('id as value', 'title as label')->where('status', 1);
            $list = ProjectQuotationTerm::where('status', 1);

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list->get();
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function getCommonDetail(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $rfqId = $request->rfq_id ?? '';

            $rfqObject = Rfq::select('id', 'division_id')->find($rfqId);
            $divisionId = $rfqObject->division_id ?? '';

            if (!$rfqObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "RFQ"]);
                return $this->sendResponse($this->response, 200);
            }

            $reference = CommonReference::where(['division_id' => $divisionId, 'status' => 1])->first();
            $salutation = CommonSalutation::where(['division_id' => $divisionId, 'status' => 1])->first();
            $tnc = CommonTnc::where(['division_id' => $divisionId, 'status' => 1])->first();
            $specialNote = CommonSpecialNote::where(['division_id' => $divisionId, 'status' => 1])->first();


            $this->response['status'] = 1;
            $this->response['data']['reference'] = $reference;
            $this->response['data']['salutation'] = $salutation;
            $this->response['data']['tnc'] = $tnc;
            $this->response['data']['special_note'] = $specialNote;
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $proQuoObject = ProjectQuotationTemp::find($id);

            if (!$proQuoObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project Quotation"]);
                return $this->sendResponse($this->response, 500);
            }

            $proQuoObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Project Quotation"]);
            $this->response['data'] = $proQuoObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project Quotation deleting failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function validateAddUpdateQuotation(Request $request)
    {
        return Validator::make($request->all(), [
            'quotation_date' => 'required',
            'sales_person' => 'required|exists:users,id,deleted_at,NULL',
            'requirements.*.part_no' => 'required',
            'requirements.*.unit' => 'required',
            'requirements.*.qty' => 'required',

        ], [
            'requirements.*.part_no.required' => 'The part no is required',
            'requirements.*.unit.required' => 'The unit is required',
            'requirements.*.qty.required' => 'The qty is required',
        ])->errors();
    }
}
