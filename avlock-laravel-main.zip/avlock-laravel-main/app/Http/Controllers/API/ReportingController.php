<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Lead;
use App\Models\MasterReportField;
use App\Models\MasterReportSubField;
use App\Models\MasterReportType;
use App\Models\Rfq;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader\Exception;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class ReportingController extends AppBaseController {
  // where user will select reporting fields
  function index(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $typeId = $request->type_id;

      $field_list = DB::table('master_report_fields')->where('status', 1)->get()->toArray();

      foreach ($field_list as $key => &$value) {
        $sub_field_list = DB::table('master_report_sub_fields')
          ->where('field_id', $value->id)
          ->whereRaw('FIND_IN_SET(?, type_id)', [$typeId])
          ->where('status', 1)
          ->get()->toArray();

        $value->sub_fields = $sub_field_list;
      }

      $typeList = MasterReportType::where('status', 1);

      $this->response['status'] = 1;
      $this->response['data']['type_list'] = $typeList->get();
      $this->response['data']['field_list'] = $field_list;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Reporting field list failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  function generateReport(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $type_id = $request->type_id ?? '';
      $fields = $request->fields ?? [];
      $export = $request->export ?? 0;

      if (!$fields || count($fields) == 0) {
        $this->response['error'] = 'Please select at least one field!';
        return $this->sendResponse($this->response, 200);
      }

      $reportType = MasterReportType::find($type_id);

      if (!$reportType) {
        $this->response['error'] = 'Please select reporting type!';
        return $this->sendResponse($this->response, 200);
      }

      $fieldsList = MasterReportSubField::whereIn('id', $fields)->get();
      $headerTitles = array_column($fieldsList->toArray(), 'title');

      if ($reportType->code == 'LEAD') {
        $reportList = $this->getLeadReport($fieldsList);
        $reportList = $reportList->map(function ($item) {
          if (isset($item->industry)) {
            $item->industry = implode(', ', json_decode($item->industry, true));
          }
          return (array)$item;
        })->toArray();

        $this->response['status'] = 1;
        $this->response['data']['headers'] = $headerTitles;
        $this->response['data']['list'] = $reportList;

        if ($export) {
          $spreadsheet = new Spreadsheet();
          $spreadsheet->getActiveSheet()->fromArray($headerTitles, null, 'A1');
          $spreadsheet->getActiveSheet()->fromArray($reportList, null, 'A2');
          $excel = new Xlsx($spreadsheet);

          $fileName = 'LeadReport' . date('YmdHis') . mt_rand(1111, 9999) . '.xlsx';

          $excel->save($this->fileAccessPath . '/reporting/' . $fileName);
          $this->response['data']['file_url'] = $this->fileAccessPath . '/reporting/' . $fileName;
        }

        return $this->sendResponse($this->response, 200);
      }

      if ($reportType->code == 'RFQ') {
        $reportList = $this->getRfqReport($fieldsList);
        $reportList = $reportList->map(function ($item) {
          if (isset($item->industry)) {
            $item->industry = implode(', ', json_decode($item->industry, true));
          }
          return (array)$item;
        })->toArray();

        $this->response['status'] = 1;
        $this->response['data']['headers'] = $headerTitles;
        $this->response['data']['list'] = $reportList;

        if ($export) {
          $spreadsheet = new Spreadsheet();
          $spreadsheet->getActiveSheet()->fromArray($headerTitles, null, 'A1');
          $spreadsheet->getActiveSheet()->fromArray($reportList, null, 'A2');
          $excel = new Xlsx($spreadsheet);

          $fileName = 'RFQReport' . date('YmdHis') . mt_rand(1111, 9999) . '.xlsx';

          $excel->save($this->fileAccessPath . '/reporting/' . $fileName);
          $this->response['data']['file_url'] = $this->fileAccessPath . '/reporting/' . $fileName;
        }

        return $this->sendResponse($this->response, 200);
      }

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Report generation failed: " . $e->getMessage());
      $this->response['error'] = $e->getMessage();
      return $this->sendResponse($this->response, 500);
    }
  }

  function getLeadReport($fields) {
    $result = DB::table('leads as l');
    $result->groupBy('l.id');

    $select = [];

    $latestRfqJoined = false;

    $latestRfqQuotationJoined = false;
    $latestPoJoined = false;
    $latestInvoiceJoined = false;
    $latestPaymentJoined = false;

    $paymentJoined = false;
    $quotationJoined = false;
    $poJoined = false;
    $invoiceJoined = false;

    foreach ($fields as $key => $field) {
      if ($field->table_name == 'leads') {
        if ($field->column_name) {
          $select[] = 'l.' . $field->column_name;
        }
      }

      if ($field->code == 'RFQ_COUNT') {
        $select[] = DB::raw('count(DISTINCT(r1.id)) as rfq_count');
        $result->leftJoin('rfqs as r1', 'r1.lead_id', 'l.id');
      }

      if ($field->code == 'LEAD_ASSIGNED_RSM') {
        $select[] = DB::raw('u.name as rsm_name');
        $result->leftJoin('users as u', 'u.id', 'l.assigned_rsm');
      }

      if ($field->code == 'LEAD_VISIT_COUNT') {
        $select[] = DB::raw('COUNT(svr.id) as visit_count');
        $result->leftJoin('sales_visit_reports as svr', 'svr.fk_lead_id', 'l.id');
      }

      $latestRfqJoinConditions = ['RFQ_STAGE', 'RFQ_NUMBER', 'RFQ_STAGE_COMMENT', 'RFQ_SEGMENT', 'RFQ_INDUSTRY', 'RFQ_TYPE', 'RFQ_DIVISION', 'RFQ_PRODUCTS'];
      if (in_array($field->code, $latestRfqJoinConditions)) {
        if (!$latestRfqJoined) {
          $result->leftJoin('rfqs as r2', function ($join) {
            $join->on('r2.lead_id', '=', 'l.id');
            $join->whereRaw('r2.id = (SELECT MAX(r3.id) FROM rfqs AS r3 WHERE r3.lead_id = l.id)');
          });
          $latestRfqJoined = true;
        }

        if ($field->code == 'RFQ_STAGE') {
          $select[] = DB::raw('ss.name as stage');
          $result->leftJoin('sub_stages as ss', 'ss.id', 'r2.curr_sub_stage_id');
        }

        if ($field->code == 'RFQ_NUMBER') {
          $select[] = DB::raw('r2.rfq_number as rfq_number');
        }

        if ($field->code == 'RFQ_STAGE_COMMENT') {
          $select[] = DB::raw('r2.comments as stage_comment');
        }

        if ($field->code == 'RFQ_SEGMENT') {
          $select[] = DB::raw('(SELECT GROUP_CONCAT(ps.name) FROM project_segments AS ps WHERE ps.id IN (SELECT JSON_UNQUOTE(JSON_EXTRACT(r2.project_segments, "$[*]")))) as segments');
        }

        if ($field->code == 'RFQ_INDUSTRY') {
          $select[] = DB::raw('JSON_UNQUOTE(JSON_EXTRACT(r2.industry, "$[*].name")) as industry');
        }

        if ($field->code == 'RFQ_TYPE') {
          $select[] = DB::raw('pt.name as rfq_type');
          $result->leftJoin('project_types as pt', 'pt.id', 'r2.fk_project_type_id');
        }

        if ($field->code == 'RFQ_DIVISION') {
          $select[] = DB::raw('d.name as division_name');
          $result->leftJoin('divisions as d', 'd.id', 'r2.division_id');
        }

        if ($field->code == 'RFQ_PRODUCTS') {
          $select[] = DB::raw('GROUP_CONCAT(DISTINCT(p.product_name)) as products');
          $result->leftJoin('rfq_products as rp', 'rp.rfq_id', 'r2.id');
          $result->leftJoin('products as p', 'p.id', 'rp.product_id');
        }
      }

      $latestRfqQuotationJoinConditions = ['QUOTATION_COUNT', 'QUOTATION_AMOUNT', 'QUOTATION_NUMBER', 'QUOTATION_DATE'];
      if (in_array($field->code, $latestRfqQuotationJoinConditions)) {
        if (!$latestRfqQuotationJoined) {
          $result->leftJoin('project_quotations as pq1', function ($join) {
            $join->on('pq1.fk_lead_id', '=', 'l.id');
            $join->whereRaw('pq1.id = (SELECT MAX(pq2.id) FROM project_quotations AS pq2 WHERE pq2.fk_lead_id = l.id)');
          });
          $latestRfqQuotationJoined = true;
        }

        if (!$quotationJoined) {
          $result->leftJoin('project_quotations as pq3', 'pq3.fk_lead_id', 'l.id');
          $quotationJoined = true;
        }

        if ($field->code == 'QUOTATION_COUNT') {
          $select[] = DB::raw('count(DISTINCT(pq3.id)) as quotation_count');
        }

        if ($field->code == 'QUOTATION_AMOUNT') {
          $select[] = DB::raw('pq1.requirement_total as quotation_amount');
        }

        if ($field->code == 'QUOTATION_NUMBER') {
          $select[] = DB::raw('pq1.quotation_no');
        }

        if ($field->code == 'QUOTATION_DATE') {
          $select[] = DB::raw('pq1.quotation_date');
        }
      }

      $latestPoJoinConditions = ['PO_COUNT', 'PO_DATE', 'PO_NUMBER', 'PO_AMOUNT'];
      if (in_array($field->code, $latestPoJoinConditions)) {
        if (!$latestPoJoined) {
          $result->leftJoin('purchase_orders as po1', function ($join) {
            $join->on('po1.fk_lead_id', '=', 'l.id');
            $join->whereRaw('po1.id = (SELECT MAX(po2.id) FROM project_quotations AS po2 WHERE po2.fk_lead_id = l.id)');
          });
          $latestPoJoined = true;
        }

        if (!$poJoined) {
          $result->leftJoin('purchase_orders as po3', 'po3.fk_lead_id', 'l.id');
          $poJoined = true;
        }

        if ($field->code == 'PO_COUNT') {
          $select[] = DB::raw('count(DISTINCT(po3.id)) as po_count');
        }

        if ($field->code == 'PO_DATE') {
          $select[] = DB::raw('po1.po_date as po_date');
        }

        if ($field->code == 'PO_NUMBER') {
          $select[] = DB::raw('po1.po_no as po_number');
        }

        if ($field->code == 'PO_AMOUNT') {
          $select[] = DB::raw('sum(DISTINCT(po3.po_details_total)) as po_amount');
        }
      }

      $latestInvoiceJoinConditions = ['INVOICE_COUNT', 'INVOICE_DATE', 'INVOICE_NUMBER', 'INVOICE_AMOUNT'];
      if (in_array($field->code, $latestInvoiceJoinConditions)) {
        if (!$latestInvoiceJoined) {
          $result->leftJoin('purchase_invoices as pi1', function ($join) {
            $join->on('pi1.fk_lead_id', '=', 'l.id');
            $join->whereRaw('pi1.id = (SELECT MAX(pi2.id) FROM project_quotations AS pi2 WHERE pi2.fk_lead_id = l.id)');
          });
          $latestInvoiceJoined = true;
        }

        if (!$invoiceJoined) {
          $result->leftJoin('purchase_invoices as pi3', 'pi3.fk_lead_id', 'l.id');
          $invoiceJoined = true;
        }

        if ($field->code == 'INVOICE_COUNT') {
          $select[] = DB::raw('count(DISTINCT(pi3.id)) as invoice_count');
        }

        if ($field->code == 'INVOICE_DATE') {
          $select[] = DB::raw('pi1.pi_date as invoice_date');
        }

        if ($field->code == 'INVOICE_NUMBER') {
          $select[] = DB::raw('pi1.pi_no as invoice_number');
        }

        if ($field->code == 'INVOICE_AMOUNT') {
          $select[] = DB::raw('pi1.pi_total_amount as invoice_amount');
        }
      }

      $latestPaymentJoinConditions = ['PAYMENT_TOTAL_RECEIVED', 'PAYMENT_BALANCE_AMOUNT', 'PAYMENT_LAST_RECEIVED', 'PAYMENT_LAST_DATE'];
      if (in_array($field->code, $latestPaymentJoinConditions)) {
        if (!$latestPaymentJoined) {
          $result->leftJoin('purchase_invoice_payments as pip1', function ($join) {
            $join->on('pip1.fk_pi_id', '=', 'pi1.id');
            $join->whereRaw('pip1.id = (SELECT MAX(pip2.id) FROM purchase_invoice_payments AS pip2 WHERE pip2.fk_pi_id = pi1.id)');
          });
          $latestPaymentJoined = true;
        }


        if (!$paymentJoined) {
          $result->leftJoin('purchase_invoice_payments as pip3', 'pip3.fk_pi_id', 'pi1.id');
          $paymentJoined = true;
        }

        if ($field->code == 'PAYMENT_TOTAL_RECEIVED') {
          $select[] = DB::raw('(SELECT SUM(pip4.payment_amount) FROM purchase_invoice_payments AS pip4 WHERE pip4.fk_pi_id = pi1.id) as total_payment_received');
        }

        if ($field->code == 'PAYMENT_BALANCE_AMOUNT') {
          $select[] = DB::raw('(pi1.pi_total_amount - COALESCE((SELECT SUM(pip5.payment_amount) FROM purchase_invoice_payments AS pip5 WHERE pip5.fk_pi_id = pi1.id), 0)) as balance_amount');
        }

        if ($field->code == 'PAYMENT_LAST_RECEIVED') {
          $select[] = DB::raw('pip1.payment_amount as payment_last_received');
        }

        if ($field->code == 'PAYMENT_LAST_DATE') {
          $select[] = DB::raw('pip1.payment_date as payment_last_date');
        }
      }
    }

    $result->select($select);

    // dd(toSqlWithBindings($result));

    return $result->get();
  }

  function getRfqReport($fields) {
    $result = DB::table('rfqs as r1');
    $result->groupBy('r1.id');
    $select = [];

    $leadJoined = false;
    $invoiceJoined = false;
    $paymentJoined = false;
    $latestPoJoined = false;

    $latestQuotationJoined = false;
    $latestInvoiceJoined = false;
    $latestPaymentJoined = false;
    $poJoined = false;

    foreach ($fields as $key => $field) {
      if ($field->table_name == 'rfqs') {
        if ($field->column_name) {
          $select[] = 'r1.' . $field->column_name;
        }
      }

      if ($field->table_name == 'leads') {
        if ($field->column_name) {
          $select[] = 'l1.' . $field->column_name;
        }
      }

      if (!$leadJoined) {
        $result->leftJoin('leads as l1', 'l1.id', 'r1.lead_id');
        $leadJoined = true;
      }

      $quotationFields = ['QUOTATION_AMOUNT', 'QUOTATION_NUMBER', 'QUOTATION_DATE'];
      if (in_array($field->code, $quotationFields)) {
        if (!$latestQuotationJoined) {
          $result->leftJoin('project_quotations as pq1', function ($join) {
            $join->on('pq1.fk_rfq_id', '=', 'r1.id');
            $join->whereRaw('pq1.id = (SELECT MAX(pq2.id) FROM project_quotations AS pq2 WHERE pq2.fk_rfq_id = r1.id)');
          });
          $latestQuotationJoined = true;
        }

        if ($field->code == 'QUOTATION_AMOUNT') {
          $select[] = DB::raw('pq1.requirement_total as quotation_amount');
        }

        if ($field->code == 'QUOTATION_NUMBER') {
          $select[] = DB::raw('pq1.quotation_no');
        }

        if ($field->code == 'QUOTATION_DATE') {
          $select[] = DB::raw('pq1.quotation_date');
        }
      }

      if ($field->code == 'LEAD_ASSIGNED_RSM') {
        $select[] = DB::raw('u.name as rsm_name');
        $result->leftJoin('users as u', 'u.id', 'l1.assigned_rsm');
      }

      if ($field->code == 'RFQ_VISIT_COUNT') {
        $select[] = DB::raw('COUNT(svr.id) as visit_count');
        $result->leftJoin('sales_visit_reports as svr', 'svr.fk_rfq_id', 'r1.id');
      }

      if ($field->code == 'RFQ_STAGE') {
        $select[] = DB::raw('ss.name as stage');
        $result->leftJoin('sub_stages as ss', 'ss.id', 'r1.curr_sub_stage_id');
      }

      if ($field->code == 'RFQ_STAGE_COMMENT') {
        $select[] = DB::raw('r1.comments as stage_comment');
      }

      if ($field->code == 'RFQ_SEGMENT') {
        $select[] = DB::raw('r1.project_segments as segment_ids');
      }

      if ($field->code == 'RFQ_INDUSTRY') {
        $select[] = DB::raw('JSON_UNQUOTE(JSON_EXTRACT(r1.industry, "$[*].name")) as industry');
      }

      if ($field->code == 'RFQ_TYPE') {
        $select[] = DB::raw('pt.name as rfq_type');
        $result->leftJoin('project_types as pt', 'pt.id', 'r1.fk_project_type_id');
      }

      if ($field->code == 'RFQ_DIVISION') {
        $select[] = DB::raw('d.name as division_name');
        $result->leftJoin('division as d', 'd.id', 'r1.division_id');
      }

      if ($field->code == 'RFQ_PRODUCTS') {
        $select[] = DB::raw('GROUP_CONCAT(DISTINCT(p.product_name)) as products');
        $result->leftJoin('rfq_products as rp', 'rp.rfq_id', 'r1.id');
        $result->leftJoin('products as p', 'p.id', 'rp.product_id');
      }

      $latestPoJoinConditions = ['PO_COUNT', 'PO_DATE', 'PO_NUMBER', 'PO_AMOUNT'];
      if (in_array($field->code, $latestPoJoinConditions)) {
        if (!$latestPoJoined) {
          $result->leftJoin('purchase_orders as po1', function ($join) {
            $join->on('po1.fk_rfq_id', '=', 'r1.id');
            $join->whereRaw('po1.id = (SELECT MAX(po2.id) FROM project_quotations AS po2 WHERE po2.fk_rfq_id = r1.id)');
          });
          $latestPoJoined = true;
        }

        if (!$poJoined) {
          $result->leftJoin('purchase_orders as po3', 'po3.fk_rfq_id', 'r1.id');
          $poJoined = true;
        }

        if ($field->code == 'PO_COUNT') {
          $select[] = DB::raw('count(DISTINCT(po3.id)) as po_count');
        }

        if ($field->code == 'PO_DATE') {
          $select[] = DB::raw('po1.po_date as po_date');
        }

        if ($field->code == 'PO_NUMBER') {
          $select[] = DB::raw('po1.po_no as po_number');
        }

        if ($field->code == 'PO_AMOUNT') {
          $select[] = DB::raw('sum(DISTINCT(po3.po_details_total)) as po_amount');
        }
      }

      $latestInvoiceJoinConditions = ['INVOICE_COUNT', 'INVOICE_DATE', 'INVOICE_NUMBER', 'INVOICE_AMOUNT'];
      if (in_array($field->code, $latestInvoiceJoinConditions)) {
        if (!$latestInvoiceJoined) {
          $result->leftJoin('purchase_invoices as pi1', function ($join) {
            $join->on('pi1.fk_rfq_id', '=', 'r1.id');
            $join->whereRaw('pi1.id = (SELECT MAX(pi2.id) FROM project_quotations AS pi2 WHERE pi2.fk_rfq_id = r1.id)');
          });
          $latestInvoiceJoined = true;
        }

        if (!$invoiceJoined) {
          $result->leftJoin('purchase_invoices as pi3', 'pi3.fk_rfq_id', 'r1.id');
          $invoiceJoined = true;
        }

        if ($field->code == 'INVOICE_COUNT') {
          $select[] = DB::raw('count(DISTINCT(pi3.id)) as invoice_count');
        }

        if ($field->code == 'INVOICE_DATE') {
          $select[] = DB::raw('pi1.pi_date as invoice_date');
        }

        if ($field->code == 'INVOICE_NUMBER') {
          $select[] = DB::raw('pi1.pi_no as invoice_number');
        }

        if ($field->code == 'INVOICE_AMOUNT') {
          $select[] = DB::raw('pi1.pi_total_amount as invoice_amount');
        }
      }

      $latestPaymentJoinConditions = ['PAYMENT_TOTAL_RECEIVED', 'PAYMENT_BALANCE_AMOUNT', 'PAYMENT_LAST_RECEIVED', 'PAYMENT_LAST_DATE'];
      if (in_array($field->code, $latestPaymentJoinConditions)) {
        if (!$latestPaymentJoined) {
          $result->leftJoin('purchase_invoice_payments as pip1', function ($join) {
            $join->on('pip1.fk_pi_id', '=', 'pi1.id');
            $join->whereRaw('pip1.id = (SELECT MAX(pip2.id) FROM purchase_invoice_payments AS pip2 WHERE pip2.fk_pi_id = pi1.id)');
          });
          $latestPaymentJoined = true;
        }


        if (!$paymentJoined) {
          $result->leftJoin('purchase_invoice_payments as pip3', 'pip3.fk_pi_id', 'pi1.id');
          $paymentJoined = true;
        }

        if ($field->code == 'PAYMENT_TOTAL_RECEIVED') {
          $select[] = DB::raw('(SELECT SUM(pip4.payment_amount) FROM purchase_invoice_payments AS pip4 WHERE pip4.fk_pi_id = pi1.id) as total_payment_received');
        }

        if ($field->code == 'PAYMENT_BALANCE_AMOUNT') {
          $select[] = DB::raw('(pi1.pi_total_amount - COALESCE((SELECT SUM(pip5.payment_amount) FROM purchase_invoice_payments AS pip5 WHERE pip5.fk_pi_id = pi1.id), 0)) as balance_amount');
        }

        if ($field->code == 'PAYMENT_LAST_RECEIVED') {
          $select[] = DB::raw('pip1.payment_amount as payment_last_received');
        }

        if ($field->code == 'PAYMENT_LAST_DATE') {
          $select[] = DB::raw('pip1.payment_date as payment_last_date');
        }
      }
    }

    $result->select($select);

    // dd(toSqlWithBindings($result));

    return $result->get();
  }
}
