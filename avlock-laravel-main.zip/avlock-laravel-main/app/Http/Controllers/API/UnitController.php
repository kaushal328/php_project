<?php

namespace App\Http\Controllers\API;

use App\Enums\ErrorType;
use App\Http\Controllers\Controller;
use App\Models\Unit;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class UnitController extends AppBaseController
{

    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $title = $request->title ?? '';

            $Unit = Unit::orderBy("id", "desc");

            if ($title) {
                $Unit->where('title', 'like', '%' . $title . '%');
            }

            $num_rows = $Unit->count();
            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Unit"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['title'] = $title;
            $this->response['data']['list'] = $Unit->limit($per_page)->offset($offset)->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Unit fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addUpdate(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateUnit($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $UnitObject = new Unit();
            $id = $request->id;
            $title = $request->title ?? '';



            if ($id) {
                $UnitObject = Unit::find($id);

                if (!$UnitObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Unit"]);
                    return $this->sendResponse($this->response, 200);
                }

                $UnitObject->first();
                $this->response['msg'] = __('admin.updated', ['module' => "Unit"]);
            } else {
                $this->response['msg'] = __('admin.created', ['module' => "Unit"]);
            }

            $UnitObject->title = $title;
            $UnitObject->save();

            $this->response['status'] = 1;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Unit: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Unit"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $UnitObject = Unit::find($id);

            if (!$UnitObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Unit"]);
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Unit"]);
            $this->response['data'] = $UnitObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Unit fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $UnitObject = Unit::find($id);

            if (!$UnitObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Unit"]);
                return $this->sendResponse($this->response, 200);
            }

            $UnitObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Unit"]);
            $this->response['data'] = $UnitObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Unit Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function getUnit(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $unitObj = Unit::get();

            if (!$unitObj) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Weight Unit"]);
                return $this->sendResponse($this->response, 500);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Weight Unit"]);
            $this->response['data']['list'] = $unitObj;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Weight Unit deleting failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function fetchUnit(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id ?? '';
            $unitObj = Unit::find($id);

            if (!$unitObj) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Unit"]);
                return $this->sendResponse($this->response, 500);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Unit"]);
            $this->response['data']['list'] = $unitObj;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Fetch unit failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function validateAddUpdateUnit(Request $request)
    {
        return Validator::make($request->all(), [
            'title' => 'required|string|unique:units,title,' . $request->id . ',id,deleted_at,NULL',
        ])->errors();
    }
}
