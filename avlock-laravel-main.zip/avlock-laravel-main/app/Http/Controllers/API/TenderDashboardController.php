<?php

namespace App\Http\Controllers\API;

use App\Models\Tender;
use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\PurchaseOrder;
use App\Models\TenderStageLog;
use App\Models\TenderPurchaseOrder;
use Illuminate\Support\Facades\Log;
use App\Models\TenderPurchaseInvoice;
use App\Http\Controllers\API\AppBaseController;
use App\Http\Resources\SalesOrderResource;
use App\Http\Resources\TabulationResource;
use App\Http\Resources\TenderDispatchResource;
use App\Models\AvlockSalesOrder;
use App\Models\BiddingConsigneeRequirment;
use App\Models\BiddingProductRequirment;
use App\Models\DeliveryConfirmation;
use App\Models\PoDespatchDetail;
use App\Models\Tabulation;
use App\Models\TenderBidding;
use App\Models\Unit;
use App\Models\User;
use Carbon\Carbon;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

class TenderDashboardController extends AppBaseController
{

    private $TENDER_APPLIED = 3;
    private $TENDER_LOST = 6;

    private function getFiscalYearDates()
    {
        $currentMonth = (int)date('m');
        $currentYear = (int)date('Y');

        return [
            'currentMonth' => $currentMonth,
            'fiscalYear' => ($currentMonth >= 1 && $currentMonth <= 3) ? $currentYear - 1 : $currentMonth,
        ];
    }


    private function applyFiscalMonthScope($query, $fiscalYear, $currentMonth, $dateColumn)
    {
        return $query->where(function ($q) use ($fiscalYear, $currentMonth, $dateColumn) {
            if ($currentMonth >= 4) {
                $q->whereYear($dateColumn, $fiscalYear)
                    ->whereMonth($dateColumn, $currentMonth);
            } else {
                $q->whereYear($dateColumn, $fiscalYear + 1)
                    ->whereMonth($dateColumn, $currentMonth);
            }
        });
    }

    private function applyFiscalYearScope($query, $fiscalYear, $dateColumn)
    {
        return $query->where(function ($q) use ($fiscalYear, $dateColumn) {
            $q->where(function ($inner) use ($fiscalYear, $dateColumn) {
                $inner->whereYear($dateColumn, $fiscalYear)
                    ->whereMonth($dateColumn, '>=', 4);
            })->orWhere(function ($inner) use ($dateColumn, $fiscalYear) {
                $inner->whereYear($dateColumn, $fiscalYear + 1)
                    ->whereMonth($dateColumn, '<=', 3);
            });
        });
    }


    public function index()
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            //Tender Dashboard
            $tenderReceived = Tender::where('application_initiate', 0)->orderBy('id', 'desc')->get()->count();
            $pendingApplication = TenderStageLog::where('sub_stage_id', '<', $this->TENDER_APPLIED)->groupBy('tender_id')->get()->count();
            $tenderSubmitted = TenderStageLog::where('sub_stage_id', '>=', $this->TENDER_APPLIED)->groupBy('tender_id')->get()->count();
            $lostTender = TenderStageLog::where('sub_stage_id', '=', $this->TENDER_LOST)->groupBy('tender_id')->get()->count();
            $totalValueSubmitted = $this->getTotalValue($this->TENDER_APPLIED, '>=');
            $totalValueLostTender = $this->getTotalValue($this->TENDER_LOST, '=');

            //Sales Dashboard
            $orderReceived = TenderPurchaseOrder::get()->count();
            $totalOrderValue = TenderPurchaseOrder::get()->sum('po_details_total');
            $totalSaleValue = TenderPurchaseInvoice::get()->sum('final_amount');
            $totalPendingOrder = $totalOrderValue - $totalSaleValue;

            //Product Dashboard
            $categoryList = [];
            $totalInvoice = TenderPurchaseInvoice::get();
            foreach ($totalInvoice as $invoice) {
                $productdetails = !empty($invoice->pi_details) ? json_decode($invoice->pi_details, true) : [];
                if (count($productdetails) > 0) {
                    foreach ($productdetails as $k => $product) {
                        $productObject = Product::with('category:id,category_name,slug')->find($product['product_id'])->toArray();
                        $category = $productObject['category'];

                        $currentProducts = @$categoryList[$category['id']]['products'] ?? [];
                        $amount = $product['total_amount'];

                        if (count($currentProducts) > 0) {
                            $amountArray = array_column($currentProducts, 'total_amount') ?? [];
                            $amount += array_sum($amountArray);
                        }

                        $categoryList[$category['id']]['category_id'] = $category['id'];
                        $categoryList[$category['id']]['category_name'] = $category['category_name'];
                        $categoryList[$category['id']]['amount'] = $amount;
                        $categoryList[$category['id']]['products'][] = $product;
                    }
                }
            }

            $salesVal = [
                //Tender Dashbpard
                'tender_received' => $tenderReceived,
                'tender_pending' => $pendingApplication,
                'tender_submitted' => $tenderSubmitted,
                'total_value_submitted' => $totalValueSubmitted,
                'lost_tender' => $lostTender,
                'total_lost_tender' => $totalValueLostTender,
                //Sale Dashboard
                'order_received' => $orderReceived,
                'total_order_value' => $totalOrderValue,
                'total_sale_value' => $totalSaleValue,
                'total_pending_order' => $totalPendingOrder,
                //Product Dashboard
                'catgory_sales_list' => array_slice($categoryList, 0, 4),
                'category_sale_other_total' => array_sum(array_column(array_slice($categoryList, 4, count($categoryList)), 'amount')),
                'category_sales_total' => array_sum(array_column($categoryList, 'amount')),
            ];

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Sales Dashboard Tenders"]);
            $this->response['data'] = $salesVal;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Segment Report Lists fetching failed: " . $e);
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    protected function getTotalValue($stageName, $condition = '')
    {
        return TenderStageLog::with('tender:id,tender_budget')->where('sub_stage_id', $condition, $stageName)->groupBy('tender_id')->get('tender_id')
            ->sum(function ($item) {
                return $item->tender->tender_budget;
            });
    }

    function poCount(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $poCount = PurchaseOrder::whereHas('tender', function ($q) {
                    $q->whereNotNull('id');
                })->where('po_type', 2)->orderBy('id', 'desc');
            } elseif ($this->isUserInsideSale || $this->psmUserRole) {
                $insideSaleDivisions = User::find($this->userId)->division_ids;
                $divisionIdsArray = explode(',', $insideSaleDivisions);

                $poCount = PurchaseOrder::whereHas('tender', function ($q) use ($divisionIdsArray) {
                    $q->whereNotNull('id');
                    $q->whereIn('division_id', $divisionIdsArray);
                })->where('po_type', 2)->orderBy('id', 'desc');
            } else {
                $poCount = PurchaseOrder::where(function ($q) use ($juniorUserIds) {
                    $q->where('prepared_by', $this->userId)->orWhere(function ($query) use ($juniorUserIds) {
                        $query->whereIn('prepared_by', $juniorUserIds);
                    });
                })->where('po_type', 2)->orderBy('id', 'desc');
            }

            $poCountThisMonthQuery = clone $poCount;
            $poCountThisMonth = $poCountThisMonthQuery->whereYear('po_date', date('Y'))->whereMonth('po_date', date('m'))->count();

            $poCountThisYearQuery = clone $poCount;
            $poCountThisYear = $poCountThisYearQuery->whereYear('po_date', date('Y'))->count();

            $result = [
                'title' => 'Purchase Order',
                'this_month' => $poCountThisMonth,
                'this_year' => $poCountThisYear,
            ];


            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Tender Purchase Order Count"]);
            $this->response['data'] = $result;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender Purchase Order Count fetching failed: " . $e);
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function getCounts(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $currentMonth = $dates['currentMonth'];

            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            // Purchase Order Query
            if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $poCount = PurchaseOrder::whereHas('tender', function ($q) {
                    $q->whereNotNull('id');
                })->where('po_type', 2)->orderBy('id', 'desc');
            } elseif ($this->isUserInsideSale || $this->psmUserRole) {
                $insideSaleDivisions = User::find($this->userId)->division_ids;
                $divisionIdsArray = explode(',', $insideSaleDivisions);

                $poCount = PurchaseOrder::whereHas('tender', function ($q) use ($divisionIdsArray) {
                    $q->whereNotNull('id');
                    $q->whereIn('division_id', $divisionIdsArray);
                })->where('po_type', 2)->orderBy('id', 'desc');
            } else {
                $poCount = PurchaseOrder::where(function ($q) use ($juniorUserIds) {
                    $q->where('prepared_by', $this->userId)
                        ->orWhere(function ($query) use ($juniorUserIds) {
                            $query->whereIn('prepared_by', $juniorUserIds);
                        });
                })->where('po_type', 2)->orderBy('id', 'desc');
            }

            // Sales Order Query
            if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $soCount = AvlockSalesOrder::orderBy('id', 'desc')->where('po_type', 2);
            } else {
                $soCount = AvlockSalesOrder::where(function ($query) use ($juniorUserIds) {
                    $query->where('created_by', $this->userId)
                        ->orWhere(function ($q) use ($juniorUserIds) {
                            $q->whereIn('created_by', $juniorUserIds);
                        });
                })->orderBy('id', 'desc')->where('po_type', 2);
            }

            //Dispatch query
            $dispatchCount = PoDespatchDetail::where('po_type', 2)->orderBy('id', 'desc');

            //Todays Dispatch Query
            $dispatchCountToday = PoDespatchDetail::where('po_type', 2)->orderBy('id', 'desc');

            //Delivered Dispatch Query
            $dcCount = DeliveryConfirmation::with('so')->where('po_type', 2)->orderBy('id', 'desc');

            //Quotation Query
            $quotationCount = TenderBidding::orderBy('id', 'desc');

            //Tabulation Query
            $tabulationCount = Tabulation::orderBy('id', 'desc');

            // Purchase Order Counts
            $poCountThisMonthQuery = clone $poCount;
            $poCountThisMonth = $this->applyFiscalMonthScope($poCountThisMonthQuery, $fiscalYear, $currentMonth, 'po_date')->count();

            $poCountThisYearQuery = clone $poCount;
            $poCountThisYear = $this->applyFiscalYearScope($poCountThisYearQuery, $fiscalYear, 'po_date')->count();

            //Quotation Count
            $quotationCountThisMonthQuery = clone $quotationCount;
            $quotationCountThisMonth = $this->applyFiscalMonthScope($quotationCountThisMonthQuery, $fiscalYear, $currentMonth, 'quotation_date')->count();

            $quotationCountThisYearQuery = clone $quotationCount;
            $quotationCountThisYear = $this->applyFiscalYearScope($quotationCountThisYearQuery, $fiscalYear, 'quotation_date')->count();

            // Sales Order Counts
            $soCountThisMonthQuery = clone $soCount;
            $soCountThisMonth = $this->applyFiscalMonthScope($soCountThisMonthQuery, $fiscalYear, $currentMonth, 'so_date')->count();

            $soCountThisYearQuery = clone $soCount;
            $soCountThisYear = $this->applyFiscalYearScope($soCountThisYearQuery, $fiscalYear, 'so_date')->count();

            //Disptach Count
            $dispatchCountMonthQuery = clone $dispatchCount;
            $dispatchCountThisMonth = $this->applyFiscalMonthScope($dispatchCountMonthQuery, $fiscalYear, $currentMonth, 'despatch_date')->count();

            $dispatchCountThisYearQuery = clone $dispatchCount;
            $dispatchCountThisYear = $this->applyFiscalYearScope($dispatchCountThisYearQuery, $fiscalYear, 'despatch_date')->count();


            //Todays Dispatch Count
            $dispatchCountTodayQuery = clone $dispatchCountToday;
            $disCountToday = $dispatchCountTodayQuery->whereDate('despatch_date', Carbon::today())->count();


            $dcCountThisMonth = clone $dcCount;
            $dcCountThisMonth = $this->applyFiscalMonthScope($dcCountThisMonth, $fiscalYear, $currentMonth, 'dc_date')->count();

            $dcCountThisYear = clone $dcCount;
            $dcCountThisYear = $this->applyFiscalYearScope($dcCountThisYear, $fiscalYear, 'dc_date')->count();

            // Purchase Order Counts
            $tabCountThisMonthQuery = clone $tabulationCount;
            $tabCountThisMonth = $this->applyFiscalMonthScope($tabCountThisMonthQuery, $fiscalYear, $currentMonth, 'created_at')->count();

            $tabCountThisYearQuery = clone $tabulationCount;
            $tabCountThisYear = $this->applyFiscalYearScope($tabCountThisYearQuery, $fiscalYear, 'created_at')->count();

            $result = [
                'sales_order' => [
                    'title' => 'Sales Order',
                    'this_month' => $soCountThisMonth,
                    'this_year' => $soCountThisYear
                ],
                'purchase_order' => [
                    'title' => 'Purchase Order',
                    'this_month' => $poCountThisMonth,
                    'this_year' => $poCountThisYear,
                ],
                'quotation' => [
                    'title' => 'Quotation',
                    'this_month' => $quotationCountThisMonth,
                    'this_year' => $quotationCountThisYear,
                ],
                'dispatch' => [
                    'title' => 'Dispatch',
                    'this_month' => $dispatchCountThisMonth,
                    'this_year' => $dispatchCountThisYear
                ],
                'today_dispatch' => [
                    'title' => 'Todays Dispatch',
                    'this_month' => $disCountToday,
                ],
                'delivered_despatch' => [
                    'title' => 'Delivered Dispatch',
                    'this_month' => $dcCountThisMonth,
                    'this_year' => $dcCountThisYear,
                ],
                'tabulation' => [
                    'title' => 'Tabulation',
                    'this_month' => $tabCountThisMonth,
                    'this_year' => $tabCountThisYear,
                ],
            ];

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Counts"]);
            $this->response['data'] = $result;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Order counts fetching failed: " . $e);
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }
    public function purchaseOrderList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $poType = $request->tab ?? '';
            $name = $request->name ?? '';
            $purchaseOrderNo = $request->po_no ?? '';
            $inspection = $request->inspection ?? '';
            $divisionId = $request->division_id ?? '';
            $startDate = $request->start_date ?? "";
            $endDate = $request->end_date ?? "";
            $dpStartDate = $request->dp_start_date ?? "";
            $dpEndDate = $request->dp_end_date ?? "";
            $dateRange = $request->date_range ?? '';
            $tenderId = $request->tender_id ?? '';
            $partId = $request->part_no_id ?? '';
            $isExport = $request->is_export;

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'po_date';

            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $po = PurchaseOrder::with(['tender', 'preparedBy', 'tenderSubStage:id,name', 'tenderQuotation', 'poDetail.poDetailConsignee.poDetailConsigneeDate'])
                    ->whereHas('tender', function ($q) {
                        $q->whereNotNull('id');
                    })->where('po_type', 2)->orderBy('updated_at', 'desc');
            } elseif ($this->isUserInsideSale || $this->psmUserRole) {
                $insideSaleDivisions = User::find($this->userId)->division_ids;
                $divisionIdsArray = explode(',', $insideSaleDivisions);

                $this->response['data']['dids'] = $divisionIdsArray;

                $po = PurchaseOrder::with(['tender', 'preparedBy', 'tenderSubStage:id,name', 'tenderQuotation', 'poDetail.poDetailConsignee.poDetailConsigneeDate'])
                    ->whereHas('tender', function ($q) use ($divisionIdsArray) {
                        $q->whereNotNull('id');
                        $q->whereIn('division_id', $divisionIdsArray);
                    })->where('po_type', 2)->orderBy('updated_at', 'desc');
            } else {
                $po = PurchaseOrder::with(['tender', 'preparedBy', 'tenderSubStage:id,name', 'tenderQuotation', 'poDetail.poDetailConsignee.poDetailConsigneeDate'])->where(function ($query) use ($juniorUserIds) {
                    $query->where('prepared_by', $this->userId)
                        ->orWhere(function ($q) use ($juniorUserIds) {
                            $q->whereIn('prepared_by', $juniorUserIds);
                        });
                })
                    ->whereHas('tender', function ($q) {
                        $q->whereNotNull('id');
                    })->where('po_type', 2)->orderBy('updated_at', 'desc');
            }

            if ($tenderId) {
                $po->where('tender_id', $tenderId);
            }

            if ($name) {
                $po->whereHas('tender', function ($q) use ($name) {
                    $q->where('name', 'like', '%' . $name . '%');
                });
            }

            if ($inspection) {
                $po->whereHas('tender', function ($q) use ($inspection) {
                    $q->where('inspection', 'like', '%' . $inspection . '%');
                });
            }

            if ($partId) {
                $po->whereRaw(
                    "JSON_CONTAINS(po_details, ?)",
                    [json_encode(['product_part_id' => (int)$partId])]
                );
            }

            if ($divisionId) {
                $po->whereHas('tender', function ($query) use ($divisionId) {
                    $query->where('division_id', $divisionId);
                });
            }

            if ($purchaseOrderNo) {
                $po->where('po_no', 'like', '%' . $purchaseOrderNo . '%');
            }

            if ($dpStartDate || $dpEndDate) {
                $po->whereHas('poDetail.poDetailConsignee.poDetailConsigneeDate', function ($q) use ($dpStartDate, $dpEndDate) {
                    if ($dpStartDate && $dpEndDate) {
                        $q->where(function ($query) use ($dpStartDate, $dpEndDate) {
                            $query->whereDate('delivery_start_date', '<=', $dpEndDate)
                                ->whereDate('delivery_end_date', '>=', $dpStartDate);
                        });
                    } elseif ($dpStartDate) {
                        $q->whereDate('delivery_end_date', '>=', $dpStartDate);
                    } elseif ($dpEndDate) {
                        $q->whereDate('delivery_start_date', '<=', $dpEndDate);
                    }
                });
            }


            if ($dateRange) {
                if ($dateRange == 'today') {
                    $po->whereDate('po_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $po->whereDate('po_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $po->whereDate('po_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $po->whereDate('po_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $po->whereDate('po_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $po->whereDate('po_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $po->whereDate('po_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $po->whereDate('po_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $po->whereMonth('po_date', date('m'))->whereYear('po_date', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $po->whereMonth('po_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('po_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }
                if ($dateRange == 'this_year') {
                    $po->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }
                if ($dateRange == 'last_year') {
                    $po->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $po->whereDate('po_date', '>=', $startDate);

                        if ($endDate) {
                            $po->whereDate('po_date', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $po->count();
            if ($isExport == 1) {
                $poList = $po->get();
            } else {
                $poList = $po->limit($per_page)->offset($offset)->get();
            }

            if ($isExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                $headers = ['PO No', 'Quotation No', 'RFQ No', 'PO Date', 'Company', 'PO Value', 'PO Type', 'Updated By', 'RSM', 'Current Stage'];
                $sheetData = [$headers];

                foreach ($poList as $item) {
                    $quotationNo = isset($item->quotation) ? $item->quotation->quotation_no : '';
                    $company = isset($item->lead) ? $item->lead->company : '';
                    $poType = isset($item->poType) ? $item->poType->title : '';
                    $updatedBy = isset($item->updatedBy) ? $item->updatedBy->name : '';
                    $rsmName = isset($item->rfq) ? $item->rfq->rsm_name : '';
                    $rfqNo = isset($item->rfq) ? $item->rfq->rfq_number : '';
                    $subStage = isset($item->subStage) ? $item->subStage->name : '';

                    $baseRowData = [
                        $item->po_no ?? '',
                        $quotationNo,
                        $rfqNo,
                        Carbon::parse($item->po_date)->format('d/m/y'),
                        $company,
                        formatIndianRupees($item->po_details_total) ?? '',
                        $poType,
                        $updatedBy,
                        $rsmName,
                        $subStage,
                    ];
                    $sheetData[] = $baseRowData;
                }

                $sheet->fromArray($sheetData, null, 'A1');
                $store = "storage/app/public/uploads/po/po_$poType.csv";
                $filePath = "storage/uploads/po/po_$poType.csv";
                $writer = new Csv($spreadsheet);
                $writer->save($store);
            }

            $poList = TenderDispatchResource::collection($poList);

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Tender Dashboard Purchase Order Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['list'] = $poList ?? [];
            $this->response['data']['filePath'] = $filePath ?? [];
            $this->response['data']['po_no'] = $purchaseOrderNo;
            $this->response['data']['division_id'] = $divisionId;
            $this->response['data']['name'] = $name;
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['end_date'] = $endDate;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function quotationList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $quotationNo = $request->quotation_no ?? '';
            $tenderNo = $request->tender_no ?? '';
            $divisionId = $request->division ?? '';
            $name = $request->name ?? '';
            $partNo = $request->part_no ?? '';
            $startDate = $request->start_date;
            $endDate = $request->end_date;
            $dateRange = strtolower($request->date_range);
            $curStageId = $request->current_stage_id ?? '';
            $finalAmount = $request->final_amount ?? '';
            $isExport = $request->is_export ?? 0;

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'quotation_date';


            $quotation = TenderBidding::with(['tender', 'biddingProReq', 'tender.currentSubStage', 'tender.division'])->orderBy('id', 'desc');

            if ($quotationNo) $quotation->where('quotation_no', 'like', '%' . $quotationNo . '%');

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $quotation->whereDate('quotation_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $quotation->whereDate('quotation_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $quotation->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $quotation->whereDate('quotation_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $quotation->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $quotation->whereDate('quotation_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $quotation->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $quotation->whereDate('quotation_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $quotation->whereMonth('quotation_date', date('m'))->whereYear('quotation_date', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $quotation->whereMonth('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $quotation->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $quotation->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $quotation->whereDate('quotation_date', '>=', $startDate);

                        if ($endDate) {
                            $quotation->whereDate('quotation_date', '<=', $endDate);
                        }
                    }
                }
            }

            if ($name) {
                $quotation->whereHas('tender', function ($query) use ($name) {
                    $query->where('name', 'like', '%' . $name . '%');
                });
            }

            if ($tenderNo) {
                $quotation->whereHas('tender', function ($query) use ($tenderNo) {
                    $query->where('tender_no', 'like', '%' . $tenderNo . '%');
                });
            }

            if ($partNo) {
                $quotation->whereHas('biddingProReq', function ($query) use ($partNo) {
                    $query->where('part_no', 'like', $partNo . '%');
                });
            }


            if ($divisionId) {
                $quotation->whereHas('tender', function ($query) use ($divisionId) {
                    $query->where('division_id', $divisionId);
                });
            }

            if ($curStageId) {
                $quotation->whereHas('tender', function ($query) use ($curStageId) {
                    $query->where('sub_stage_id', $curStageId);
                });
            }

            $num_rows = $quotation->count();
            if ($isExport == 1) {
                $quotation = $quotation->get();
            } else {
                $quotation = $quotation->limit($per_page)->offset($offset)->get();
            }

            if ($isExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                $headers = [
                    'Quotation No',
                    'Quotation Date',
                    'Tender No.',
                    'Tenderer Name',
                    'Division',
                    'Part No.',
                    'Product Description (Avlock)',
                    'Product Description (Customer)',
                    'Qty',
                    'Unit',
                    'Rate',
                    'Total',
                    'Current Stage',
                    'Updated At'
                ];

                $sheetData = [$headers];

                foreach ($quotation as $key => $item) {
                    $products = BiddingProductRequirment::with(['tender', 'consignee'])
                        ->where('tender_id', $item->tender_id)
                        ->get();

                    $divisionName = isset($item->tender->division) ? $item->tender->division->name : '';

                    foreach ($products as $product) {
                        $totalConsigneeQty = 0; // Initialize total consignee quantity
                        if ($product->consignee && count($product->consignee) > 0) {
                            foreach ($product->consignee as $consignee) {
                                $totalConsigneeQty += floatVal($consignee->qty);
                            }
                        }

                        $productRow = [
                            $item->quotation_no,
                            Carbon::parse($item->quotation_date)->format('d/m/y'),
                            isset($item->tender) ? $item->tender->tender_no : '-',
                            isset($item->tender) ? $item->tender->name : '-',
                            $divisionName,
                            $product->part_no ?? '',
                            $product->avlock_description ?? '',
                            $product->description ?? '',
                            $totalConsigneeQty,
                            '-',
                            $product->rate ?? '',
                            $totalConsigneeQty * ($product->rate ?? 0), // Total amount
                            isset($item->tender) && isset($item->tender->currentSubStage)
                                ? $item->tender->currentSubStage->name
                                : '',
                            Carbon::parse($item->updated_at)->format('M d, Y h:i a')
                        ];
                        $sheetData[] = $productRow;

                        if ($product->consignee && count($product->consignee) > 0) {
                            foreach ($product->consignee as $consignee) {
                                $unitObj = null;
                                if ($consignee->unit) {
                                    $unitObj = Unit::find($consignee->unit);
                                }

                                $consigneeRow = [
                                    $item->quotation_no,
                                    Carbon::parse($item->quotation_date)->format('d/m/y'),
                                    isset($item->tender) ? $item->tender->tender_no : '-',
                                    isset($item->tender) ? $item->tender->name : '-',
                                    $divisionName,
                                    $product->part_no ?? '',
                                    $product->avlock_description ?? '',
                                    $product->description ?? '',
                                    $consignee->qty, // Consignee qty
                                    $unitObj->title ?? '', // Consignee unit
                                    '',
                                    '', // Total amount
                                    isset($item->tender) && isset($item->tender->currentSubStage)
                                        ? $item->tender->currentSubStage->name
                                        : '',
                                    Carbon::parse($item->updated_at)->format('M d, Y h:i a')
                                ];
                                $sheetData[] = $consigneeRow;
                            }
                        }
                    }
                }


                $sheet->fromArray($sheetData, null, 'A1');
                $store = "storage/app/public/uploads/quotation/TenderQuotation.csv";
                $filePath = "storage/uploads/quotation/TenderQuotation.csv";
                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }

            $totalBidValue = 0;
            if ($quotation && $quotation->isNotEmpty()) {
                $totalBidValue = $quotation->sum(function ($item) {
                    return isset($item['total_bid_value']) ? $item['total_bid_value'] : 0;
                });
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Quotation Lists"]);
            $this->response['filePath'] = $filePath ?? '';
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['quotation_no'] = $quotationNo;
            $this->response['data']['tender_no'] = $tenderNo;
            $this->response['data']['tender_name'] = $name;
            $this->response['data']['part_no'] = $partNo;
            $this->response['data']['division'] = $divisionId;
            $this->response['data']['final_amount'] = $finalAmount;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['current_stage_id'] = $curStageId;
            $this->response['data']['total_bid_value'] = moneyFormatIndia($totalBidValue) ?? 0;
            $this->response['data']['list'] = $quotation ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Quotation Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function tabulationList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $tenderNo = $request->tender_no ?? '';
            $tenderName = $request->name ?? '';
            $quotationNo = $request->quotation_no ?? '';
            $divisionId = $request->division ?? '';
            $partNo = $request->part_no ?? '';
            $result = $request->result ?? '';
            $currSubSatgeId = $request->current_stage_id ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';
            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'created_at';
            $isExport = $request->is_export ?? 0;

            $poDispatchObj = Tabulation::with(['tender.tenderBidding.biddingProReq'])->orderBy('id', 'desc');

            if ($tenderNo) {
                $poDispatchObj->whereHas('tender', function ($q) use ($tenderNo) {
                    $q->where('tender_no', 'like', '%' . $tenderNo . '%');
                });
            }

            if ($tenderName) {
                $poDispatchObj->whereHas('tender', function ($q) use ($tenderName) {
                    $q->where('name', 'like', '%' . $tenderName . '%');
                });
            }

            if ($divisionId) {
                $poDispatchObj->whereHas('tender', function ($q) use ($divisionId) {
                    $q->where('division_id', $divisionId);
                });
            }

            if ($quotationNo) {
                $poDispatchObj->whereHas('tender.tenderBidding', function ($q) use ($quotationNo) {
                    $q->where('quotation_no', 'like', '%' . $quotationNo . '%');
                });
            }

            if ($result) {
                $poDispatchObj->whereHas('tender', function ($q) use ($result) {
                    $q->where('tender_status', $result);
                });
            }

            if ($result) {
                $poDispatchObj->whereHas('tender', function ($q) use ($result) {
                    $q->where('tender_status', $result);
                });
            }

            if ($currSubSatgeId) {
                $poDispatchObj->whereHas('tender', function ($q) use ($currSubSatgeId) {
                    $q->where('sub_stage_id', $currSubSatgeId);
                });
            }

            if ($partNo) {
                $poDispatchObj->whereHas('tender.tenderBidding.biddingProReq', function ($q) use ($partNo) {
                    $q->where('part_no', 'like', '%' . $partNo . '%');
                });
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $poDispatchObj->whereDate('created_at', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $poDispatchObj->whereDate('created_at', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-14 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-28 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $poDispatchObj->whereMonth('created_at', date('m'))->whereYear('created_at', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $poDispatchObj->whereMonth('created_at', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('created_at', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $poDispatchObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $poDispatchObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $poDispatchObj->whereDate('created_at', '>=', $startDate);

                        if ($endDate) {
                            $poDispatchObj->whereDate('created_at', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $poDispatchObj->count();
            if ($isExport == 1) {
                $dispatchList = $poDispatchObj->get();
            } else {
                $dispatchList = $poDispatchObj->limit($per_page)->offset($offset)->get();
            }

            $results = TabulationResource::collection($dispatchList) ?? [];


            if ($isExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                $headers = [
                    'Sr No.',
                    'Tender No',
                    'Due Date',
                    'Railway Zones',
                    'Consignee Location',
                    'Part No',
                    'Qty',
                    'Unit',
                    'Rate/Set',
                    'LC',
                    'QTN No',
                    'QTN Date',
                ];

                $maxLevels = 0;
                foreach ($results as $item) {
                    $item = json_decode(json_encode($item));
                    $levelCount = count($item->tabulationDetails->tab_details ?? []);
                    if ($levelCount > $maxLevels) {
                        $maxLevels = $levelCount;
                    }
                }

                for ($i = 1; $i <= $maxLevels; $i++) {
                    $headers[] = "L{$i} Name";
                    $headers[] = "Rate";
                    $headers[] = "MF";
                }

                $sheetData = [$headers];
                $sr = 1;

                foreach ($results as $item) {
                    $item = json_decode(json_encode($item));

                    $tender = $item->tender ?? null;
                    $tenderBidding = $tender->tender_bidding ?? null;

                    $tenderNo = $tender->tender_no ?? '';
                    $dueDate = $tender->tender_end_date ?? '';
                    $formattedDueDate = $dueDate ? Carbon::parse($dueDate)->format('d/m/y') : '';
                    $tenderName = $tender->name ?? '';

                    $lc1 = $item->tabulationDetails->lc ?? '';
                    $quotationNo = $tenderBidding->quotation_no ?? '';
                    $quotationDate = $tenderBidding->quotation_date ?? '';
                    $formattedQtnDate = $quotationDate ? Carbon::parse($quotationDate)->format('d/m/y') : '';

                    $tabDetails = $item->tabulationDetails->tab_details ?? [];

                    if (!empty($item->tenderPartNoConsignee)) {
                        foreach ($item->tenderPartNoConsignee as $part) {
                            $partNo = $part->part_no ?? '-';

                            if (!empty($part->consignees)) {
                                foreach ($part->consignees as $consignee) {
                                    $row = [
                                        $sr++,
                                        $tenderNo,
                                        $formattedDueDate,
                                        $tenderName,
                                        $consignee->consignee_name ?? '-',
                                        $partNo,
                                        $consignee->consignee_qty ?? '',
                                        $consignee->unit ?? '',
                                        $consignee->price ?? '',
                                        $lc1,
                                        $quotationNo,
                                        $formattedQtnDate,
                                    ];

                                    for ($i = 0; $i < $maxLevels; $i++) {
                                        $row[] = $tabDetails[$i]->company_name ?? '';
                                        $row[] = $tabDetails[$i]->price ?? '';
                                        $row[] = $tabDetails[$i]->mf ?? '';
                                    }

                                    $sheetData[] = $row;
                                }
                            }
                        }
                    }
                }

                $sheet->fromArray($sheetData, null, 'A1');

                $timestamp = now()->format('Ymd_His');
                $store = "storage/app/public/uploads/tender/Tabulation_$timestamp.csv";
                $filePath = "storage/uploads/tender/Tabulation_$timestamp.csv";
                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Dispatch Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['quotation_no'] = $quotationNo;
            $this->response['data']['tender_no'] = $tenderNo;
            $this->response['data']['name'] = $tenderName;
            $this->response['data']['part_no'] = $partNo;
            $this->response['data']['filePath'] = $filePath ?? '';
            $this->response['data']['division'] = $divisionId;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['result'] = $result ?? '';
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['list'] = $results ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e);
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function DispatchList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $poNo = $request->po_no ?? '';
            $soNo = $request->so_no ?? '';
            $name = $request->name ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'despatch_date';

            $poDispatchObj = PoDespatchDetail::with(['po', 'po.lead', 'po.tender', 'so', 'so.dc'])->where('po_type', 2)->orderBy('id', 'desc');

            if ($poNo) {
                $poDispatchObj->whereHas('po', function ($q) use ($poNo) {
                    $q->where('po_no', 'like', '%' . $poNo . '%');
                });
            }

            if ($soNo) {
                $poDispatchObj->whereHas('so', function ($q) use ($soNo) {
                    $q->where('so_no', 'like', '%' . $soNo . '%');
                });
            }

            if ($name) {
                $poDispatchObj->whereHas('po.tender', function ($q) use ($name) {
                    $q->where('name', 'like', '%' . $name . '%');
                });
            }


            if ($dateRange) {
                if ($dateRange == 'today') {
                    $poDispatchObj->whereDate('despatch_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $poDispatchObj->whereDate('despatch_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $poDispatchObj->whereDate('despatch_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $poDispatchObj->whereDate('despatch_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $poDispatchObj->whereDate('despatch_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $poDispatchObj->whereDate('despatch_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $poDispatchObj->whereDate('despatch_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $poDispatchObj->whereDate('despatch_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $poDispatchObj->whereMonth('despatch_date', date('m'))->whereYear('despatch_date', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $poDispatchObj->whereMonth('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $poDispatchObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $poDispatchObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $poDispatchObj->whereDate('despatch_date', '>=', $startDate);

                        if ($endDate) {
                            $poDispatchObj->whereDate('despatch_date', '<=', $endDate);
                        }
                    }
                }
            }
            $num_rows = $poDispatchObj->count();
            $dispatchList = $poDispatchObj->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Dispatch Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['list'] = $dispatchList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function todayDispatchList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $poNo = $request->po_no ?? '';
            $soNo = $request->so_no ?? '';
            $name = $request->name ?? '';

            $poDispatchObj = PoDespatchDetail::with(['po', 'po.lead', 'po.tender', 'so', 'so.dc'])->where('po_type', 2)->whereDate('despatch_date', Carbon::today())->orderBy('id', 'desc');

            if ($poNo) {
                $poDispatchObj->whereHas('po', function ($q) use ($poNo) {
                    $q->where('po_no', 'like', '%' . $poNo . '%');
                });
            }

            if ($soNo) {
                $poDispatchObj->whereHas('so', function ($q) use ($soNo) {
                    $q->where('so_no', 'like', '%' . $soNo . '%');
                });
            }

            if ($name) {
                $poDispatchObj->whereHas('po.tender', function ($q) use ($name) {
                    $q->where('name', 'like', '%' . $name . '%');
                });
            }


            $num_rows = $poDispatchObj->count();
            $dispatchList = $poDispatchObj->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Po Dispatch Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['list'] = $dispatchList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function deliveredDispatchList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;
            $poNo = $request->po_no ?? '';
            $soNo = $request->so_no ?? '';
            $name = $request->name ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'dc_date';

            $poDispatchObj = DeliveryConfirmation::with(['so', 'so.lead', 'so.po'])->where('po_type', 2)->orderBy('id', 'desc');

            if ($poNo) {
                $poDispatchObj->whereHas('so.po', function ($q) use ($poNo) {
                    $q->where('po_no', 'like', '%' . $poNo . '%');
                });
            }

            if ($soNo) {
                $poDispatchObj->whereHas('so', function ($q) use ($soNo) {
                    $q->where('so_no', 'like', '%' . $soNo . '%');
                });
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $poDispatchObj->whereDate('dc_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $poDispatchObj->whereDate('dc_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $poDispatchObj->whereDate('dc_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $poDispatchObj->whereDate('dc_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $poDispatchObj->whereDate('dc_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $poDispatchObj->whereDate('dc_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $poDispatchObj->whereDate('dc_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $poDispatchObj->whereDate('dc_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $poDispatchObj->whereMonth('dc_date', date('m'))->whereYear('dc_date', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $poDispatchObj->whereMonth('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $poDispatchObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $poDispatchObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $poDispatchObj->whereDate('dc_date', '>=', $startDate);

                        if ($endDate) {
                            $poDispatchObj->whereDate('dc_date', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $poDispatchObj->count();
            $dispatchList = $poDispatchObj->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Delivery Confirmation Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['list'] = $dispatchList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function SalesOrderList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $soNo = $request->so_no ?? '';
            $poNo = $request->po_no ?? '';
            $name = preg_replace('/\s+/', ' ', $request->name) ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'so_date';

            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $salesOrderObj = AvlockSalesOrder::with(['dispatch', 'po', 'po.tender', 'lead',])
                    ->where('po_type', 2)
                    ->orderBy('id', 'desc');
            } else {
                $salesOrderObj = AvlockSalesOrder::with(['dispatch', 'po', 'po.tender', 'lead'])->where(function ($query) use ($juniorUserIds) {
                    $query->where('created_by', $this->userId)
                        ->orWhere(function ($q) use ($juniorUserIds) {
                            $q->whereIn('created_by', $juniorUserIds);
                        });
                })->where('po_type', 2)->orderBy('id', 'desc');
            }

            if ($soNo) {
                $salesOrderObj->where('your_so_no', $soNo);
            }

            if ($poNo) {
                $salesOrderObj->whereHas('po', function ($query) use ($poNo) {
                    $query->where('po_no', $poNo);
                });
            }

            if ($name) {
                $salesOrderObj->whereHas('po.tender', function ($q) use ($name) {
                    $q->where('name', 'like', '%' . $name . '%');
                });
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $salesOrderObj->whereDate('so_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $salesOrderObj->whereDate('so_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $salesOrderObj->whereDate('so_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $salesOrderObj->whereDate('so_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $salesOrderObj->whereDate('so_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $salesOrderObj->whereDate('so_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $salesOrderObj->whereDate('so_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $salesOrderObj->whereDate('so_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $salesOrderObj->whereMonth('so_date', date('m'))->whereYear('so_date', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $salesOrderObj->whereMonth('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $salesOrderObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $salesOrderObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $salesOrderObj->whereDate('so_date', '>=', $startDate);

                        if ($endDate) {
                            $salesOrderObj->whereDate('so_date', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $salesOrderObj->count();
            $salesOrderList = $salesOrderObj->limit($per_page)->offset($offset)->get();
            $result = SalesOrderResource::collection($salesOrderList);



            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Sales Order Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['list'] = $result ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }
}
