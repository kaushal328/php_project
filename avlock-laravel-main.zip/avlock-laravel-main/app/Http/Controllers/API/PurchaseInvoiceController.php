<?php

namespace App\Http\Controllers\API;

use App\Events\PiLogCreated;
use App\Http\Controllers\Controller;
use App\Http\Resources\PurchaseInvoiceResource;
use App\Models\Product;
use App\Models\ProjectQuotation;
use App\Models\PurchaseInvoice;
use App\Models\PurchaseOrder;
use App\Models\RfqProduct;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class PurchaseInvoiceController extends AppBaseController
{
  function index(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $fk_po_id = $request->fk_po_id ?? "";
      $fk_quotation_id = $request->fk_quotation_id ?? "";
      $fk_rfq_id = $request->fk_rfq_id ?? "";
      $fk_lead_id = $request->fk_lead_id ?? "";
      $pi_date = $request->pi_date ?? '';
      $pi_no = $request->pi_no ?? '';
      $payment_done = $request->payment_done ?? '';


      $piObject = PurchaseInvoice::with('po', 'quotation', 'lead', 'rfq', 'rfq.designation');

      if ($fk_po_id) $piObject->where('fk_po_id',  $fk_po_id);
      if ($fk_quotation_id) $piObject->where('fk_quotation_id',  $fk_quotation_id);
      if ($fk_rfq_id) $piObject->where('fk_rfq_id',  $fk_rfq_id);
      if ($fk_lead_id) $piObject->where('fk_lead_id',  $fk_lead_id);
      if ($pi_date) $piObject->where('pi_date', '>=', $this->convertToDatabaseDateForSearch($pi_date));
      if ($pi_no) $piObject->where('pi_no', 'like', '%' . $pi_no . '%');
      if ($payment_done == 'no') $piObject->where('payment_done',  0);

      $num_rows = $piObject->count();

      $result = $piObject->limit($per_page)->offset($offset)->get();
      $piList = PurchaseInvoiceResource::collection($result);


      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Purchase Invoice"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['fk_rfq_id'] = $fk_rfq_id;
      $this->response['data']['fk_quotation_id'] = $fk_quotation_id;
      $this->response['data']['fk_lead_id'] = $fk_lead_id;
      $this->response['data']['pi_date'] = $pi_date;
      $this->response['data']['pi_no'] = $pi_no;
      $this->response['data']['list'] = $piList;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Purchase Invoice List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function dashboardIndex(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $fk_po_id = $request->fk_po_id ?? "";
      $pi_date = $request->pi_date ?? '';
      $pi_no = $request->pi_no ?? '';


      $piObject = PurchaseInvoice::with('po', 'lead')
        ->whereHas('lead', function ($query) {
          $query->where('assigned_rsm', $this->userId);
        });

      if ($fk_po_id) $piObject->where('fk_po_id', $fk_po_id);
      if ($pi_date) $piObject->where('pi_date', '>=', $this->convertToDatabaseDateForSearch($pi_date));
      if ($pi_no) $piObject->where('pi_no', 'like', '%' . $pi_no . '%');

      $num_rows = $piObject->count();

      $result = $piObject->limit($per_page)->offset($offset)->get();
      $piList = PurchaseInvoiceResource::collection($result);


      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Purchase Invoice"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['pi_date'] = $pi_date;
      $this->response['data']['pi_no'] = $pi_no;
      $this->response['data']['list'] = $piList;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Purchase Invoice List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function get(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $piId = $request->pi_id ?? "";

      if (!$piId) {
        $this->response['error'] = "Please select a valid Purchase Invoice!";
        return $this->sendResponse($this->response, 200);
      }

      $piObject = PurchaseInvoice::with('po', 'quotation', 'lead', 'rfq', 'rfq.designation')->find($piId);

      if (!$piObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Invoice"]);
        return $this->sendResponse($this->response, 200);
      }

      if (isset($piObject->rfq->id)) {
        $rfqProduct = RfqProduct::where('rfq_id', $piObject->rfq->id)->get()->toArray();
        if (!empty($rfqProduct)) {

          $productIds = array_column($rfqProduct, 'product_id');
          $piObject->rfq_products = Product::select('id', 'product_name')->whereIn('id', $productIds)->get();
        }
      }


      $this->response['status'] = 1;
      $this->response['data'] = $piObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Purchase Invoice Details fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }


  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdatePurchaseInvoice($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $piObject = new PurchaseInvoice();
      $id = $request->id;
      $poId = $request->po_id;

      $poObject = PurchaseOrder::find($poId);

      if (!$poObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
        return $this->sendResponse($this->response, 200);
      }


      $fk_quotation_id = $poObject->fk_quotation_id;
      $fk_rfq_id = $poObject->fk_rfq_id;
      $fk_lead_id = $poObject->fk_lead_id;
      // $pi_date = Carbon::createFromFormat('d/m/Y g:i A', $request->pi_date)->format('Y-m-d H:i:s');
      $formattedDate = Carbon::createFromFormat('d/m/Y', $request->pi_date);
      $shortPiYear = $formattedDate->format('y');
      $shortNextYear = $formattedDate->copy()->addYear()->format('y');
      $piDate = $formattedDate->format('Y-m-d');
      $pi_details = json_encode($request->pi_details ?? []);
      $pi_total_amount = $request->pi_total_amount;

      $remark = $request->remark;


      if ($id) {
        $piObject = PurchaseInvoice::find($id);

        if (!$piObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Invoice"]);
          return $this->sendResponse($this->response, 200);
        }
        $piObject->first();
        $piObject->updated_by = $this->userId;

        $this->response['msg'] = __('admin.updated', ['module' => "Purchase Invoice"]);
      } else {

        $piObject->created_by = $this->userId;
        $baseString = strtoupper('IN/'  . $shortPiYear . '-' . $shortNextYear . '/');
        $piObject->pi_no = generateSeries($baseString, 'purchase_invoices', 'pi_no');
        $piObject->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => "Purchase Invoice"]);
      }

      $piObject->fk_po_id = $poId;
      $piObject->fk_quotation_id = $fk_quotation_id;
      $piObject->fk_rfq_id = $fk_rfq_id;
      $piObject->fk_lead_id = $fk_lead_id;
      $piObject->pi_date = $piDate;
      $piObject->pi_details = $pi_details;
      $piObject->pi_total_amount = $pi_total_amount;
      $piObject->pi_total_amount_paid =  $piObject->pi_total_amount_paid ?? 0;
      $piObject->pi_total_amount_pending =  max(0, $pi_total_amount - ($piObject->pi_total_amount_paid ?? 0));
      $piObject->payment_done =  $piObject->pi_total_amount_pending > 0  ?  0 : 1;

      $piObject->remark = $remark;

      $piObject->save();

      $piObject->action = 'created';
      if ($id) {
        $piObject->action = 'updated';
      }
      PiLogCreated::dispatch($piObject);

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Creating Purchase Invoice: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Purchase Invoice"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function deleteEwayBill(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $rfqObject = EwayBill::find($id);

      if (!$rfqObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "E-Way Bill"]);
        return $this->sendResponse($this->response, 500);
      }

      $rfqObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "E-Way Bill"]);
      $this->response['data'] = $rfqObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("E-Way Bill deleting failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdatePurchaseInvoice(Request $request)
  {
    return Validator::make($request->all(), [
      'pi_date' => 'required|date_format:d/m/Y g:i A',

    ])->errors();
  }
}
