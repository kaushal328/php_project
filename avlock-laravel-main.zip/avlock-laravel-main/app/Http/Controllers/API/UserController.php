<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\Menu;
use App\Models\Role;
use App\Models\User;
use App\Models\UserHierarchyManagement;
use App\Models\UserHierarchyManagment;
use App\Models\UserRole;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class UserController extends AppBaseController
{

    /**
     * Display a listing of the User.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $name = $request->name ?? '';
            $email = $request->email ?? '';
            $mobile = $request->mobile ?? '';
            $divisionId = $request->division_id ?? '';
            $department_id = $request->department_id ?? '';
            $superAdmin = $this->isSuperAdmin;

            $user = User::with('designation', 'roles.department', 'roles.departmentType')->orderBy("name", "asc");
            $user->where('id', '!=', 1);

            if ($name) {
                $user->where('name', 'like', '%' . $name . '%');
            }

            if ($email) {
                $user->where('email', 'like', '%' . $email . '%');
            }

            if ($divisionId) {
                $user->whereRaw("FIND_IN_SET(?, division_ids)", [$divisionId]);
            }

            if ($mobile) {
                $user->where('mobile', 'like', '%' . $mobile . '%');
            }
            if ($department_id) {
                $user->whereHas('roles', function ($query) use ($department_id) {
                    $query->where('fk_department_id', $department_id);
                });
            }

            $num_rows = $user->count();
            $user = $user->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Designation"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['name'] = $name;
            $this->response['data']['email'] = $email;
            $this->response['data']['mobile'] = $mobile;
            $this->response['data']['super_admin'] = $superAdmin;
            $this->response['data']['department_id'] = $department_id;
            $this->response['data']['list'] = UserResource::collection($user);

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Designation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function addUpdate(Request $request)
    {

        try {
            DB::beginTransaction();

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateUser($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $userObject = new User();
            $id = $request->id;
            $employee_id = $request->employee_id;
            $name = $request->name;
            $email = $request->email;
            $mobile = $request->mobile;
            $colorCode = $request->color_code ?? '';
            $seniorUserIds = $request->senior_user_ids ?? [];

            $division_ids = $request->division_ids ?? 0;
            $division_head_ids = $request->division_head_ids ?? 0;
            $designation_id = $request->designation_id ?? 0;
            $permissions = $request->permissions;
            $rsm_code = $request->rsm_code ?? '';

            $status = $request->status ?? 1;

            if (count($request->department_and_role) > 0) {

                $departmentIds = array_column($request->department_and_role, 'department_id');

                if (in_array(5, $departmentIds)) { // 5 is use for RSM
                    if ($rsm_code == '') {
                        $this->response['error'] = "RSM Code is Require when user is RSM";
                        return $this->sendResponse($this->response, 200);
                    } elseif (strlen($rsm_code) < 3) {
                        $this->response['error'] = "RSM Code must have a minimum length of three characters";
                        return $this->sendResponse($this->response, 200);
                    }
                }
            }

            $divisionIds = [];
            if ($division_ids) $divisionIds = implode(',', $division_ids);

            $divisionHeadIds = [];
            if ($division_head_ids) $divisionHeadIds = implode(',', $division_head_ids);

            if ($id) {
                $userObject = User::find($id);

                if (!$userObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "User"]);
                    return $this->sendResponse($this->response, 200);
                }

                if ($this->isSuperAdmin) {
                    $password = Hash::make($request->password);
                    $p = $request->password;
                    $userObject->password = $password;
                    $userObject->p = $p;
                }

                $userObject->first();
                $this->response['msg'] = __('admin.updated', ['module' => "User"]);
            } else {
                $password = Hash::make($request->password);
                $p = $request->password;
                $userObject->password = $password;
                $userObject->p = $p;
                $this->response['msg'] = __('admin.created', ['module' => "User"]);
            }


            $userObject->employee_id = $employee_id;
            $userObject->name = $name;
            $userObject->email = strtolower($email);
            $userObject->mobile = $mobile;
            $userObject->color_code = $colorCode;
            $userObject->fk_designation_id = $designation_id;
            $userObject->division_ids = $divisionIds;
            $userObject->division_head_ids = $divisionHeadIds;
            $userObject->permissions = json_encode($permissions);
            $userObject->rsm_code = $rsm_code;
            $userObject->status = $status;
            $userObject->save();
            $lastInsertedUserId = $userObject->id;

            $uhmIds = array_column($seniorUserIds, 'id');
            $uhmIds = array_filter($uhmIds, 'is_numeric');

            UserHierarchyManagement::where('user_id', $lastInsertedUserId)
                ->whereNotIn('id', $uhmIds)
                ->delete();

            if (count($seniorUserIds) > 0) {
                foreach ($seniorUserIds as $value) {
                    if (!empty($value['id'])) {
                        $userHmObj = UserHierarchyManagement::find($value['id']);
                    } else {
                        $userHmObj = new UserHierarchyManagement();
                        $userHmObj->user_id = $lastInsertedUserId;
                    }

                    $userHmObj->senior_user_id = $value['senior_user_id'];
                    $userHmObj->save();
                }
            }

            if (count($request->department_and_role) > 0) {

                foreach ($request->department_and_role as $roles) {
                    $depId = $roles['department_id'];
                    $depTypeId = $roles['department_type_id'];
                    $userRoleId = $roles['id'];

                    $userRoleObject = new UserRole();

                    if ($userRoleId) {
                        $userRoleObject = UserRole::find($userRoleId);

                        if (!$userRoleObject) {
                            $this->response['error'] = __('admin.id_not_found', ['module' => "User Role"]);
                            return $this->sendResponse($this->response, 200);
                        }
                    }

                    if ($depId != "" && $depTypeId != "") {
                        $userRoleObject->fk_user_id = $lastInsertedUserId;
                        $userRoleObject->fk_department_id = $depId;
                        $userRoleObject->fk_department_type_id = $depTypeId;
                        $userRoleObject->save();
                    }
                }
            }
            DB::commit();
            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating User: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "User"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $userObject = User::find($id);

            if (!$userObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "User"]);
                return $this->sendResponse($this->response, 401);
            }
            $userObject->first();

            $uhm = UserHierarchyManagement::where('user_id', $userObject->id)->get();

            $uhmArray = [];
            foreach ($uhm as $uhmVal) {
                $id = $uhmVal->id ?? '';
                $userId = $uhmVal->user_id ?? '';
                $seniorUserId = $uhmVal->senior_user_id ?? '';

                $uhmArray[] = [
                    'id' => $id,
                    'user_id' => $userId,
                    'senior_user_id' => $seniorUserId,
                ];
            }

            $userObject->user_heirarchy_management = $uhmArray ?? [];

            $userRoles = UserRole::select('id', 'fk_department_id as department_id', 'fk_department_type_id as department_type_id')->where('fk_user_id', $id)->get();
            $userObject->department_and_role = $userRoles;

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "User"]);
            $this->response['data'] = $userObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("User fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function deleteRole(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $userRoleObject = UserRole::find($id);

            if (!$userRoleObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "User Role"]);
                return $this->sendResponse($this->response, 401);
            }

            $userRoleObject->forceDelete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "User Role"]);
            $this->response['data'] = $userRoleObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("User Role Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $userObject = User::find($id);

            if (!$userObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "User"]);
                return $this->sendResponse($this->response, 401);
            }

            $userObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "User"]);
            $this->response['data'] = $userObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("User Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }



    public function permissionList(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $departmentAndRole = $request->department_and_role;

            $permissionList = Menu::all();
            $permissionByDepartment = null;


            if ($departmentAndRole) {
                if (count($departmentAndRole) > 0) {
                    foreach ($departmentAndRole as $dep) {
                        $depId = $dep['department_id'];
                        $depTypeId = $dep['department_type_id'];

                        if ($depId != "" && $depTypeId != "") {
                            $permissions = Role::where('department_id', $depId)
                                ->where('department_type_id', $depTypeId)
                                ->first();

                            if ($permissions && $permissions->permissions) {
                                if ($permissionByDepartment === null) {
                                    $permissionByDepartment = json_decode($permissions->permissions, true);
                                } else {
                                    $permissionsArray = json_decode($permissions->permissions, true);
                                    foreach ($permissionsArray as $key => $value) {
                                        if (array_key_exists($key, $permissionByDepartment)) {
                                            $permissionByDepartment[$key] = array_merge($permissionByDepartment[$key], $value);
                                        } else {
                                            $permissionByDepartment[$key] = $value;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }





            // if ($departmentAndRole) {
            //   if (count($departmentAndRole) > 0) {
            //     foreach ($departmentAndRole as $dep) {
            //       $depId = $dep['department_id'];
            //       $depTypeId = $dep['department_type_id'];

            //       if ($depId != "" && $depTypeId != "") {
            //         $permissions = Role::where('department_id', $depId)
            //           ->where('department_type_id', $depTypeId)
            //           ->first();

            //         if ($permissions && $permissions->permissions) {
            //           if ($permissionByDepartment === null) {
            //             $permissionByDepartment = json_decode($permissions->permissions, true);
            //           } else {

            //             $department = [];

            //             foreach (json_decode($permissions->permissions, true) as $key => $value) {
            //               if (isset($department[$key])) {
            //                 $department[$key] = array_merge($department[$key], $value);
            //               } else {
            //                 $department[$key] = $value;
            //               }
            //             }
            //             $permissionByDepartment = [...$department];



            //             // $permissionByDepartment = array_reduce(json_decode($permissions->permissions, true), function ($carry, $item) use ($permissionByDepartment) {
            //             //   echo '<pre>';
            //             //   print_r($item);
            //             //   die;
            //             //   foreach ($item as $key => $value) {
            //             //     if (array_key_exists($key, $carry)) {


            //             //       $carry[$key] = array_merge($carry[$key], $value);
            //             //     } else {
            //             //       $carry[$key] = $value;
            //             //     }
            //             //   }
            //             //   return $carry;
            //             // }, $permissionByDepartment);
            //           }
            //         }
            //       }
            //     }
            //   }
            // }

            $this->response['status'] = 1;
            $this->response['data']['permission_list'] = $permissionList;
            $this->response['data']['permission_by_department'] = $permissionByDepartment;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Fetching User Permssion: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    private function validateAddUpdateUser(Request $request)
    {
        return Validator::make($request->all(), [
            'employee_id' => 'required|string',
            'name' => 'required|string',
            'email' => 'required|string|email|max:255|unique:users,email,' . $request->id . ',id,deleted_at,NULL',
            'color_code' => 'nullable|unique:users,color_code,' . $request->id . ',id,deleted_at,NULL',
            'mobile' => 'required|string|regex:/^[6-9]\d{9}$/|unique:users,mobile,' . $request->id . ',id,deleted_at,NULL',
            'password' => !$this->isSuperAdmin && $request->id ? '' : 'required|string',
            'designation_id' => 'required|integer|exists:designations,id',
            'permissions' => 'required',
            'status' => 'sometimes|required|integer|in:0,1',
        ])->errors();
    }
}
