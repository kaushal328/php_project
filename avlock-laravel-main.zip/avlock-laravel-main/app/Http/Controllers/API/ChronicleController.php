<?php

namespace App\Http\Controllers\API;

use App\Enums\UnitType;
use App\Models\Chronicle;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\API\AppBaseController;

class ChronicleController extends AppBaseController
{

    /**
     * Display a listing of the Chronicle.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $title = $request->title ?? '';
            $status = $request->status ?? '';

            $chronicleObject = Chronicle::withoutTrashed()->orderBy("id", "desc");

            if ($title) {
                $chronicleObject->where('unit_detail', 'like', '%' . $title . '%');
            }

            if ($status) {
                $chronicleObject->where('status', $status);
            }
            $num_rows = $chronicleObject->count();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Chronicle"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['title'] = $title;
            $this->response['data']['list'] = $chronicleObject->limit($per_page)->offset($offset)->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Chronicle fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addUpdate(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateChronicle($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $chronicleObject = new Chronicle();
            $id = $request->id;
            $unit = $request->unit ?? '';

            $vals = [
                'unit_id' => $unit,
                'title' => $request->title,
                'unit' => ($unit == 1) ? 'Days' : (($unit == 2) ? 'Months' : (($unit == 3) ? 'Years' : '')),
            ];

            $formattedVals = json_encode($vals);
            $status = $request->status ?? 1;

            if ($id) {
                $chronicleObject = Chronicle::find($id);

                if (!$chronicleObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Chronicle"]);
                    return $this->sendResponse($this->response, 500);
                }

                $chronicleObject->first();
                $this->response['msg'] = __('admin.updated', ['module' => "Chronicle"]);
            } else {
                $this->response['msg'] = __('admin.created', ['module' => "Chronicle"]);
            }

            $chronicleObject->unit_detail = $formattedVals;
            $chronicleObject->status = $status;

            $chronicleObject->save();

            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Chronicle: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Chronicle"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $chronicleObject = Chronicle::find($id);

            if (!$chronicleObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Chronicle"]);
                return $this->sendResponse($this->response, 500);
            }
            $chronicleObject->first();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Chronicle"]);
            $this->response['data'] = $chronicleObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Chronicle fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $chronicleObject = Chronicle::find($id);

            if (!$chronicleObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Chronicle"]);
                return $this->sendResponse($this->response, 500);
            }

            $chronicleObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Chronicle"]);
            $this->response['data'] = $chronicleObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Chronicle Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function chronicleList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $chronicleList = Chronicle::where('status', 1)->get();

            $this->response['status'] = 1;
            $this->response['data'] = $chronicleList;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Chronicle List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getUnitType(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Unit Type"]);
            $this->response['data']['list'] = UnitType::getListForHTML();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Unit Type fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function validateAddUpdateChronicle(Request $request)
    {
        return Validator::make($request->all(), [
            'title' => 'required',
            'unit' => 'required',
            'status' => 'sometimes|required|integer|in:0,1',
        ])->errors();
    }
}
