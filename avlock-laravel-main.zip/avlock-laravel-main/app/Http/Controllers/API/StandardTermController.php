<?php

namespace App\Http\Controllers\API;

use App\Models\StandardTerm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\API\AppBaseController;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class StandardTermController extends AppBaseController
{

    /**
     * Display a listing of the Designation.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $title = $request->title ?? '';
            $status = $request->status ?? '';

            $standardTermObject = StandardTerm::withoutTrashed()->orderBy("id", "desc");

            if ($title) {
                $standardTermObject->where('title', 'like', '%' . $title . '%');
            }

            if ($status) {
                $standardTermObject->where('status', $status);
            }
            $num_rows = $standardTermObject->count();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "StandardTerm"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['title'] = $title;
            $this->response['data']['list'] = $standardTermObject->limit($per_page)->offset($offset)->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("StandardTerm fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addUpdate(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateStandardTerm($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $standardTermObject = new StandardTerm();
            $id = $request->id;
            $title = $request->title ?? '';
            $status = $request->status ?? 1;

            if ($id) {
                $standardTermObject = StandardTerm::find($id);

                if (!$standardTermObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "StandardTerm"]);
                    return $this->sendResponse($this->response, 500);
                }

                $standardTermObject->first();
                $this->response['msg'] = __('admin.updated', ['module' => "StandardTerm"]);
            } else {
                $this->response['msg'] = __('admin.created', ['module' => "StandardTerm"]);
            }

            $standardTermObject->title = $title;
            $standardTermObject->status = $status;

            $standardTermObject->save();

            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating StandardTerm: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "StandardTerm"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $standardTermObject = StandardTerm::find($id);

            if (!$standardTermObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "StandardTerm"]);
                return $this->sendResponse($this->response, 500);
            }
            $standardTermObject->first();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "StandardTerm"]);
            $this->response['data'] = $standardTermObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("StandardTerm fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $standardTermObject = StandardTerm::find($id);

            if (!$standardTermObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "StandardTerm"]);
                return $this->sendResponse($this->response, 500);
            }

            $standardTermObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "StandardTerm"]);
            $this->response['data'] = $standardTermObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("StandardTerm Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function standardTermList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = StandardTerm::where('status', 1)->get();

            $this->response['status'] = 1;
            $this->response['data'] = ['list' => $list];
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    private function validateAddUpdateStandardTerm(Request $request)
    {
        return Validator::make($request->all(), [
            'title' => 'required|string|unique:standard_terms,title,' . $request->id . ',id,deleted_at,NULL',
            'status' => 'sometimes|required|integer|in:0,1',
        ])->errors();
    }
}
