<?php

namespace App\Http\Controllers\API;

use App\Models\Supplier;
use App\Models\BankerDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class BankerController extends AppBaseController
{

  public function index(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $banker = BankerDetail::withoutTrashed()->orderBy("id", "desc");
      $num_rows = $banker->count();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Banker Detail"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = $banker->limit($per_page)->offset($offset)->get();;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Banker Details fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateBanker($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $bankerObject = new BankerDetail();
      $id = $request->id;
      $supplierId = $request->supplier_id;
      $accountName = $request->account_name;
      $ifscCode = $request->ifsc_code;
      $accountNumber = $request->account_number;
      $bankName = $request->bank_name;
      $bankBranchName = $request->bank_branch_name;
      $status = $request->status ?? 1;

      $files = [];
      if (isset($request->cancel_cheque)) {

        foreach ($request->cancel_cheque as $item) {
          moveFile('banker/', $item['filename']);
          $files[] = ['filename' => $item['filename'], 'path' => $this->fileAccessPath . "/banker/" . $item['filename']];
        }
      }

      $cancelCheque = json_encode($files) ?? '';

      if ($id) {
        $bankerObject = BankerDetail::find($id);

        if (!$bankerObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Banker Details"]);
          return $this->sendResponse($this->response, 401);
        }

        $bankerObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Banker Details"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Banker Details"]);
      }

      $bankerObject->supplier_id = $supplierId;
      $bankerObject->account_name = $accountName;
      $bankerObject->ifsc_code = $ifscCode;
      $bankerObject->account_number = $accountNumber;
      $bankerObject->bank_name = $bankName;
      $bankerObject->bank_branch_name = $bankBranchName;
      $bankerObject->cancel_cheque = $cancelCheque;
      $bankerObject->status = $status;

      $bankerObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Banker Details: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Banker Details"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $id = $request->id ?? '';
      $bankerObject = BankerDetail::find($id);

      if (!$bankerObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Banker Details"]);
        return $this->sendResponse($this->response, 401);
      }

      $bankerObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Banker Details"]);
      $this->response['data']['list'] = $bankerObject;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Banker Details fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function getBankers(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $supplierId = $request->supplier_id ?? '';
      $bankerObject = Supplier::find($supplierId);

      if (!$bankerObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Banker Details"]);
        return $this->sendResponse($this->response, 401);
      }

      $banker = BankerDetail::where('supplier_id', $supplierId)->withoutTrashed()->orderBy("id", "desc");
      $num_rows = $banker->count();

      $result = $banker->limit($per_page)->offset($offset)->get();

      $bankerObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Banker Details"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = $result;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Banker Details fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $bankerObject = BankerDetail::find($id);

      if (!$bankerObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Banker Details"]);
        return $this->sendResponse($this->response, 401);
      }

      $bankerObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Banker Details"]);
      $this->response['data'] = $bankerObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Banker Details Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddUpdateBanker(Request $request)
  {
    return Validator::make($request->all(), [
      'account_name' => 'required',
      'ifsc_code' => 'required',
      'account_number' => 'required',
      'bank_name' => 'required',
    ])->errors();
  }
}
