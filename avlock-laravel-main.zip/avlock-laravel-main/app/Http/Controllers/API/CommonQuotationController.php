<?php

namespace App\Http\Controllers\API;

use App\Models\CommonReference;
use App\Models\CommonSalutation;
use App\Models\CommonSpecialNote;
use App\Models\CommonTnc;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class CommonQuotationController extends AppBaseController
{

  public function index(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';

      $reference = CommonReference::with('division:id,name')->orderBy("title");

      if ($title) {
        $reference->where('title', 'like', '%' . $title . '%');
      }

      $num_rows = $reference->count();
      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Reference"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['list'] = $reference->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Reference fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $refObject = CommonReference::find($id);

      if (!$refObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Reference"]);
        return $this->sendResponse($this->response, 500);
      }
      $refObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Reference"]);
      $this->response['data'] = $refObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Reference fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateReference($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $refObject = new CommonReference();
      $id = $request->id;
      $divisionId = $request->division_id;
      $title = $request->title ?? '';
      $status = $request->status ?? 1;

      if ($id) {
        $refObject = CommonReference::find($id);

        if (!$refObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Reference"]);
          return $this->sendResponse($this->response, 500);
        }

        $refObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Reference"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Reference"]);
      }

      $refObject->division_id = $divisionId;
      $refObject->title = $title;
      $refObject->status = $status;

      $refObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Reference: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Reference"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $refObject = CommonReference::find($id);

      if (!$refObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Reference"]);
        return $this->sendResponse($this->response, 500);
      }

      $refObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Reference"]);
      $this->response['data'] = $refObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Reference Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function indexSalutation(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';

      $salutation = CommonSalutation::with('division:id,name')->orderBy("title");

      if ($title) {
        $salutation->where('title', 'like', '%' . $title . '%');
      }

      $num_rows = $salutation->count();
      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Salutation"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['list'] = $salutation->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Salutation fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function getSalutation(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $salutationObject = CommonSalutation::find($id);

      if (!$salutationObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Salutation"]);
        return $this->sendResponse($this->response, 500);
      }
      $salutationObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Salutation"]);
      $this->response['data'] = $salutationObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Salutation fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdateSalutation(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateSalutation($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $salutationObject = new CommonSalutation();
      $id = $request->id;
      $divisionId = $request->division_id;
      $title = $request->title ?? '';
      $status = $request->status ?? 1;

      if ($id) {
        $salutationObject = CommonSalutation::find($id);

        if (!$salutationObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Salutation"]);
          return $this->sendResponse($this->response, 500);
        }

        $salutationObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Salutation"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Salutation"]);
      }

      $salutationObject->division_id = $divisionId;
      $salutationObject->title = $title;
      $salutationObject->status = $status;

      $salutationObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Salutation: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Salutation"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function deleteSalutation(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $salutationObject = CommonSalutation::find($id);

      if (!$salutationObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "salutation"]);
        return $this->sendResponse($this->response, 500);
      }

      $salutationObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "salutation"]);
      $this->response['data'] = $salutationObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("salutation Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function indexTnc(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $termCatId = $request->term_category_id ?? '';
      $termId = $request->term_id ?? '';
      $divisionId = $request->division_id ?? '';

      $tnc = CommonTnc::with('division:id,name')->orderBy('sequence');

      if ($divisionId) {
        $tnc->where('division_id', $divisionId);
      }

      $num_rows = $tnc->count();
      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Terms & Condition"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['term_id'] = $termId;
      $this->response['data']['term_category_id'] = $termCatId;
      $this->response['data']['list'] = $tnc->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Terms & Condition fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function getTnc(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $tncObject = CommonTnc::find($id);

      if (!$tncObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Terms & condition"]);
        return $this->sendResponse($this->response, 500);
      }
      $tncObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Terms & condition"]);
      $this->response['data'] = $tncObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Terms & condition fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdateTnc(Request $request)
  {

    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateTnc($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $tncObject = new CommonTnc();
      $id = $request->id;
      $divisionId = $request->division_id;
      $terms = $request->terms;
      $isTender = $request->is_tender ?? '';
      $status = $request->status ?? 1;

      if ($id) {
        $tncObject = CommonTnc::find($id);

        if (!$tncObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Terms & Condition"]);
          return $this->sendResponse($this->response, 500);
        }

        $tncObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Terms & Condition"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Terms & Condition"]);
      }

      $tncObject->division_id = $divisionId;
      $tncObject->terms = $terms;
      $tncObject->status = $status;

      $tncObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Terms & Condition: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Terms & Condition"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function deleteTnc(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $tncObject = CommonTnc::find($id);

      if (!$tncObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Terms & condition"]);
        return $this->sendResponse($this->response, 500);
      }

      $tncObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Terms & condition"]);
      $this->response['data'] = $tncObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Terms & condition Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function indexSpecialNote(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;


      $specialNoteObj = CommonSpecialNote::with('division:id,name')->orderBy('note');

      $num_rows = $specialNoteObj->count();
      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Special Note"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = $specialNoteObj->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Special Note fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function getSpecialNote(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $tncObject = CommonSpecialNote::find($id);

      if (!$tncObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Special Note"]);
        return $this->sendResponse($this->response, 500);
      }
      $tncObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Special Note"]);
      $this->response['data'] = $tncObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Special Note fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdateSpecialnote(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateSpecialNote($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $specialNoteObj = new CommonSpecialNote();
      $id = $request->id;
      $divisionId = $request->division_id;
      $notes = $request->note;
      $status = $request->status ?? 1;

      if ($id) {
        $specialNoteObj = CommonSpecialNote::find($id);

        if (!$specialNoteObj) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Special Notes"]);
          return $this->sendResponse($this->response, 500);
        }

        $specialNoteObj->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Special Notes"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Special Notes"]);
      }

      $specialNoteObj->division_id = $divisionId;
      $specialNoteObj->note = $notes;
      $specialNoteObj->status = $status;

      $specialNoteObj->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Special Note: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Special Note"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function deleteSpecialNote(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $specialNoteObj = CommonSpecialNote::find($id);

      if (!$specialNoteObj) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Special Note"]);
        return $this->sendResponse($this->response, 500);
      }

      $specialNoteObj->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Special Note"]);
      $this->response['data'] = $specialNoteObj;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Special Note Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function organizeTncList(Request $request)
  {
    $sequenceData = $request->input('order');
    foreach ($sequenceData as $sequence => $itemData) {
      $itemArray = explode('/', $itemData);
      $newSequence = $sequence + 1;
      $id = $itemArray[0];
      $table = DB::table('common_tncs');
      $table->where('id', $id)->update(['sequence' => $newSequence + ($itemArray[2] * ($itemArray[1] - 1))]);
    }

    $this->response['status'] = 1;
    $this->response['msg'] = __('admin.deleted', ['module' => "Parameter reordered successfully"]);
    return $this->sendResponse($this->response, 200);
  }

  private function validateAddUpdateReference(Request $request)
  {
    return Validator::make($request->all(), [
      'division_id' => 'required|unique:common_references,division_id,' . $request->id . ',id',
      'title' => 'required',
    ])->errors();
  }

  private function validateAddUpdateSalutation(Request $request)
  {
    return Validator::make($request->all(), [
      'division_id' => 'required|unique:common_salutations,division_id,' . $request->id . ',id',
      'title' => 'required',
    ])->errors();
  }

  // private function validateAddUpdateTnc(Request $request)
  // {
  //   return Validator::make($request->all(), [
  //     'division_id' => 'required|unique:common_tncs,division_id,' . $request->id . ',id',
  //     'terms' => 'required',
  //   ])->errors();
  // }

  private function validateAddUpdateTnc(Request $request)
  {
    return Validator::make($request->all(), [
      'division_id' => [
        'required',
        Rule::unique('common_tncs')->where(function ($query) use ($request) {
          return $query->where('division_id', $request->division_id)
            ->where('is_tender', $request->is_tender ?? 0)
            ->where('id', '!=', $request->id ?? 0);
        })
      ],
      'terms' => 'required',
    ], [
      'division_id.unique' => 'A Terms & Condition for this division' .
        ($request->is_tender ? ' with tender' : '') .
        ' already exists.'
    ])->errors();
  }


  private function validateAddUpdateSpecialNote(Request $request)
  {
    return Validator::make($request->all(), [
      'division_id' => 'required',
      'note' => 'required',
    ])->errors();
  }
}
