<?php

namespace App\Http\Controllers\API;

use App\Events\PiLogCreated;
use App\Events\PoLogCreated;
use App\Http\Controllers\Controller;
use App\Http\Resources\SalesOrderResource;
use App\Models\Product;
use App\Models\ProjectQuotation;
use App\Models\AvlockSalesOrder;
use App\Models\Division;
use App\Models\PurchaseOrder;
use App\Models\Rfq;
use App\Models\RfqProduct;
use App\Models\Tender;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Spatie\LaravelPdf\Enums\Format;
use Spatie\LaravelPdf\Facades\Pdf as MyPdf;

class SalesOrderController extends AppBaseController
{

  function index(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $fk_po_id = $request->fk_po_id ?? "";
      $fk_quotation_id = $request->fk_quotation_id ?? "";
      $fk_rfq_id = $request->fk_rfq_id ?? "";
      $fk_lead_id = $request->fk_lead_id ?? "";
      $so_date = $request->so_date ?? '';
      $so_no = $request->so_no ?? '';
      $payment_done = $request->payment_done ?? '';
      $dispatchId = $request->dispatch_id ?? '';
      $poType = $request->po_type ?? '';


      $soObject = AvlockSalesOrder::with('po', 'quotation', 'lead', 'rfq', 'rfq.designation', 'dispatch');

      if ($fk_po_id) $soObject->where('fk_po_id',  $fk_po_id);
      if ($fk_quotation_id) $soObject->where('fk_quotation_id',  $fk_quotation_id);
      if ($dispatchId) $soObject->where('dispatch_id',  $dispatchId);
      if ($poType) $soObject->where('po_type',  $poType);
      if ($fk_rfq_id) $soObject->where('fk_rfq_id',  $fk_rfq_id);
      if ($fk_lead_id) $soObject->where('fk_lead_id',  $fk_lead_id);
      if ($so_date) $soObject->where('so_date', '>=', $this->convertToDatabaseDateForSearch($so_date));
      if ($so_no) $soObject->where('so_no', 'like', '%' . $so_no . '%');
      if ($payment_done == 'no') $soObject->where('payment_done',  0);

      $num_rows = $soObject->count();

      $result = $soObject->limit($per_page)->offset($offset)->get();
      $soList = SalesOrderResource::collection($result);


      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Sales Order"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['fk_rfq_id'] = $fk_rfq_id;
      $this->response['data']['fk_quotation_id'] = $fk_quotation_id;
      $this->response['data']['fk_lead_id'] = $fk_lead_id;
      $this->response['data']['so_date'] = $so_date;
      $this->response['data']['so_no'] = $so_no;
      $this->response['data']['list'] = $soList;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Sales Order List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function get(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $soId = $request->so_id ?? "";
      $poId = $request->po_id ?? '';
      $rfqId = $request->rfq_id ?? '';
      $leadId = $request->lead_id ?? '';
      $poType = $request->po_type ?? '';

      // if (!$soId) {
      //   $this->response['error'] = "Please select a valid Sales Order!";
      //   return $this->sendResponse($this->response, 200);
      // }

      $soObject = AvlockSalesOrder::with('po', 'quotation', 'lead', 'rfq', 'rfq.designation');

      if ($soId) {
        $soObject->where('id', $soId);
      }

      if ($poId) {
        $soObject->where('fk_po_id', $poId);
      }

      if ($rfqId) {
        $soObject->where('fk_rfq_id', $rfqId);
      }

      if ($leadId) {
        $soObject->where('fk_lead_id', $leadId);
      }

      if ($poType) {
        $soObject->where('po_type', $poType);
      }

      $soObject;

      if (!$soObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Sales Order"]);
        return $this->sendResponse($this->response, 200);
      }

      // if (isset($soObject->rfq->id)) {
      //   $rfqProduct = RfqProduct::where('rfq_id', $soObject->rfq->id)->get()->toArray();
      //   if (!empty($rfqProduct)) {

      //     $productIds = array_column($rfqProduct, 'product_id');
      //     $soObject->rfq_products = Product::select('id', 'product_name')->whereIn('id', $productIds)->get();
      //   }
      // }


      $this->response['status'] = 1;
      $this->response['data'] = $soObject->first();

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Sales Order Details fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(Request $request)
  {
    try {
      DB::beginTransaction();

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateSalesOrder($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $soObject = new AvlockSalesOrder();
      $id = $request->id;
      $poId = $request->po_id;
      $poType = $request->po_type ?? '';

      $poObject = PurchaseOrder::find($poId);

      if (!$poObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
        return $this->sendResponse($this->response, 200);
      }


      $fk_quotation_id = $poObject->fk_quotation_id ?? 0;
      $rfqId = $poObject->fk_rfq_id ?? 0;
      $leadId = $poObject->fk_lead_id ?? 0;
      $formattedDate = Carbon::createFromFormat('d/m/Y', $request->so_date);
      $soDate = $formattedDate->format('Y-m-d H:i:s');

      $soMonth = $formattedDate->format('M');
      $monthNumber = $formattedDate->format('n');
      $year = $formattedDate->format('Y');
      $financialYearStart = $monthNumber >= 4 ? $year : $year - 1;
      $shortFinYearStart = substr($financialYearStart, -2);
      $shortFinYearEnd = substr($financialYearStart + 1, -2);

      $soDetails = $request->so_details ?? [];
      $serviceDetails = $request->service_details ?? [];
      $soTotalAmount = $request->so_total_amount;
      $currStageId = $request->curr_stage_id ?? '';
      $currSubStageId = $request->curr_sub_stage_id ?? '';
      $currUser = $request->curr_user ?? [];
      $commUsers = $request->comm_users ?? [];
      $currUserIds = $request->curr_user_ids ?? '';
      $comments = $request->comments ?? '';
      $from = $request->from ?? '';
      $attachments = $request->attachments ?? [];
      $remark = $request->remark;
      $cgst = $request->cgst ?? 0;
      $sgst = $request->sgst ?? 0;
      $igst = $request->igst ?? 0;
      $cgstValue = $sgstValue = $igstValue = 0;
      $dispatchId = $request->dispatch_id ?? '';
      $billingLeadAddressesId = $request->billing_lead_addresses_id ?? '';
      $billingContactPeopleId = $request->billing_lead_contact_people_id ?? '';
      $billingAddress1 = $request->billing_address1 ?? NULL;
      $billingAddress2 = $request->billing_address2;
      $billingCity = $request->billing_city;
      $billingPincode = $request->billing_pincode;
      $billingstate = $request->billing_state;
      $billingContactNo = $request->billing_contact_no;
      $billingCustomerName = $request->billing_customer_name;
      $billingEmail = $request->billing_email;
      $shippingLeadAddressesId = $request->shipping_lead_addresses_id ?? '';
      $shippingContactPeopleId = $request->shipping_lead_contact_people_id ?? '';
      $shippingAddress1 = $request->shipping_address1;
      $shippingAddress2 = $request->shipping_address2;
      $shippingCity = $request->shipping_city;
      $shippingPincode = $request->shipping_pincode;
      $shippingState = $request->shipping_state;
      $shippingContactNo = $request->shipping_contact_no;
      $shippingCustomerName = $request->shipping_customer_name;
      $shippingEmail = $request->shipping_email;
      $yourSoNo = $request->your_so_no ?? '';

      $soDetailsEmpty = false;
      if ($poType === 1) {
        foreach ($soDetails as $key => $item) {
          if (empty($item['product_id']) || empty($item['part_no']) || empty($item['qty']) || empty($item['rate'])) {
            $soDetailsEmpty = true;
            break;
          }
        }
      } else {
        foreach ($soDetails as $key => $item) {
          if (empty($item['part_no']) || empty($item['rate'])) {
            $soDetailsEmpty = true;
            break;
          }
        }
      }

      $serviceTotal = 0;
      if ($poType === 1) {
        if (!empty($serviceDetails) && is_array($serviceDetails)) {
          $serviceTotal = array_reduce($serviceDetails, function ($carry, $item) {
            return $carry + (isset($item['total_amount']) ? intval($item['total_amount']) : 0);
          }, 0);
        }
      }

      $soDetailTotal = 0;
      if ($poType === 1) {
        if (!empty($soDetails) && is_array($soDetails)) {
          $soDetailTotal = array_reduce($soDetails, function ($carry, $item) {
            return $carry + (isset($item['total_amount']) ? intval($item['total_amount']) : 0);
          }, 0);
        }
      } else {
        if ($soDetails) {
          foreach ($soDetails as $value) {
            $consigneeDetailTotal = array_reduce($value['consignees'], function ($sum, $item) {
              return $sum + $item['qty'];
            }, 0);

            $soDetailTotal = $consigneeDetailTotal * $value['rate'];
          }
        }
      }

      $finalAmount = $soDetailTotal + $serviceTotal;
      if ($cgst > 0) $cgstValue = ($finalAmount * floatval($cgst)) / 100;
      if ($sgst > 0) $sgstValue = ($finalAmount * floatval($sgst)) / 100;
      if ($igst > 0) $igstValue = ($finalAmount * floatval($igst)) / 100;

      $finalAmount = $finalAmountInInr = $finalAmount + $cgstValue + $sgstValue + $igstValue;

      if ($soDetailsEmpty) {
        $this->response["errors"] = ["po_details" => "Please fill all Sales Order Details"];
        return $this->sendResponse($this->response, 200);
      }

      $files = [];
      if (!empty($attachments)) {
        foreach ($attachments as $item) {
          moveFile('project/files/', $item['filename']);
          $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
        }
      }


      $serviceDetails = json_encode($serviceDetails);
      $soDetails = json_encode($soDetails);
      $attachments = json_encode($files);

      $rfqObject = Rfq::find($rfqId);
      $isCurrencyUsd = $rfqObject->currency ?? null;

      if ($isCurrencyUsd) {
        $usdToInrRateResponse = getUsdToInrRate();

        if (isset($usdToInrRateResponse['error']) && !empty($usdToInrRateResponse['error'])) {
          $this->response['error'] = $usdToInrRateResponse['error'];
          return $this->sendResponse($this->response, 200);
        }

        $usdToInrRate = $usdToInrRateResponse['data'];
        $finalAmountInInr = $soDetailTotal * floatval($usdToInrRate);
      }

      $tenderObject = Tender::where('id', $poObject->fk_tender_id)->first();

      if ($poType === 1) {
        $division = Division::find($rfqObject->division_id);
      } else {
        $division = Division::find($tenderObject->division_id);
      }

      if (!$division) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Division"]);
        return $this->sendResponse($this->response, 200);
      }


      if ($id) {
        $soObject = AvlockSalesOrder::find($id);

        if (!$soObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Sales Order"]);
          return $this->sendResponse($this->response, 200);
        }
        $soObject->first();
        $soObject->updated_by = $this->userId;

        $this->response['msg'] = __('admin.updated', ['module' => "Sales Order"]);
      } else {

        $soObject->created_by = $this->userId;
        $baseString = strtoupper('SO/'  . $division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . $soMonth . '/');
        $soObject->so_no = generateSeries($baseString, 'avlock_sales_orders', 'so_no');
        $this->response['msg'] = __('admin.created', ['module' => "Sales Order"]);
      }


      $soObject->fk_po_id = $poId;
      $soObject->fk_quotation_id = $poType === 1 ? $fk_quotation_id : 0;
      $soObject->fk_rfq_id = $poType === 1 ? $rfqId : 0;
      $soObject->fk_lead_id = $poType === 1 ? $leadId : 0;
      $soObject->so_date = $soDate;
      $soObject->your_so_no = $yourSoNo;
      $soObject->so_details = $soDetails;
      $soObject->service_details = $serviceDetails;
      $soObject->so_total_amount = $soDetailTotal;
      $soObject->final_amount = $finalAmount ?? 0;
      $soObject->final_amount_in_inr = $finalAmountInInr ?? 0;
      $soObject->so_total_amount_paid =  $soObject->so_total_amount_paid ?? 0;
      $soObject->so_total_amount_pending =  max(0, $soTotalAmount - ($soObject->so_total_amount_paid ?? 0));
      $soObject->payment_done =  $soObject->so_total_amount_pending > 0  ?  0 : 1;
      $soObject->cgst = $cgst;
      $soObject->cgst_value = $cgstValue;
      $soObject->sgst = $sgst;
      $soObject->sgst_value = $sgstValue;
      $soObject->igst = $igst;
      $soObject->igst_value = $igstValue;
      $soObject->curr_stage_id = $currStageId;
      $soObject->curr_sub_stage_id = $currSubStageId;
      $soObject->curr_user = json_encode($currUser);
      $soObject->curr_user_ids = $currUserIds;
      $soObject->attachments = $attachments;
      $soObject->po_type = $poType;
      // $soObject->comm_users = json_encode($commUsers);
      // $soObject->comments = $comments;
      $soObject->remark = $remark;
      $soObject->dispatch_id = $dispatchId;
      $soObject->billing_lead_addresses_id = $billingLeadAddressesId;
      $soObject->billing_lead_contact_people_id = $billingContactPeopleId;
      $soObject->billing_address1 = $billingAddress1;
      $soObject->billing_address2 = $billingAddress2;
      $soObject->billing_city = $billingCity;
      $soObject->billing_pincode = $billingPincode;
      $soObject->billing_state = $billingstate;
      $soObject->billing_contact_no = $billingContactNo;
      $soObject->billing_customer_name = $billingCustomerName;
      $soObject->billing_email = $billingEmail;
      $soObject->shipping_lead_addresses_id = $shippingLeadAddressesId;
      $soObject->shipping_lead_contact_people_id = $shippingContactPeopleId;
      $soObject->shipping_address1 = $shippingAddress1;
      $soObject->shipping_address2 = $shippingAddress2;
      $soObject->shipping_city = $shippingCity;
      $soObject->shipping_pincode = $shippingPincode;
      $soObject->shipping_state = $shippingState;
      $soObject->shipping_contact_no = $shippingContactNo;
      $soObject->shipping_customer_name = $shippingCustomerName;
      $soObject->shipping_email = $shippingEmail;
      $soObject->save();

      $soObject->action = 'created';
      if ($id) {
        $soObject->action = 'updated';
      }

      if (empty($id)) {
        $poObject->curr_sub_stage_id = $currSubStageId;
        $poObject->save();
        PoLogCreated::dispatch($poObject);
      }

      $this->response['status'] = 1;
      $this->response['data']['id'] = $soObject->id ?? '';
      DB::commit();

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      DB::rollBack();
      Log::error("Failed Creating Sales Order: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      DB::rollBack();
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Sales Order"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $rfqObject = AvlockSalesOrder::find($id);

      if (!$rfqObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Sales Order"]);
        return $this->sendResponse($this->response, 500);
      }

      $rfqObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Sales Order"]);
      $this->response['data'] = $rfqObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Sales Order deleting failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function downloadPdf(Request $request)
  {
    try {

      $salesOrderId = $request->so_id;
      $viewPdf = $request->view_pdf;
      $salesOrderObject = AvlockSalesOrder::with(['po', 'rfq.banner', 'rfq.footer', 'rfq.currencyData', 'lead'])->find($salesOrderId);
      $detail = new SalesOrderResource($salesOrderObject);
      $details = json_decode(json_encode($detail));
      $view = 'pdf.dispatch.sales_order_view';

      if ($viewPdf == 1) {
        $this->response['status'] = 1;
        $this->response['msg'] = __('admin.fetched', ['module' => "Sales Order"]);
        $this->response['data']['html'] = view($view, ['details' => $details])->render();
        return $this->sendResponse($this->response, 200);
      }
      $path = 'pdf/dispatch/' . str_replace(['-', '/'], '', $salesOrderObject->so_no) . '.pdf';

      MyPdf::view($view, ['details' => $details])
        ->format(Format::A4)
        ->margins(10, 10, 10, 10)
        ->save(storage_path('app/public/uploads/' . $path));

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Sales Order Pdf"]);
      $this->response['data'] = $this->fileAccessPath . '/' . $path;
      $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Sales Order pdf Generation Failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }


  private function validateAddUpdateSalesOrder(Request $request)
  {
    return Validator::make($request->all(), [
      // 'so_no' => 'required',
      'so_date' => 'required|date_format:d/m/Y',
    ])->errors();
  }
}
