<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Tender;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class CronJobController extends Controller
{

    public function markTendersAsLost()
    {
        $threeMonthsAgo = Carbon::now()->subMonths(3);

        Tender::where('tender_start_date', '<=', $threeMonthsAgo)
            ->where('tender_status', '!=', 0)
            ->whereDoesntHave('pos')
            ->update(['tender_status' => 0]);

        return response()->json(['message' => 'Tenders without PO marked as lost successfully.']);
    }
}
