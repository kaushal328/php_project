<?php

namespace App\Http\Controllers\API;

use App\Models\Supplier;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class SupplierController extends AppBaseController
{

  public function index(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $organizationName = $request->organization_name ?? '';
      $assessmentDate = $request->assessment_date ?? '';

      $supplier = Supplier::withoutTrashed()->orderBy("id", "desc");
      $numRows = $supplier->count();

      if ($organizationName) {
        $supplier->where('organization_name', 'like', '%' . $organizationName . '%');
      }

      if ($assessmentDate) {
        $supplier->where('assessment_date', '>=', $this->convertToDatabaseDateForSearch($assessmentDate));
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Supplier"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $per_page ? 1 : ceil($numRows / $per_page);
      $this->response['data']['organization_name'] = $organizationName;
      $this->response['data']['assessment_date'] = $assessmentDate;
      $this->response['data']['list'] = $supplier->limit($per_page)->offset($offset)->get();
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Supplier fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $supplier = Supplier::find($id);

      if (!$supplier) {
        $this->response['error'] = __('admin.id_not_found', ['module' => 'Supplier']);
        return $this->sendResponse($this->response, 400);
      }

      $supplier->first();
      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => 'Supplier']);
      $this->response['data'] = $supplier;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Supplier fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateSupplier($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $supplier = new Supplier();
      $id = $request->id;
      $organizationName = $request->organization_name;
      $assessmentDate = Carbon::createFromFormat('d/m/Y h:i A', $request->assessment_date)->format('Y-m-d H:i:s');
      $officeAddress = $request->office_address;
      $factoryAddress = $request->factory_address;
      $assessmentTeamDetails = $request->assessment_team_details;
      $supplierCategory = $request->supplier_category;
      $constitution = $request->constitution;
      $businessNature = $request->business_nature;
      $directorContact = $request->director_contact;
      $technicalContact = $request->technical_contact;
      $commercialContact = $request->commercial_contact;
      $qaContact = $request->qa_contact;
      $landline = $request->landline;
      $establishmentYear = $request->establishment_year;
      $experienceYear = $request->experience_year;
      $weeklyHoliday = $request->weekly_holiday;
      $workingHoursStart = Carbon::createFromFormat('H:i', $request->working_hours_start)->format('H:i');
      $workingHoursEnd = Carbon::createFromFormat('H:i', $request->working_hours_end)->format('H:i');
      $nearestRailwayStation = $request->nearest_railway_station;
      $nearestPostOffice = $request->nearest_post_office;
      $nearestAirport = $request->nearest_airport;
      $plantLocatedInOwnLand = $request->plant_located_in_own_land;
      $plantLocatedInOwnLandComment = $request->plant_located_in_own_land_comment;
      $ifOwnLandComment = $request->if_own_land_comment;
      $openAreaSqrMtr = $request->open_area_sqr_mtr;
      $coveredAreaSqrMtr = $request->covered_area_sqr_mtr;
      $electricPowerAvailable = $request->electric_power_available;
      $electricPowerCapacity = $request->electric_power_capacity;
      $generatorAvailable = $request->generator_available;
      $generatorCapacity = $request->generator_capacity;
      $sufficientGeneratorCapacity = $request->sufficient_generator_capacity;
      $connectedGeneratorEquipment = $request->connected_generator_equipment;
      $notConnectedGeneratorEquipment = $request->not_connected_generator_equipment;
      $operationsCarriedOut = json_encode($request->operations_carriedout) ?? [];
      $fullInhouseFacilityItem = $request->full_inhouse_facility_item;
      $fullInhouseFacilityItemComment = $request->full_inhouse_facility_item_comment;
      $technologyIndigenous = $request->technology_indigenous;
      $technologyIndigenousComment = $request->technology_indigenous_comment;
      $technologyAdopted = $request->technology_adopted;
      $technologyAdoptedComment = $request->technology_adopted_comment;
      $technicalColaboration = $request->technical_colaboration;
      $technicalColaborationComment = $request->technical_colaboration_comment;
      $jointVenture = $request->joint_venture;
      $jointVentureComment = $request->joint_venture_comment;
      $noOfEmployees = $request->no_of_employees;
      $noOfEmployeesCompanyRole = $request->no_of_employees_company_role;
      $noOfContractLabour = $request->no_of_contract_labour;
      $noOfSkilledEmployees = $request->no_of_skilled_employees;
      $noOfUnskilledEmployees = $request->no_of_unskilled_employees;
      $environment = $request->environment;
      $environmentComment = $request->environment_comment;
      $safety = $request->safety;
      $safetyComment = $request->safety_comment;
      $factoryLicense = $request->factory_license;
      $factoryLicenseComment = $request->factory_license_comment;
      $pollutionControlBoard = $request->pollution_control_board;
      $pollutionControlBoardComment = $request->pollution_control_board_comment;
      $weightAndMeasure = $request->weight_and_measure;
      $weightAndMeasureComment = $request->weight_and_measure_comment;
      $eccNo = $request->ecc_no;
      $range = $request->range;
      $division = $request->division;
      $collectorate = $request->collectorate;
      $cstNo = $request->cst_no;
      $tinNo = $request->tin_no;
      $panNo = $request->pan_no;
      $vatRegNo = $request->vat_reg_no;
      $serviceTaxNo = $request->service_tax_no;
      $plantLayoutAttached = $request->plant_layout_attached;
      $plantLayoutCertified = $request->plant_layout_certified;
      $problemSolvingTechnique = json_encode($request->problem_solving_technique) ?? [];
      $majorCustomerBusinessShare = $request->major_customer_business_share ?? [];
      $orderInHand = $request->order_in_hand;
      $lastYearRevenue = $request->last_year_revenue;
      $secondLastYearRevenue = $request->second_last_year_revenue;
      $expansionPlanAttachment = $request->expansion_plan_attachment;
      $pendingLitigationAgainstVendor = $request->pending_litigation_against_vendor;
      $pendingLitigationAgainstVendorComment = $request->pending_litigation_against_vendor_comment;
      $aboveQuestionYes = $request->above_question_yes;
      $scrapDisposalSystem = json_encode($request->scrap_disposal_system) ?? [];

      $files = [];
      if (isset($request->expansion_plan_attachment_doc)) {
        if (count($request->expansion_plan_attachment_doc) > 0) {
          foreach ($request->expansion_plan_attachment_doc as $item) {
            moveFile('supplier/files/', $item['filename']);
            $files[] = ['filename' => $item['filename'], 'path' => $this->fileAccessPath . "/supplier/files/" . $item['filename']];
          }
        }
      }

      $expansionDoc = json_encode($files) ?? null;

      $fileTwo = [];
      if (isset($request->if_own_land)) {
        if (count($request->if_own_land) > 0) {
          foreach ($request->if_own_land as $item) {
            moveFile('ownland/files/', $item['filename']);
            $fileTwo[] = ['filename' => $item['filename'], 'path' => $this->fileAccessPath . "/ownland/files/" . $item['filename']];
          }
        }
      }

      $ownDoc = json_encode($fileTwo) ?? null;

      if ($id) {
        $supplier = Supplier::find($id);

        if (!$supplier) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Supplier"]);
          return $this->sendResponse($this->response, 200);
        }

        $supplier->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Supplier"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Supplier"]);
      }

      $supplier->assessment_date = $assessmentDate;
      $supplier->organization_name = $organizationName;
      $supplier->office_address = $officeAddress;
      $supplier->factory_address = $factoryAddress;
      $supplier->assessment_team_details = json_encode($assessmentTeamDetails) ?? [];
      $supplier->supplier_category = json_encode($supplierCategory) ?? [];
      $supplier->constitution = $constitution;
      $supplier->business_nature = $businessNature;
      $supplier->director_contact = json_encode($directorContact) ?? [];
      $supplier->technical_contact = json_encode($technicalContact) ?? [];
      $supplier->commercial_contact = json_encode($commercialContact) ?? [];
      $supplier->qa_contact = json_encode($qaContact) ?? [];
      $supplier->landline = $landline;
      $supplier->establishment_year = $establishmentYear;
      $supplier->experience_year = $experienceYear;
      $supplier->weekly_holiday = json_encode($weeklyHoliday) ?? [];
      $supplier->working_hours_start = $workingHoursStart;
      $supplier->working_hours_end = $workingHoursEnd;
      $supplier->nearest_railway_station = $nearestRailwayStation;
      $supplier->nearest_post_office = $nearestPostOffice;
      $supplier->nearest_airport = $nearestAirport;
      $supplier->plant_located_in_own_land = $plantLocatedInOwnLand;
      $supplier->plant_located_in_own_land_comment = $plantLocatedInOwnLandComment;
      $supplier->if_own_land = $ownDoc;
      $supplier->if_own_land_comment = $ifOwnLandComment;
      $supplier->open_area_sqr_mtr = $openAreaSqrMtr;
      $supplier->covered_area_sqr_mtr = $coveredAreaSqrMtr;
      $supplier->electric_power_available = $electricPowerAvailable;
      $supplier->electric_power_capacity = $electricPowerCapacity;
      $supplier->generator_available = $generatorAvailable;
      $supplier->generator_capacity = $generatorCapacity;
      $supplier->sufficient_generator_capacity = $sufficientGeneratorCapacity;
      $supplier->connected_generator_equipment = $connectedGeneratorEquipment;
      $supplier->not_connected_generator_equipment = $notConnectedGeneratorEquipment;
      $supplier->operations_carriedout = $operationsCarriedOut;
      $supplier->full_inhouse_facility_item = $fullInhouseFacilityItem;
      $supplier->full_inhouse_facility_item_comment = $fullInhouseFacilityItemComment;
      $supplier->technology_indigenous = $technologyIndigenous;
      $supplier->technology_indigenous_comment = $technologyIndigenousComment;
      $supplier->technology_adopted = $technologyAdopted;
      $supplier->technology_adopted_comment = $technologyAdoptedComment;
      $supplier->technical_colaboration = $technicalColaboration;
      $supplier->technical_colaboration_comment = $technicalColaborationComment;
      $supplier->joint_venture = $jointVenture;
      $supplier->joint_venture_comment = $jointVentureComment;
      $supplier->no_of_employees = $noOfEmployees;
      $supplier->no_of_employees_company_role = $noOfEmployeesCompanyRole;
      $supplier->no_of_contract_labour = $noOfContractLabour;
      $supplier->no_of_skilled_employees = json_encode($noOfSkilledEmployees) ?? [];
      $supplier->no_of_unskilled_employees = json_encode($noOfUnskilledEmployees) ?? [];
      $supplier->environment = $environment;
      $supplier->environment_comment = $environmentComment;
      $supplier->safety = $safety;
      $supplier->safety_comment = $safetyComment;
      $supplier->factory_license = $factoryLicense;
      $supplier->factory_license_comment = $factoryLicenseComment;
      $supplier->pollution_control_board = $pollutionControlBoard;
      $supplier->pollution_control_board_comment = $pollutionControlBoardComment;
      $supplier->weight_and_measure = $weightAndMeasure;
      $supplier->weight_and_measure_comment = $weightAndMeasureComment;
      $supplier->ecc_no = $eccNo;
      $supplier->range = $range;
      $supplier->division = $division;
      $supplier->collectorate = $collectorate;
      $supplier->cst_no = $cstNo;
      $supplier->tin_no = $tinNo;
      $supplier->pan_no = $panNo;
      $supplier->vat_reg_no = $vatRegNo;
      $supplier->service_tax_no = $serviceTaxNo;
      $supplier->plant_layout_attached = $plantLayoutAttached;
      $supplier->plant_layout_certified = $plantLayoutCertified;
      $supplier->problem_solving_technique = $problemSolvingTechnique;
      $supplier->major_customer_business_share = json_encode($majorCustomerBusinessShare) ?? [];
      $supplier->order_in_hand = $orderInHand;
      $supplier->last_year_revenue = $lastYearRevenue;
      $supplier->second_last_year_revenue = $secondLastYearRevenue;
      $supplier->expansion_plan_attachment = $expansionPlanAttachment;
      $supplier->expansion_plan_attachment_doc = $expansionDoc;
      $supplier->pending_litigation_against_vendor = $pendingLitigationAgainstVendor;
      $supplier->pending_litigation_against_vendor_comment = $pendingLitigationAgainstVendorComment;
      $supplier->above_question_yes = $aboveQuestionYes;
      $supplier->scrap_disposal_system = $scrapDisposalSystem;

      $supplier->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Creating Supplier: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Supplier"]);
      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $supplier = Supplier::find($id);

      if (!$supplier) {
        $this->response['error'] = __('admin.id_not_found', ['module' => 'Supplier']);
        return $this->sendResponse($this->response, 400);
      }

      $supplier->delete();
      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => 'Supplier']);
      $this->response['data'] = $supplier;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Supplier deleting failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function masterDataList(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $this->response['status'] = 1;
      $this->response['data'] = [
        'supplier_category' => config('global.SUPPLIER_CATEGORY'),
        'constitution' => config('global.CONSTITUTION'),
        'business_nature' => config('global.BUSINESS_NATURE'),
        'week_days' => config('global.WEEK_DAYS'),
        'operations_carriedout' => config('global.OPERATIONS_CARRIEDOUT'),
        'problem_solving_techniques' => config('global.PROBLEM_SOLVING_TECHNIQUES'),
        'scraps_disposal_system' => config('global.SCRAPS_DISPOSAL_SYSTEM'),
      ];

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Supplier Master Data List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdateSupplier(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'organization_name' => 'required',
        'assessment_date' => 'required|date_format:d/m/Y h:i A',
        'working_hours_start' => 'date_format:H:i',
        'working_hours_end' => 'date_format:H:i',
      ],
      [
        'rfq.required_if' => 'Please Select RFQ if Activity for is set RFQ.',
      ]
    )->errors();
  }
}
