<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\ProjectType;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ProjectTypeController extends AppBaseController
{
    /**
     * Display a listing of the Project Type.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $name = $request->name ?? '';
            $status = $request->status ?? '';

            $projectType = ProjectType::orderBy("id", "desc");

            if ($name) {
                $projectType->where('name', 'like', '%' . $name . '%');
            }

            if ($status) {
                $projectType->where('status', $status);
            }

            $num_rows = $projectType->count();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Project Type"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['name'] = $name;
            $this->response['data']['list'] = $projectType->limit($per_page)->offset($offset)->get();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project Type fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addUpdate(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateProjectType($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $projectTypeObject = new ProjectType();
            $id = $request->id;
            $name = $request->name ?? '';
            $status = $request->status ?? 1;



            if ($id) {
                $projectTypeObject = ProjectType::find($id);

                if (!$projectTypeObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Project Type"]);
                    return $this->sendResponse($this->response, 401);
                }

                $projectTypeObject->first();
                $projectTypeObject->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "Project Type"]);
            } else {
                $projectTypeObject->created_by = $this->userId;
                $this->response['msg'] = __('admin.created', ['module' => "Project Type"]);
            }

            $projectTypeObject->name = $name;
            $projectTypeObject->status = $status;

            $projectTypeObject->save();

            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed Creating Project Type: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Project Type"]);

            return $this->sendResponse($this->response, 401);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $projectTypeObject = ProjectType::find($id);

            if (!$projectTypeObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project Type"]);
                return $this->sendResponse($this->response, 401);
            }
            $projectTypeObject->first();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Project Type"]);
            $this->response['data'] = $projectTypeObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project Type fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $projectTypeObject = ProjectType::find($id);

            if (!$projectTypeObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project Type"]);
                return $this->sendResponse($this->response, 401);
            }

            $projectTypeObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Project Type"]);
            $this->response['data'] = $projectTypeObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project Type Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    private function validateAddUpdateProjectType(Request $request)
    {
        return Validator::make($request->all(), [
            'name' => 'required|string|unique:project_types,name,' . $request->id . ',id,deleted_at,NULL',
            'status' => 'sometimes|required|integer|in:0,1',
        ])->errors();
    }
}
