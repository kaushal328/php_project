<?php

namespace App\Http\Controllers\API;

use Exception;
use Carbon\Carbon;
use App\Models\Rfq;
use App\Models\Task;
use App\Models\User;
use App\Models\Tender;
use App\Enums\PoStatus;
use App\Enums\TenderDispatchDocument;
use App\Enums\TenderStatus;
use App\Models\Reminder;
use App\Models\SubStage;
use App\Models\TaskUser;
use App\Models\UserRole;
use App\Models\Department;
use App\Models\Tabulation;
use App\Models\ReminderUser;
use Illuminate\Http\Request;
use App\Events\TaskLogCreated;
use App\Models\TenderStageLog;
use App\Models\TenderSubStage;
use App\Models\TenderQuotation;
use Illuminate\Support\Facades\DB;
use App\Models\TenderPurchaseOrder;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use App\Models\TenderPurchaseInvoice;
use App\Models\TenderPurchaseOrderLr;
use App\Models\TenderPurchaseOrderRn;
use App\Http\Resources\AllUserResource;
use App\Http\Resources\RfqListResource;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\IOFactory;
use App\Models\TenderProductRequirement;
use App\Events\TenderQuotationLogCreated;
use App\Http\Resources\TabulationResource;
use App\Models\TenderConsigneeRequirment;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\TenderListResource;
use App\Http\Resources\TenderQuotationResource;
use App\Models\TenderPurchaseOrderEInvoice;
use App\Models\TenderPurchaseOrderAgreement;
use App\Models\TenderPurchaseOrderLabelling;
use App\Models\TenderPurchaseOrderDneInvoice;
use App\Models\TenderPurchaseOrderPdrQuality;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use App\Models\TenderPurchaseOrderPackagingList;
use App\Http\Resources\UserRoleTenderHistoryResource;
use App\Models\BiddingConsigneeRequirment;
use App\Models\BiddingProductRequirment;
use App\Models\CommonTnc;
use App\Models\Division;
use App\Models\PoDespatchDetail;
use App\Models\Product;
use App\Models\PurchaseOrder;
use App\Models\TenderBidding;
use App\Models\TenderPoDispatch;
use App\Models\TenderQuotationLog;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Crypt;
use Spatie\LaravelPdf\Facades\Pdf as MyPdf;
use Spatie\LaravelPdf\Enums\Format;
use PDF;

class TenderController extends AppBaseController
{
    private $firstSubStageId = 1;
    private $APPLICATION_INITIATED = 1;
    private $APPLICATION_READY_FOR_SUBMISSION = 2;
    private $BIDDING_SUBMITTED = 3;
    private $TABULATION = 4;
    private $TENDER_ACCUIRED = 5;
    private $TENDER_LOST = 6;
    private $PO_RECEIVED_SUB_STAGE_ID = 7;
    private $AGREEMENT_PREPARED_UPLOADED_SUB_STAGE_ID = 10;
    private $MATERIAL_PLANNING_INITIATES = 30;
    private $PI_PREPARED_UPLOADED_SUB_STAGE_ID = 15;
    private $PACKAGING_LIST_PREPARED_UPLOADED_SUB_STAGE_ID = 21;
    private $LABELLING_PREPARED_UPLOADED_SUB_STAGE_ID = 22;
    private $DNE_PREPARED_UPLOADED_SUB_STAGE_ID = 23;
    private $PDR_PREPARED_UPLOADED_SUB_STAGE_ID = 25;
    private $E_INVOICE_PREPARED_UPLOADED = 24;
    private $LR_RECEIVED_UPLOADED_SUB_STAGE_ID = 26;
    private $R_NOTE_RECEIVED = 29;

    private function getFiscalYearDates()
    {
        $currentMonth = (int)date('m');
        $currentYear = (int)date('Y');

        return [
            'currentMonth' => $currentMonth,
            'fiscalYear' => ($currentMonth >= 1 && $currentMonth <= 3) ? $currentYear - 1 : $currentYear,
        ];
    }

    // Tender List
    function index(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $name = $request->name ?? '';
            $tenderNo = $request->tender_no ?? '';
            $consignee = $request->consignee ?? '';
            $partNo = $request->part_no ?? '';
            $currSubSatgeId = $request->current_stage_id ?? '';
            $startDate = $request->tender_start_date ?? '';
            $endDate = $request->tender_end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';
            $tenderStatus = $request->tender_status ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'tender_start_date';

            $tenders = Tender::with([
                'subStageUsers.designation',
                'products',
                'consignee',
                'currentSubStage',
                'pos.tenderSubStage.nextSubStage'
            ])->where('application_initiate', 1);

            if ($this->isUserAdmin) {
                $tenders = $tenders->orderBy('updated_at', 'desc');
            } else {
                $user = User::find($this->userId);
                $divisionIdsArray = explode(',', $user->division_ids);

                $tenders = $tenders->where(function ($query) use ($divisionIdsArray) {
                    $query->whereIn('division_id', $divisionIdsArray);
                })->orderBy('updated_at', 'desc');
            }


            if ($name) $tenders->where('name', 'like', '%' . $name . '%');
            if ($tenderNo) $tenders->where('tender_no', 'like', '%' . $tenderNo . '%');

            if ($tenderStatus) {
                $tenders->where('tender_status', $tenderStatus);
            }

            if ($currSubSatgeId) {
                $tenders->where('sub_stage_id', $currSubSatgeId);
            }

            if ($consignee) {
                $tenders->whereHas('consignee', function ($query) use ($consignee) {
                    $query->where('name', 'like', '%' . $consignee . '%');
                });
            }

            if ($partNo) {
                $tenders->whereHas('products', function ($query) use ($partNo) {
                    $query->where('part_no', 'like', '%' . $partNo . '%');
                });
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $tenders->whereDate('tender_start_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $tenders->whereDate('tender_start_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $tenders->whereDate('tender_start_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $tenders->whereDate('tender_start_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $tenders->whereDate('tender_start_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $tenders->whereDate('tender_start_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $tenders->whereDate('tender_start_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $tenders->whereDate('tender_start_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $tenders->whereMonth('tender_start_date', date('m'))->whereYear('tender_start_date', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $tenders->whereMonth('tender_start_date', date('m', strtotime('-1 month')));
                }

                if ($dateRange == 'this_year') {
                    $tenders->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $tenders->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $tenders->whereDate('tender_start_date', '>=', $startDate);

                        if ($endDate) {
                            $tenders->whereDate('tender_start_date', '<=', $endDate);
                        }
                    }
                }
            }

            $numRows = $tenders->count();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Tenders"]);

            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $numRows;
            $this->response['data']['total_pages'] = $numRows < $per_page ? 1 : ceil($numRows / $per_page);
            $this->response['data']['current_stage_id'] = $currSubSatgeId;
            $this->response['data']['name'] = $name;
            $this->response['data']['tender_start_date'] = $startDate;
            $this->response['data']['tender_end_date'] = $endDate;
            $this->response['data']['tender_status'] = $endDate;

            $tenders = $tenders->limit($per_page)->offset($offset)->get();
            $this->response['data']['list'] = TenderListResource::collection($tenders);

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender saving failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function upcomingList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $name = $request->name ?? '';
            $organization = $request->organization ?? '';
            $tender_start_date = $request->tender_start_date ?? '';
            $tender_end_date = $request->tender_end_date ?? '';

            $tenders = Tender::where('application_initiate', 0)->orderBy('id', 'desc');

            if ($name) $tenders->where('name', 'like', '%' . $name . '%');
            if ($organization) $tenders->where('organization', 'like', '%' . $organization . '%');

            $numRows = $tenders->count();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Tenders"]);

            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $numRows;
            $this->response['data']['total_pages'] = $numRows < $per_page ? 1 : ceil($numRows / $per_page);
            $this->response['data']['name'] = $name;
            $this->response['data']['organization'] = $organization;
            $this->response['data']['tender_start_date'] = $tender_start_date;
            $this->response['data']['tender_end_date'] = $tender_end_date;

            $tenders = $tenders->limit($per_page)->offset($offset)->get();
            $this->response['data']['list'] = $tenders;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender saving failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    // Get Tender Details
    function get(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $tender = Tender::with(['products.product', 'tenderBidding', 'subStageUsers', 'currentSubStage', 'division:id,name', 'products.consignee', 'pos.tenderSubStage.nextSubStage', 'inspectionRequiredBy:id,title'])->where('id', $id)->get();
            if (!$tender) {
                $this->response['error'] = "Tender not found!";
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['data'] = TenderListResource::collection($tender);

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender saving failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    // Create or Update Tender
    function addUpdate(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateTenderCreate($request);
            if (count($validationErrors)) {
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $id = $request->id ?? '';
            $name = $request->name ?? '';
            $tender_no = $request->tender_no ?? '';
            $organization = $request->organization ?? '';
            $tender_start_date = $request->tender_start_date ?? '';
            $tender_end_date = $request->tender_end_date ?? '';
            $tender_end_time = $request->tender_end_time ?? '';
            // $reminder_to = $request->reminder_to ?? '';

            $tender = Tender::find($id);
            if (!$tender) {
                $tender = new Tender();
                $tender->sub_stage_id = $this->firstSubStageId;
                $tender->sub_stage_remark = "";
                $tender->sub_stage_attachments = json_encode([]);
            }

            $userIds = array((int)$this->userId);

            $tender->sub_stage_user_ids = $userIds;
            $tender->name = $name;
            $tender->tender_no = $tender_no;
            $tender->organization = $organization;
            $tender->tender_start_date = Carbon::createFromFormat('d/m/Y', $tender_start_date)->format('Y-m-d');
            $tender->tender_end_date = Carbon::createFromFormat('d/m/Y', $tender_end_date)->format('Y-m-d');
            $tender->tender_start_time = '00:00:00';
            $tender->tender_end_time = Carbon::createFromFormat('H:i', $tender_end_time)->format('H:i:s');
            $tender->save();
            // $tender->reminder_to = $reminder_to;
            $tender->created_by = $this->userId;
            $tender->save();

            if ($id) {
                TenderProductRequirement::where('tender_id', $tender->id)->delete();
            } else {
                $tenderSubStageLog = new TenderStageLog();
                $tenderSubStageLog->tender_id = $tender->id;
                $tenderSubStageLog->sub_stage_id = $this->firstSubStageId;
                $tenderSubStageLog->remark = "";
                $tenderSubStageLog->attachments = json_encode([]);
                $tenderSubStageLog->save();
            }

            $this->response['status'] = 1;
            $this->response['msg'] = "Tender saved successfully";

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender saving failed: " . $e);
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function applicationAddUpdate(REQUEST $request)
    {
        DB::beginTransaction();
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateApplicationAddUpdate($request);
            if (count($validationErrors)) {
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $id = $request->id;
            $name = $request->name ?? '';
            $tender_no = $request->tender_no ?? '';
            $organization = $request->organization ?? '';
            $tender_start_date = $request->tender_start_date ?? '';
            $tender_end_date = $request->tender_end_date ?? '';
            $tender_end_time = $request->tender_end_time ?? '';
            $contact_no = $request->contact_no ?? '';
            $email = $request->email ?? '';
            $address = $request->address ?? '';
            $description = $request->description ?? '';
            $tender_type = $request->tender_type ?? '';
            $product_inspection = $request->product_inspection ?? '';
            $inspection_required_by = $request->inspection_required_by ?? '';
            $inspection_required = $request->inspection_required ?? 0;
            $tender_budget = $request->tender_budget ?? '';
            $inspection_agency = $request->inspection_agency ?? '';
            $earnest_money = $request->earnest_money ?? '';
            $warranty = $request->warranty ?? '';
            $divisionId = $request->division_id ?? '';
            $additional_cause = $request->additional_cause ?? '';
            $set_name = $request->set_name ?? 'Set';
            $set_value = $request->set_value ?? 1;
            $totalSetValue = $request->total_set_value ?? 0;
            $products = $request->products ?? [];
            $userIds = array((int)$this->userId);


            $proQty = array_reduce(
                $products,
                fn($carry, $product) => $carry + $product['qty'],
                0
            );


            $conQty = array_reduce(
                $products,
                function ($carry, $product) {
                    $totalConsigneeQty = array_reduce(
                        $product['consignee'],
                        fn($consigneeCarry, $consignee) => $consigneeCarry + $consignee['qty'],
                        0
                    );
                    return $carry + $totalConsigneeQty;
                },
                0
            );


            if ($proQty != $conQty) {
                $this->response['error'] = 'Consignee quantity should be the same as its product quantity';
                return $this->sendResponse($this->response, 200);
            }

            $division = Division::find($divisionId);
            if (!$division) {
                $this->response['error'] = "Please Select Division.";
                return $this->sendResponse($this->response, 200);
            }

            $tenderObject = new Tender();
            if ($id) {
                $tenderObject = Tender::find($id);

                if (!$tenderObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Upcoming Tender"]);
                    return $this->sendResponse($this->response, 200);
                }

                $tenderObject->application_initiate = 1;
                $tenderObject->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "Upcoming Tender"]);
            } else {
                $tenderObject->sub_stage_id = $this->APPLICATION_INITIATED;
                $this->response['msg'] = __('admin.created', ['module' => "Upcoming Tender"]);
            }

            $tenderObject->name = $name;
            $tenderObject->tender_no = $tender_no;
            $tenderObject->organization = $organization;
            $tenderObject->tender_start_date = Carbon::createFromFormat('d/m/Y', $tender_start_date)->format('Y-m-d');
            $tenderObject->tender_end_date = Carbon::createFromFormat('d/m/Y', $tender_end_date)->format('Y-m-d');
            $tenderObject->tender_start_time = '00:00:00';
            $tenderObject->tender_end_time = $tender_end_time;
            $tenderObject->description = $description;
            $tenderObject->contact_no = $contact_no;
            $tenderObject->email = $email;
            $tenderObject->address = $address;
            $tenderObject->tender_type = $tender_type;
            $tenderObject->product_inspection = $product_inspection;
            $tenderObject->inspection_required_by = $inspection_required_by;
            $tenderObject->inspection_required = $inspection_required;
            $tenderObject->tender_budget = $tender_budget;
            $tenderObject->inspection_agency = $inspection_agency;
            $tenderObject->earnest_money = $earnest_money;
            $tenderObject->warranty = $warranty;
            $tenderObject->division_id = $divisionId;
            $tenderObject->sub_stage_user_ids = $userIds;
            $tenderObject->additional_cause = $additional_cause;
            $tenderObject->set_name = $set_name;
            $tenderObject->set_value = $set_value;
            $tenderObject->total_set_value = $totalSetValue;
            $tenderObject->application_initiate = 1;
            $tenderObject->save();
            $lastInsertedTenderId = $tenderObject->id;

            if (!$id) {
                $tenderQuotation = new TenderQuotation();
                $tenderQuotation->tender_id = $lastInsertedTenderId;
                $tenderQuotation->quotation_date = Carbon::now()->format('Y-m-d');
                $tenderQuotation->user_ids = json_encode($userIds);
                $baseString = strtoupper('AVL/BID/' . $division->name . '/');
                $tenderQuotation->quotation_no = generateSeries($baseString, 'tender_quotations', 'quotation_no');
                $tenderQuotation->save();
            }

            $productIds = array_column($products, 'product_id');
            $tenderProId = array_column($products, 'id');

            if (count($productIds) > 0) {
                // Filter out empty and non-numeric values from $tenderProId
                $tenderProId = array_filter($tenderProId, 'is_numeric');
            }

            // First, get the product IDs that are not present in the payload
            $tenderProductsToDelete = TenderProductRequirement::where('tender_id', $lastInsertedTenderId)
                ->whereNotIn('id', $tenderProId)
                ->get();

            // Extract the IDs of the products to be deleted
            $tenderProductIdsToDelete = $tenderProductsToDelete->pluck('id');

            // Delete consignees related to the products to be deleted
            TenderConsigneeRequirment::where('tender_id', $lastInsertedTenderId)
                ->whereIn('product_id', $tenderProductIdsToDelete)
                ->delete();

            // First, delete the product IDs that are not present in the payload
            TenderProductRequirement::where('tender_id', $lastInsertedTenderId)
                ->whereNotIn('id', $tenderProId)
                ->delete();


            foreach ($products as $product) {
                $tenderReqId = $product['id'] ?? null;
                $tenderProId = $product['product_id'] ?? null;
                $tenderProPartId = $product['product_part_id'] ?? null;
                $tenderPartNo = $product['part_no'] ?? null;
                $tenderDesc = $product['description'] ?? null;
                $tenderQty = $product['qty'];
                $tenderRate = $product['rate'];
                $consignee = $product['consignee'] ?? [];

                $tenderProductRequirement = TenderProductRequirement::firstOrNew(
                    ['id' => $tenderReqId, 'tender_id' => $lastInsertedTenderId],
                    ['product_id' => $tenderProId]
                );

                $tenderProductRequirement->product_id = $tenderProId;
                $tenderProductRequirement->product_part_id = $tenderProPartId;
                $tenderProductRequirement->part_no = $tenderPartNo;
                $tenderProductRequirement->description = $tenderDesc;
                $tenderProductRequirement->qty = $tenderQty;
                $tenderProductRequirement->rate = $tenderRate;

                if ($tenderProductRequirement->trashed()) {
                    $tenderProductRequirement->restore();
                }

                $tenderProductRequirement->save();

                // Get existing consignee IDs for this product
                $existingConsigneeIds = TenderConsigneeRequirment::where('tender_id', $lastInsertedTenderId)
                    ->where('product_id', $tenderProductRequirement->id)
                    ->pluck('id');

                // Get consignee IDs from the payload for this product
                $payloadConsigneeIds = collect($consignee)->pluck('id')->filter();

                // Delete consignees that are not in the payload
                TenderConsigneeRequirment::where('tender_id', $lastInsertedTenderId)
                    ->where('product_id', $tenderProductRequirement->id)
                    ->whereIn('id', $existingConsigneeIds)
                    ->whereNotIn('id', $payloadConsigneeIds)
                    ->delete();

                foreach ($consignee as $singleConsignee) {
                    $conId = $singleConsignee['id'] ?? null;
                    $conProId = $tenderProductRequirement->id;
                    $conName = $singleConsignee['name'] ?? null;
                    $conQty = $singleConsignee['qty'] ?? null;
                    $conUnit = $singleConsignee['unit'] ?? null;
                    $conDeliveryPeriod = $singleConsignee['delivery_period'] ?? null;

                    $tenderConsigneeRequirment = TenderConsigneeRequirment::firstOrNew(
                        ['id' => $conId, 'tender_id' => $lastInsertedTenderId],
                        ['product_id' => $conProId]
                    );

                    $tenderConsigneeRequirment->name = $conName;
                    $tenderConsigneeRequirment->qty = $conQty;
                    $tenderConsigneeRequirment->delivery_period = $conDeliveryPeriod;
                    $tenderConsigneeRequirment->unit = $conUnit;

                    if ($tenderConsigneeRequirment->trashed()) {
                        $tenderConsigneeRequirment->restore();
                    }

                    $tenderConsigneeRequirment->save();
                }
            }

            DB::commit();
            $this->response['status'] = 1;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating Tender: " . $e);
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Tender"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    // Delete Tender
    function delete(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $tender = Tender::find($id);
            if (!$tender) {
                $this->response['error'] = "Tender not found!";
                return $this->sendResponse($this->response, 200);
            }

            $tender->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = "Tender deleted successfully";

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender deleting failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function view(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $tender_id = $request->tender_id;
            $selected_sub_stage_id = $request->sub_stage_id;

            $tender = Tender::with(['products.product', 'products.consignee.unitData', 'currentSubStage', 'subStageUsers'])->find($tender_id);
            if (!$tender) {
                $this->response['error'] = 'Tender details not found!';
                return $this->sendResponse($this->response, 200);
            }

            //for current Stage users
            $usersIds = $tender->sub_stage_user_ids;
            $currStageUser = [];

            if (!empty($usersIds)) {
                $currUsers = User::with('designation')->whereIn('id', $usersIds)->get();

                foreach ($currUsers as $currUser) {
                    $desTitle = $currUser->designation->title ?? '';
                    $userId = $currUser->id ?? '';
                    $userName = $currUser->name ?? '';

                    $currUserString = $userName . ' ' . '(' . $desTitle . ')';

                    $currStageUser[] = [
                        'id' => $userId,
                        'user_designation' => $currUserString,
                    ];
                }
            }

            $data['curr_stage_users'] = $currStageUser;



            $nextSubStageIds = $tender->currentSubStage->next_sub_stage_ids;
            $nextSubStageIds = $nextSubStageIds ?? [];

            $nextSubStages = [];
            if (count($nextSubStageIds)) $nextSubStages = TenderSubStage::whereIn('id', $nextSubStageIds)->get()->toArray();

            $data['tender'] = $tender;
            $data['current_sub_stage'] = $tender->currentSubStage;
            $data['next_sub_stages'] = $nextSubStages;

            $currentPos = TenderPurchaseOrder::where(['fk_tender_id' => $tender->id])->get();

            $currentSubStage = $tender->toArray()['current_sub_stage'];
            if ($currentSubStage) $currentSubStage['name'] = 'Current Stage (' . $currentSubStage['name'] . ')';
            if ($currentSubStage['is_last_stage'] == 1) {
                $data['sub_stages'] = $nextSubStages;
            } else {
                $data['sub_stages'] = array_merge([$currentSubStage], $nextSubStages);
            }

            // User and Department List
            $department_ids = [];
            if ($selected_sub_stage_id) {
                $selectedSubStage = TenderSubStage::find($selected_sub_stage_id);
                $department_ids = explode(',', $selectedSubStage->from_departments);
            } else {
                $department_ids = explode(',', $tender->currentSubStage->from_departments);
            }

            $departmentAndUsers = $this->getDepartmentAndUserList($department_ids);
            $usersArr = $departmentAndUsers['users']->toArray($request);
            $users = [];

            $i = 0;
            foreach ($usersArr as $key => $user) {
                $users[$i] = $user;
                $users[$i]['selected'] = $selected_sub_stage_id == $currentSubStage['id'] && in_array($user['id'], $tender->sub_stage_user_ids) ? 1 : 0;
                // $users[$i]['selected'] = $selected_sub_stage_id == $currentSubStage['id'] && in_array($user['id'], json_decode($tender->sub_stage_user_ids ?? '[]', true)) ? 1 : 0;
                $i++;
            }

            $attachments = [];
            if ($selected_sub_stage_id == $currentSubStage['id']) {
                $attachments = json_decode($tender->sub_stage_attachments);
            }


            $poId = $request->po_id;
            $po = PurchaseOrder::find($poId);

            $showFormFor = '';

            /*
              _, __, __, _,  _  _,  _, ___ _  _, _, _   __, __,  _, __, , _   __,  _, __,    _, _,_ __, _, _ _  _,  _, _  _, _, _
             / \ |_) |_) |   | / ` / \  |  | / \ |\ |   |_) |_  / \ | \ \ |   |_  / \ |_)   (_  | | |_) |\/| | (_  (_  | / \ |\ |
             |~| |   |   | , | \ , |~|  |  | \ / | \|   | \ |   |~| |_/  \|   |   \ / | \   , ) | | |_) |  | | , ) , ) | \ / | \|
             ~ ~ ~   ~   ~~~ ~  ~  ~ ~  ~  ~  ~  ~  ~   ~ ~ ~~~ ~ ~ ~     )   ~    ~  ~ ~    ~  `~' ~   ~  ~ ~  ~   ~  ~  ~  ~  ~
                                                                         ~'
            */

            if ($selected_sub_stage_id == $this->APPLICATION_READY_FOR_SUBMISSION) {
                $showFormFor = 'APPLICATION_READY_FOR_SUBMISSION';

                $tenderQuotation = TenderQuotation::where(['tender_id' => $tender_id])->first();
                $tenderProReq = TenderProductRequirement::where(['tender_id' => $tender_id])->get();
                $data['quotation_id'] = $tenderQuotation->id ?? '';
                $data['quotation_number'] = $tenderQuotation->quotation_no ?? '';
                $data['quotation_date'] = $tenderQuotation->quotation_date ?? '';
                $data['standard_term'] = $tenderQuotation->terms ?? [];
                $data['tenderer_name'] = $tender->organization ?? '';
                $data['tender_end_date'] = $tender->tender_end_date ?? '';
                $data['tender_end_time'] = $tender->tender_end_time ?? '';
                $data['tender_no'] = $tender->tender_no ?? '';
                $products = [];

                if (!empty($tenderProReq)) {
                    foreach ($tenderProReq as $key => $tpr) {
                        $id = $tpr->id ?? '';
                        $productId = $tpr->product_id ?? '';
                        $productPartId = $tpr->product_part_id ?? '';
                        $partNo = $tpr->part_no ?? '';
                        $qty = $tpr->qty ?? '';
                        $description = $tpr->description ?? '';
                        $avlockDescription = $tpr->avlock_description ?? '';
                        $rate = $tpr->rate ?? '';

                        $tenderConReq = TenderConsigneeRequirment::where(['tender_id' => $tender_id, 'product_id' => $id])->get();
                        $consignee = [];
                        foreach ($tenderConReq as $ckey => $tcr) {
                            $conId = $tcr->id ?? null;
                            $name = $tcr->name ?? '';
                            $conQty = $tcr->qty ?? 0;
                            $deliveryPeriod = $tcr->delivery_period ?? null;
                            $unit = $tcr->unit ?? '';

                            $consignee[] = [
                                'id' => $conId,
                                'name' => $name,
                                'qty' => $conQty,
                                'delivery_period' => $deliveryPeriod,
                                'unit' => $unit,
                            ];
                        }

                        $products[] = [
                            'id' => $id,
                            'product_id' => $productId,
                            'product_part_id' => $productPartId,
                            'part_no' => $partNo,
                            'qty' => $qty,
                            'description' => $description,
                            'avlock_description' => $avlockDescription,
                            'rate' => $rate,
                            'consignee' => $consignee,
                        ];
                    }
                }
                $data['products_new'] = $products;
            }

            /*
            __, _ __, __, _ _, _  _,    _, _,_ __, _, _ _ ___ ___ __, __,
            |_) | | \ | \ | |\ | / _   (_  | | |_) |\/| |  |   |  |_  | \
            |_) | |_/ |_/ | | \| \ /   , ) | | |_) |  | |  |   |  |   |_/
            ~   ~ ~   ~   ~ ~  ~  ~     ~  `~' ~   ~  ~ ~  ~   ~  ~~~ ~

           */

            if ($selected_sub_stage_id == $this->BIDDING_SUBMITTED) {
                $showFormFor = 'BIDDING_SUBMITTED';

                $tenderBidding = TenderBidding::where(['tender_id' => $tender_id])->first();
                $biddingProReq = BiddingProductRequirment::where(['tender_id' => $tender_id])->get();
                $divisionId = $tender->division_id ?? '';
                $tnc = CommonTnc::where(['division_id' => $divisionId, 'is_tender' => 0, 'status' => 1])->first();

                $data['bidding_quotation_id'] = $tenderBidding->id ?? '';
                $data['bidding_quotation_number'] = $tenderBidding->quotation_no ?? '';
                $data['bidding_quotation_date'] = $tenderBidding->quotation_date ?? '';
                $biddingProducts = [];

                if (!empty($biddingProReq)) {
                    foreach ($biddingProReq as $key => $tpr) {
                        $id = $tpr->id ?? '';
                        $productId = $tpr->product_id ?? '';
                        $productPartId = $tpr->product_part_id ?? '';
                        $partNo = $tpr->part_no ?? '';
                        $qty = $tpr->qty ?? '';
                        $description = $tpr->description ?? '';
                        $avlockDescription = $tpr->avlock_description ?? '';
                        $rate = $tpr->rate ?? '';

                        $biddingConReq = BiddingConsigneeRequirment::where(['tender_id' => $tender_id, 'product_id' => $id])->get();
                        $biddingConsignee = [];
                        foreach ($biddingConReq as $ckey => $tcr) {
                            $conId = $tcr->id ?? null;
                            $name = $tcr->name ?? '';
                            $conQty = $tcr->qty ?? 0;
                            $conUnit = $tcr->unit ?? 0;
                            $deliveryPeriod = $tcr->delivery_period ?? null;

                            $biddingConsignee[] = [
                                'id' => $conId,
                                'name' => $name,
                                'qty' => $conQty,
                                'unit' => $conUnit,
                                'delivery_period' => $deliveryPeriod,
                            ];
                        }

                        $biddingProducts[] = [
                            'id' => $id,
                            'product_id' => $productId,
                            'product_part_id' => $productPartId,
                            'part_no' => $partNo,
                            'qty' => $qty,
                            'description' => $description,
                            'avlock_description' => $avlockDescription,
                            'rate' => $rate,
                            'consignee' => $biddingConsignee,
                        ];
                    }
                }
                $data['bidding_products'] = $biddingProducts;

                $tenderQuotation = TenderQuotation::where(['tender_id' => $tender_id])->first();
                $tenderProReq = TenderProductRequirement::where(['tender_id' => $tender_id])->get();
                $data['quotation_id'] = $tenderQuotation->id ?? '';
                $data['quotation_number'] = $tenderQuotation->quotation_no ?? '';
                $data['quotation_date'] = $tenderQuotation->quotation_date ?? '';
                // $data['bidding_standard_term'] = isset($tenderQuotation->terms) ? $tenderQuotation->terms : ($tenderBidding->terms ?? '');
                $data['bidding_standard_term'] = isset($tenderBidding->terms) ? $tenderBidding->terms : ($tnc->terms ?? '');

                $products = [];

                if (!empty($tenderProReq)) {
                    foreach ($tenderProReq as $key => $tpr) {
                        $id = $tpr->id ?? '';
                        $productId = $tpr->product_id ?? '';
                        $productPartId = $tpr->product_part_id ?? '';
                        $partNo = $tpr->part_no ?? '';
                        $qty = $tpr->qty ?? '';
                        $description = $tpr->description ?? '';
                        $avlockDescription = $tpr->avlock_description ?? '';
                        $rate = $tpr->rate ?? '';

                        $tenderConReq = TenderConsigneeRequirment::where(['tender_id' => $tender_id, 'product_id' => $id])->get();
                        $consignee = [];
                        foreach ($tenderConReq as $ckey => $tcr) {
                            $conId = $tcr->id ?? null;
                            $name = $tcr->name ?? '';
                            $conQty = $tcr->qty ?? 0;
                            $deliveryPeriod = $tcr->delivery_period ?? null;
                            $unit = $tcr->unit ?? '';

                            $consignee[] = [
                                'id' => $conId,
                                'name' => $name,
                                'qty' => $conQty,
                                'unit' => $unit,
                                'delivery_period' => $deliveryPeriod,
                            ];
                        }

                        $products[] = [
                            'id' => $id,
                            'product_id' => $productId,
                            'product_part_id' => $productPartId,
                            'part_no' => $partNo,
                            'qty' => $qty,
                            'description' => $description,
                            'avlock_description' => $avlockDescription,
                            'rate' => $rate,
                            'consignee' => $consignee,
                        ];
                    }
                }
                $data['products_new'] = $products;
            }

            /*
             ___  _, __, _,_ _,   _, ___ _  _, _, _
              |  /_\ |_) | | |   /_\  |  | / \ |\ |
              |  | | |_) | | | , | |  |  | \ / | \|
              ~  ~ ~ ~   `~' ~~~ ~ ~  ~  ~  ~  ~  ~

            */
            if ($selected_sub_stage_id == $this->TABULATION) {
                $showFormFor = 'TABULATION';

                $tenderQuotation = Tabulation::where(['tender_id' => $tender_id])->get();
                if (!$tenderQuotation) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Tabulation"]);
                    return $this->sendResponse($this->response, 200);
                }

                $biddingProReq = BiddingProductRequirment::where(['tender_id' => $tender_id])->get();
                $biddingProducts = [];

                if (!empty($biddingProReq)) {
                    foreach ($biddingProReq as $key => $tpr) {
                        $id = $tpr->id ?? '';
                        $productPartId = $tpr->product_part_id ?? '';
                        $partNo = $tpr->part_no ?? '';
                        $lc = $tpr->lc ?? '';
                        $qty = $tpr->qty ?? '';
                        $description = $tpr->description ?? '';
                        $rate = $tpr->rate ?? '';

                        $levels = [];
                        for ($i = 0; $i < 3; $i++) {
                            $levels[] = [
                                'company_name' => ($i == 0) ? 'Avlock International India Pvt. Ltd.' : '',
                                'is_Self' => ($i == 0) ? 1 : 0,
                                'price' => '',
                                'mf' => '',
                            ];
                        }

                        $biddingProducts[] = [
                            'id' => $id,
                            'product_part_id' => $productPartId,
                            'part_no' => $partNo,
                            'lc' => $lc,
                            'rate' => $rate,
                            'levels' => $levels,
                        ];
                    }
                }

                $tenderStatus = $tender->tender_status ?? '';

                $tabulationDetails = [];
                if (isset($tenderQuotation) && !empty($tenderQuotation)) {
                    foreach ($tenderQuotation as $value) {
                        $tabulationId = $value->id ?? '';
                        $productPartId = $value->product_part_id ?? '';
                        $partNo = $value->part_no ?? '';
                        $lc = $value->lc ?? '';
                        $proLevels = json_decode($value->tabulation_detail) ?? [];

                        $tabulationDetails[] = [
                            "tabulation_id" => $tabulationId,
                            "product_part_id" => $productPartId,
                            "part_no" => $partNo,
                            "lc" => $lc,
                            "levels" => $proLevels,
                        ];
                    }
                }

                $data['initial_bidding_products'] = $biddingProducts ?? [];
                $data['tab_from_bidding'] = $biddingProducts ?? [];
                $data['tabulation_details'] = $tabulationDetails ?? [];
                $data['tender_status'] = $tenderStatus;
            }

            /*
             ___ __, _, _ __, __, __,   _,   _,  _, ___
              |  |_  |\ | | \ |_  |_)   |   / \ (_   |
              |  |   | \| |_/ |   | \   | , \ / , )  |
              ~  ~~~ ~  ~ ~   ~~~ ~ ~   ~~~  ~   ~   ~

            */

            if ($selected_sub_stage_id == $this->TENDER_LOST) {
                $showFormFor = 'TENDER_LOST';
            }

            if ($selected_sub_stage_id == $this->PO_RECEIVED_SUB_STAGE_ID) {
                $showFormFor = 'PO_RECEIVED';
                $poReceived = PurchaseOrder::where(['id' => $poId, 'fk_tender_id' => $tender_id, 'po_type' => 2])->first();
                $tenderBidding = TenderBidding::where(['tender_id' => $tender_id])->first();
                $biddingProReq = BiddingProductRequirment::where(['tender_id' => $tender_id])->get();

                $biddingProducts = [];
                if (!empty($biddingProReq)) {
                    foreach ($biddingProReq as $key => $tpr) {
                        $id = $tpr->id ?? '';
                        $productId = $tpr->product_id ?? '';
                        $productPartId = $tpr->product_part_id ?? '';
                        $partNo = $tpr->part_no ?? '';
                        $qty = $tpr->qty ?? '';
                        $description = $tpr->description ?? '';
                        $avlockDescription = $tpr->avlock_description ?? '';
                        $rate = $tpr->rate ?? '';

                        $biddingConReq = BiddingConsigneeRequirment::where(['tender_id' => $tender_id, 'product_id' => $id])->get();
                        $biddingConsignee = [];
                        foreach ($biddingConReq as $ckey => $tcr) {
                            $conId = $tcr->id ?? null;
                            $name = $tcr->name ?? '';
                            $conQty = $tcr->qty ?? 0;
                            $conUnit = $tcr->unit ?? 0;
                            $deliveryPeriod = $tcr->delivery_period ?? null;

                            $biddingConsignee[] = [
                                'name' => $name,
                                'qty' => $conQty,
                                'unit' => $conUnit,
                                'delivery_period' => $deliveryPeriod,
                                'consigneesDates' => [
                                    [
                                        'delivery_start_date' => '',
                                        'delivery_end_date' => '',
                                        'qty' => '',
                                    ]
                                ],
                            ];
                        }

                        $biddingProducts[] = [
                            'product_id' => $productId,
                            'product_part_id' => $productPartId,
                            'part_no' => $partNo,
                            'qty' => $qty,
                            'description' => $description,
                            'avlock_description' => $avlockDescription,
                            'rate' => $rate,
                            'consignees' => $biddingConsignee,
                        ];
                    }
                }

                if ($poReceived) {
                    $data['igst'] = $poReceived->igst;
                    $data['sgst'] = $poReceived->sgst;
                    $data['cgst'] = $poReceived->cgst;
                    $data['po_date'] = $poReceived->po_date;
                    $data['po_no'] = $poReceived->po_no;
                    $data['inspection'] = $poReceived->inspection ?? '';
                    $data['po_attachment'] = json_decode($poReceived->attachments);
                    $data['po_details'] = json_decode($poReceived->po_details);
                } else {
                    $data['po_details'] = $biddingProducts;
                }
            } else if ($selected_sub_stage_id == $this->MATERIAL_PLANNING_INITIATES) {
                $showFormFor = 'MATERIAL_PLANNING_INITIATES';
                $poId = $request->po_id ?? '';

                $poReceived = PurchaseOrder::where(['fk_tender_id' => $tender_id,])->first();
                // $tenderPoDispatch = TenderPoDispatch::where(['po_id' => $poId,])->first();
                $tenderPoDispatch = PoDespatchDetail::where(['po_id' => $poId,])->first();

                $temp = [];
                if (!empty($poReceived)) {
                    foreach (json_decode($poReceived->po_details) as $value) {
                        $productId = $value->product_id ?? '';
                        $productName = Product::where('id', $productId)->pluck('product_name')->first();
                        $partNo = $value->part_no ?? '';
                        $description = $value->description ?? '';
                        $avlockDescription = $value->avlock_description ?? '';
                        $qty = $value->qty ?? 0;
                        $rate = $value->rate ?? 0;
                        $consignees = $value->consignees ?? [];

                        $temp[] = [
                            'product_id' => $productId,
                            'product_name' => $productName,
                            'part_no' => $partNo,
                            'description' => $description,
                            'avlock_description' => $avlockDescription,
                            'qty' => $qty,
                            'rate' => $rate,
                            'consignees' => $consignees
                        ];
                    }
                }

                $newTemp = [
                    [
                        'id' => '',
                        'po_despatch_date' => Carbon::now()->format('d/m/Y'),
                        'details' => $temp,
                    ]
                ];

                if ($tenderPoDispatch) {
                    $data['dispatch_date'] = $tenderPoDispatch->dispatch_date;
                    $data['dispatch_details'] = json_decode($tenderPoDispatch->details);
                } else {
                    $data['dispatch_details'] = $newTemp ?? [];
                }
            } else if ($selected_sub_stage_id == $this->AGREEMENT_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $showFormFor = 'AGREEMENT_PREPARED_UPLOADED';

                if ($po) {
                    $agreement = TenderPurchaseOrderAgreement::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id, 'is_latest' => 1])->first();
                    if ($agreement) {
                        $data['agreement_id'] = $agreement->id;
                        $data['agreement_date'] = $agreement->agreement_date;
                        $data['agreement_no'] = $agreement->agreement_no;
                        $data['agreement_remark'] = $agreement->remark;
                    }
                }
            } else if ($selected_sub_stage_id == $this->PI_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $showFormFor = 'PI_PREPARED_UPLOADED';

                if ($po) {
                    $pi = TenderPurchaseInvoice::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id, 'is_latest' => 1])->first();
                    if ($pi) {
                        $data['pi_id'] = $pi->id;
                        $data['pi_date'] = $pi->pi_date;
                        $data['pi_no'] = $pi->pi_no;
                        $data['pi_details'] = $pi->pi_details;
                        $data['invoice_charges_detail'] = $pi->invoice_charges_detail;
                        $data['pi_remark'] = $pi->remark;
                    } else {
                        $data['pi_details'] = $po->po_details;
                    }
                }
            } else if ($selected_sub_stage_id == $this->PACKAGING_LIST_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $showFormFor = 'PACKAGING_LIST_PREPARED_UPLOADED';

                if ($po) {
                    $packaging = TenderPurchaseOrderPackagingList::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id, 'is_latest' => 1])->first();
                    if ($packaging) {
                        $data['packaging_id'] = $packaging->id;
                        $data['packaging_date'] = $packaging->packaging_date;
                        $data['packaging_no'] = $packaging->packaging_no;
                        $data['packaging_remark'] = $packaging->remark;
                    }
                }
            } else if ($selected_sub_stage_id == $this->LABELLING_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $showFormFor = 'LABELLING_PREPARED_UPLOADED';

                if ($po) {
                    $label = TenderPurchaseOrderLabelling::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id, 'is_latest' => 1])->first();
                    if ($label) {
                        $data['label_id'] = $label->id;
                        $data['label_date'] = $label->label_date;
                        $data['label_no'] = $label->label_no;
                        $data['label_remark'] = $label->remark;
                    }
                }
            } else if ($selected_sub_stage_id == $this->DNE_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $showFormFor = 'DNE_PREPARED_UPLOADED';

                if ($po) {
                    $dne_invoice = TenderPurchaseOrderDneInvoice::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id, 'is_latest' => 1])->first();
                    if ($dne_invoice) {
                        $data['dne_invoice_id'] = $dne_invoice->id;
                        $data['dne_invoice_date'] = $dne_invoice->dne_invoice_date;
                        $data['dne_invoice_no'] = $dne_invoice->dne_invoice_no;
                        $data['dne_invoice_remark'] = $dne_invoice->remark;
                    }
                }
            } else if ($selected_sub_stage_id == $this->E_INVOICE_PREPARED_UPLOADED) {
                $showFormFor = 'E_INVOICE_PREPARED_UPLOADED';

                if ($po) {
                    $e_invoice = TenderPurchaseOrderEInvoice::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id, 'is_latest' => 1])->first();
                    $pi = TenderPurchaseInvoice::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id, 'is_latest' => 1])->first();
                    $data['pi_details'] = $pi->pi_details;
                    if ($e_invoice) {
                        $data['e_invoice_id'] = $e_invoice->id;
                        $data['e_invoice_date'] = $e_invoice->e_invoice_date;
                        $data['e_invoice_no'] = $e_invoice->e_invoice_no;
                        $data['invoice_charges_detail'] = $e_invoice->invoice_charges_detail;
                        $data['e_invoice_remark'] = $e_invoice->remark;
                    } else {
                        $data['invoice_charges_detail'] = $pi->invoice_charges_detail;
                    }
                }
            } else if ($selected_sub_stage_id == $this->PDR_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $showFormFor = 'PDR_PREPARED_UPLOADED';

                if ($po) {
                    $quality_report = TenderPurchaseOrderPdrQuality::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id, 'is_latest' => 1])->first();
                    if ($quality_report) {
                        $data['quality_id'] = $quality_report->quality_id;
                        $data['quality_report_date'] = $quality_report->quality_report_date;
                        $data['quality_report_no'] = $quality_report->quality_report_no;
                        $data['quality_report_remark'] = $quality_report->remark;
                    }
                }
            } else if ($selected_sub_stage_id == $this->LR_RECEIVED_UPLOADED_SUB_STAGE_ID) {
                $showFormFor = 'LR_RECEIVED_UPLOADED';

                if ($po) {
                    $lr = TenderPurchaseOrderLr::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id, 'is_latest' => 1])->first();
                    if ($lr) {
                        $data['lr_id'] = $lr->lr_id;
                        $data['lr_date'] = $lr->lr_date;
                        $data['lr_no'] = $lr->lr_no;
                        $data['lr_remark'] = $lr->remark;
                    }
                }
            } else if ($selected_sub_stage_id == $this->R_NOTE_RECEIVED) {
                $showFormFor = 'R_NOTE_RECEIVED';

                if ($po) {
                    $rn = TenderPurchaseOrderRn::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id, 'is_latest' => 1])->first();
                    if ($rn) {
                        $data['rn_id'] = $rn->rn_id;
                        $data['rn_date'] = $rn->rn_date;
                        $data['rn_no'] = $rn->rn_no;
                        $data['rn_remark'] = $rn->remark;
                    }
                }
            }

            $data['user_departments'] = $departmentAndUsers['departments'];
            $data['user_list'] = $users;
            $data['remark'] = $selected_sub_stage_id == $currentSubStage['id'] ? $tender->sub_stage_remark : '';
            $data['attachments'] = $attachments;
            $data['show_form_for'] = $showFormFor;

            $this->response['status'] = 1;
            $this->response['data'] = $data;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender view failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function getCurrentStageDetails(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $tender_id = $request->tender_id;

            $tender = Tender::with(['currentStage'])->find($tender_id);
            if (!$tender) {
                $this->response['error'] = 'Tender details not found!';
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['data'] = $tender;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender getCurrentStageDetails failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function saveStage(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateTenderStageChange($request);

            if (count($validationErrors)) {
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $tender_id = $request->tender_id;
            $requested_sub_stage_id = $request->sub_stage_id;
            $user_ids = $request->user_ids ?? [];
            $remark = $request->remark ?? '';

            $tender = Tender::with(['currentSubStage', 'division:id,name'])->find($tender_id);
            if (!$tender) {
                $this->response['error'] = 'Tender details not found!';
                return $this->sendResponse($this->response, 200);
            }

            $requestSubStage = TenderSubStage::where('id', $requested_sub_stage_id)->first();
            $stageActionDepartments = $requestSubStage->action_departments ?? '';

            $actionDepartmentIds = [];
            if ($stageActionDepartments != '') {
                $actionDepartmentIds = explode(",", $stageActionDepartments);
            }

            $user = UserRole::with('user', 'department')->whereIn('fk_department_id', $actionDepartmentIds)->groupBy('fk_user_id')->get();

            if ($user->isEmpty()) {
                $this->response["error"] = "Current Stage has no user";
                return $this->sendResponse($this->response, 200);
            }

            if (!$user) {
                $this->response["error"] = "You are not authorized to change this stage";
                return $this->sendResponse($this->response, 200);
            }

            $stageToDepartments = $requestSubStage->to_departments ?? '';

            $toDepartmentIds = [];
            if ($stageToDepartments != '') {
                $toDepartmentIds = explode(",", $stageToDepartments);
            }

            $toDepartments = Department::whereIn('id', $toDepartmentIds)->pluck('title')->toArray();
            $currentToUserDepartments = UserRole::whereIn('fk_user_id', $user_ids)
                ->with('department')
                ->groupBy('fk_department_id')
                ->get()->toArray();

            $departmentTitles = [];

            foreach ($currentToUserDepartments as $userDepartment) {
                // Assuming that 'department' is the name of the relationship in the UserRole model
                $departmentTitles[] = $userDepartment['department']['title'];
            }

            $allDepartmentUSerFound = true;

            foreach ($toDepartments as $department) {
                if (!in_array($department, $departmentTitles)) {
                    $allDepartmentUSerFound = false;
                    break;
                }
            }

            // if (!$allDepartmentUSerFound) {
            //     $this->response["errors"] =  ["curr_user" => "Select Atleast One User from Each Department"];
            //     return $this->sendResponse($this->response, 200);
            // }

            $files = [];
            if (isset($request->attachments)) {
                if (count($request->attachments) > 0) {
                    foreach ($request->attachments as $item) {
                        moveFile('tender/files/', $item['filename']);
                        $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/tender/files/" . $item['filename']];
                    }
                }
            }

            $attachments = $files ?? [];

            /*
             __,  _, __,   ___  _, __, _,_ _,   _, ___ _  _, _, _    _, ___  _,  _, __,
             |_  / \ |_)    |  / \ |_) | | |   / \  |  | / \ |\ |   (_   |  / \ / _ |_
             |   \ / | \    |  |~| |_) | | | , |~|  |  | \ / | \|   , )  |  |~| \ / |
             ~    ~  ~ ~    ~  ~ ~ ~   `~' ~~~ ~ ~  ~  ~  ~  ~  ~    ~   ~  ~ ~  ~  ~~~
            */

            if ($requestSubStage->id == $this->TABULATION) {

                $tabulationDetails = $request->tabulation_details ?? [];
                $tenderStatus = $request->tender_status;

                $tabDetailsEmpty = false;
                foreach ($tabulationDetails as $key => $item) {
                    foreach ($item['levels'] as $val) {
                        if (empty($val['price'])) {
                            $tabDetailsEmpty = true;
                            break;
                        }
                    }
                }

                if ($tabDetailsEmpty) {
                    $this->response["error"] = "Please fill all Tabulation Details";
                    return $this->sendResponse($this->response, 200);
                }

                $validationErrors = $this->validateApplicationTabulation($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                // $tenderClosingTime = Carbon::parse($tender->tender_end_date . ' ' . $tender->tender_end_time)->format('Y-m-d H:i:s');
                // $currentTime = Carbon::now()->format('Y-m-d H:i:s');

                // //IF CURRENT DATETIME IS BEFORE TENDER CLOSING THROW ERROR
                // if ($currentTime <= $tenderClosingTime) {
                //     $this->response["error"] = "Tabulation cannot be fill before the tender is closed.";
                //     return $this->sendResponse($this->response, 200);
                // }

                // $tabulationTotal = array_reduce($tabulationDetails, function ($accumulator, $form) {
                //     return $accumulator + array_reduce($form['products'], function ($acc, $product) {
                //         $totalAmount = (floatval($product['qty']) ?: 0) * (floatval($product['rate']) ?: 0);
                //         $lc = isset($product['lc']) ? floatval($product['lc']) : 0;
                //         $rateDividedByLc = $lc ? (floatval($product['rate']) / $lc) : 0;
                //         $finalAmount = $totalAmount + $rateDividedByLc;
                //         return $acc + $finalAmount;
                //     }, 0);
                // }, 0);


                foreach ($tabulationDetails as $key => $item) {
                    if (isset($item['tabulation_id']) && !empty($item['tabulation_id'])) {
                        $tabulationObject = Tabulation::find($item['tabulation_id']);
                    } else {
                        $tabulationObject = new Tabulation();
                    }
                    $proPartNoId = $item['product_part_id'] ?? '';
                    $partNo = $item['part_no'] ?? '';
                    $lc = $item['lc'] ?? '';
                    $levels = $item['levels'] ?? [];
                    $tabulationObject->tender_id = $tender_id;
                    $tabulationObject->level = $key + 1;
                    $tabulationObject->product_part_id = $proPartNoId;
                    $tabulationObject->part_no = $partNo;
                    $tabulationObject->lc = $lc;
                    $tabulationObject->tabulation_detail = json_encode($levels);
                    // $tabulationObject->tabulation_detail_total = $tabulationTotal;
                    $tabulationObject->save();
                }

                $tenderObj = Tender::find($tender_id);
                if (!$tenderObj) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Tender"]);
                    return $this->sendResponse($this->response, 200);
                }

                $tenderObj->tender_status = $tenderStatus;
                $tenderObj->save();


                //Added in the task table
                $usersForTask = User::with('designation')->whereIn('id', $user_ids)->get();

                $userDesignation = [];
                foreach ($usersForTask as $ut) {
                    $designation = $ut->designation->title;
                    $name = $ut->name . ' ' . '(' . $designation . ')';
                    $userDesignation[] = [
                        "id" => $ut->id,
                        "name" => $name,
                    ];
                }

                $tenderDesc = 'Tender No.:' . $tender->tender_no . ", Name: " . $tender->name;
                $taskObject = new Task();

                $taskObject->title = "Fill Up Tabulation";
                $taskObject->fk_task_type_id = 4;
                $taskObject->fk_type_task_id = 0;
                $taskObject->description = $tenderDesc;
                $taskObject->allDay = 0;
                $taskObject->is_physical_visit = 0;
                $taskObject->start = Carbon::now();
                $taskObject->end = Carbon::now();
                $taskObject->fk_status_id = 2;
                $taskObject->fk_user_id = $this->userId;
                $taskObject->task_user = json_encode($userDesignation);
                $taskObject->created_by = $this->userId;
                $taskObject->save();

                $lastInsertedUserId = $taskObject->id;

                if (count($userDesignation) > 0) {

                    TaskUser::where('fk_task_id', $lastInsertedUserId)->forceDelete();

                    foreach ($userDesignation as $user) {
                        $userId = $user['id'];
                        $userName = $user['name'];

                        $taskUserObject = new TaskUser();

                        if ($userId != "") {
                            $taskUserObject->fk_task_id = $lastInsertedUserId;
                            $taskUserObject->fk_user_id = $userId;
                            $taskUserObject->user_name = $userName;
                            $taskUserObject->save();
                        }
                    }
                }

                $this->response['status'] = 1;

                $taskObject->action = 'created';
                TaskLogCreated::dispatch($taskObject);

                //Add in reminder table
                $reminderObject = new Reminder();
                $forMe = 1;
                $taskType = 4;
                $reminderTime = Carbon::now();
                $comment = '';

                $reminderObject->task_type = $taskType;
                $reminderObject->for_me = $forMe;
                $reminderObject->comment = $comment;
                $reminderObject->reminder_time = $reminderTime;
                $reminderObject->save();

                $lastInsertedUserId = $reminderObject->id;

                ReminderUser::where('fk_reminder_id', $lastInsertedUserId)->forceDelete();

                $reminderUser = new ReminderUser();
                if (count($userDesignation) > 0) {
                    ReminderUser::where('fk_reminder_id', $lastInsertedUserId)->forceDelete();

                    foreach ($userDesignation as $user) {
                        $userId = $user['id'];
                        $userName = $user['name'];

                        $reminderUser = new ReminderUser();

                        if ($userId != "") {
                            $reminderUser->fk_reminder_id = $lastInsertedUserId;
                            $reminderUser->fk_user_id = $userId;
                            $reminderUser->user_name = $userName;
                            $reminderUser->save();
                        }
                    }
                }
            }

            //When Tender Lost
            if ($requestSubStage->id == $this->TENDER_LOST) {
                $validationErrors = $this->validateTenderLost($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $tenderRecieverName = $request->tender_receiver_name;
                $reasonTenderLoss = $request->reason_tender_loss;
                $tenderComment = $request->tender_comment;

                $tenderLostDetail = [
                    "name" => $tenderRecieverName,
                    "reason" => $reasonTenderLoss,
                    "comment" => $tenderComment,
                ];

                $tenderObject = new Tender();
                $tenderId = $request->tender_id;

                if ($tenderId != 0) {
                    $tenderObject = Tender::find($tenderId);

                    if (!$tenderObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Tender"]);
                        return $this->sendResponse($this->response, 401);
                    }
                    $tenderObject->first();
                }

                $tenderObject->tender_lost_detail = json_encode($tenderLostDetail);
                $tenderObject->save();

                $tenderStageLogObject = new TenderStageLog();
                $tenderStageLogObject->tender_lost_detail = $tenderObject->tender_lost_detail;
                $tenderStageLogObject->save();
            }

            // When Po Received
            // if ($requestSubStage->id == $this->PO_RECEIVED_SUB_STAGE_ID) {
            //     $validationErrors = $this->validateAddUpdatePurchaseOrder($request);

            //     if (count($validationErrors)) {
            //         Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
            //         $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
            //         return $this->sendResponse($this->response, 200);
            //     }

            //     $poDate = Carbon::createFromFormat('d/m/Y g:i A', $request->po_date)->format('Y-m-d H:i:s');
            //     $poDetails = $request->po_details ?? [];
            //     $poNo = $request->po_no;

            //     if (empty($poDetails)) {
            //         $this->response["errors"] = ["po_details" => "Please Fill the Purchase Order Details"];
            //         return $this->sendResponse($this->response, 200);
            //     }

            //     $poDetailsEmpty = false;

            //     foreach ($poDetails as $key => $item) {
            //         if (empty($item['product_id']) || empty($item['part_no']) || empty($item['qty']) || empty($item['rate'])) {
            //             $poDetailsEmpty = true;
            //             break;
            //         }
            //     }

            //     if ($poDetailsEmpty) {
            //         $this->response["errors"] = ["po_details" => "Please fill all Purchase Order Details"];
            //         return $this->sendResponse($this->response, 200);
            //     }

            //     $po_details_total = array_reduce($poDetails, function ($carry, $item) {
            //         $carry += $item['qty'] * $item['rate'];
            //         return $carry;
            //     }, 0);

            //     $poObject = new TenderPurchaseOrder();

            //     $poId = $request->po_id ?? 0;

            //     if ($poId != 0) {
            //         $poObject = TenderPurchaseOrder::find($poId);

            //         if (!$poObject) {
            //             $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
            //             return $this->sendResponse($this->response, 200);
            //         }

            //         $poObject->updated_by = $this->userId;
            //     } else {
            //         $poObject->created_by = $this->userId;
            //     }

            //     $poObject->fk_tender_id = $tender->id;
            //     $poObject->po_date = $poDate;
            //     $poObject->po_no = $poNo;
            //     $poObject->po_details = json_encode($poDetails);
            //     $poObject->po_details_total = $po_details_total;
            //     $poObject->prepared_by = $this->userId;
            //     $poObject->po_status = PoStatus::ACTIVE;
            //     $poObject->curr_sub_stage_id = $requestSubStage->id;
            //     $poObject->curr_user_ids = json_encode($user_ids);
            //     $poObject->attachments = json_encode($attachments);
            //     $poObject->comments = $remark;

            //     $poObject->save();
            // }

            $poId = $request->po_id ?? 0;
            if ($requestSubStage->po_required == 1) {
                if (!$poId || $poId == 0) {
                    $this->response['error'] = 'Please file PO first!';
                    return $this->sendResponse($this->response, 200);
                }

                $po = PurchaseOrder::find($poId);
                if (!$po) {
                    $this->response['error'] = 'Please file PO first!';
                    return $this->sendResponse($this->response, 200);
                }

                $po->curr_sub_stage_id = $requestSubStage->id;
                $po->curr_user_ids = json_encode($user_ids);
                if (count($attachments)) $po->attachments = json_encode($attachments);
                $po->is_verified = 1;
                $po->updated_by = $this->userId;
                $po->save();
            }


            //When for Application ready for submission
            if ($requestSubStage->id == $this->APPLICATION_READY_FOR_SUBMISSION) {
                $validationErrors = $this->validateQuotationGenerated($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $tenderQuotationID = $request->quotation_id;
                $formattedDate = Carbon::createFromFormat('d/m/Y', $request->quotation_date ?? now()->format('d/m/Y'));
                $rfqMonth = $formattedDate->format('M');
                $shortRfqYear = $formattedDate->format('y');
                $shortNextYear = $formattedDate->copy()->addYear()->format('y');
                $quotationDate = $formattedDate->format('Y-m-d');
                $standardTerm = $request->standard_term;
                $products = $request->products ?? [];
                $tenderId = $request->tender_id ?? '';

                $tenderQuotation = new TenderQuotation();
                $divisionId = isset($tender->division) ? $tender->division->id : '';
                $division = Division::find($divisionId);
                if (!$division) {
                    $this->response['error'] = "Please Select Division.";
                    return $this->sendResponse($this->response, 200);
                }

                if ($tenderQuotationID != 0) {
                    $tenderQuotation = TenderQuotation::find($tenderQuotationID);

                    if (!$tenderQuotation) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Tender quotation"]);
                        return $this->sendResponse($this->response, 500);
                    }
                    // $tenderQuotation->first();
                    $tenderQuotation->updated_by = $this->userId;
                } else {
                    $tenderQuotation->created_by = $this->userId;
                }

                $usersForTask = User::with('designation')->whereIn('id', $user_ids)->get();

                $userDesignation = [];
                foreach ($usersForTask as $ut) {
                    $designation = $ut->designation->title;
                    $name = $ut->name . ' ' . '(' . $designation . ')';
                    $userDesignation[] = [
                        "id" => $ut->id,
                        "name" => $name,
                    ];
                }

                $tenderQuotation->tender_id = $request->tender_id;
                if (!$tenderQuotationID) {
                    $baseString = strtoupper('AVL/BID/' . $division->name);
                    $tenderQuotation->quotation_no = generateSeries($baseString, 'tender_quotations', 'quotation_no');
                } else {
                    $tenderQuotation->quotation_no = $request->quotation_number ?? '';
                }
                $tenderQuotation->quotation_date = $quotationDate;
                $tenderQuotation->quotation_remark = $request->quotation_remark;
                $tenderQuotation->terms = $standardTerm;
                $tenderQuotation->user_ids = json_encode($user_ids);
                $tenderQuotation->users = json_encode($userDesignation);
                $tenderQuotation->save();

                //GENERATE_QUOTATION_PDF

                $tenderQuotation->action = 'created';
                if ($tenderQuotationID) {
                    $tenderQuotation->action = 'updated';
                }
                TenderQuotationLogCreated::dispatch($tenderQuotation);
                $productIds = array_column($products, 'product_id');
                $tenderProId = array_column($products, 'id');

                if (count($productIds) > 0) {
                    // Filter out empty and non-numeric values from $tenderProId
                    $tenderProId = array_filter($tenderProId, 'is_numeric');
                }

                // get the product IDs that are not present in the payload
                $tenderProductsToDelete = TenderProductRequirement::where('tender_id', $tenderId)
                    ->whereNotIn('id', $tenderProId)
                    ->get();

                // Extract the IDs of the products to be deleted
                $tenderProductIdsToDelete = $tenderProductsToDelete->pluck('id');

                // Delete consignees related to the products to be deleted
                TenderConsigneeRequirment::where('tender_id', $tenderId)
                    ->whereIn('product_id', $tenderProductIdsToDelete)
                    ->delete();

                // delete the product IDs that are not present in the payload
                TenderProductRequirement::where('tender_id', $tenderId)
                    ->whereNotIn('id', $tenderProId)
                    ->delete();

                foreach ($products as $product) {
                    $tenderReqId = $product['id'] ?? null;
                    $tenderProId = $product['product_id'] ?? null;
                    $tenderProPartId = $product['product_part_id'] ?? null;
                    $tenderPartNo = $product['part_no'] ?? null;
                    $tenderDesc = $product['description'] ?? null;
                    $tenderQty = $product['qty'];
                    $tenderRate = $product['rate'];
                    $consignee = $product['consignee'] ?? [];

                    $tenderProductRequirement = TenderProductRequirement::firstOrNew(
                        ['id' => $tenderReqId, 'tender_id' => $tenderId],
                        ['product_id' => $tenderProId]
                    );

                    $tenderProductRequirement->product_id = $tenderProId;
                    $tenderProductRequirement->product_part_id = $tenderProPartId;
                    $tenderProductRequirement->part_no = $tenderPartNo;
                    $tenderProductRequirement->description = $tenderDesc;
                    $tenderProductRequirement->qty = $tenderQty;
                    $tenderProductRequirement->rate = $tenderRate;

                    if ($tenderProductRequirement->trashed()) {
                        $tenderProductRequirement->restore();
                    }

                    $tenderProductRequirement->save();

                    foreach ($consignee as $singleConsignee) {
                        $conId = $singleConsignee['id'] ?? null;
                        $conProId = $tenderProductRequirement->id;
                        $conName = $singleConsignee['name'] ?? null;
                        $conQty = $singleConsignee['qty'] ?? null;
                        $conDeliveryPeriod = $singleConsignee['delivery_period'] ?? null;
                        $conUnit = $singleConsignee['unit'] ?? null;

                        $tenderConsigneeRequirment = TenderConsigneeRequirment::firstOrNew(['id' => $conId, 'tender_id' => $tenderId], ['product_id' => $conProId]);

                        $tenderConsigneeRequirment->name = $conName;
                        $tenderConsigneeRequirment->qty = $conQty;
                        $tenderConsigneeRequirment->delivery_period = $conDeliveryPeriod;
                        $tenderConsigneeRequirment->unit = $conUnit;

                        if ($tenderConsigneeRequirment->trashed()) {
                            $tenderConsigneeRequirment->restore();
                        }

                        $tenderConsigneeRequirment->save();
                    }
                }
            }

            /*
             __,  _, __,   __, _ __, __, _ _, _  _,    _, _,_ __, _, _ _ ___ ___ __, __,    _, ___  _,  _, __, ,
             |_  / \ |_)   |_) | | \ | \ | |\ | / _   (_  | | |_) |\/| |  |   |  |_  | \   (_   |  / \ / _ |_  |
             |   \ / | \   |_) | |_/ |_/ | | \| \ /   , ) | | |_) |  | |  |   |  |   |_/   , )  |  |~| \ / |   |
             ~    ~  ~ ~   ~   ~ ~   ~   ~ ~  ~  ~     ~  `~' ~   ~  ~ ~  ~   ~  ~~~ ~      ~   ~  ~ ~  ~  ~~~ .

            */

            // AGREEMENT PREPARED/UPLOADED
            if ($requestSubStage->id == $this->AGREEMENT_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $validationErrors = $this->validateAgreement($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $agreementDate = Carbon::createFromFormat('d/m/Y g:i A', $request->agreement_date)->format('Y-m-d H:i:s');
                $agreementNo = $request->agreement_no;
                $agreement_remark = $request->agreement_remark ?? '';

                TenderPurchaseOrderAgreement::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id])->update(['is_latest' => 0]);

                $agreementObject = new TenderPurchaseOrderAgreement();
                $agreement_id = $request->agreement_id ?? 0;

                if ($agreement_id != 0) {
                    $agreementObject = TenderPurchaseOrderAgreement::find($agreement_id);

                    if (!$agreementObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Agreement"]);
                        return $this->sendResponse($this->response, 401);
                    }
                    $agreementObject->first();
                }

                $agreementObject->fk_po_id = $po->id;
                $agreementObject->fk_tender_id = $tender->id;
                $agreementObject->agreement_no = $agreementNo;
                $agreementObject->agreement_date = $agreementDate;
                $agreementObject->remark = $agreement_remark;

                $agreementObject->save();
            }

            // PI PREPARED/UPLOADED
            if ($requestSubStage->id == $this->PI_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $validationErrors = $this->validatePi($request);
                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $pi_date = Carbon::createFromFormat('d/m/Y g:i A', $request->pi_date)->format('Y-m-d H:i:s');
                // $pi_no = $request->pi_no;
                $pi_details = $request->pi_details ?? [];
                $invoice_charges_detail = $request->invoice_charges_detail ?? [];
                $pi_remark = $request->pi_remark;


                if (empty($pi_details)) {
                    $this->response["errors"] = ["pi_details" => "Please Fill the Purchase Invoice Details"];
                    return $this->sendResponse($this->response, 200);
                }

                $poDetailsEmpty = false;

                foreach ($pi_details as $key => $item) {
                    if (empty($item['part_no']) || empty($item['qty']) || empty($item['rate'])) {
                        $poDetailsEmpty = true;
                        break;
                    }
                }

                if ($poDetailsEmpty) {
                    $this->response["errors"] = ["pi_details" => "Please fill all Purchase Orde Details"];
                    return $this->sendResponse($this->response, 200);
                }

                TenderPurchaseInvoice::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id])->update(['is_latest' => 0]);

                $piObject = new TenderPurchaseInvoice();

                $lastEntry = TenderPurchaseInvoice::latest('id')->first();
                $lastId = $lastEntry ? $lastEntry->id : 0;
                $pi_no = generateUniqueNumber($lastId, "AVL-PI");

                $pi_total_amount = array_reduce($pi_details, function ($carry, $item) {
                    $carry += $item['total_amount'];
                    return $carry;
                });

                $invoice_charges_amount = 0;
                if ($invoice_charges_detail) {
                    $invoice_charges_amount = array_reduce($invoice_charges_detail, function ($carry, $item) {
                        $carry += $item['total_amount'];
                        return $carry;
                    });
                }

                $piObject->fk_po_id = $po->id;
                $piObject->fk_tender_id = $tender->id;
                $piObject->pi_no = $pi_no;
                $piObject->pi_date = $pi_date;
                $piObject->pi_details = json_encode($pi_details);
                $piObject->invoice_charges_detail = json_encode($invoice_charges_detail);
                $piObject->pi_total_amount = $pi_total_amount;
                $piObject->invoice_charges_amount = $invoice_charges_amount;
                $piObject->final_amount = $pi_total_amount + $invoice_charges_amount;
                $piObject->pi_total_amount_paid =  $piObject->pi_total_amount_paid ?? 0;
                $piObject->pi_total_amount_pending =  max(0, ($pi_total_amount + $invoice_charges_amount) - ($piObject->pi_total_amount_paid ?? 0));
                $piObject->payment_done = $piObject->pi_total_amount_pending > 0  ?  0 : 1;

                $piObject->remark = $pi_remark;
                $piObject->save();
            }

            // PACKAGING PREPARED/UPLOADED
            if ($requestSubStage->id == $this->PACKAGING_LIST_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $validationErrors = $this->validatePackagingList($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $packagingDate = Carbon::createFromFormat('d/m/Y g:i A', $request->packaging_date)->format('Y-m-d H:i:s');
                $packagingNo = $request->packaging_no;
                $packaging_remark = $request->packaging_remark ?? '';

                TenderPurchaseOrderPackagingList::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id])->update(['is_latest' => 0]);

                $packagingObject = new TenderPurchaseOrderPackagingList();
                $packaging_id = $request->packaging_id ?? 0;

                if ($packaging_id != 0) {
                    $packagingObject = TenderPurchaseOrderPackagingList::find($packaging_id);

                    if (!$packagingObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Agreement"]);
                        return $this->sendResponse($this->response, 401);
                    }
                    $packagingObject->first();
                }

                $packagingObject->fk_po_id = $po->id;
                $packagingObject->fk_tender_id = $tender->id;
                $packagingObject->packaging_no = $packagingNo;
                $packagingObject->packaging_date = $packagingDate;
                $packagingObject->remark = $packaging_remark;

                $packagingObject->save();
            }

            // LABELLING PREPARED/UPLOADED
            if ($requestSubStage->id == $this->LABELLING_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $validationErrors = $this->validateLabelling($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $labelDate = Carbon::createFromFormat('d/m/Y g:i A', $request->label_date)->format('Y-m-d H:i:s');
                $labelNo = $request->label_no;
                $label_remark = $request->label_remark ?? '';

                TenderPurchaseOrderLabelling::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id])->update(['is_latest' => 0]);

                $labelObject = new TenderPurchaseOrderLabelling();
                $label_id = $request->label_id ?? 0;

                if ($label_id != 0) {
                    $labelObject = TenderPurchaseOrderLabelling::find($label_id);

                    if (!$labelObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Agreement"]);
                        return $this->sendResponse($this->response, 401);
                    }
                    $labelObject->first();
                }

                $labelObject->fk_po_id = $po->id;
                $labelObject->fk_tender_id = $tender->id;
                $labelObject->label_no = $labelNo;
                $labelObject->label_date = $labelDate;
                $labelObject->remark = $label_remark;

                $labelObject->save();
            }

            // DNE PREPARED/UPLOADED
            if ($requestSubStage->id == $this->DNE_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $validationErrors = $this->validateDneInvoice($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $dne_invoice_date = Carbon::createFromFormat('d/m/Y g:i A', $request->dne_invoice_date)->format('Y-m-d H:i:s');
                $dne_invoice_no = $request->dne_invoice_no;
                $dne_invoice_remark = $request->dne_invoice_remark ?? '';

                TenderPurchaseOrderDneInvoice::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id])->update(['is_latest' => 0]);

                $dneInvoiceObject = new TenderPurchaseOrderDneInvoice();
                $dne_invoice_id = $request->dne_invoice_id ?? 0;

                if ($dne_invoice_id != 0) {
                    $dneInvoiceObject = TenderPurchaseOrderDneInvoice::find($dne_invoice_id);

                    if (!$dneInvoiceObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Agreement"]);
                        return $this->sendResponse($this->response, 401);
                    }
                    $dneInvoiceObject->first();
                }

                $dneInvoiceObject->fk_po_id = $po->id;
                $dneInvoiceObject->fk_tender_id = $tender->id;
                $dneInvoiceObject->dne_invoice_no = $dne_invoice_no;
                $dneInvoiceObject->dne_invoice_date = $dne_invoice_date;
                $dneInvoiceObject->remark = $dne_invoice_remark;

                $dneInvoiceObject->save();
            }

            //When for E_INVOICE
            if ($requestSubStage->id == $this->E_INVOICE_PREPARED_UPLOADED) {
                $validationErrors = $this->validateEInvoice($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $e_invoice_date = Carbon::createFromFormat('d/m/Y g:i A', $request->e_invoice_date)->format('Y-m-d H:i:s');
                $e_invoice_no = $request->e_invoice_no;
                $e_invoice_remark = $request->e_invoice_remark ?? '';
                $invoice_charges_detail = $request->invoice_charges_detail ?? [];

                TenderPurchaseOrderEInvoice::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id])->update(['is_latest' => 0]);

                $eInvoiceObject = new TenderPurchaseOrderEInvoice();
                $e_invoice_id = $request->e_invoice_id ?? 0;

                if ($e_invoice_id != 0) {
                    $eInvoiceObject = TenderPurchaseOrderEInvoice::find($e_invoice_id);

                    if (!$eInvoiceObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "E Invoice"]);
                        return $this->sendResponse($this->response, 401);
                    }
                    $eInvoiceObject->first();
                }

                $eInvoiceObject->fk_po_id = $po->id;
                $eInvoiceObject->fk_tender_id = $tender->id;
                $eInvoiceObject->e_invoice_no = $e_invoice_no;
                $eInvoiceObject->e_invoice_date = $e_invoice_date;
                $eInvoiceObject->invoice_charges_detail = json_encode($invoice_charges_detail);
                $eInvoiceObject->remark = $e_invoice_remark;
                $eInvoiceObject->save();
            }

            // PDR PREPARED/UPLOADED
            if ($requestSubStage->id == $this->PDR_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $validationErrors = $this->validateQualityReport($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $quality_report_date = Carbon::createFromFormat('d/m/Y g:i A', $request->quality_report_date)->format('Y-m-d H:i:s');
                $quality_report_no = $request->quality_report_no;
                $quality_report_remark = $request->quality_report_remark ?? '';

                TenderPurchaseOrderPdrQuality::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id])->update(['is_latest' => 0]);

                $qualityReportObject = new TenderPurchaseOrderPdrQuality();
                $quality_report_id = $request->quality_report_id ?? 0;

                if ($quality_report_id != 0) {
                    $qualityReportObject = TenderPurchaseOrderPdrQuality::find($quality_report_id);

                    if (!$qualityReportObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Agreement"]);
                        return $this->sendResponse($this->response, 401);
                    }
                    $qualityReportObject->first();
                }

                $qualityReportObject->fk_po_id = $po->id;
                $qualityReportObject->fk_tender_id = $tender->id;
                $qualityReportObject->quality_report_no = $quality_report_no;
                $qualityReportObject->quality_report_date = $quality_report_date;
                $qualityReportObject->remark = $quality_report_remark;

                $qualityReportObject->save();
            }

            // LR PREPARED/UPLOADED
            if ($requestSubStage->id == $this->LR_RECEIVED_UPLOADED_SUB_STAGE_ID) {
                $validationErrors = $this->validateLr($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $lr_date = Carbon::createFromFormat('d/m/Y g:i A', $request->lr_date)->format('Y-m-d H:i:s');
                $lr_no = $request->lr_no;
                $lr_remark = $request->lr_remark ?? '';

                TenderPurchaseOrderLr::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id])->update(['is_latest' => 0]);

                $lrObject = new TenderPurchaseOrderLr();
                $lr_id = $request->lr_id ?? 0;

                if ($lr_id != 0) {
                    $lrObject = TenderPurchaseOrderLr::find($lr_id);

                    if (!$lrObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Agreement"]);
                        return $this->sendResponse($this->response, 401);
                    }
                    $lrObject->first();
                }

                $lrObject->fk_po_id = $po->id;
                $lrObject->fk_tender_id = $tender->id;
                $lrObject->lr_no = $lr_no;
                $lrObject->lr_date = $lr_date;
                $lrObject->remark = $lr_remark;

                $lrObject->save();
            }

            if ($requestSubStage->id == $this->R_NOTE_RECEIVED) {
                $validationErrors = $this->validateRNoteReceived($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $rn_date = Carbon::createFromFormat('d/m/Y g:i A', $request->rn_date)->format('Y-m-d H:i:s');
                $rn_no = $request->rn_no;
                $rn_remark = $request->rn_remark ?? '';

                TenderPurchaseOrderRn::where(['fk_tender_id' => $tender->id, 'fk_po_id' => $po->id])->update(['is_latest' => 0]);

                $rnObject = new TenderPurchaseOrderRn();
                $rn_id = $request->rn_id ?? 0;

                if ($rn_id != 0) {
                    $rnObject = TenderPurchaseOrderRn::find($rn_id);

                    if (!$rnObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "R Notes"]);
                        return $this->sendResponse($this->response, 401);
                    }
                    $rnObject->first();
                }

                $rnObject->fk_po_id = $po->id;
                $rnObject->fk_tender_id = $tender->id;
                $rnObject->rn_no = $rn_no;
                $rnObject->rn_date = $rn_date;
                $rnObject->rn_remark = $rn_remark;

                $rnObject->save();
            }

            $tender->sub_stage_id = $requested_sub_stage_id;
            $tender->sub_stage_user_ids = $user_ids;
            $tender->sub_stage_remark = $remark;
            $tender->sub_stage_attachments = json_encode($attachments);
            $tender->save();

            //set all related old log to latest 0
            TenderStageLog::where(['tender_id' => $tender_id, 'sub_stage_id' => $requested_sub_stage_id])->update(['is_latest' => 0]);

            $tenderSubStageLog = new TenderStageLog();
            $tenderSubStageLog->tender_id = $tender_id;
            $tenderSubStageLog->user_ids = $user_ids;
            $tenderSubStageLog->sub_stage_id = $requested_sub_stage_id;
            $tenderSubStageLog->remark = $remark;
            $tenderSubStageLog->attachments = json_encode($attachments);
            $tenderSubStageLog->po_id = $po->id ?? null;
            $tenderSubStageLog->pi_id = null;
            $tenderSubStageLog->agreement_id = isset($agreementObject) ? $agreementObject->id : null;
            $tenderSubStageLog->packaging_id = isset($packagingObject) ? $packagingObject->id : null;
            $tenderSubStageLog->labelling_id = isset($labelObject) ? $labelObject->id : null;
            $tenderSubStageLog->dne_id = isset($dneInvoiceObject) ? $dneInvoiceObject->id : null;
            $tenderSubStageLog->pdr_id = isset($qualityReportObject) ? $qualityReportObject->id : null;
            $tenderSubStageLog->lr_id = isset($lrObject) ? $lrObject->id : null;
            $tenderSubStageLog->save();

            $this->response['status'] = 1;
            $this->response['msg'] = "Stage updated successfully";

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender saveStage failed: " . $e);
            $this->response['error'] = $e;
            return $this->sendResponse($this->response, 500);
        }
    }

    function history(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $tender_id = $request->tender_id;

            $tender = Tender::find($tender_id);
            if (!$tender) {
                $this->response['error'] = 'Tender details not found!';
                return $this->sendResponse($this->response, 200);
            }

            $stages = TenderStageLog::with(['subStage', 'users.roles.department'])
                ->where(['tender_id' => $tender->id])
                ->orderBy('id', 'desc')
                ->get();

            $stages = UserRoleTenderHistoryResource::collection($stages);

            // $stagesList = [];

            // foreach ($stages as $key => $stage) {
            //     $stagesList[$key] = $stage;
            //     $stagesList[$key]['old_stages'] = TenderStageLog::with(['subStage'])
            //         ->where(['tender_id' => $tender_id, 'sub_stage_id' => $stage->sub_stage_id])
            //         ->where('id', '!=', $stage->id)
            //         ->orderBy('id', 'desc')->get();
            // }

            $this->response['status'] = 1;
            $this->response['data']['list'] = $stages;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender Save Stage failed: " . $e);
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function poList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $tenderPo = PurchaseOrder::where('fk_tender_id', $id)->get();

            if (!$tenderPo) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Purchase Order"]);
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Tender Purchase Order"]);
            $this->response['data']['list'] = $tenderPo;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender Purchase Order fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function quotationList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->tender_id;
            $tenderQuotation = TenderQuotationLog::where('tender_id', $id)->get();

            if (!$tenderQuotation) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Quotation List"]);
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Tender Quotation List"]);
            $this->response['data']['list'] = $tenderQuotation;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender Quotation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function getTenderStatus(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Tender Status"]);
            $this->response['data']['list'] = TenderStatus::getListForHTML();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Tender Status fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    public function importUpcomingTender(Request $request)
    {
        try {

            DB::beginTransaction();

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateImportUpcomingTender($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $files = $request->excel ?? [];

            $highestRow = 0;
            foreach ($files as $item) {

                $filePath = storage_path('app/public/uploads/temp/' . $item['filename']);
                $sourcePath = 'public/uploads/temp/' .  $item['filename'];

                if (!Storage::exists($sourcePath)) {

                    $this->response['error'] = __('admin.file_not_found', ['file' => $item['filename']]);
                    return $this->sendResponse($this->response, 500);
                }

                $spreadsheet = IOFactory::load($filePath);
                $sheetNames = $spreadsheet->getSheetNames();
                $dataRecords = [];

                foreach ($sheetNames as $sheetName) {
                    $worksheet = $spreadsheet->getSheetByName($sheetName);
                    $cellIterator = $worksheet->getRowIterator()->current()->getCellIterator();
                    $cellIterator->setIterateOnlyExistingCells(true);

                    $headers = [];
                    foreach ($cellIterator as $cell) {
                        if ($cell->getValue() != '') {
                            $headers[] = $cell->getValue();
                        }
                    }

                    if (array_values($headers) != array_values(config('global.UPCOMING_TENDER_FORMAT'))) {
                        $this->response['error'] = __('admin.excel_format_error', ['file' => $item['filename'], 'sheet' => $sheetName]);
                        return $this->sendResponse($this->response, 200);
                    }

                    // $highestRow = $worksheet->getHighestRow();
                    $highestRow = max($highestRow, $worksheet->getHighestRow());
                    $dataRecords = [];

                    for ($row = 2; $row <= $highestRow; $row++) {
                        $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
                        if (!empty(array_filter($rowData[$row]))) {
                            $dataRecords[] = $rowData[$row];
                        }
                    }
                }

                foreach ($dataRecords as $key => $data) {

                    if (isset($data['A']) && !empty($data['A'])) {
                        $tenderNo = $data['A'];
                    } else {
                        $this->response['error'] = "Tender Can not be empty : " . $sheetName . "at row : " . $key + 2;
                        return $this->sendResponse($this->response, 200);
                    }

                    if (isset($data['B']) && !empty($data['B'])) {
                        $name = convertToCamelCase($data['B']);
                    } else {
                        $this->response['error'] = "Name can not be empty : " . $sheetName . "at row : " . $key + 2;
                        return $this->sendResponse($this->response, 200);
                    }

                    if (isset($data['C']) && !empty($data['C'])) {
                        $organization = convertToCamelCase($data['C']);
                    } else {
                        $this->response['error'] = "Organization Can not be empty : " . $sheetName . "at row : " . $key + 2;
                        return $this->sendResponse($this->response, 200);
                    }

                    if (isset($data['D']) && !empty($data['D'])) {
                        $tenderStartDate = Carbon::createFromFormat('d/m/Y', $data['D'])->format('Y-m-d');
                    } else {
                        $this->response['error'] = "Tender Start Date cannot be empty : " . $sheetName . " at row : " . $key + 2;
                        return $this->sendResponse($this->response, 200);
                    }


                    if (isset($data['E']) && !empty($data['E'])) {
                        $dateTime = Carbon::createFromFormat('d/m/Y', $data['E']);
                        $tenderEndDate = Carbon::createFromFormat('d/m/Y', $data['E'])->format('Y-m-d');
                    } else {
                        $this->response['error'] = "Tender End Date Can not be empty : " . $sheetName . "at row : " . $key + 2;
                        return $this->sendResponse($this->response, 200);
                    }

                    if (isset($data['F']) && !empty($data['F'])) {
                        $tenderEndTime = Carbon::createFromFormat('H:i', trim($data['F']))->format('H:i:s');
                    } else {

                        $this->response['error'] = "Tender End Time Can not be empty : " . $sheetName . "at row : " . $key + 2;
                        return $this->sendResponse($this->response, 200);
                    }


                    $tenderObject = Tender::where('tender_no', $tenderNo)->first();
                    if (!$tenderObject) $tenderObject = new Tender();

                    $tenderObject->tender_no = $tenderNo;
                    $tenderObject->name = $name;
                    $tenderObject->organization = $organization;
                    $tenderObject->tender_start_date = $tenderStartDate;
                    $tenderObject->tender_end_date = $tenderEndDate;
                    $tenderObject->tender_end_time = $tenderEndTime;
                    $tenderObject->save();
                }

                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.created', ['module' => "Upcoming Tender Data"]);
                DB::commit();

                return $this->sendResponse($this->response, 200);
            }
        } catch (\Exception $e) {
            Log::error("Failed Creating Upcoming Tender Data: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getTenderDispatchDocument(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            // $id = $request->id ?? '';

            // $isEnable = false;
            // $saleOrder = AvlockSalesOrder::where('fk_po_id', $id)->first();
            // // $packaging = PackagingSlip::where('fk_po_id', $id)->first();
            // $deliveryNote = DeliveryNote::where('fk_po_id', $id)->first();
            // $eInvoice = AvlockPurchaseInvoice::where('fk_po_id', $id)->first();

            // $salesOrderIsEnabled = true;
            // $packagingIsEnabled = $saleOrder ? true : false;
            // $deliveryNoteIsEnabled = $saleOrder ? true : false;
            // $invoiceIsEnabled = $deliveryNote ? true : false;
            // $eWayBillIsEnabled = $eInvoice ? true : false;



            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Tender Dispatch Document"]);
            $this->response['data']['list'] = TenderDispatchDocument::getListForHTML();
            // $this->response['data']['sales_order_enable'] = $salesOrderIsEnabled;
            // $this->response['data']['packaging_enable'] = $packagingIsEnabled;
            // $this->response['data']['delivery_note_enable'] = $deliveryNoteIsEnabled;
            // $this->response['data']['invoice_enable'] = $invoiceIsEnabled;
            // $this->response['data']['eway_enable'] = $eWayBillIsEnabled;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Dispatch Document fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    ////////////////////// VALIDATION ////////////////////////
    private function validateTenderCreate(Request $request)
    {
        return Validator::make($request->all(), [
            'tender_no' => 'required',
            'name' => 'required',
            'organization' => 'required',
            'description' => '',
            'tender_start_date' => 'required|date_format:d/m/Y',
            'tender_end_date' => 'required|date_format:d/m/Y',
            'tender_end_time' => 'required|date_format:H:i'
        ])->errors();
    }

    private function validateQuotationGenerated(Request $request)
    {
        return Validator::make($request->all(), [
            'quotation_date' => 'required|date_format:d/m/Y',
            'standard_term' => 'required',
            'standard_term.*.terms_category_id' => 'required',
        ], [
            'standard_term.required' => 'Standard Term is Required',
            'standard_term.*.terms_category_id.required' => 'Standard Term is Required',
        ])->errors();
    }

    private function validateBiddingSubmitted(Request $request)
    {
        return Validator::make($request->all(), [
            'quotation_date' => 'required|date_format:d/m/Y',
            'bidding_standard_term' => 'required',
            'standard_term.*.terms_category_id' => 'required',
        ], [
            'bidding_standard_term.required' => 'Standard Term is Required',
            'standard_term.*.terms_category_id.required' => 'Standard Term is Required',
        ])->errors();
    }

    private function validateApplicationAddUpdate(Request $request)
    {
        return Validator::make($request->all(), [
            'tender_no' => 'required',
            'division_id' => 'required',
            // 'name' => 'required',
            // 'organization' => 'required',
            // 'description' => '',
            'tender_start_date' => 'required|date_format:d/m/Y',
            // 'tender_end_time' => 'required|date_format:H:i',
            // 'tender_type' => 'required|integer',
            // 'inspection_required_by' => 'required',
            'products.*.part_no' => 'required',
            'products.*.qty' => 'required|numeric',
            'products.*.consignee.*.name' => 'required',
            'products.*.consignee.*.qty' => 'required|numeric',
            // 'products.*.consignee.*.delivery_period' => 'required|numeric',
        ], [
            'division_id.required' => 'The division is required',
            'products.*.part_no.required' => 'The part number is required',
            'products.*.qty.required' => 'The quantity is required',
            'products.*.qty.numeric' => 'The quantity must be a numeric value',
            'products.*.consignee.*.name.required' => 'The consignee name is required',
            'products.*.consignee.*.qty.required' => 'The consignee quantity is required',
            'products.*.consignee.*.qty.numeric' => 'The consignee quantity must be a numeric value',
            'products.*.consignee.*.delivery_period.required' => 'The consignee delivery period is required',
            // 'products.*.consignee.*.delivery_period.numeric' => 'The consignee delivery period must be a numeric value',
        ])->errors();
    }


    private function validateTenderStageChange(Request $request)
    {
        $validationArray = [
            'sub_stage_id' => 'required',
            'user_ids' => 'required',
            'remark' => '',
        ];

        $requested_sub_stage = TenderSubStage::find($request->sub_stage_id);
        if ($requested_sub_stage) {
            if ($requested_sub_stage->attachment_required == 1) $validationArray['attachments'] = 'required';
        }

        return Validator::make($request->all(), $validationArray, [
            'sub_stage_id.required' => 'Stage is required',
            'user_ids.required' => 'User selection is required'
        ])->errors();
    }

    private function validateApplicationTabulation(Request $request)
    {
        return Validator::make($request->all(), [
            'tender_status' => 'required',
            'attachments' => 'required',
            'tabulation_details.*.levels.*.price' => 'required|numeric',
        ], [
            'tabulation_details.*.levels.*.price.required' => 'The price is required',
        ])->errors();
    }

    private function validateTenderLost(Request $request)
    {
        return Validator::make($request->all(), [
            'tender_receiver_name' => 'required',
            'reason_tender_loss' => 'required',
        ])->errors();
    }

    // private function validateAddUpdatePurchaseOrder(Request $request)
    // {
    //     return Validator::make($request->all(), [
    //         'po_date' => 'required|date_format:d/m/Y g:i A',
    //         'po_no' => 'required',

    //     ])->errors();
    // }

    private function validateImportUpcomingTender(Request $request)
    {
        return Validator::make($request->all(), [
            'excel' => 'required',
        ])->errors();
    }

    private function validateAgreement(Request $request)
    {
        return Validator::make($request->all(), [
            'agreement_date' => 'required|date_format:d/m/Y g:i A',
            'agreement_no' => 'required',

        ])->errors();
    }

    private function validatePi(Request $request)
    {
        return Validator::make($request->all(), [
            'pi_date' => 'required|date_format:d/m/Y g:i A',
            // 'agreement_no' => 'required',

        ])->errors();
    }

    private function validatePackagingList(Request $request)
    {
        return Validator::make($request->all(), [
            'packaging_date' => 'required|date_format:d/m/Y g:i A',
            'packaging_no' => 'required',

        ])->errors();
    }

    private function validateLabelling(Request $request)
    {
        return Validator::make($request->all(), [
            'label_date' => 'required|date_format:d/m/Y g:i A',
            'label_no' => 'required',

        ])->errors();
    }

    private function validateDneInvoice(Request $request)
    {
        return Validator::make($request->all(), [
            'dne_invoice_date' => 'required|date_format:d/m/Y g:i A',
            'dne_invoice_no' => 'required',

        ])->errors();
    }

    private function validateEInvoice(Request $request)
    {
        return Validator::make($request->all(), [
            'e_invoice_date' => 'required|date_format:d/m/Y g:i A',
            'e_invoice_no' => 'required',

        ])->errors();
    }

    private function validateQualityReport(Request $request)
    {
        return Validator::make($request->all(), [
            'quality_report_date' => 'required|date_format:d/m/Y g:i A',
            'quality_report_no' => 'required',

        ])->errors();
    }

    private function validateLr(Request $request)
    {
        return Validator::make($request->all(), [
            'lr_date' => 'required|date_format:d/m/Y g:i A',
            'lr_no' => 'required',

        ])->errors();
    }

    private function validateRNoteReceived(Request $request)
    {
        return Validator::make($request->all(), [
            'rn_date' => 'required|date_format:d/m/Y g:i A',
            'rn_no' => 'required',

        ])->errors();
    }
    ////////////////////// VALIDATION ////////////////////////


    ////////////////////// HELPERS ///////////////////////////
    function getDepartmentAndUserList($department_ids = [])
    {
        $data['user_departments'] = [];
        $data['user_list'] = [];

        if (!count($department_ids)) return $data;

        $userDepartmentList = Department::whereIn('id', $department_ids)->get()->toArray();
        $userDepartmentList = implode(', ', array_column($userDepartmentList, 'title'));

        $users = UserRole::with('user.roles.department', 'user.roles.departmentType', 'department')
            ->whereHas('user.roles', function ($q) {
                $q->whereNotNull('id');
            })
            ->whereIn('fk_department_id', $department_ids)
            ->groupBy('fk_user_id')
            ->get()->sortBy(function ($item) {
                return $item->user->name;
            }); // For RSM department id is 5

        $userList =  AllUserResource::collection($users);

        $data['departments'] = $userDepartmentList;
        $data['users'] = $userList;

        return $data;
    }

    function generateRandomNumber()
    {
        $randomNumber = mt_rand(1000, 9999);
        $result = 'AVL-' . $randomNumber;
        return $result;
    }

    public function viewQuotation(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $tenderId = $request->tender_id ?? "";

            $tenderQuotation = TenderQuotation::where('tender_id', $tenderId)->first();
            if (!$tenderQuotation) {
                $this->response['error'] = "Please generate quotation!";
                return $this->sendResponse($this->response, 200);
            }

            $quotationId = $tenderQuotation->id;

            $quotationObject = TenderQuotation::with('tender', 'preparedBy')->find($quotationId);

            if (!$quotationObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Quotation"]);
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['data'] = new TenderQuotationResource($quotationObject);

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Tender saving failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function downloadPdf(Request $request)
    {
        try {

            $quotationId = $request->quotation_id ?? '';
            $viewPdf = $request->view_pdf;

            $quotationObject = TenderBidding::with(['tender'])->find($quotationId);

            if (!$quotationObject) {
                $this->response['error'] = 'Quotation not generated';
                return $this->sendResponse($this->response, 200);
            }

            $result = new TenderQuotationResource($quotationObject);

            $details = json_decode(json_encode($result));
            $view = 'pdf.tender.view';

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "Tender Quotation"]);
                $this->response['data']['html'] = view($view, ['details' => $details])->render();

                return $this->sendResponse($this->response, 200);
            }

            $qtnNo = str_replace(['-', '/'], '_', $quotationObject->quotation_no);
            $qtnNo = str_replace('QTN_', 'QTN', $qtnNo);
            $path = 'pdf/tender/' . str_replace(['-', '/'], '', $qtnNo) . '.pdf';


            MyPdf::view($view, ['details' => $details])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Tender Quotation Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Tender Quotation pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    public function downloadTabulationPdf(Request $request)
    {
        try {

            $tabId = $request->tab_id ?? '';
            $viewPdf = $request->view_pdf;

            $detailsResource = Tabulation::with(['tender:id,tender_no,contact_no,email,name,tender_start_date,tender_end_date,address'])->find($tabId);


            if (!$detailsResource) {
                $this->response['error'] = 'Tabulation not generated';
                return $this->sendResponse($this->response, 200);
            }

            $details = new TabulationResource($detailsResource);
            $details = json_decode(json_encode($details));

            $view = 'pdf.tender.tabulation';

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "Tender Tabulation"]);
                $this->response['data']['html'] = view($view, ['details' => $details])->render();

                return $this->sendResponse($this->response, 200);
            }

            $tenderNo = $detailsResource->tender->tender_no ?? '';
            $path = 'pdf/tender/tabulation' . $tenderNo . '.pdf';


            MyPdf::view($view, ['details' => $details])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Tender Tabulation Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Tender Tabulation pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    ////////////////////// HELPERS ///////////////////////////

    public function generateQuotation(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $tenderId = $request->tender_id ?? "";

            $tenderQuotation = TenderQuotation::where('tender_id', $tenderId)->first();
            if (!$tenderQuotation) {
                $this->response['error'] = "Please generate quotation!";
                return $this->sendResponse($this->response, 200);
            }

            $quotationId = $tenderQuotation->id;

            $quotationObject = TenderQuotation::with('tender', 'preparedBy')->find($quotationId);

            if (!$quotationObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Quotation"]);
                return $this->sendResponse($this->response, 200);
            }

            $quotation = new TenderQuotationResource($quotationObject);

            $data = [
                'details' => json_decode(json_encode($quotation)),
            ];

            $dompdf = PDF::loadView('pdf.tender_quotation_pdf', $data);

            $dompdf->setPaper('A4', 'portrait');

            $encryptName = Crypt::encryptString($quotationId);
            $trimLength = substr($encryptName, 0, 6);
            $timestamp = now()->timestamp;
            $fileName = $trimLength . $timestamp . '.pdf';
            // Render the PDF
            $dompdf->render();

            $pdfContent = $dompdf->output(); // Get the generated PDF content

            file_put_contents(storage_path('app/public/uploads/pdf/tender_quotation/' . $fileName), $pdfContent); // Save the PDF to the specified file path

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Tender Quotation Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/pdf/tender_quotation/' . $fileName;
            $this->response['filePath'] = $this->fileAccessPath . '/pdf/tender_quotation/' . $fileName;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Tender Quotation pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }
}
