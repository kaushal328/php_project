<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Resources\DeliveryNoteResource;
use App\Models\DeliveryNote;
use App\Models\EwayBill;
use App\Models\Labeling;
use App\Models\Lr;
use App\Models\PackagingSlip;
use App\Models\PackagingSlipDetail;
use App\Models\PurchaseOrder;
use App\Http\Resources\PackagingSlipResource;
use App\Models\AvlockPurchaseInvoice;
use App\Models\AvlockSalesOrder;
use App\Models\Division;
use App\Models\PoDespatchDetail;
use App\Models\ProductPart;
use App\Models\Rfq;
use App\Models\Tender;
use App\Models\WeightUnit;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpParser\Node\Stmt\Label;
use Spatie\LaravelPdf\Facades\Pdf as MyPdf;
use Spatie\LaravelPdf\Enums\Format;

class DispatchController extends AppBaseController
{

    public function addPackaging(Request $request)
    {
        DB::beginTransaction();
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdatePackaging($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $packagingObject = new PackagingSlip();
            $id = $request->id;
            $poId = $request->po_id;
            $quotationId = $request->fk_quotation_id ?? 0;
            $rfqId = $request->fk_rfq_id ?? 0;
            $leadId = $request->fk_lead_id ?? 0;
            $psNo = $request->ps_no;
            $formattedDate = Carbon::createFromFormat('d/m/Y', $request->ps_date);
            $packMonth = $formattedDate->format('M');
            $psDate = $formattedDate->format('Y-m-d H:i:s');
            $monthNumber = $formattedDate->format('n');
            $year = $formattedDate->format('Y');
            $financialYearStart = $monthNumber >= 4 ? $year : $year - 1;
            $shortFinYearStart = substr($financialYearStart, -2);
            $shortFinYearEnd = substr($financialYearStart + 1, -2);

            $salesOrderDate = $request->sales_order_date ?? '';
            // $dispatchDate = Carbon::createFromFormat('d/m/Y', $request->dispatch_date)->format('Y-m-d');
            $attachments = $request->attachments ?? [];
            $packagingDetalils = $request->packaging_detail ?? [];
            $poType = $request->po_type ?? [];

            $files = [];
            if (!empty($attachments)) {
                foreach ($attachments as $item) {
                    moveFile('project/files/', $item['filename']);
                    $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                }
            }

            $attachments = json_encode($files);

            $salesOrderObj = AvlockSalesOrder::find($salesOrderDate);
            $soDetails = $salesOrderObj->so_details ? json_decode($salesOrderObj->so_details) : [];
            $soDetailTotal = 0;
            if ($soDetails) {
                $soDetailTotal = array_reduce($soDetails, function ($carry, $item) {
                    return $carry + (isset($item->qty) ? floatval($item->qty) : 0);
                }, 0);
            }

            $qtyTotal = 0;
            if ($packagingDetalils) {
                $qtyTotal = array_reduce($packagingDetalils, function ($carry, $item) {
                    foreach ($item['lists'] as $listItem) {
                        $carry += isset($listItem['qty']) ? floatval($listItem['qty']) : 0;
                    }
                    return $carry;
                }, 0);
            }

            if ($qtyTotal > $soDetailTotal) {
                $this->response["error"] = "The quantity cannot exceed the actual product quantity.";
                return $this->sendResponse($this->response, 200);
            }

            $poObject = PurchaseOrder::find($poId);

            if ($poType === 1) {
                $rfqObject = Rfq::find($rfqId);
                $division = Division::find($rfqObject->division_id);
            } else {
                $tenderObject = Tender::find($poObject->fk_tender_id);
                $division = Division::find($tenderObject->division_id);
            }

            if (!$division) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Division"]);
                return $this->sendResponse($this->response, 200);
            }

            if ($id) {
                $packagingObject = PackagingSlip::find($id);

                if (!$packagingObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Packaging Slip"]);
                    return $this->sendResponse($this->response, 200);
                }

                $this->response['msg'] = __('admin.updated', ['module' => "Packaging Slip"]);
            } else {
                $baseString = strtoupper('PACK/'  . $division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . $packMonth . '/');
                $packagingObject->packaging_slip_no = generateSeries($baseString, 'packaging_slips', 'packaging_slip_no');
                $this->response['msg'] = __('admin.created', ['module' => "Packaging Slip"]);
            }

            $packagingObject->fk_po_id = $poId;
            $packagingObject->fk_quotation_id = $quotationId;
            $packagingObject->fk_rfq_id = $rfqId;
            $packagingObject->fk_lead_id = $leadId;
            $packagingObject->po_type = $poType;
            $packagingObject->packaging_slip_date = $psDate;
            $packagingObject->sales_order_date = $salesOrderDate;
            // $packagingObject->dispatch_date = $dispatchDate;
            $packagingObject->attachments = $attachments;
            $packagingObject->save();
            $lastId = $packagingObject->id;

            $poObject = PurchaseOrder::find($poId);

            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            $poObject->minimum_document_generated = 1;
            $poObject->save();

            if (isset($packagingDetalils) && !empty($packagingDetalils)) {
                foreach ($packagingDetalils as $value) {
                    $packagingId = $value['id'] ?? '';
                    if (isset($packagingId) && !empty($packagingId)) {
                        $packagingSlipDetailObj = PackagingSlipDetail::find($packagingId);
                    } else {
                        $packagingSlipDetailObj = new PackagingSlipDetail();
                    }

                    $packagingSlipDetailObj->packaging_slip_id = $lastId;
                    $packagingSlipDetailObj->product_part_ids = implode(',', $value['product_part_ids']);
                    $packagingSlipDetailObj->batch_no = $value['batch_no'];
                    $packagingSlipDetailObj->dispatch_date = $value['dispatch_date'];
                    $packagingSlipDetailObj->save();
                    $lastPsId = $packagingSlipDetailObj->id;

                    $existingLabels = Labeling::where('packaging_slip_detail_id', $lastPsId)->pluck('id')->toArray();

                    $currentLabelIds = [];

                    foreach ($value['lists'] as $key => $item) {
                        $labelingId = $item['id'] ?? '';

                        if (isset($labelingId) && !empty($labelingId)) {
                            $labelingObj = Labeling::find($labelingId);
                        } else {
                            $labelingObj = new Labeling();
                        }

                        $currentLabelIds[] = $labelingId;

                        $labelingObj->packaging_slip_id = $lastId;
                        $labelingObj->packaging_slip_detail_id = $lastPsId;
                        $labelingObj->qty = $item['qty'];
                        $labelingObj->no_of_carton = $item['no_of_carton'];
                        $labelingObj->total_qty = $item['total_qty'];
                        $labelingObj->weight_carton = $item['weight_carton'];
                        $labelingObj->total_weight = $item['total_weight'];
                        $labelingObj->weight_unit = $item['weight_unit'];
                        $labelingObj->save();
                    }

                    $labelsToDelete = array_diff($existingLabels, $currentLabelIds);

                    if (!empty($labelsToDelete)) {
                        Labeling::whereIn('id', $labelsToDelete)->delete();
                    }
                }
            }


            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.created', ['module' => "Packaging Slip"]);
            DB::commit();
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating Packaging Slip: " . $e);
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            Log::error("Record Not Found: " . $e);
            $this->response['error'] = __('admin.record_not_found', ['module' => "Packaging Slip"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    function packagingIndex(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poId = $request->po_id ?? '';
            $PsObjectQuery = PackagingSlip::with(['purchaseOrder', 'salesOrderDate.dispatch'])->where('fk_po_id', $poId)->get();
            if (!$PsObjectQuery) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Packaging Slip"]);
                return $this->sendResponse($this->response, 200);
            }


            $this->response['status'] = 1;
            $this->response['data']['list'] = PackagingSlipResource::collection($PsObjectQuery);

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Labeling Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    function getPackaging(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.austhentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poId = $request->po_id ?? "";
            $psId = $request->packaging_id ?? "";

            $PsObjectQuery = PackagingSlip::with(['purchaseOrder', 'salesOrderDate'])->where('id', $psId)->first();
            if (!$PsObjectQuery) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Packaging Slip"]);
                return $this->sendResponse($this->response, 200);
            }


            $this->response['status'] = 1;
            $this->response['data'] = new PackagingSlipResource($PsObjectQuery);

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Labeling Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addLabeling(Request $request)
    {
        DB::beginTransaction();
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateLabeling($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $labelingObject = new Labeling();
            $id = $request->id;
            $poId = $request->po_id;
            $quotationId = $request->fk_quotation_id ?? '';
            $rfqId = $request->fk_rfq_id ?? '';
            $leadId = $request->fk_lead_id ?? '';
            $poNo = $request->po_number ?? '';
            $poDate = Carbon::createFromFormat('d/m/Y', $request->po_date)->format('Y-m-d');
            $poNo = $request->po_number ?? '';
            $batchNumber = $request->batch_number ?? '';
            $labelingNo = $request->labeling_no ?? '';
            $attachments = $request->attachments ?? [];
            $labelingdate = Carbon::createFromFormat('d/m/Y', $request->labeling_date)->format('Y-m-d');
            $labels = $request->labels ?? [];

            $validationError = false;
            foreach ($labels as $value) {
                if (empty($value['part_no']) || empty($value['description']) || empty($value['no_of_cartons']) || empty($value['qty']) || empty($value['total_qty']) || empty($value['total_weight']) || empty($value['weight'])) {
                    $validationError = true;
                    break;
                }
            }

            if ($validationError) {
                $this->response['error'] = __('Please fill all details');
                return $this->sendResponse($this->response, 200);
            }


            $files = [];
            if (!empty($attachments)) {
                foreach ($attachments as $item) {
                    moveFile('project/files/', $item['filename']);
                    $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                }
            }

            $attachments = json_encode($files);

            if ($id) {
                $labelingObject = Labeling::find($id);

                if (!$labelingObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Labeling"]);
                    return $this->sendResponse($this->response, 200);
                }

                $labelingObject->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "Labeling"]);
            } else {
                $labelingObject->created_by = $this->userId;
                $this->response['msg'] = __('admin.created', ['module' => "Labeling"]);
            }

            $labelingObject->fk_po_id = $poId;
            $labelingObject->fk_quotation_id = $quotationId;
            $labelingObject->fk_rfq_id = $rfqId;
            $labelingObject->fk_lead_id = $leadId;
            $labelingObject->po_number = $poNo;
            $labelingObject->po_date = $poDate;
            $labelingObject->batch_number = $batchNumber;
            $labelingObject->labeling_no = $labelingNo;
            $labelingObject->labeling_date = $labelingdate;
            $labelingObject->attachments = $attachments;
            $labelingObject->labels = json_encode($labels);
            $labelingObject->save();

            $poObject = PurchaseOrder::find($poId);

            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            $poObject->minimum_document_generated = 1;
            $poObject->save();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.created', ['module' => "Labeling"]);
            DB::commit();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating Labeling: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Labeling"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    function getLabel(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poId = $request->po_id ?? "";
            $labelId = $request->label_id ?? "";

            $labelObjectQuery = Labeling::with('purchaseOrder')->where('fk_po_id', $poId);

            if ($labelId) {
                $labelObjectQuery->where('id', $labelId);
                $labelObject = $labelObjectQuery->first();
            } else {
                $labelObject = $labelObjectQuery->get();
            }


            if (!$labelObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Labeling"]);
                return $this->sendResponse($this->response, 200);
            }


            $this->response['status'] = 1;
            $this->response['data'] = $labelObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Labeling Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function downloadPackagingPdf(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $viewPdf = $request->view_pdf;
            $mainView = $request->main_view;

            $transformPsdObj = [];
            if (!empty($mainView)) {
                $psdObj = PackagingSlipDetail::with(['packagingSlip.lead', 'packagingSlip.salesOrderDate', 'packagingSlip.rfq'])->where('packaging_slip_id', $id)->get();

                foreach ($psdObj as $value) {
                    $productPartIds = !empty($value->product_part_ids) ? explode(',', $value->product_part_ids) : [];
                    $productParts = ProductPart::whereIn('id', $productPartIds)->pluck('part_no')->filter() ?? '';
                    $productPartNames = $productParts->isNotEmpty() ? $productParts->implode(', ') : '';
                    $labels = [];
                    $labelings = Labeling::where('packaging_slip_detail_id', $value->id)->get() ?? [];
                    foreach ($labelings as $labelItem) {
                        $labels[] = [
                            'qty' => $labelItem->qty ?? 0,
                            'no_of_carton' => $labelItem->no_of_carton ?? 0,
                            'total_qty' => $labelItem->total_qty ?? 0,
                            'weight_carton' => $labelItem->weight_carton ?? 0,
                            'total_weight' => $labelItem->total_weight ?? 0,
                        ];
                    }
                    $batchNo = $value->batch_no ?? '';
                    $transformPsdObj[] = [
                        'part_no' => $productPartNames,
                        'batch_no' => $batchNo,
                        'labels' => $labels,
                    ];
                }

                $packagingSlipObj = PackagingSlip::with(['lead', 'rfq', 'PurchaseOrder', 'salesOrderDate'])->where('id', $id)->first();
            }

            // $labelForMain = Labeling::with(['packagingSlipDetail.productPart'])->where('packaging_slip_id', $id)->get();
            if (empty($mainView)) {
                $labelObj = Labeling::with(['packagingSlipDetail'])->find($id);
                if ($labelObj) {
                    $productPartIds = !empty($labelObj->packagingSlipDetail->product_part_ids) ? explode(',', $labelObj->packagingSlipDetail->product_part_ids) : [];
                    $productParts = ProductPart::whereIn('id', $productPartIds)->get(['part_no', 'description']);
                    $productPartNames = $productParts->isNotEmpty() ? $productParts->map(function ($part) {
                        return $part->part_no;
                    })->implode(', ') : '';

                    $descriptionList = $productParts->isNotEmpty()
                        ? $productParts->map(function ($part) {
                            return $part->description;
                        })->implode(', ')
                        : '';
                }
            }

            $totalCartons = 0;
            $totalQty = 0;
            $totalWeight = 0;

            $totalCartons = array_sum(array_map(function ($item) {
                return array_sum(array_column($item['labels'], 'no_of_carton'));
            }, $transformPsdObj));

            $totalQty = array_sum(array_map(function ($item) {
                return array_sum(array_column($item['labels'], 'total_qty'));
            }, $transformPsdObj));

            $totalWeight = array_sum(array_map(function ($item) {
                return array_sum(array_column($item['labels'], 'total_weight'));
            }, $transformPsdObj));

            $data = [
                'poDispatchDetail' => $transformPsdObj,
                'details' => $packagingSlipObj ?? [],
                'labelProductPartNames' => $productPartNames ?? [],
                'labelDescriptionLists' => $descriptionList ?? '',
                'labels' => $labelObj ?? [],
                'totalCartons' => $totalCartons,
                'totalQty' => $totalQty,
                'totalWeight' => $totalWeight
            ];

            $view = ($mainView == 'mainView') ? 'pdf.dispatch.main_view' : 'pdf.dispatch.view';

            // if ($viewPdf == 1) {
            //     $this->response['status'] = 1;
            //     $this->response['msg'] = __('admin.fetched', ['module' => "Labeling Pdf"]);
            //     $this->response['data']['html'] = view('pdf.dispatch.view', ['details' => $data['details']])->render();

            //     return $this->sendResponse($this->response, 200);
            // }

            // $path = 'pdf/dispatch/' . str_replace(['-', '/'], '', $psdObj->packagingSlip->packaging_slip_no ?? 'default-pack') . '.pdf';
            $path = 'pdf/dispatch/' . str_replace(['-', '/'], '', 'packagingSlip' . Carbon::now()->format('Ymd_His')) . '.pdf';


            MyPdf::view($view, $data)
                ->landscape()
                ->paperSize(10, 15, 'in')
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Packaging/Label Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Labeling pdf Generation Failed: " . $e);
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addDeliveryNote(Request $request)
    {

        DB::beginTransaction();
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateDelivery($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $deliveryNoteObject = new DeliveryNote();
            $id = $request->dn_id;
            $poId = $request->po_id;
            $quotationId = $request->fk_quotation_id ?? 0;
            $rfqId = $request->fk_rfq_id ?? 0;
            $leadId = $request->fk_lead_id ?? 0;
            $salesOrderId = $request->sales_order_id;
            $yourDnNo = $request->your_dn_no;
            $attachments = $request->attachments ?? [];
            $formattedDate = Carbon::createFromFormat('d/m/Y', $request->delivery_note_date);
            $dnMonth = $formattedDate->format('M');
            $deliveryNoteDate = $formattedDate->format('Y-m-d');
            $monthNumber = $formattedDate->format('n');
            $year = $formattedDate->format('Y');
            $financialYearStart = $monthNumber >= 4 ? $year : $year - 1;
            $shortFinYearStart = substr($financialYearStart, -2);
            $shortFinYearEnd = substr($financialYearStart + 1, -2);


            $dispatchThrough = $request->dispatch_through ?? '';
            $destinationAddress = $request->destination_address ?? '';
            $packagingDate = $request->packaging_date ?? '';
            $billingLeadAddressesId = $request->billing_lead_addresses_id ?? '';
            $billingContactPeopleId = $request->billing_lead_contact_people_id ?? '';
            $billingAddress1 = $request->billing_address1 ?? NULL;
            $billingAddress2 = $request->billing_address2;
            $billingCity = $request->billing_city;
            $billingPincode = $request->billing_pincode;
            $billingstate = $request->billing_state;
            $billingContactNo = $request->billing_contact_no;
            $billingCustomerName = $request->billing_customer_name;
            $billingEmail = $request->billing_email;
            $shippingLeadAddressesId = $request->shipping_lead_addresses_id ?? '';
            $shippingContactPeopleId = $request->shipping_lead_contact_people_id ?? '';
            $shippingAddress1 = $request->shipping_address1;
            $shippingAddress2 = $request->shipping_address2;
            $shippingCity = $request->shipping_city;
            $shippingPincode = $request->shipping_pincode;
            $shippingState = $request->shipping_state;
            $shippingContactNo = $request->shipping_contact_no;
            $shippingCustomerName = $request->shipping_customer_name;
            $shippingEmail = $request->shipping_email;
            $dnDetails = $request->dn_details ?? [];
            $serviceDetails = $request->service_details ?? [];
            $cgst = $request->cgst ?? 0;
            $sgst = $request->sgst ?? 0;
            $igst = $request->igst ?? 0;
            $cgstValue = $sgstValue = $igstValue = 0;
            $remark = $request->remark ?? '';
            $poType = $request->po_type ?? '';

            $dnDetailsEmpty = false;
            foreach ($dnDetails as $key => $item) {
                if (empty($item['product_id']) || empty($item['part_no']) || empty($item['qty']) || empty($item['rate'])) {
                    $dnDetailsEmpty = true;
                    break;
                }
            }

            $serviceTotal = 0;
            if ($serviceDetails) {
                $serviceTotal = array_reduce($serviceDetails, function ($carry, $item) {
                    return $carry + (isset($item['total_amount']) ? intval($item['total_amount']) : 0);
                }, 0);
            }

            $dnDetailTotal = 0;
            if ($dnDetails) {
                $dnDetailTotal = array_reduce($dnDetails, function ($carry, $item) {
                    return $carry + (isset($item['total_amount']) ? intval($item['total_amount']) : 0);
                }, 0);
            }

            $finalAmount = $dnDetailTotal + $serviceTotal;
            if ($cgst > 0) $cgstValue = ($finalAmount * floatval($cgst)) / 100;
            if ($sgst > 0) $sgstValue = ($finalAmount * floatval($sgst)) / 100;
            if ($igst > 0) $igstValue = ($finalAmount * floatval($igst)) / 100;

            $finalAmount = $finalAmount + $cgstValue + $sgstValue + $igstValue;

            if ($dnDetailsEmpty) {
                $this->response["errors"] = ["dn_details" => "Please fill all Delivery  Details"];
                return $this->sendResponse($this->response, 200);
            }

            $serviceDetails = json_encode($serviceDetails);
            $dnDetails = json_encode($dnDetails);


            $files = [];
            if (!empty($attachments)) {
                foreach ($attachments as $item) {
                    moveFile('project/files/', $item['filename']);
                    $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                }
            }

            $attachments = json_encode($files);

            $poObject = PurchaseOrder::find($poId);

            if ($poType === 1) {
                $rfqObject = Rfq::find($rfqId);
                $division = Division::find($rfqObject->division_id);
            } else {
                $tenderObject = Tender::find($poObject->fk_tender_id);
                $division = Division::find($tenderObject->division_id);
            }

            if (!$division) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Division"]);
                return $this->sendResponse($this->response, 200);
            }

            if ($id) {
                $deliveryNoteObject = DeliveryNote::find($id);

                if (!$deliveryNoteObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Delivery Note"]);
                    return $this->sendResponse($this->response, 200);
                }

                $deliveryNoteObject->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "Delivery Note"]);
            } else {
                $baseString = strtoupper('DC/'  . $division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . $dnMonth . '/');
                $deliveryNoteObject->delivery_note_no = generateSeries($baseString, 'delivery_notes', 'delivery_note_no');
                $deliveryNoteObject->created_by = $this->userId;
                $this->response['msg'] = __('admin.created', ['module' => "Delivery Note"]);
            }

            $deliveryNoteObject->fk_po_id = $poId;
            $deliveryNoteObject->fk_quotation_id = $quotationId;
            $deliveryNoteObject->fk_rfq_id = $rfqId;
            $deliveryNoteObject->fk_lead_id = $leadId;
            $deliveryNoteObject->po_type = $poType;
            $deliveryNoteObject->sales_order_id = $salesOrderId;
            $deliveryNoteObject->packaging_date = $packagingDate;
            $deliveryNoteObject->your_dn_no = $yourDnNo;
            $deliveryNoteObject->delivery_note_date = $deliveryNoteDate;
            $deliveryNoteObject->dispatch_through = $dispatchThrough;
            $deliveryNoteObject->destination_address = $destinationAddress;
            $deliveryNoteObject->attachments = $attachments;
            $deliveryNoteObject->billing_lead_addresses_id = $billingLeadAddressesId;
            $deliveryNoteObject->billing_lead_contact_people_id = $billingContactPeopleId;
            $deliveryNoteObject->billing_address1 = $billingAddress1;
            $deliveryNoteObject->billing_address2 = $billingAddress2;
            $deliveryNoteObject->billing_city = $billingCity;
            $deliveryNoteObject->billing_pincode = $billingPincode;
            $deliveryNoteObject->billing_state = $billingstate;
            $deliveryNoteObject->billing_contact_no = $billingContactNo;
            $deliveryNoteObject->billing_customer_name = $billingCustomerName;
            $deliveryNoteObject->billing_email = $billingEmail;
            $deliveryNoteObject->shipping_lead_addresses_id = $shippingLeadAddressesId;
            $deliveryNoteObject->shipping_lead_contact_people_id = $shippingContactPeopleId;
            $deliveryNoteObject->shipping_address1 = $shippingAddress1;
            $deliveryNoteObject->shipping_address2 = $shippingAddress2;
            $deliveryNoteObject->shipping_city = $shippingCity;
            $deliveryNoteObject->shipping_pincode = $shippingPincode;
            $deliveryNoteObject->shipping_state = $shippingState;
            $deliveryNoteObject->shipping_contact_no = $shippingContactNo;
            $deliveryNoteObject->shipping_customer_name = $shippingCustomerName;
            $deliveryNoteObject->shipping_email = $shippingEmail;
            $deliveryNoteObject->dn_details = $dnDetails;
            $deliveryNoteObject->service_details = $serviceDetails;
            $deliveryNoteObject->dn_total_amount = $dnDetailTotal;
            $deliveryNoteObject->service_total_amount = $serviceTotal;
            $deliveryNoteObject->final_amount = $finalAmount ?? 0;
            $deliveryNoteObject->cgst = $cgst;
            $deliveryNoteObject->cgst_value = $cgstValue;
            $deliveryNoteObject->sgst = $sgst;
            $deliveryNoteObject->sgst_value = $sgstValue;
            $deliveryNoteObject->igst = $igst;
            $deliveryNoteObject->igst_value = $igstValue;
            $deliveryNoteObject->remark = $remark;
            $deliveryNoteObject->save();

            $poObject = PurchaseOrder::find($poId);

            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            $poObject->minimum_document_generated = 1;
            $poObject->save();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.created', ['module' => "Delivery Note"]);
            DB::commit();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating Delivery Note: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Delivery Note"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    function getDeliveryNote(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poId = $request->po_id ?? "";
            $dnId = $request->dn_id ?? "";

            $dnObjectQuery = DeliveryNote::with('purchaseOrder', 'rfq.currencyData', 'packagingSlipDate', 'salesOrder.dispatch')->where('fk_po_id', $poId);

            if ($dnId) {
                $dnObjectQuery->where('id', $dnId);
                $deliveryNoteObject = $dnObjectQuery->first();
            } else {
                $deliveryNoteObject = $dnObjectQuery->get();
            }


            if (!$deliveryNoteObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Delivery Note"]);
                return $this->sendResponse($this->response, 200);
            }


            $this->response['status'] = 1;
            $this->response['data'] = $deliveryNoteObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Delivery Note Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function downloadDeliveryPdf(Request $request)
    {
        try {

            $deliveryNoteId = $request->dn_id;
            $viewPdf = $request->view_pdf;
            $deliveryObject = DeliveryNote::with(['PurchaseOrder', 'salesOrder', 'rfq', 'rfq.currencyData', 'lead'])->find($deliveryNoteId);
            $details = new DeliveryNoteResource($deliveryObject);
            $details = json_decode(json_encode($details));
            $view = 'pdf.dispatch.delivery_note_view';

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "Delivery Note"]);
                $this->response['data']['html'] = view($view, ['details' => $details])->render();
                return $this->sendResponse($this->response, 200);
            }

            $path = 'pdf/dispatch/' . str_replace(['-', '/'], '', $deliveryObject->delivery_note_no) . '.pdf';

            MyPdf::view($view, ['details' => $details])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Delivery Note Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Delivery Note pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addLr(Request $request)
    {
        DB::beginTransaction();
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateLr($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $lrObject = new Lr();
            $id = $request->id;
            $poId = $request->po_id;
            $quotationId = $request->fk_quotation_id;
            $rfqId = $request->fk_rfq_id;
            $leadId = $request->fk_lead_id;
            $lrNo = $request->lr_no;
            $lorryNo = $request->lorry_no;
            $driverName = $request->driver_name;
            $attachments = $request->attachments ?? [];
            $lrDate = Carbon::createFromFormat('d/m/Y', $request->lr_date)->format('Y-m-d');

            $files = [];
            if (!empty($attachments)) {
                foreach ($attachments as $item) {
                    moveFile('project/files/', $item['filename']);
                    $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                }
            }

            $attachments = json_encode($files);

            if ($id) {
                $lrObject = Lr::find($id);

                if (!$lrObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "LR"]);
                    return $this->sendResponse($this->response, 200);
                }

                $lrObject->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "LR"]);
            } else {
                $lrObject->created_by = $this->userId;
                $this->response['msg'] = __('admin.created', ['module' => "LR"]);
            }

            $lrObject->fk_po_id = $poId;
            $lrObject->fk_quotation_id = $quotationId;
            $lrObject->fk_rfq_id = $rfqId;
            $lrObject->fk_lead_id = $leadId;
            $lrObject->lr_no = $lrNo;
            $lrObject->lorry_no = $lorryNo;
            $lrObject->driver_name = $driverName;
            $lrObject->lr_date = $lrDate;
            $lrObject->attachments = $attachments;
            $lrObject->save();

            $poObject = PurchaseOrder::find($poId);

            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            $poObject->minimum_document_generated = 1;
            $poObject->save();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.created', ['module' => "LR"]);
            DB::commit();
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating LR: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "LR"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    function getLr(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poId = $request->po_id ?? "";
            $lrId = $request->lr_id ?? "";

            $lrObjectQuery = Lr::with('purchaseOrder')->where('fk_po_id', $poId);

            if ($lrId) {
                $lrObjectQuery->where('id', $lrId);
                $lrObject = $lrObjectQuery->first();
            } else {
                $lrObject = $lrObjectQuery->get();
            }


            if (!$lrObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "LR"]);
                return $this->sendResponse($this->response, 200);
            }


            $this->response['status'] = 1;
            $this->response['data'] = $lrObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("LR Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addEwayBill(Request $request)
    {
        DB::beginTransaction();
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateEwayBill($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $eWayBillObj = new EwayBill();
            $id = $request->id;
            $poId = $request->po_id;
            $quotationId = $request->fk_quotation_id ?? 0;
            $rfqId = $request->fk_rfq_id ?? 0;
            $leadId = $request->fk_lead_id ?? 0;
            $poType = $request->po_type ?? '';
            $eWayBillNo = $request->e_way_bill_no;
            $eWayBillDate = Carbon::createFromFormat('d/m/Y', $request->e_way_bill_date)->format('Y-m-d');
            // $validFrom = Carbon::createFromFormat('d/m/Y', $request->valid_from)->format('Y-m-d H:i:s');
            // $validUntil = Carbon::createFromFormat('d/m/Y', $request->valid_until)->format('Y-m-d H:i:s');
            // $ackDate = Carbon::createFromFormat('d/m/Y', $request->ack_date)->format('Y-m-d H:i:s');
            $irn = $request->irn;
            $ackNo = $request->ack_no;
            $soNo = $request->sales_order_id ?? '';
            $transporter = $request->transporter;
            $attachments = $request->attachments ?? [];
            $invoiceDate = $request->invoice_date ?? '';
            $deliveryDate = $request->delivery_note_date ?? '';
            $remark = $request->remark ?? '';


            $files = [];
            if (!empty($attachments)) {
                foreach ($attachments as $item) {
                    moveFile('project/files/', $item['filename']);
                    $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                }
            }

            $attachments = json_encode($files);

            if ($id) {
                $eWayBillObj = EwayBill::find($id);

                if (!$eWayBillObj) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "E-Way Bill"]);
                    return $this->sendResponse($this->response, 200);
                }

                $eWayBillObj->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "E-Way Bill"]);
            } else {
                $eWayBillObj->created_by = $this->userId;
                $this->response['msg'] = __('admin.created', ['module' => "E-Way Bill"]);
            }

            $eWayBillObj->fk_po_id = $poId;
            $eWayBillObj->fk_quotation_id = $quotationId;
            $eWayBillObj->fk_rfq_id = $rfqId;
            $eWayBillObj->fk_lead_id = $leadId;
            $eWayBillObj->po_type = $poType;
            $eWayBillObj->invoice_date = $invoiceDate;
            $eWayBillObj->delivery_note_date = $deliveryDate;
            $eWayBillObj->e_way_bill_no = $eWayBillNo;
            $eWayBillObj->e_way_bill_date = $eWayBillDate;
            $eWayBillObj->remark = $remark;
            // $eWayBillObj->valid_from = $validFrom;
            // $eWayBillObj->valid_until = $validUntil;
            // $eWayBillObj->ack_date = $ackDate;
            $eWayBillObj->irn = $irn;
            $eWayBillObj->ack_no = $ackNo;
            $eWayBillObj->sales_order_id = $soNo;
            $eWayBillObj->transporter = $transporter;
            $eWayBillObj->attachments = $attachments;
            $eWayBillObj->save();

            $poObject = PurchaseOrder::find($poId);

            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            $poObject->minimum_document_generated = 1;
            $poObject->save();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.created', ['module' => "E-Way Bill"]);
            DB::commit();
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating E-Way Bill: " . $e);
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            Log::error("Record Not Found: " . $e);
            $this->response['error'] = __('admin.record_not_found', ['module' => "E-Way Bill"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    function getEwayBill(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poId = $request->po_id ?? "";
            $eWayBillId = $request->e_way_bill_id ?? "";

            $eWayBillQuery = EwayBill::with(['purchaseOrder', 'salesOrder.dispatch'])->where('fk_po_id', $poId);

            if ($eWayBillId) {
                $eWayBillQuery->where('id', $eWayBillId);
                $eWayBillObj = $eWayBillQuery->first();
            } else {
                $eWayBillObj = $eWayBillQuery->get();
            }


            if (!$eWayBillObj) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "LR"]);
                return $this->sendResponse($this->response, 200);
            }


            $this->response['status'] = 1;
            $this->response['data'] = $eWayBillObj;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("LR Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function deleteLabeling(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $rfqObject = Labeling::find($id);

            if (!$rfqObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Labeling"]);
                return $this->sendResponse($this->response, 500);
            }

            $rfqObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Labeling"]);
            $this->response['data'] = $rfqObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Labeling deleting failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function deleteDeliveryNote(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $rfqObject = DeliveryNote::find($id);

            if (!$rfqObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Delivery Note"]);
                return $this->sendResponse($this->response, 500);
            }

            $rfqObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Delivery Note"]);
            $this->response['data'] = $rfqObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Delivery Note deleting failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function deleteLr(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $rfqObject = Lr::find($id);

            if (!$rfqObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "LR"]);
                return $this->sendResponse($this->response, 500);
            }

            $rfqObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "LR"]);
            $this->response['data'] = $rfqObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("LR deleting failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function downloadEwayBillPdf(Request $request)
    {
        try {

            $eWayId = $request->id ?? '';
            $viewPdf = $request->view_pdf;

            $eWayBillObj = EwayBill::with(['lead', 'rfq', 'rfq.banner', 'rfq.footer', 'rfq.designation', 'invoiceDate'])->find($eWayId);
            $data = json_decode(json_encode($eWayBillObj));
            $view = 'pdf.dispatch.e_way_bill_view';

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.created', ['module' => "E-Way Bill Pdf"]);
                $this->response['data']['html'] = view($view, ['details' => $data])->render();

                return $this->sendResponse($this->response, 200);
            }

            $path = 'pdf/dispatch/' . str_replace(['-', '/'], '', $eWayBillObj->e_way_bill_no) . '.pdf';


            MyPdf::view($view, ['details' => $data])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.created', ['module' => "E-Way Bill"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("E-Way Bill Pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function deleteEwayBill(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $rfqObject = EwayBill::find($id);

            if (!$rfqObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "E-Way Bill"]);
                return $this->sendResponse($this->response, 500);
            }

            $rfqObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "E-Way Bill"]);
            $this->response['data'] = $rfqObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("E-Way Bill deleting failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function getWeightUnit(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $weightUnitObj = WeightUnit::get();

            if (!$weightUnitObj) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Weight Unit"]);
                return $this->sendResponse($this->response, 500);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Weight Unit"]);
            $this->response['data']['list'] = $weightUnitObj;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Weight Unit deleting failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    function getPoDispatchDetail(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $dispatchId = $request->po_dispatch_id ?? '';
            $poDispatchObj = PoDespatchDetail::find($dispatchId);
            if (!$poDispatchObj) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "PO Dispatch Detail"]);
                return $this->sendResponse($this->response, 500);
            }
            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "PO Dispatch Detail"]);
            $this->response['data'] = $poDispatchObj;
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("PO Dispatch Detail fetch failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    public function importDispatch(Request $request)
    {
        try {
            DB::beginTransaction();
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateImportDispatch($request);
            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $file = $request->excel ?? null;
            $filePath = storage_path('app/public/uploads/temp/' . $file['filename']);
            $sourcePath = 'public/uploads/temp/' .  $file['filename'];

            if (!Storage::exists($sourcePath)) {
                $this->response['error'] = __('admin.file_not_found', ['file' => $file['filename']]);
                return $this->sendResponse($this->response, 500);
            }

            $spreadsheet = IOFactory::load($filePath);
            $sheetNames = $spreadsheet->getSheetNames();
            $dataRecords = [];

            $worksheet = $spreadsheet->getSheetByName($sheetNames[0]);
            $cellIterator = $worksheet->getRowIterator(7)->current()->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(true);

            $headers = [];
            foreach ($cellIterator as $cell) {
                if ($cell->getValue() != '') {
                    $headers[] = $cell->getValue();
                }
            }

            if (array_values($headers) != array_values(config('global.DISPATCH_HEADER_FORMAT'))) {
                $this->response['error'] = __('admin.excel_format_error', ['file' => $file['filename'], 'sheet' => $sheetNames[0]]);
                return $this->sendResponse($this->response, 200);
            }


            $highestRow = $worksheet->getHighestRow();
            $dataRecords = [];

            for ($row = 2; $row <= $highestRow; $row++) {
                $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
                if (!empty(array_filter($rowData[$row]))) {
                    $dataRecords[] = $rowData[$row];
                }
            }


            unset($headers[0]);

            $fieldsData = [
                'fields_count' => 10,
                'table_fields' => [
                    ['label' => 'Delivery Note Number', 'value' => 'your_dn_no'],
                    ['label' => 'Delivery Note Date', 'value' => 'delivery_note_date'],
                    ['label' => 'Delivery Note Remark', 'value' => 'remark'],
                    ['label' => 'Invoice Date', 'value' => 'pi_date'],
                    ['label' => 'Invoice Number', 'value' => 'your_pi_no'],
                    ['label' => 'Invoice Amount', 'value' => 'pi_amount'],
                    ['label' => 'Invoice Remark', 'value' => 'remark'],
                    ['label' => 'E Way Bill Date', 'value' => 'e_way_bill_date'],
                    ['label' => 'E Way Bill No', 'value' => 'e_way_bill_no'],
                    ['label' => 'E Way Bill Remark', 'value' => 'remark'],
                ],
                'sheet_fields' => array_values($headers)
            ];

            // foreach ($dataRecords as $key => $data) {
            //     if (isset($data['A']) && !empty($data['A'])) {
            //         $salesOrderNo = $data['A'];
            //         $existingSo = AvlockSalesOrder::where('so_no', $salesOrderNo)->first();
            //         $salesOrderId = $existingSo->id ?? '';
            //         $poId = $existingSo->fk_po_id ?? '';
            //         $quotationId = $existingSo->fk_quotation_id ?? '';
            //         $rfqId = $existingSo->fk_rfq_id ?? '';
            //         $leadId = $existingSo->fk_lead_id ?? '';
            //     } else {
            //         $this->response['error'] = "Sales Order No cannot be empty: " . $sheetName . " at row: " . ($key + 2);
            //         return $this->sendResponse($this->response, 200);
            //     }

            //     if (isset($data['B']) && !empty($data['B'])) {
            //         $deliveryNoteNo = $data['B'];
            //     } else {
            //         $deliveryNoteNo = '';
            //     }

            //     if (isset($data['C']) && !empty($data['C'])) {
            //         $deliveryNoteDate = Carbon::createFromFormat('d/m/Y', $data['C'])->format('Y-m-d H:i:s');
            //     } else {
            //         $this->response['error'] = "Delivery Note Date Can not be empty : " . $sheetName . "at row : " . $key + 2;
            //         return $this->sendResponse($this->response, 200);
            //     }

            //     if (isset($data['D']) && !empty($data['D'])) {
            //         $deliveryNotRemark = convertToCamelCase($data['D']);
            //     } else {
            //         $deliveryNotRemark = '';
            //     }

            //     if (isset($data['E']) && !empty($data['E'])) {
            //         $invoiceDate = Carbon::createFromFormat('d/m/Y', $data['E'])->format('Y-m-d H:i:s');
            //     } else {
            //         $this->response['error'] = "Invoice Date Can not be empty : " . $sheetName . "at row : " . $key + 2;
            //         return $this->sendResponse($this->response, 200);
            //     }

            //     if (isset($data['F']) && !empty($data['F'])) {
            //         $invoiceNo = $data['F'];
            //     } else {
            //         $invoiceNo = '';
            //     }

            //     if (isset($data['G']) && !empty($data['G'])) {
            //         $invoiceAmount = $data['G'];
            //     } else {
            //         $invoiceAmount = '';
            //     }

            //     if (isset($data['H']) && !empty($data['H'])) {
            //         $invoiceRemark = convertToCamelCase($data['H']);
            //     } else {
            //         $invoiceRemark = '';
            //     }

            //     if (isset($data['I']) && !empty($data['I'])) {
            //         $eWayBillDate = Carbon::createFromFormat('d/m/Y', $data['I'])->format('Y-m-d H:i:s');
            //     } else {
            //         $this->response['error'] = "E-way Bill Date Can not be empty : " . $sheetName . "at row : " . $key + 2;
            //         return $this->sendResponse($this->response, 200);
            //     }

            //     if (isset($data['J']) && !empty($data['J'])) {
            //         $ewayBillNo = $data['J'];
            //     } else {
            //         $ewayBillNo = '';
            //     }

            //     if (isset($data['K']) && !empty($data['K'])) {
            //         $ewayBillRemark = convertToCamelCase($data['K']);
            //     } else {
            //         $ewayBillRemark = '';
            //     }

            //     $deliveryNoteObj = new DeliveryNote();
            //     $deliveryNoteObj->fk_po_id = $poId;
            //     $deliveryNoteObj->fk_quotation_id = $quotationId;
            //     $deliveryNoteObj->fk_rfq_id = $rfqId;
            //     $deliveryNoteObj->fk_lead_id = $leadId;
            //     $deliveryNoteObj->sales_order_id = $salesOrderId;
            //     $deliveryNoteObj->your_dn_no = $deliveryNoteNo;
            //     $deliveryNoteObj->delivery_note_date = $deliveryNoteDate;
            //     $deliveryNoteObj->remark = $deliveryNotRemark;
            //     $deliveryNoteObj->save();

            //     $purchaseInvoiceObj = new AvlockPurchaseInvoice();
            //     $purchaseInvoiceObj->fk_po_id = $poId;
            //     $purchaseInvoiceObj->fk_quotation_id = $quotationId;
            //     $purchaseInvoiceObj->fk_rfq_id = $rfqId;
            //     $purchaseInvoiceObj->fk_lead_id = $leadId;
            //     $purchaseInvoiceObj->sales_order_id = $salesOrderId;
            //     $purchaseInvoiceObj->your_pi_no = $invoiceNo;
            //     $purchaseInvoiceObj->pi_amount = $invoiceAmount;
            //     $purchaseInvoiceObj->pi_date = $invoiceDate;
            //     $purchaseInvoiceObj->remark = $invoiceRemark;
            //     $purchaseInvoiceObj->save();

            //     $ewayBillObj = new EwayBill();
            //     $ewayBillObj->fk_po_id = $poId;
            //     $ewayBillObj->fk_quotation_id = $quotationId;
            //     $ewayBillObj->fk_rfq_id = $rfqId;
            //     $ewayBillObj->fk_lead_id = $leadId;
            //     $ewayBillObj->sales_order_id = $salesOrderId;
            //     $ewayBillObj->e_way_bill_no = $ewayBillNo;
            //     $ewayBillObj->e_way_bill_date = $eWayBillDate;
            //     $ewayBillObj->remark = $ewayBillRemark;
            //     $ewayBillObj->save();
            // }

            $newRecord = $dataRecords ?? [];
            foreach ($newRecord as &$val) {
                array_shift($val);
            }


            $this->response['data']['fields'] = $fieldsData;
            $this->response['data']['records'] = $newRecord;

            $this->response['status'] = 1;
            // $this->response['msg'] = 'Dispatch Data Uploaded Successfully.';
            DB::commit();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Dispatch Data: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function exelSaveDispatch(Request $request)
    {
        try {
            DB::beginTransaction();
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateImportDispatch($request);
            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $file = $request->excel ?? null;
            $filePath = storage_path('app/public/uploads/temp/' . $file['filename']);
            $sourcePath = 'public/uploads/temp/' .  $file['filename'];

            if (!Storage::exists($sourcePath)) {
                $this->response['error'] = __('admin.file_not_found', ['file' => $file['filename']]);
                return $this->sendResponse($this->response, 500);
            }

            $spreadsheet = IOFactory::load($filePath);
            $sheetNames = $spreadsheet->getSheetNames();
            $dataRecords = [];

            $worksheet = $spreadsheet->getSheetByName($sheetNames[0]);
            $cellIterator = $worksheet->getRowIterator(7)->current()->getCellIterator();
            $cellIterator->setIterateOnlyExistingCells(true);

            $headers = [];
            foreach ($cellIterator as $cell) {
                if ($cell->getValue() != '') {
                    $headers[] = $cell->getValue();
                }
            }

            if (array_values($headers) != array_values(config('global.DISPATCH_HEADER_FORMAT'))) {
                $this->response['error'] = __('admin.excel_format_error', ['file' => $file['filename'], 'sheet' => $sheetNames[0]]);
                return $this->sendResponse($this->response, 200);
            }


            $highestRow = $worksheet->getHighestRow();
            $dataRecords = [];

            for ($row = 8; $row <= $highestRow; $row++) {
                $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
                if (!empty(array_filter($rowData[$row]))) {
                    $dataRecords[] = $rowData[$row];
                }
            }

            foreach ($dataRecords as $key => $data) {
                if (isset($data['A']) && !empty($data['A'])) {
                    $salesOrderNo = $data['A'];
                    $existingSo = AvlockSalesOrder::where('so_no', $salesOrderNo)->first();
                    $salesOrderId = $existingSo->id ?? '';
                    $poId = $existingSo->fk_po_id ?? '';
                    $quotationId = $existingSo->fk_quotation_id ?? '';
                    $rfqId = $existingSo->fk_rfq_id ?? '';
                    $leadId = $existingSo->fk_lead_id ?? '';
                } else {
                    $this->response['error'] = "Sales Order No cannot be empty: " . $sheetNames . " at row: " . ($key + 2);
                    return $this->sendResponse($this->response, 200);
                }

                if (isset($data['B']) && !empty($data['B'])) {
                    $deliveryNoteNo = $data['B'];
                } else {
                    $deliveryNoteNo = '';
                }

                if (isset($data['C']) && !empty($data['C'])) {
                    $deliveryNoteDate = Carbon::createFromFormat('d/m/Y', $data['C'])->format('Y-m-d H:i:s');
                } else {
                    $this->response['error'] = "Delivery Note Date Can not be empty : " . $sheetNames . "at row : " . $key + 2;
                    return $this->sendResponse($this->response, 200);
                }

                if (isset($data['D']) && !empty($data['D'])) {
                    $deliveryNotRemark = convertToCamelCase($data['D']);
                } else {
                    $deliveryNotRemark = '';
                }

                if (isset($data['E']) && !empty($data['E'])) {
                    $invoiceDate = Carbon::createFromFormat('d/m/Y', $data['E'])->format('Y-m-d H:i:s');
                } else {
                    $this->response['error'] = "Invoice Date Can not be empty : " . $sheetNames . "at row : " . $key + 2;
                    return $this->sendResponse($this->response, 200);
                }

                if (isset($data['F']) && !empty($data['F'])) {
                    $invoiceNo = $data['F'];
                } else {
                    $invoiceNo = '';
                }

                if (isset($data['G']) && !empty($data['G'])) {
                    $invoiceAmount = $data['G'];
                } else {
                    $invoiceAmount = '';
                }

                if (isset($data['H']) && !empty($data['H'])) {
                    $invoiceRemark = convertToCamelCase($data['H']);
                } else {
                    $invoiceRemark = '';
                }

                if (isset($data['I']) && !empty($data['I'])) {
                    $eWayBillDate = Carbon::createFromFormat('d/m/Y', $data['I'])->format('Y-m-d H:i:s');
                } else {
                    $this->response['error'] = "E-way Bill Date Can not be empty : " . $sheetNames . "at row : " . $key + 2;
                    return $this->sendResponse($this->response, 200);
                }

                if (isset($data['J']) && !empty($data['J'])) {
                    $ewayBillNo = $data['J'];
                } else {
                    $ewayBillNo = '';
                }

                if (isset($data['K']) && !empty($data['K'])) {
                    $ewayBillRemark = convertToCamelCase($data['K']);
                } else {
                    $ewayBillRemark = '';
                }

                $deliveryNoteObj = new DeliveryNote();
                $deliveryNoteObj->fk_po_id = $poId;
                $deliveryNoteObj->fk_quotation_id = $quotationId;
                $deliveryNoteObj->fk_rfq_id = $rfqId;
                $deliveryNoteObj->fk_lead_id = $leadId;
                $deliveryNoteObj->sales_order_id = $salesOrderId;
                $deliveryNoteObj->your_dn_no = $deliveryNoteNo;
                $deliveryNoteObj->delivery_note_date = $deliveryNoteDate;
                $deliveryNoteObj->remark = $deliveryNotRemark;
                $deliveryNoteObj->save();

                $purchaseInvoiceObj = new AvlockPurchaseInvoice();
                $purchaseInvoiceObj->fk_po_id = $poId;
                $purchaseInvoiceObj->fk_quotation_id = $quotationId;
                $purchaseInvoiceObj->fk_rfq_id = $rfqId;
                $purchaseInvoiceObj->fk_lead_id = $leadId;
                $purchaseInvoiceObj->sales_order_id = $salesOrderId;
                $purchaseInvoiceObj->your_pi_no = $invoiceNo;
                $purchaseInvoiceObj->pi_amount = $invoiceAmount;
                $purchaseInvoiceObj->pi_date = $invoiceDate;
                $purchaseInvoiceObj->remark = $invoiceRemark;
                $purchaseInvoiceObj->save();

                $ewayBillObj = new EwayBill();
                $ewayBillObj->fk_po_id = $poId;
                $ewayBillObj->fk_quotation_id = $quotationId;
                $ewayBillObj->fk_rfq_id = $rfqId;
                $ewayBillObj->fk_lead_id = $leadId;
                $ewayBillObj->sales_order_id = $salesOrderId;
                $ewayBillObj->e_way_bill_no = $ewayBillNo;
                $ewayBillObj->e_way_bill_date = $eWayBillDate;
                $ewayBillObj->remark = $ewayBillRemark;
                $ewayBillObj->save();
            }


            $this->response['status'] = 1;
            $this->response['msg'] = 'Dispatch Data Saved Successfully.';
            DB::commit();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Dispatch Data: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function createDocument(Request $request)
    {
        try {
            $fileString = $request->file_string ?? [];
            $docDetails = $fileString['DocDtls'] ?? [];
            $valDetails = $fileString['ValDtls'] ?? [];
            $type = $docDetails['Typ'] ?? null;

            if (!in_array($type, ['Delivery Note', 'INV', 'Payment'])) {
                return;
            }

            $docNo   = $docDetails['No'] ?? null;
            $salesOrderNo = $docDetails['SalesOrdNo'] ?? null;
            $docDate = $docDetails['Dt'] ?? null;

            $formattedDate      = Carbon::createFromFormat('d/m/Y', $docDate);
            $documentDate       = $formattedDate->format('Y-m-d');
            $documentMonth      = $formattedDate->format('M');
            $monthNumber        = $formattedDate->format('n');
            $year               = $formattedDate->format('Y');
            $financialYearStart = $monthNumber >= 4 ? $year : $year - 1;
            $shortFinYearStart  = substr($financialYearStart, -2);
            $shortFinYearEnd    = substr($financialYearStart + 1, -2);
            $remark = $fileString['Remark']['remark'] ?? '';

            $salesOrderObj = AvlockSalesOrder::where('your_so_no', $salesOrderNo)->first();

            $soId        = $salesOrderObj->id ?? null;
            $poId        = $salesOrderObj->fk_po_id ?? null;
            $quotationId = $salesOrderObj->fk_quotation_id ?? null;
            $rfqId       = $salesOrderObj->fk_rfq_id ?? null;
            $leadId      = $salesOrderObj->fk_lead_id ?? null;
            $rfqObject = $rfqId ? Rfq::find($rfqId) : null;
            $division  = $rfqObject ? Division::find($rfqObject->division_id) : null;

            if ($type === 'Delivery Note') {

                $existingDn = DeliveryNote::where('your_dn_no', 'like', '%' . $docNo . '%')->first();

                if ($existingDn) {
                    $existingDn->delivery_note_date = $documentDate;
                    $existingDn->remark             = $remark;
                    $existingDn->save();
                } else {
                    $baseString = strtoupper("DC/{$division->name}/{$shortFinYearStart}-{$shortFinYearEnd}/{$documentMonth}/");

                    $deliveryNoteObj = new DeliveryNote();
                    $deliveryNoteObj->fk_po_id           = $poId;
                    $deliveryNoteObj->fk_quotation_id    = $quotationId;
                    $deliveryNoteObj->fk_rfq_id          = $rfqId;
                    $deliveryNoteObj->fk_lead_id         = $leadId;
                    $deliveryNoteObj->sales_order_id     = $soId;
                    $deliveryNoteObj->delivery_note_no   = generateSeries($baseString, 'delivery_notes', 'delivery_note_no');
                    $deliveryNoteObj->your_dn_no         = $docNo;
                    $deliveryNoteObj->delivery_note_date = $documentDate;
                    $deliveryNoteObj->remark             = $remark;
                    $deliveryNoteObj->save();
                }
                return $this->sendResponse(['message' => 'Delivery Note processed successfully'], 200);
            }

            if ($type === 'INV') {
                $invoiceAmount = $valDetails['TotInvVal'] ?? null;
                $existingInvoice = AvlockPurchaseInvoice::where('your_pi_no', $docNo)->first();

                if ($existingInvoice) {
                    $existingInvoice->pi_date = $documentDate;
                    $existingInvoice->remark = $remark;
                    $existingInvoice->save();
                } else {
                    $baseString = strtoupper("IN/{$division->name}/{$shortFinYearStart}-{$shortFinYearEnd}/{$documentMonth}/");

                    $purchaseInvoiceObj = new AvlockPurchaseInvoice();
                    $purchaseInvoiceObj->fk_po_id          = $poId;
                    $purchaseInvoiceObj->fk_quotation_id   = $quotationId;
                    $purchaseInvoiceObj->fk_rfq_id         = $rfqId;
                    $purchaseInvoiceObj->fk_lead_id        = $leadId;
                    $purchaseInvoiceObj->sales_order_id    = $soId;
                    $purchaseInvoiceObj->pi_no             = generateSeries($baseString, 'avlock_purchase_invoices', 'pi_no');
                    $purchaseInvoiceObj->your_pi_no        = $docNo;
                    $purchaseInvoiceObj->remark            = $remark;
                    $purchaseInvoiceObj->pi_date           = $documentDate;
                    $purchaseInvoiceObj->pi_amount         = $invoiceAmount;
                    $purchaseInvoiceObj->save();
                }
                return $this->sendResponse(['message' => 'Invoice processed successfully'], 200);
            }

            if ($type === 'Payment') {
                $invoiceAmount = $valDetails['TotInvVal'] ?? null;

                $invoiceObj = AvlockPurchaseInvoice::where('your_pi_no', $docNo)->first();

                $purchaseInvoiceObj = new PurchaseInvoicePayment();
                $purchaseInvoiceObj->fk_pi_id          = $invoiceObj->id;
                $purchaseInvoiceObj->fk_lead_id   = $invoiceObj->fk_lead_id;
                $purchaseInvoiceObj->payment_amount         = $rfqId;
                $purchaseInvoiceObj->payment_date        = $leadId;
                $purchaseInvoiceObj->remark             = $soId;
                $purchaseInvoiceObj->remark            = $remark;
                $purchaseInvoiceObj->pi_date           = $documentDate;
                $purchaseInvoiceObj->pi_amount         = $invoiceAmount;
                $purchaseInvoiceObj->save();

                return $this->sendResponse(['message' => 'Payment processed successfully'], 200);
            }
        } catch (\Exception $e) {
            Log::error("Failed Creating Document ({$type}): " . $e->getMessage());
            return $this->sendResponse(['error' => __('auth.something_went_wrong')], 500);
        }
    }


    private function validateAddUpdatePackaging(Request $request)
    {
        return Validator::make($request->all(), [
            'ps_date' => 'required|date_format:d/m/Y',
            'packaging_detail.*.product_part_ids' => 'required',
            'packaging_detail.*.batch_no' => 'required',
            // 'packaging_detail.*.dispatch_date' => 'required',
            'packaging_detail.*.lists.*.qty' => 'required|numeric',
            'packaging_detail.*.lists.*.no_of_carton' => 'required|numeric',
            'packaging_detail.*.lists.*.total_qty' => 'required|numeric',
            'packaging_detail.*.lists.*.weight_carton' => 'required|numeric',
            'packaging_detail.*.lists.*.total_weight' => 'required|numeric',
        ], [
            'packaging_detail.*.product_part_ids.required' => 'The part no is required',
            'packaging_detail.*.batch_no.required' => 'The batch no is required',
            // 'packaging_detail.*.dispatch_date.required' => 'The dispatch date is required',
            'packaging_detail.*.lists.*.qty.required' => 'The qty is required',
            'packaging_detail.*.lists.*.no_of_carton.required' => 'The no of carton is required',
            'packaging_detail.*.lists.*.total_qty.required' => 'The total qty is required',
            'packaging_detail.*.lists.*.weight_carton.required' => 'The weight carton is required',
            'packaging_detail.*.lists.*.total_weight.required' => 'The total weight is required',

        ])->errors();
    }

    private function validateImportDispatch(Request $request)
    {
        return Validator::make(
            $request->all(),
            [
                'excel' => 'required',
            ]
        )->errors();
    }

    private function validateDeliveryNote(Request $request)
    {
        return Validator::make($request->all(), [
            'sales_order_no' => 'required',
            'tally_delivery_no' => 'required',
        ])->errors();
    }

    private function validateInvoice(Request $request)
    {
        return Validator::make($request->all(), [
            'sales_order_no' => 'required',
            'tally_invoice_no' => 'required',
            'invoice_amount' => 'required',
        ])->errors();
    }

    private function validateAddUpdateLabeling(Request $request)
    {
        return Validator::make($request->all(), [
            'labeling_date' => 'required|date_format:d/m/Y',
            'labeling_no' => 'required',
        ])->errors();
    }

    private function validateAddUpdateDelivery(Request $request)
    {
        return Validator::make($request->all(), [
            'delivery_note_date' => 'required|date_format:d/m/Y',
            // 'delivery_note_no' => 'required',
        ])->errors();
    }

    private function validateAddUpdateLr(Request $request)
    {
        return Validator::make($request->all(), [
            'lr_date' => 'required|date_format:d/m/Y',
            'lr_no' => 'required',
            'attachments' => 'required',

        ])->errors();
    }

    private function validateAddUpdateEwayBill(Request $request)
    {
        return Validator::make($request->all(), [
            'e_way_bill_date' => 'required|date_format:d/m/Y',
            'e_way_bill_no' => 'required',
            'attachments' => 'required',

        ])->errors();
    }
}
