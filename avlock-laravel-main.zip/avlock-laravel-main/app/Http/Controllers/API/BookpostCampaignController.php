<?php

namespace App\Http\Controllers\API;

use Dompdf\Dompdf;
use DateTime;
use Exception;

use Carbon\Carbon;
use App\Models\BookpostData;
use Illuminate\Http\Request;
use App\Models\BookpostCampaign;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use App\Http\Resources\BookpostCampaignResource;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class BookpostCampaignController extends AppBaseController
{
  public function index(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';
      $campaign_id = $request->campaign_id ?? '';
      $start_date = $request->start_date ?? '';
      $end_date = $request->end_date ?? '';
      $budget = $request->budget ?? '';

      $BookpostCampaign = BookpostCampaign::withoutTrashed()->orderBy("id", "desc");

      if ($campaign_id) {
        $BookpostCampaign->where('campaign_id', 'like', '%' . $campaign_id . '%');
      }

      if ($title) {
        $BookpostCampaign->where('title', 'like', '%' . $title . '%');
      }

      if ($start_date) {
        $BookpostCampaign->whereDate('start_date', '>=', $this->convertToDatabaseDateForSearch($start_date));
      }

      if ($end_date) {
        $BookpostCampaign->whereDate('end_date', '<=', $this->convertToDatabaseDateForSearch($end_date));
      }

      if ($budget) {
        $BookpostCampaign->where('budget', $budget);
      }

      $num_rows = $BookpostCampaign->count();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Bookpost Campaign"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['campaign_id'] = $campaign_id;
      $this->response['data']['start_date'] = $start_date;
      $this->response['data']['end_date'] = $end_date;
      $this->response['data']['budget'] = $budget;
      $this->response['data']['list'] = $BookpostCampaign->limit($per_page)->offset($offset)->get();
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Book post campaign fetching failed" . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateBookpostCampaign($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $BookpostCampaignObject = new BookpostCampaign();
      $id = $request->id;
      $title = $request->title ?? 0;
      $campaign_id = $request->campaign_id ?? 0;
      $start_date = Carbon::createFromFormat('d/m/Y g:i A', $request->start_date)->format('Y-m-d H:i:s');
      $end_date = Carbon::createFromFormat('d/m/Y g:i A', $request->end_date)->format('Y-m-d H:i:s');
      $budget = $request->budget ?? 0;
      $status = $request->status ?? 0;

      if ($id) {
        $BookpostCampaignObject = BookpostCampaign::find($id);

        if (!$BookpostCampaignObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Bookpost Campaign"]);
          return $this->sendResponse($this->response, 401);
        }

        $BookpostCampaignObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Bookpost Campaign"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Bookpost Campaign"]);
      }

      $BookpostCampaignObject->title = $title;
      $BookpostCampaignObject->campaign_id = $campaign_id;
      $BookpostCampaignObject->start_date = $start_date;
      $BookpostCampaignObject->end_date = $end_date;
      $BookpostCampaignObject->budget = $budget;
      $BookpostCampaignObject->status = $status;

      $BookpostCampaignObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Creating Bookpost Campaign: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Bookpost Campaign"]);
      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $BookpostCampaignObject = BookpostCampaign::withoutTrashed()->find($id);

      if (!$BookpostCampaignObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Bookpost Campaign"]);
        return $this->sendResponse($this->response, 401);
      }
      $BookpostCampaignObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Bookpost Campaign"]);
      $this->response['data'] = $BookpostCampaignObject;


      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Bookpost Campaign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $bookObject = BookpostCampaign::find($id);

      if (!$bookObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Bookpost Campaign"]);
        return $this->sendResponse($this->response, 401);
      }

      $bookObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Bookpost Campaign"]);
      $this->response['data'] = $bookObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Bookpost Campaign Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addData(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $files = $request->excel ?? [];

      $validationErrors = $this->validateAddData($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      foreach ($files as $item) {

        $filePath = storage_path('app/public/uploads/temp/' . $item['filename']);
        $sourcePath = 'public/uploads/temp/' .  $item['filename'];

        if (!Storage::exists($sourcePath)) {

          $this->response['error'] = __('admin.file_not_found', ['file' => $item['filename']]);
          return $this->sendResponse($this->response, 401);
        }

        $spreadsheet = IOFactory::load($filePath);
        $sheetNames = $spreadsheet->getSheetNames();
        $dataRecords = [];

        foreach ($sheetNames as $sheetName) {
          $worksheet = $spreadsheet->getSheetByName($sheetName);
          $cellIterator = $worksheet->getRowIterator()->current()->getCellIterator();
          $cellIterator->setIterateOnlyExistingCells(true);

          $headers = [];
          foreach ($cellIterator as $cell) {
            if ($cell->getValue() != '') {
              $headers[] = $cell->getValue();
            }
          }

          if (array_values($headers) != array_values(config('global.BOOKPOST_CAMPAIGN_DATA_HEADER_FORMAT'))) {
            $this->response['error'] = __('admin.excel_format_error', ['file' => $item['filename'], 'sheet' => $sheetName]);
            return $this->sendResponse($this->response, 200);
          }

          $highestRow = $worksheet->getHighestRow();
          $dataRecords = [];

          for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
            $dataRecords[] = $rowData[$row];
          }
        }

        foreach ($dataRecords as $data) {
          BookpostData::create([

            'name' => convertToCamelCase($data['A']),
            'mobile' => $data['B'],
            'email' => $data['C'],
            'address' => convertToCamelCase($data['D']),
            'city' => convertToCamelCase($data['E']),
            'designation' => convertToCamelCase($data['F']),
            'country' => convertToCamelCase($data['G']),
            'pincode' => convertToCamelCase($data['H']),
            'fk_bookpost_campaign_id' => $id

          ]);
        }

        $this->response['status'] = 1;
        $this->response['msg'] = __('admin.created', ['module' => "Bookpost Data"]);
        return $this->sendResponse($this->response, 200);
      }
    } catch (\Exception $e) {
      Log::error("Failed Creating Excel Data: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addDataSingle(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddDataSingle($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $BOOKPOSTDATA = new BookpostData();
      $id = $request->id;
      $campaign_id = $id;
      $name = $request->name;
      $email = $request->email;
      $mobile = $request->mobile;
      $address = $request->address;
      $city = $request->city;
      $designation = $request->designation;
      $country = $request->country;
      $pincode = $request->pincode;


      if ($id) {
        $BOOKPOSTDATA = new BookpostData();

        if (!$BOOKPOSTDATA) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Bookpost Data"]);
          return $this->sendResponse($this->response, 401);
        }

        $BOOKPOSTDATA->fk_bookpost_campaign_id = $campaign_id;
        $BOOKPOSTDATA->name = $name;
        $BOOKPOSTDATA->email = $email;
        $BOOKPOSTDATA->mobile = $mobile;
        $BOOKPOSTDATA->address = $address;
        $BOOKPOSTDATA->city = $city;
        $BOOKPOSTDATA->designation = $designation;
        $BOOKPOSTDATA->country = $country;
        $BOOKPOSTDATA->pincode = $pincode;
      }

      $BOOKPOSTDATA->save();
      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.created', ['module' => "Bookpost Data"]);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Bookpost Data: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Bookpost Data"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function deleteData(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $BOOKPOSTDATA = BookpostData::find($id);

      if (!$BOOKPOSTDATA) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Bookpost Data"]);
        return $this->sendResponse($this->response, 401);
      }

      $BOOKPOSTDATA->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Bookpost Data"]);
      $this->response['data'] = $BOOKPOSTDATA;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Bookpost Data deleting failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function listData(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $bookpost_campaign_id = $request->bookpost_campaign_id ?? '';
      $name = $request->name ?? '';
      $address = $request->address ?? '';
      $city = $request->city ?? '';
      $mobile = $request->mobile ?? '';
      $email = $request->email ?? '';
      $designation = $request->designation ?? '';
      $country = $request->country ?? '';
      $pincode = $request->pincode ?? '';

      $BOOKPOSTDATA = BookpostData::with('campaign');


      if ($bookpost_campaign_id) {
        $BOOKPOSTDATA->whereHas('campaign', function ($query) use ($bookpost_campaign_id) {
          $query->where('fk_bookpost_campaign_id', $bookpost_campaign_id);
        });
      }

      if ($name) {
        $BOOKPOSTDATA->where('name', 'like', '%' . $name . '%');
      }

      if ($address) {
        $BOOKPOSTDATA->where('address', 'like', '%' . $address . '%');
      }

      if ($city) {
        $BOOKPOSTDATA->where('city', 'like', '%' . $city . '%');
      }

      if ($mobile) {
        $BOOKPOSTDATA->where('mobile', 'like', '%' . $mobile . '%');
      }

      if ($email) {
        $BOOKPOSTDATA->where('email', 'like', '%' . $email . '%');
      }

      if ($designation) {
        $BOOKPOSTDATA->where('designation', 'like', '%' . $designation . '%');
      }

      if ($country) {
        $BOOKPOSTDATA->where('country', 'like', '%' . $country . '%');
      }

      if ($pincode) {
        $BOOKPOSTDATA->where('pincode', 'like', '%' . $pincode . '%');
      }

      $num_rows = $BOOKPOSTDATA->count();
      $BOOKPOSTDATA = $BOOKPOSTDATA->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['model' => 'SMS Campaign']);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['bookpost_campaign_id'] = $bookpost_campaign_id;
      $this->response['data']['address'] = $address;
      $this->response['data']['city'] = $city;
      $this->response['data']['name'] = $name;
      $this->response['data']['mobile'] = $mobile;
      $this->response['data']['email'] = $email;
      $this->response['data']['designation'] = $designation;
      $this->response['data']['country'] = $country;
      $this->response['data']['pincode'] = $pincode;
      $this->response['data']['list'] = BookpostCampaignResource::collection($BOOKPOSTDATA);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SMS Data fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function generatePdf(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $fk_bookpost_campaign_id = $request->fk_bookpost_campaign_id ?? '';
      $name = $request->name ?? '';
      $address = $request->address ?? '';
      $city = $request->city ?? '';
      $mobile = $request->mobile ?? '';
      $email = $request->email ?? '';

      $BOOKPOSTDATA = BookpostData::with('campaign');

      if ($fk_bookpost_campaign_id) {
        $BOOKPOSTDATA->whereHas('campaign', function ($query) use ($fk_bookpost_campaign_id) {
          $query->where('fk_bookpost_campaign_id', $fk_bookpost_campaign_id);
        });
      }

      if ($name) {
        $BOOKPOSTDATA->where('name', 'like', '%' . $name . '%');
      }

      if ($address) {
        $BOOKPOSTDATA->where('address', 'like', '%' . $address . '%');
      }

      if ($city) {
        $BOOKPOSTDATA->where('city', 'like', '%' . $city . '%');
      }

      if ($mobile) {
        $BOOKPOSTDATA->where('mobile', 'like', '%' . $mobile . '%');
      }

      if ($email) {
        $BOOKPOSTDATA->where('email', 'like', '%' . $email . '%');
      }

      $BOOKPOSTDATA = $BOOKPOSTDATA->get();

      $envelopeWidth = 377;
      $envelopeHeight = 170;

      $htmlContent = bookPostPdfContent($BOOKPOSTDATA, $envelopeWidth, $envelopeHeight);
      $filePath = 'Book Post Data.pdf';

      // 
      // dompdf
      // 

      $dompdf = new Dompdf();
      $dompdf->loadHtml($htmlContent);

      // Render the PDF
      $dompdf->render();

      $pdfContent = $dompdf->output(); // Get the generated PDF content

      file_put_contents(storage_path('app/public/uploads/temp/' . $filePath), $pdfContent); // Save the PDF to the specified file path

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Bookpost Campaign"]);
      $this->response['data'] = $this->fileAccessPath . '/temp/' . $filePath;
      $this->response['filePath'] = $this->fileAccessPath . '/temp/' . $filePath;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Bookpost Campaign Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddUpdateBookpostCampaign(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'title' => 'required|string|unique:bookpost_campaigns,title,' . $request->id . ',id,deleted_at,NULL',
        'campaign_id' => 'required|string|unique:bookpost_campaigns,campaign_id,' . $request->id . ',id,deleted_at,NULL',
        'start_date' => 'required|date_format:d/m/Y g:i A',
        'end_date' => 'required|date_format:d/m/Y g:i A|after:start_date',
        'budget' => 'sometimes|required|numeric',
        'status' => 'sometimes|required|integer|in:0,1',
      ],
      [
        'title.unique' => 'Campaign name already exist',
        'start_date.date_format' => 'Invalid date format',
        'end_date.date_format' => 'Invalid date format',
        'campaign_id.unique' => 'Campaign ID already exist'
      ]
    )->errors();
  }

  private function validateAddData(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'id' => 'required|exists:bookpost_campaigns,id,deleted_at,NULL',
        'excel' => 'required',
      ],
      [
        'id.exists' => "Campaign doesn't exists with provided id",
      ]
    )->errors();
  }

  private function validateAddDataSingle(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'id' => 'required|exists:bookpost_campaigns,id,deleted_at,NULL',
        'name' => 'required',
        'address' => 'required',
        'city' => 'required',
        'email' => 'required',
        'mobile' => 'required',
      ],
      [
        'id.exists' => "Campaign doesn't exists with provided id",
      ]
    )->errors();
  }
}
