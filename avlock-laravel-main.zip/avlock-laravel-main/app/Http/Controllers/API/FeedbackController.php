<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Feedback;
use App\Models\Industry;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class FeedbackController extends AppBaseController {

    /**
   * Display a listing of the Feedback.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if (!$this->isUserAdmin) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';

      $feedback = Feedback::with('user')->orderBy("id", "desc");
      $num_rows = $feedback->count();

      if ($title) {
        $feedback->where('title', 'like', '%' . $title . '%');
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Feedback"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['list'] = $feedback->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Feedback fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(Request $request) {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateFeedback($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $feedbackObject = new Feedback();
      $id = $request->id;
      $title = $request->title ?? '';
      $description = $request->description ?? '';
      $images = $request->images ?? [];
      $status = $request->status ?? 1;

      if ($id) {
        $feedbackObject = Feedback::find($id);

        if (!$feedbackObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Feedback"]);
          return $this->sendResponse($this->response, 500);
        }

        $feedbackObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Feedback"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Feedback"]);
      }

      $allImages = [];

      foreach ($images as $item) {

        moveFile('feedback/', $item['filename']);

        $allImages[] = [
          'filename' => $item['filename'],
          'path' => $this->fileAccessPath . "/feedback/" . $item['filename'],
        ];
      }

      $feedbackObject->title = $title;
      $feedbackObject->description = $description;
      $feedbackObject->image = json_encode($allImages);
      $feedbackObject->user_id = $this->userId;
      $feedbackObject->status = $status;

      $feedbackObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Feedback: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Feedback"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $feedbackObject = Feedback::find($id);

      if (!$feedbackObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Feedback"]);
        return $this->sendResponse($this->response, 500);
      }
      $feedbackObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Feedback"]);
      $this->response['data'] = $feedbackObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Feedback fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $feedbackObject = Feedback::find($id);

      if (!$feedbackObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Feedback"]);
        return $this->sendResponse($this->response, 500);
      }

      $feedbackObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Feedback"]);
      $this->response['data'] = $feedbackObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Feedback Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function isResolved(Request $request){
    try {
      
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $feedbackObject = new Feedback();
      $id = $request->id;
      $isResolved = $request->is_resolved ?? 0;

      if ($id) {
        $feedbackObject = Feedback::find($id);

        if (!$feedbackObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Feedback"]);
          return $this->sendResponse($this->response, 500);
        }

        $feedbackObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Feedback"]);
      }

      $feedbackObject->is_resolved = $isResolved;
      $feedbackObject->save();

      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);

    } catch (\Exception $e) {
      Log::error("Failed Creating Feedback: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Feedback"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdateFeedback(Request $request) {
    return Validator::make($request->all(), [
      'title' => 'required',
      'description' => 'required',
      'status' => 'sometimes|required|integer|in:0,1',
    ])->errors();
  }
}
