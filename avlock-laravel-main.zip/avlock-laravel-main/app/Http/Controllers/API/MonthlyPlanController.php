<?php

namespace App\Http\Controllers\API;

use App\Http\Resources\MonthlyPlanResource;
use Carbon\Carbon;
use App\Models\Task;
use App\Enums\TaskFrom;
use App\Events\TaskLogCreated;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\StatusResource;
use App\Http\Resources\UserResourceForSelectInput;
use App\Models\MonthlyPlan;
use App\Models\MonthlyPlanExcel;
use App\Models\PurchaseOrder;
use App\Models\TaskType;
use App\Models\TaskUser;
use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Csv;

class MonthlyPlanController extends AppBaseController
{

  // public function index(Request $request)
  // {
  //   try {

  //     if (!$this->userId) {
  //       $this->response['error'] = __('auth.authentication_failed');
  //       return $this->sendResponse($this->response, 401);
  //     }

  //     $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
  //     $perPage = (isset($request->perPage) && $request->perPage != 'undefined') ? intval($request->perPage) : config('global.DEFAULT_PAGINATE_LENGTH');
  //     $offset = ($page - 1) * $perPage;

  //     $title = $request->title ?? '';
  //     $fk_status_id = $request->fk_status_id ?? '';
  //     $fk_rfq_id = $request->fk_rfq_id ?? '';
  //     $start = $request->start ?? '';
  //     $end = $request->end ?? '';
  //     $fk_task_type_id = $request->fk_task_type_id ?? '';
  //     $fk_user_id = $request->fk_user_id ?? '';
  //     $created_by = $request->created_by ?? '';

  //     $status = Task::with('statuses', 'taskType', 'lead', 'rfq')->orderBy("id", "desc")->where('task_from', TaskFrom::MONTHLY_PLAN->value);
  //     if (!$this->isUserAdmin) {
  //       $status->where('created_by', $this->userId);
  //       $status->whereHas('assignedToUsers', function ($query) {
  //         $query->orWhere('fk_user_id', $this->userId);
  //       });
  //     }
  //     if ($title) {
  //       $status->where('title', 'like', '%' . $title . '%');
  //     }

  //     if ($fk_status_id) {
  //       $status->where('fk_status_id', $fk_status_id);
  //     }

  //     if ($fk_rfq_id) {
  //       $status->where('fk_rfq_id', $fk_rfq_id);
  //     }

  //     if ($start) {
  //       $status->where('start', '>=', $this->convertToDatabaseDateForSearch($start));
  //     }

  //     if ($end) {
  //       $status->where('end', '<=', $this->convertToDatabaseDateForSearch($end));
  //     }

  //     if ($fk_task_type_id) {
  //       $status->where('fk_task_type_id', $fk_task_type_id);
  //     }

  //     if ($fk_user_id) {

  //       $status->whereHas('assignedToUsers', function ($query) use ($fk_user_id) {
  //         $query->where('fk_user_id', $fk_user_id);
  //       });
  //     }

  //     if ($created_by) {
  //       $status->where('created_by', $created_by);
  //     }

  //     $status = $status->limit($perPage)->offset($offset)->get();
  //     $numRows = $status->count();

  //     $this->response['status'] = 1;
  //     $this->response['msg'] =  __('admin.fetched', ['module' => "Task"]);
  //     $this->response['data']['page'] = $page;
  //     $this->response['data']['per_page'] = $perPage;
  //     $this->response['data']['num_rows'] = $numRows;
  //     $this->response['data']['total_pages'] = $numRows < $perPage ? 1 : ceil($numRows / $perPage);
  //     $this->response['data']['title'] = $title;
  //     $this->response['data']['fk_status_id'] = $fk_status_id;
  //     $this->response['data']['fk_user_id'] = $fk_user_id;
  //     $this->response['data']['created_by'] = $created_by;
  //     $this->response['data']['list'] = StatusResource::collection($status);
  //     $this->response['data']['events'] = StatusResource::collection($status);

  //     return $this->sendResponse($this->response, 200);
  //   } catch (\Exception $e) {
  //     Log::error("Task fetching failed: " . $e->getMessage());
  //     $this->response['error'] = __('auth.something_went_wrong');
  //     return $this->sendResponse($this->response, 500);
  //   }
  // }

  public function index(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $perPage = (isset($request->perPage) && $request->perPage != 'undefined') ? intval($request->perPage) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $perPage;

      $monthlyPlanExcelId = $request->id ?? '';
      $rsm_id = $request->rsm_id ?? '';
      $customer_name = $request->customer_name ?? '';
      $startDate = $request->start_date ?? "";
      $endDate = $request->end_date ?? "";
      $isExport = $request->is_export ?? 0;
      $dateRange = strtolower($request->date_range) ?? '';


      $status = MonthlyPlan::with('rsm')->where('monthly_plan_id', $monthlyPlanExcelId)->orderBy("monthly_plan_id", "desc");
      $juniorUserIds = $this->getJuniorIds(true);
      rsort($juniorUserIds);

      if ($this->isMarketing || $this->isManagement || $this->isUserAdmin) {
        $status = MonthlyPlan::with('rsm')->where('monthly_plan_id', $monthlyPlanExcelId)->orderBy("id", "desc");
      } else {
        $status = MonthlyPlan::with('rsm')
          ->where('monthly_plan_id', $monthlyPlanExcelId)
          ->where(function ($q) use ($juniorUserIds) {
            $q->whereIn('rsm_id', $juniorUserIds);
            $q->orWhereIn('created_by', $juniorUserIds);
          })
          ->orderBy("id", "desc");
      }

      if ($rsm_id) {
        $rsmId = explode(',', $rsm_id);
        $status->whereIn('rsm_id', $rsmId);
      }

      if ($customer_name) {
        $status->where('customer_name', 'like', '%' . $customer_name . '%');
      }

      // if ($visit_date) {
      //   $status->where('visit_date', '>=', $this->convertToDatabaseDateForSearch($visit_date));
      // }


      if ($dateRange) {
        if ($dateRange == 'today') {
          $status->whereDate('visit_date', date('Y-m-d'));
        }
        if ($dateRange == 'yesterday') {
          $status->whereDate('visit_date', date('Y-m-d', strtotime('-1 day')));
        }
        if ($dateRange == 'last_7_days') {
          $status->whereDate('visit_date', '>=', date('Y-m-d', strtotime('-7 days')));
          $status->whereDate('visit_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'last_14_days') {
          $status->whereDate('visit_date', '>=', date('Y-m-d', strtotime('-14 days')));
          $status->whereDate('visit_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'last_28_days') {
          $status->whereDate('visit_date', '>=', date('Y-m-d', strtotime('-28 days')));
          $status->whereDate('visit_date', '<=', date('Y-m-d'));
        }
        if ($dateRange == 'this_month') {
          $status->whereMonth('visit_date', date('m'))->whereYear('visit_date', date('Y'));
        }
        if ($dateRange == 'last_month') {
          $status->whereMonth('visit_date', date('m', strtotime('-1 month')));
        }
        if ($dateRange == 'this_year') {
          $status->whereYear('visit_date', date('Y'));
        }
        if ($dateRange == 'last_year') {
          $status->whereYear('visit_date', date('Y', strtotime('-1 year')));
        }

        if ($dateRange == 'custom_date') {
          if ($startDate) {
            $status->whereDate('visit_date', '>=', $startDate);

            if ($endDate) {
              $status->whereDate('visit_date', '<=', $endDate);
            }
          }
        }
      }


      $numRows = $status->count();
      $status = $status->limit($perPage)->offset($offset)->get();


      if ($isExport == 1) {
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $headers = ['RSM', 'Visit Date', 'Customer Name', 'Place', 'Type of Industry', 'Type Of Customer'];
        $sheetData = [$headers];

        foreach ($status as $item) {
          $visitDate = Carbon::parse($item->visit_date)->format('d/m/y');
          $rsmName = $item->rsm ? $item->rsm->name : '';

          $basedRowData = [
            $rsmName,
            $visitDate,
            $item->customer_name ?? '',
            $item->place,
            $item->industry_type,
            $item->customer_type,
          ];

          $sheetData[] = $basedRowData;
        }

        $sheet->fromArray($sheetData, null, 'A1');
        $timestamp = now()->format('Ymd_Hi');
        $store = storage_path("app/public/uploads/monthlyPlan/MonthlyPlan_{$timestamp}.csv");
        $filePath = "storage/uploads/monthlyPlan/MonthlyPlan_$timestamp.csv";
        $writer = new Csv($spreadsheet);
        $writer->save($store);
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Monthly Plan"]);
      $this->response['filePath'] = $filePath ?? '';
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $perPage;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $perPage ? 1 : ceil($numRows / $perPage);
      $this->response['data']['rsm_id'] = $rsm_id;
      $this->response['data']['customer_name'] = $customer_name;
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['end_date'] = $endDate;
      $this->response['data']['date_range'] = $dateRange;
      $this->response['data']['list'] = MonthlyPlanResource::collection($status);
      $this->response['data']['juniorIds'] = $juniorUserIds;


      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Monthly Plan fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }


  public function monthlyPlanList(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $perPage = (isset($request->perPage) && $request->perPage != 'undefined') ? intval($request->perPage) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $perPage;

      $rsm_id = $request->rsm_id ?? '';
      $customer_name = $request->customer_name ?? '';
      $startDate = $request->start_date ?? "";
      $endDate = $request->end_date ?? "";
      $startDate = null;
      $endDate = null;
      $month = strtolower($request->month) ?? '';
      $year = $request->year ?? '';


      $status = MonthlyPlanExcel::select('id', 'rsm_id', 'month', 'year', 'target')->with('rsm:id,name')->orderBy("id", "desc");
      $juniorUserIds = $this->getJuniorIds(true);
      rsort($juniorUserIds);

      if ($this->isMarketing || $this->isManagement || $this->isUserAdmin) {
        $status = MonthlyPlanExcel::select('id', 'rsm_id', 'month', 'year', 'target')->with('rsm:id,name')->orderBy("id", "desc");
      } else {
        $status = MonthlyPlanExcel::select('id', 'rsm_id', 'month', 'year', 'target')->with('rsm:id,name')->where(function ($q) use ($juniorUserIds) {
          $q->whereIn('rsm_id', $juniorUserIds);
        })
          ->orderBy("id", "desc");
      }

      if ($rsm_id) {
        $rsmId = explode(',', $rsm_id);
        $status->whereIn('rsm_id', $rsmId);
      }

      if ($customer_name) {
        $status->where('customer_name', 'like', '%' . $customer_name . '%');
      }

      if ($month) {
        $status->where('month', $month);
      }

      if ($year) {
        $status->where('year', $year);
      }

      $numRows = $status->count();
      $status = $status->limit($perPage)->offset($offset)->get();


      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Monthly Plan"]);
      $this->response['filePath'] = $filePath ?? '';
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $perPage;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $perPage ? 1 : ceil($numRows / $perPage);
      $this->response['data']['rsm_id'] = $rsm_id;
      $this->response['data']['customer_name'] = $customer_name;
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['end_date'] = $endDate;
      $this->response['data']['date_range'] = $year;
      $this->response['data']['month'] = $month;
      $this->response['data']['list'] = MonthlyPlanResource::collection($status);
      $this->response['data']['juniorIds'] = $juniorUserIds;


      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Monthly Plan fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $monthlyPlan = MonthlyPlan::with('rsm')->find($id);

      if (!$monthlyPlan) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Monthly Plan"]);
        return $this->sendResponse($this->response, 401);
      }

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Monthly Plan"]);
      $this->response['data'] = new MonthlyPlanResource($monthlyPlan);

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Monthly Plan fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function getPlanCombination(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $rsmId = $request->rsm_id;
      $month = $request->month;
      $year = $request->year;

      $monthlyPlanExcel = MonthlyPlanExcel::where([
        'rsm_id' => $rsmId,
        'month' => $month,
        'year' => $year
      ])->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Monthly Plan"]);
      $this->response['data'] = $monthlyPlanExcel;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Monthly Plan Combination fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }


  public function addUpdate(Request $request)
  {
    try {

      DB::beginTransaction();


      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateTask($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }


      if (count($request->task_user) == 0) {
        $this->response['errors'] = ['user' => "Select Atleast one user"];
        return $this->sendResponse($this->response, 200);
      }
      $taskObject = new Task();
      $id = $request->id;
      $title = $request->title ?? '';
      $taskType = $request->taskType ?? 0;
      $lead = $request->lead ?? 0;
      $rfq = $request->rfq ?? 0;
      $description = $request->description ?? '';
      $start =  Carbon::parse($request->start)->toDateTimeString();
      $end =  Carbon::parse($request->end)->toDateTimeString();
      $taskStatus = $request->status ?? '';
      $taskUser = $request->user ?? '';
      $allDay = $request->allDay ?? 0;

      $files = [];
      if (isset($request->attachment)) {
        if (count($request->attachment) > 0) {
          foreach ($request->attachment as $item) {
            moveFile('task/files/', $item['filename']);
            $files[] = ['filename' => $item['filename'], 'path' => $this->fileAccessPath . "/task/files/" . $item['filename']];
          }
        }
      }

      $attachment = json_encode($files) ?? '';

      if ($id) {
        $taskObject = Task::find($id);

        if (!$taskObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Task"]);
          return $this->sendResponse($this->response, 500);
        }

        $taskObject->first();
        $taskObject->updated_by = $this->userId;

        $this->response['msg'] = __('admin.updated', ['module' => "Task"]);
      } else {
        $taskObject->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => "Task"]);
      }

      $taskObject->title = $title;
      $taskObject->fk_task_type_id = $taskType;
      $taskObject->fk_lead_id = $lead;
      $taskObject->fk_rfq_id = $rfq;
      $taskObject->description = $description;
      $taskObject->allDay = $allDay;
      $taskObject->start = $start;
      $taskObject->end = $end;
      $taskObject->fk_status_id = $taskStatus;
      $taskObject->fk_user_id = $taskUser;
      $taskObject->attachment = $attachment;
      $taskObject->task_user = json_encode($linkedUser);

      $taskObject->save();

      $lastInsertedUserId = $taskObject->id;

      if (count($request->task_user) > 0) {

        TaskUser::where('fk_task_id', $lastInsertedUserId)->forceDelete();

        foreach ($request->task_user as $user) {
          $userId = $user['id'];
          $userName = $user['name'];

          $taskUserObject = new TaskUser();

          if ($userId != "") {
            $taskUserObject->fk_task_id = $lastInsertedUserId;
            $taskUserObject->fk_user_id = $userId;
            $taskUserObject->user_name = $userName;
            $taskUserObject->save();
          }
        }
      }

      $this->response['status'] = 1;

      $taskObject->action = 'created';
      if ($id) {
        $taskObject->action = 'updated';
      }
      TaskLogCreated::dispatch($taskObject);
      DB::commit();
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Task: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Task"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function importFiles(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }



      if (!$request->hasFile('files')) {
        $this->response['error'] = __('admin.file_upload_error');
        return $this->sendResponse($this->response, 200);
      }

      $files = [];
      $imageTempPath = 'uploads/temp';

      foreach ($request->file('files') as $index => $file) {

        $extension = $file->extension();

        if (!in_array($extension, ['xlsx'])) {
          $this->response['error'] = __('admin.excel_type_error');
          return $this->sendResponse($this->response, 200);
        }
        $tempImageName = uniqid() . '.' . $extension;
        $file->storeAs($imageTempPath, $tempImageName, 'public');

        $files[] = ['filename' => $tempImageName, 'path' => $this->fileAccessPath . '/temp/'  . $tempImageName];
      }

      $this->response['status'] = 1;
      $this->response['files'] = $files;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("File Upload failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  // public function importPlan(Request $request)
  // {
  //   try {

  //     DB::beginTransaction();

  //     if (!$this->userId) {
  //       $this->response['error'] = __('auth.authentication_failed');
  //       return $this->sendResponse($this->response, 401);
  //     }

  //     $validationErrors = $this->validateAddMonthlyPlan($request);

  //     if (count($validationErrors)) {
  //       Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
  //       $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
  //       return $this->sendResponse($this->response, 200);
  //     }

  //     $rsmUser = $request->rsm_id ?? '';
  //     $month = $request->month ?? '';
  //     $year = $request->year ?? '';
  //     $files = $request->excel ?? [];

  //     $rsmUserObject = User::with('roles.department')->where('id', $rsmUser)->first();
  //     $rsmUserResource = new UserResourceForSelectInput($rsmUserObject);

  //     $rsmUserArray = $rsmUserResource->toArray($request);

  //     $taskUser = json_encode(['id' => $rsmUserArray['id'], 'name' => $rsmUserArray['name']]);

  //     if (!$rsmUserObject) {
  //       $this->response['error'] = __('admin.id_not_found', ['module' => "RSM User"]);
  //       return $this->sendResponse($this->response, 500);
  //     }


  //     $highestRow = 0;
  //     foreach ($files as $item) {

  //       $filePath = storage_path('app/public/uploads/temp/' . $item['filename']);
  //       $sourcePath = 'public/uploads/temp/' .  $item['filename'];

  //       if (!Storage::exists($sourcePath)) {

  //         $this->response['error'] = __('admin.file_not_found', ['file' => $item['filename']]);
  //         return $this->sendResponse($this->response, 500);
  //       }

  //       $spreadsheet = IOFactory::load($filePath);
  //       $sheetNames = $spreadsheet->getSheetNames();
  //       $dataRecords = [];

  //       $monthlyPlanExcelObject = new MonthlyPlanExcel();
  //       $monthlyPlanExcelObject->rsm_id = $rsmUser;
  //       $monthlyPlanExcelObject->month = $month;
  //       $monthlyPlanExcelObject->year = $year;
  //       $monthlyPlanExcelObject->filename = $sourcePath;

  //       $monthlyPlanExcelObject->save();

  //       $lastInsertedmonthlyPlanExcelId = $monthlyPlanExcelObject->id;

  //       foreach ($sheetNames as $sheetName) {
  //         $worksheet = $spreadsheet->getSheetByName($sheetName);
  //         $cellIterator = $worksheet->getRowIterator()->current()->getCellIterator();
  //         $cellIterator->setIterateOnlyExistingCells(true);

  //         $headers = [];
  //         foreach ($cellIterator as $cell) {
  //           if ($cell->getValue() != '') {
  //             $headers[] = $cell->getValue();
  //           }
  //         }

  //         if (array_values($headers) != array_values(config('global.MONTHLY_PLAN_HEADER_FORMAT'))) {
  //           $this->response['error'] = __('admin.excel_format_error', ['file' => $item['filename'], 'sheet' => $sheetName]);
  //           return $this->sendResponse($this->response, 200);
  //         }

  //         // $highestRow = $worksheet->getHighestRow();
  //         $highestRow = max($highestRow, $worksheet->getHighestRow());
  //         $dataRecords = [];

  //         for ($row = 2; $row <= $highestRow; $row++) {
  //           $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
  //           if (!empty(array_filter($rowData[$row]))) {
  //             $dataRecords[] = $rowData[$row];
  //           }
  //         }
  //       }

  //       foreach ($dataRecords as $key => $data) {

  //         if (isset($data['A']) && !empty($data['A'])) {
  //           $date = Carbon::createFromFormat('d/m/Y', $data['A'])->format('Y-m-d H:i:s');
  //           $timestamp = strtotime($date);
  //           $recordYear = date("Y", $timestamp);
  //           $recordMonth = date("F", $timestamp);

  //           if ($recordYear != $year || strtolower($recordMonth) != $month) {
  //             $this->response['error'] = "The month or year of the date is incorrect on : " . $sheetName . " at row : " . $key + 2;
  //             return $this->sendResponse($this->response, 200);
  //           }
  //         } else {
  //           $this->response['error'] = "Date Can not be empty : " . $sheetName . "at row : " . $key + 2;
  //           return $this->sendResponse($this->response, 200);
  //         }

  //         if (isset($data['B']) && !empty($data['B'])) {
  //           $title = $data['B'];
  //         } else {
  //           $this->response['error'] = "Title Can not be empty : " . $sheetName . "at row : " . $key + 2;
  //           return $this->sendResponse($this->response, 200);
  //         }

  //         if (isset($data['C']) && !empty($data['C'])) {
  //           $description = $data['C'];
  //         } else {
  //           $this->response['error'] = "Description Can not be empty : " . $sheetName . "at row : " . $key + 2;
  //           return $this->sendResponse($this->response, 200);
  //         }

  //         if (isset($data['D']) && !empty($data['D'])) {
  //           $remark = $data['D'];
  //         } else {
  //           $this->response['error'] = "Remark Can not be empty : " . $sheetName . "at row : " . $key + 2;
  //           return $this->sendResponse($this->response, 200);
  //         }

  //         $taskObject = new Task();

  //         $taskObject->title = $title;
  //         $taskObject->fk_task_type_id = 3;
  //         $taskObject->description = $description;
  //         $taskObject->remark = $remark;
  //         $taskObject->start = $date;
  //         $taskObject->end = $date;
  //         $taskObject->fk_status_id = 2;
  //         $taskObject->fk_user_id = $rsmUser;
  //         $taskObject->task_user = $taskUser;
  //         $taskObject->task_from = TaskFrom::MONTHLY_PLAN->value;
  //         $taskObject->monthly_plan_id = $lastInsertedmonthlyPlanExcelId;
  //         $taskObject->created_by = $this->userId;
  //         $taskObject->save();

  //         $lastInsertedTaskId = $taskObject->id;

  //         $taskUserObject = new TaskUser();

  //         $taskUserObject->fk_task_id = $lastInsertedTaskId;
  //         $taskUserObject->fk_user_id = $rsmUserArray['id'];
  //         $taskUserObject->user_name = $rsmUserArray['name'];
  //         $taskUserObject->save();

  //         $taskObject->action = 'created';
  //         TaskLogCreated::dispatch($taskObject);
  //       }

  //       $this->response['status'] = 1;
  //       $this->response['msg'] = __('admin.created', ['module' => "Monthly Plan Data"]);
  //       DB::commit();

  //       return $this->sendResponse($this->response, 200);
  //     }
  //   } catch (\Exception $e) {
  //     Log::error("Failed Creating Excel Lead Data: " . $e->getMessage());
  //     $this->response['error'] = __('auth.something_went_wrong');
  //     return $this->sendResponse($this->response, 500);
  //   }
  // }

  public function importPlan(Request $request)
  {
    try {

      DB::beginTransaction();

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddMonthlyPlan($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $rsmUser = $request->rsm_id ?? '';
      $target = $request->target ?? 0;
      $month = $request->month ?? '';
      $year = $request->year ?? '';
      $files = $request->excel ?? [];

      $rsmUserObject = User::with('roles.department')->where('id', $rsmUser)->first();

      if (!$rsmUserObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "RSM User"]);
        return $this->sendResponse($this->response, 500);
      }

      $rsmUserResource = new UserResourceForSelectInput($rsmUserObject);
      $rsmUserArray = $rsmUserResource->toArray($request);
      $taskUser = json_encode(['id' => $rsmUserArray['id'], 'name' => $rsmUserArray['name']]);


      $highestRow = 0;
      foreach ($files as $item) {

        $filePath = storage_path('app/public/uploads/temp/' . $item['filename']);
        $sourcePath = 'public/uploads/temp/' .  $item['filename'];

        if (!Storage::exists($sourcePath)) {

          $this->response['error'] = __('admin.file_not_found', ['file' => $item['filename']]);
          return $this->sendResponse($this->response, 500);
        }

        $spreadsheet = IOFactory::load($filePath);
        $sheetNames = $spreadsheet->getSheetNames();
        $dataRecords = [];

        $combination = MonthlyPlanExcel::where([
          'rsm_id' => $rsmUser,
          'month' => $month,
          'year' => $year
        ])->first();

        if ($combination) {
          $lastInsertedmonthlyPlanExcelId = $combination->id;
        } else {
          $monthlyPlanExcelObject = new MonthlyPlanExcel();
          $monthlyPlanExcelObject->rsm_id = $rsmUser;
          $monthlyPlanExcelObject->target = $target;
          $monthlyPlanExcelObject->month = $month;
          $monthlyPlanExcelObject->year = $year;
          $monthlyPlanExcelObject->filename = $sourcePath;

          $monthlyPlanExcelObject->save();

          $lastInsertedmonthlyPlanExcelId = $monthlyPlanExcelObject->id;
        }

        $sheetName = $sheetNames[0];
        $worksheet = $spreadsheet->getSheetByName($sheetName);
        $cellIterator = $worksheet->getRowIterator()->current()->getCellIterator();
        $cellIterator->setIterateOnlyExistingCells(true);

        $headers = [];
        foreach ($cellIterator as $cell) {
          if ($cell->getValue() != '') {
            $headers[] = $cell->getValue();
          }
        }

        if (array_values($headers) != array_values(config('global.MONTHLY_PLAN_HEADER_FORMAT'))) {
          $this->response['error'] = __('admin.excel_format_error', ['file' => $item['filename'], 'sheet' => $sheetName]);
          return $this->sendResponse($this->response, 200);
        }

        // $highestRow = $worksheet->getHighestRow();
        $highestRow = max($highestRow, $worksheet->getHighestRow());
        $dataRecords = [];

        for ($row = 2; $row <= $highestRow; $row++) {
          $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
          if (!empty(array_filter($rowData[$row]))) {
            $dataRecords[] = $rowData[$row];
          }
        }

        foreach ($dataRecords as $key => $data) {

          if (isset($data['A']) && !empty($data['A'])) {

            $day = $data['A'];
            $monthNumber = date('n', strtotime($month));
            $formattedDate = Carbon::create($year, $monthNumber, $day, 0, 0, 0)->format('d/m/Y');
            $date = Carbon::createFromFormat('d/m/Y', $formattedDate)->format('Y-m-d H:i:s');

            // if ($recordYear != $year || strtolower($recordMonth) != $month) {
            //   $this->response['error'] = "The month or year of the date is incorrect on : " . $sheetName . " at row : " . $key + 2;
            //   return $this->sendResponse($this->response, 200);
            // }
          } else {
            $this->response['error'] = "Date Of Vist Can not be empty : " . $sheetName . "at row : " . $key + 2;
            return $this->sendResponse($this->response, 200);
          }

          if (isset($data['B']) && !empty($data['B'])) {
            $customerName = convertToCamelCase($data['B']);
          } else {
            $this->response['error'] = "Name of the customer can not be empty : " . $sheetName . "at row : " . $key + 2;
            return $this->sendResponse($this->response, 200);
          }

          if (isset($data['C']) && !empty($data['C'])) {
            $place = convertToCamelCase($data['C']);
          } else {
            $place = '';
            // $this->response['error'] = "Place Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          if (isset($data['D']) && !empty($data['D'])) {
            $industryType = $data['D'];
          } else {
            $industryType = '';

            // $this->response['error'] = "Type of industry Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          if (isset($data['E']) && !empty($data['E'])) {
            $customerType = $data['E'];
          } else {
            $customerType = '';

            // $this->response['error'] = "Type of Customer Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          if (isset($data['F']) && !empty($data['F'])) {
            $productName = convertToCamelCase($data['F']);
          } else {
            $productName = '';

            // $this->response['error'] = "Product to be discussed Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          // if (isset($data['G']) && !empty($data['G'])) {
          //   $visitPlan = $data['G'];
          // } else {
          //   $visitPlan = '';

          //   $this->response['error'] = "Visit/interaction Planned in Can not be empty : " . $sheetName . "at row : " . $key + 2;
          //   return $this->sendResponse($this->response, 200);
          // }

          if (isset($data['G']) && !empty($data['G'])) {
            $visitPurpose = $data['G'];
          } else {
            $visitPurpose = '';

            // $this->response['error'] = "Purpose of visit / interaction planned Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          // if (isset($data['I']) && !empty($data['I'])) {
          //   $actualVisitPlan = $data['I'];
          // } else {
          //   $actualVisitPlan = '';

          //   $this->response['error'] = "Actual Meeting/ interaction Happened in Can not be empty : " . $sheetName . "at row : " . $key + 2;
          //   return $this->sendResponse($this->response, 200);
          // }

          if (isset($data['H']) && !empty($data['H'])) {
            $svrNo = $data['H'];
          } else {
            $svrNo = '';

            // $this->response['error'] = "SVR Number Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          if (isset($data['I']) && !empty($data['I'])) {
            $discussionMode = $data['I'];
          } else {
            $discussionMode = '';

            // $this->response['error'] = "Mode of Discussion Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          if (isset($data['J']) && !empty($data['J'])) {
            $keyPointsOfDiscussion = $data['J'];
          } else {
            $keyPointsOfDiscussion = '';

            // $this->response['error'] = "Key Points of discussion with customer Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          if (isset($data['K']) && !empty($data['K'])) {
            $nextActionPlan = $data['K'];
          } else {
            $nextActionPlan = '';

            // $this->response['error'] = "Next action plan Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          if (isset($data['L']) && !empty($data['L'])) {
            $managementOrBossComment = $data['L'];
          } else {
            $managementOrBossComment = '';

            // $this->response['error'] = "Comment from direct boss / Mnagement Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          if (isset($data['M']) && !empty($data['M'])) {
            $commentByName = $data['M'];
          } else {
            $commentByName = '';

            // $this->response['error'] = "Name who made the comments Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          if (isset($data['N']) && !empty($data['N'])) {
            $replyOnComment = $data['N'];
          } else {
            $replyOnComment = '';

            // $this->response['error'] = "Your reply to management on their comment / instructions Can not be empty : " . $sheetName . "at row : " . $key + 2;
            // return $this->sendResponse($this->response, 200);
          }

          if (isset($data['O']) && !empty($data['O'])) {

            if ($data['O'] != 'Lead' && $data['O'] != 'RFQ' && $data['O'] != 'Other') {
              $this->response['error'] = "Wrong Plan Type It should be (Lead,RFQ,Other) : " . $sheetName . " at row : " . $key + 2;
              return $this->sendResponse($this->response, 200);
            }
            $planType = 3;

            if ($data['O'] == 'Lead') {
              $planType = 1;
            }

            if ($data['O'] == 'RFQ') {
              $planType = 2;
            }

            if ($data['O'] == 'Other') {
              $planType = 3;
            }
          } else {

            $this->response['error'] = "Plan Type Can not be empty : " . $sheetName . "at row : " . $key + 2;
            return $this->sendResponse($this->response, 200);
          }

          $monthlyPlanObject = new MonthlyPlan();

          $monthlyPlanObject->rsm_id = $rsmUser;
          $monthlyPlanObject->visit_date = $date;
          $monthlyPlanObject->customer_name = $customerName;
          $monthlyPlanObject->place = $place;
          $monthlyPlanObject->industry_type = $industryType;
          $monthlyPlanObject->customer_type = $customerType;
          $monthlyPlanObject->product_name = $productName;
          $monthlyPlanObject->visit_purpose = $visitPurpose;
          $monthlyPlanObject->svr_no = $svrNo;
          $monthlyPlanObject->discussion_mode = $discussionMode;
          $monthlyPlanObject->key_points_of_discussion = $keyPointsOfDiscussion;
          $monthlyPlanObject->next_action_plan = $nextActionPlan;
          $monthlyPlanObject->management_or_boss_comment = $managementOrBossComment;
          $monthlyPlanObject->comment_by_name = $commentByName;
          $monthlyPlanObject->reply_on_comment = $replyOnComment;
          $monthlyPlanObject->monthly_plan_id = $lastInsertedmonthlyPlanExcelId;

          $monthlyPlanObject->created_by = $this->userId;
          $monthlyPlanObject->save();
          $monthlyPlanRecordId = $monthlyPlanObject->id;

          $taskObject = new Task();

          $taskObject->title = $customerName;
          $taskObject->fk_task_type_id = $planType;
          $taskObject->description = $industryType;
          $taskObject->remark = $managementOrBossComment;
          $taskObject->start = $date;
          $taskObject->end = $date;
          $taskObject->is_physical_visit = 1;
          $taskObject->fk_status_id = 2;
          $taskObject->fk_user_id = $rsmUser;
          $taskObject->task_user = $taskUser;
          $taskObject->task_from = TaskFrom::MONTHLY_PLAN->value;
          $taskObject->monthly_plan_id = $lastInsertedmonthlyPlanExcelId;
          $taskObject->monthly_plan_record_id = $monthlyPlanRecordId;
          $taskObject->created_by = $this->userId;
          $taskObject->save();

          $lastInsertedTaskId = $taskObject->id;

          $taskUserObject = new TaskUser();

          $taskUserObject->fk_task_id = $lastInsertedTaskId;
          $taskUserObject->fk_user_id = $rsmUserArray['id'];
          $taskUserObject->user_name = $rsmUserArray['name'];
          $taskUserObject->save();

          $taskObject->action = 'created';
          TaskLogCreated::dispatch($taskObject);
        }

        $this->response['status'] = 1;
        $this->response['msg'] = __('admin.created', ['module' => "Monthly Plan Data"]);
        DB::commit();

        return $this->sendResponse($this->response, 200);
      }
    } catch (\Exception $e) {
      Log::error("Failed Creating Monthly Plan Data: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdateMonthlyPlan(Request $request)
  {
    try {

      DB::beginTransaction();


      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateMonthlyExcel($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      //Monthly Plan Excel
      $monthyPlanExcel = new MonthlyPlanExcel();
      $id = $request->id;
      $rsmUser = $request->rsm_id ?? '';
      $target = $request->target ?? 0;
      $month = $request->month ?? '';
      $year = $request->year ?? '';

      $rsmUserObject = User::with('roles.department')->where('id', $rsmUser)->first();

      if (!$rsmUserObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "RSM User"]);
        return $this->sendResponse($this->response, 500);
      }

      $rsmUserResource = new UserResourceForSelectInput($rsmUserObject);
      $rsmUserArray = $rsmUserResource->toArray($request);
      $taskUser = json_encode(['id' => $rsmUserArray['id'], 'name' => $rsmUserArray['name']]);

      $monthly_plan_id = $request->monthly_plan_id;

      $combination = MonthlyPlanExcel::where([
        'rsm_id' => $rsmUser,
        'month' => $month,
        'year' => $year
      ])->first();

      if ($combination) {
        $lastInsertedmonthlyPlanExcelId = $combination->id;
      } else {
        $monthyPlanExcel->rsm_id = $rsmUser;
        $monthyPlanExcel->month = $month;
        $monthyPlanExcel->year = $year;
        $monthyPlanExcel->target = $target;
        $monthyPlanExcel->save();
        $lastInsertedmonthlyPlanExcelId = $monthyPlanExcel->id;
      }


      // Monthly Plan Table
      $monthlyPlanObject = new MonthlyPlan();
      $date = Carbon::createFromFormat('d/m/Y g:i A', $request->visit_date)->format('Y-m-d H:i:s');
      $customerName = $request->customer_name;
      $place = $request->place;
      $industryType = $request->industry_type;
      $customerType = $request->customer_type;
      $productName = $request->product_name;
      $visitPurpose = $request->visit_purpose;
      $svrNo = $request->svr_no;
      $discussionMode = $request->discussion_mode;
      $keyPointsOfDiscussion = $request->key_points_of_discussion;
      $nextActionPlan = $request->next_action_plan;
      $managementOrBossComment = $request->management_or_boss_comment;
      $commentByName = $request->comment_by_name;
      $replyOnComment = $request->reply_on_comment;


      if ($id) {
        $monthlyPlanObject = MonthlyPlan::find($id);

        if (!$monthlyPlanObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Monthly Plan"]);
          return $this->sendResponse($this->response, 500);
        }

        $monthlyPlanObject->first();
        $monthlyPlanObject->updated_by = $this->userId;
        $this->response['msg'] = __('admin.updated', ['module' => "Monthly Plan"]);
      } else {
        $monthlyPlanObject->monthly_plan_id = $lastInsertedmonthlyPlanExcelId;
        $monthlyPlanObject->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => "Monthly Plan"]);
      }

      $monthlyPlanObject->rsm_id = $rsmUser;
      $monthlyPlanObject->visit_date = $date;
      $monthlyPlanObject->customer_name = $customerName;
      $monthlyPlanObject->place = $place;
      $monthlyPlanObject->industry_type = $industryType;
      $monthlyPlanObject->customer_type = $customerType;
      $monthlyPlanObject->product_name = $productName;
      $monthlyPlanObject->visit_purpose = $visitPurpose;
      $monthlyPlanObject->svr_no = $svrNo;
      $monthlyPlanObject->discussion_mode = $discussionMode;
      $monthlyPlanObject->key_points_of_discussion = $keyPointsOfDiscussion;
      $monthlyPlanObject->next_action_plan = $nextActionPlan;
      $monthlyPlanObject->management_or_boss_comment = $managementOrBossComment;
      $monthlyPlanObject->comment_by_name = $commentByName;
      $monthlyPlanObject->reply_on_comment = $replyOnComment;
      $monthlyPlanObject->save();
      $monthlyPlanRecordId = $monthlyPlanObject->id;

      $taskObject = new Task();

      if ($id) {
        $taskObject = Task::where('monthly_plan_record_id', $id)->first();

        if (!$taskObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Task"]);
          return $this->sendResponse($this->response, 500);
        }

        $taskObject->first();
        $taskObject->updated_by = $this->userId;
      } else {
        $taskObject->fk_task_type_id = $request->plan_type;
        $taskObject->monthly_plan_id = $lastInsertedmonthlyPlanExcelId;
        $taskObject->monthly_plan_record_id = $monthlyPlanRecordId;
        $taskObject->created_by = $this->userId;
      }

      $taskObject->title = $customerName;
      $taskObject->description = $industryType;
      $taskObject->remark = $managementOrBossComment;
      $taskObject->start = $date;
      $taskObject->end = $date;
      $taskObject->is_physical_visit = 1;
      $taskObject->fk_status_id = 2;
      $taskObject->fk_user_id = $rsmUser;
      $taskObject->task_user = $taskUser;
      $taskObject->task_from = TaskFrom::MONTHLY_PLAN->value;
      $taskObject->created_by = $this->userId;
      $taskObject->save();

      $lastInsertedTaskId = $taskObject->id;

      if (empty($id)) {
        $taskUserObject = new TaskUser();
        $taskUserObject->fk_task_id = $lastInsertedTaskId;
        $taskUserObject->fk_user_id = $rsmUserArray['id'];
        $taskUserObject->user_name = $rsmUserArray['name'];
        $taskUserObject->save();

        $taskObject->action = 'created';
        TaskLogCreated::dispatch($taskObject);
      }

      $this->response['status'] = 1;
      DB::commit();
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Updating Monthly Plan: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Monthly Plan"]);
      return $this->sendResponse($this->response, 500);
    }
  }

  public function actualVsTargetExport(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $dateRange = $request->input('date_range', 'this_financial_year');
      $rsmId = $request->input('rsm_id', '');
      $startDate = null;
      $endDate = null;

      if ($dateRange !== 'lifetime') {
        switch ($dateRange) {
          case 'this_financial_year':
            $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
            $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
            $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
            break;
          case 'last_financial_year':
            $currentYear = now()->month >= 4 ? now()->year - 1 : now()->year - 2;
            $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
            $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
            break;
          default:
            $startDate = null;
            $endDate = null;
            break;
        }
      }

      $year = $startDate ? $startDate->year : (now()->month >= 4 ? now()->year : now()->subYear()->year);
      $nextYear = $year + 1;

      $juniorUserIds = $this->getJuniorIds(true);
      $currUser = User::find($this->userId);
      $divisionIds = explode(',', $currUser->division_ids);

      $userLists = User::select('id', 'name', 'division_ids')->with('roles:id,fk_department_id')
        ->whereIn('id', $juniorUserIds)
        ->where(function ($query) use ($divisionIds) {
          foreach ($divisionIds as $i => $divId) {
            $method = $i === 0 ? 'whereRaw' : 'orWhereRaw';
            $query->$method('FIND_IN_SET(?, division_ids)', [$divId]);
          }
        })
        ->whereHas('roles', function ($query) {
          $query->where('fk_department_id', 5)
            ->where('fk_department_id', '!=', 1);
        })
        ->orderBy("name", "asc")
        ->get();


      // Define months order
      $months = [
        'april',
        'may',
        'june',
        'july',
        'august',
        'september',
        'october',
        'november',
        'december',
        'january',
        'february',
        'march'
      ];

      // Create a new spreadsheet and set headers
      $spreadsheet = new Spreadsheet();
      $sheet = $spreadsheet->getActiveSheet();

      $headers = [
        'RSM',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December',
        'January',
        'February',
        'March',
      ];
      $sheet->fromArray($headers, null, 'A1');

      $rowData = [];
      foreach ($userLists as $ul) {
        $userId = $ul->id;
        $rsmName = $ul->name;

        $actualSalesData = PurchaseOrder::select(
          DB::raw("LOWER(MONTHNAME(po_date)) as month"),
          DB::raw("SUM(total_basic_value_in_inr) as total_actual")
        )
          ->where('po_type', 1)
          ->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
            $query->whereBetween('po_date', [$startDate, $endDate]);
          })
          ->where('created_by', $userId)
          ->groupBy('month')
          ->get()
          ->mapWithKeys(function ($item) {
            return [$item->month => (float) ($item->total_actual ?? 0)];
          })->all();


        $aprilToDecemberPlan = MonthlyPlanExcel::select('month', DB::raw('SUM(target) as total_target'))
          ->where('year', $year)
          ->whereIn('month', [
            'april',
            'may',
            'june',
            'july',
            'august',
            'september',
            'october',
            'november',
            'december'
          ])
          ->when($startDate && $endDate, function ($query) use ($startDate, $endDate, $year) {
            $startMonth = strtolower($startDate->format('F'));
            $endMonth = strtolower($endDate->format('F'));
            $startYear = $startDate->year;
            $endYear = $endDate->year;

            if ($startYear == $year) {
              $query->where('month', '>=', $startMonth);
            }
            if ($endYear == $year) {
              $query->where('month', '<=', $endMonth);
            }
          })
          ->where('rsm_id', $userId)
          ->groupBy('month')
          ->get()
          ->mapWithKeys(function ($item) {
            return [strtolower($item->month) => (float) ($item->total_target ?? 0)];
          })->all();

        $januaryToMarchPlan = MonthlyPlanExcel::select('month', DB::raw('SUM(target) as total_target'))
          ->where('year', $nextYear)
          ->whereIn('month', ['january', 'february', 'march'])
          ->when($startDate && $endDate, function ($query) use ($startDate, $endDate, $nextYear) {
            $startMonth = strtolower($startDate->format('F'));
            $endMonth = strtolower($endDate->format('F'));
            $startYear = $startDate->year;
            $endYear = $endDate->year;

            if ($startYear == $nextYear) {
              $query->where('month', '>=', $startMonth);
            }
            if ($endYear == $nextYear) {
              $query->where('month', '<=', $endMonth);
            }
          })
          ->where('rsm_id', $userId)
          ->groupBy('month')
          ->get()
          ->mapWithKeys(function ($item) {
            return [$item->month => (float) ($item->total_target ?? 0)];
          })->all();

        $plannedSalesData = array_merge($aprilToDecemberPlan, $januaryToMarchPlan);

        $targetData = [];
        $actualData = [];
        $achievedData = [];

        foreach ($months as $month) {
          $target = $plannedSalesData[$month] ?? 0;
          $actual = $actualSalesData[$month] ?? 0;
          $targetData[] = $target;
          $actualData[] = $actual;
          $percentage = ($target > 0) ? round(($actual / $target) * 100, 2) . '%' : '0%';
          $achievedData[] = $percentage;
        }

        $rowData[] = [$rsmName];
        $rowData[] = array_merge(['Target'], $targetData);
        $rowData[] = array_merge(['Actual'], $actualData);
        $rowData[] = array_merge(['Achieved'], $achievedData);
        $rowData[] = array_fill(0, count($headers), '');
      }

      $sheet->fromArray($rowData, null, 'A2');

      $timestamp = date('Y-m-d_H-i-s');
      $store = storage_path("app/public/uploads/data_analysis/actual_target$timestamp.csv");
      $filePath = "storage/uploads/data_analysis/actual_target$timestamp.csv";

      $writer = new Csv($spreadsheet);
      $writer->setUseBOM(true);
      $writer->save($store);

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Actual Vs Target"]);
      $this->response['data'] = [
        'filePath'     => $filePath ?? '',
        'project_year' => $year,
        'rsm_id'       => $rsmId ?? '',
        'date_range'   => $dateRange ?? '',
      ];
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Actual Vs Target fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $monthlyPlanObject = MonthlyPlan::find($id);

      if (!$monthlyPlanObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Monthly Plan"]);
        return $this->sendResponse($this->response, 500);
      }

      $taskObject = Task::where('monthly_plan_record_id', $id);

      if (!$taskObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Task"]);
        return $this->sendResponse($this->response, 500);
      }

      $monthlyPlanObject->delete();

      $taskObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Monthly Plan"]);
      // $$this->response['data'] = $monthlyPlanObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Lead deleting failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddUpdateMonthlyExcel(Request $request)
  {
    $validator = Validator::make($request->all(), [
      'visit_date' => 'required|date_format:d/m/Y g:i A',
      'customer_name' => 'required',
    ]);

    $validator->sometimes('rsm_id', 'required|integer|exists:users,id', function ($input) use ($request) {
      return empty($request->id);
    });

    $validator->sometimes('target', 'required|numeric|min:0.01', function ($input) use ($request) {
      return empty($request->id);
    });

    $validator->sometimes('plan_type', 'required', function ($input) use ($request) {
      return empty($request->id);
    });

    $validator->sometimes('month', 'required', function ($input) use ($request) {
      return empty($request->id);
    });

    $validator->sometimes('year', 'required', function ($input) use ($request) {
      return empty($request->id);
    });

    return $validator->errors();
  }


  private function validateAddMonthlyPlan(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'rsm_id' => 'required|integer|exists:users,id',
        'target' => 'required|numeric|min:0.01',
        'month' => 'required',
        'year' => 'required',
        'excel' => 'required',
      ]
    )->errors();
  }
}
