<?php

namespace App\Http\Controllers\API;

use App\Models\Supplier;
use App\Models\Instrument;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class InstrumentController extends AppBaseController
{

  public function index(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $instrument = Instrument::withoutTrashed()->orderBy("id", "desc");
      $num_rows = $instrument->count();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Instrument"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = $instrument->limit($per_page)->offset($offset)->get();;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Instrument fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateInstrument($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $instrumentObject = new Instrument();
      $id = $request->id;
      $supplierId = $request->supplier_id;
      $description = $request->description;
      $make = $request->make;
      $range = $request->range;
      $quantity = $request->quantity;
      $leastCount = $request->least_count;
      $lastcalibratedDate = Carbon::createFromFormat('d/m/Y', $request->last_calibrated_date)->format('Y-m-d H:i:s');
      $dueDateForNextCalibration = Carbon::createFromFormat('d/m/Y', $request->due_date_next_calibration)->format('Y-m-d H:i:s');
      $status = $request->status ?? 1;

      if ($id) {
        $instrumentObject = Instrument::find($id);

        if (!$instrumentObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Instrument"]);
          return $this->sendResponse($this->response, 401);
        }

        $instrumentObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Instrument"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Instrument"]);
      }

      $instrumentObject->supplier_id = $supplierId;
      $instrumentObject->description = $description;
      $instrumentObject->make = $make;
      $instrumentObject->range = $range;
      $instrumentObject->quantity = $quantity;
      $instrumentObject->least_count = $leastCount;
      $instrumentObject->last_calibrated_date = $lastcalibratedDate;
      $instrumentObject->due_date_next_calibration = $dueDateForNextCalibration;
      $instrumentObject->status = $status;

      $instrumentObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Instrument: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Instrument"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $id = $request->id ?? '';
      $instrumentObject = Instrument::find($id);

      if (!$instrumentObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Instrument"]);
        return $this->sendResponse($this->response, 401);
      }

      $instrumentObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Instrument"]);
      $this->response['data']['list'] = $instrumentObject;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Instrument fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function getInstrument(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $supplierId = $request->supplier_id ?? '';
      $supplierObject = Supplier::find($supplierId);

      if (!$supplierObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Instrument"]);
        return $this->sendResponse($this->response, 401);
      }

      $instrument = Instrument::where('supplier_id', $supplierId)->withoutTrashed()->orderBy("id", "desc");
      $num_rows = $instrument->count();

      $result = $instrument->limit($per_page)->offset($offset)->get();

      $supplierObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Instrument"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = $result;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Instrument fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $instrumentObject = Instrument::find($id);

      if (!$instrumentObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Instrument"]);
        return $this->sendResponse($this->response, 401);
      }

      $instrumentObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Instrument"]);
      $this->response['data'] = $instrumentObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Instrument Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddUpdateInstrument(Request $request)
  {
    return Validator::make($request->all(), [
      'make' => 'required',
      'range' => 'required',
      'last_calibrated_date' => 'required|date_format:d/m/Y',
      'due_date_next_calibration' => 'date_format:d/m/Y',
      'quantity' => 'required',
    ])->errors();
  }
}
