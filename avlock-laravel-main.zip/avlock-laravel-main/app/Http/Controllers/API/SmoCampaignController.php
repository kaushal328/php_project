<?php

namespace App\Http\Controllers\API;

use Carbon\Carbon;
use App\Models\Menu;
use App\Models\SmoCampaign;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Http\Resources\RoleResource;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class SmoCampaignController extends AppBaseController
{

  public function index(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $platform = $request->platform ?? '';
      $campaign_id = $request->campaign_id ?? '';
      $title = $request->title ?? '';
      $start_date = $request->start_date ?? '';
      $end_date = $request->end_date ?? '';

      $budget = $request->budget ?? '';

      $campaign = SmoCampaign::withoutTrashed()->orderBy("id", "desc");
      $num_rows = $campaign->count();

      if ($platform) {
        $campaign->where('platform', 'like', '%' . $platform . '%');
      }

      if ($campaign_id) {
        $campaign->where('campaign_id', 'like', '%' . $campaign_id . '%');
      }

      if ($title) {
        $campaign->where('title', 'like', '%' . $title . '%');
      }

      if ($start_date) {
        $campaign->where('start_date', '>=', $this->convertToDatabaseDateForSearch($start_date));
      }

      if ($end_date) {
        $campaign->where('end_date', '<=', $this->convertToDatabaseDateForSearch($end_date));
      }

      if ($budget) {
        $campaign->where('budget', $budget);
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "SMO Campaign"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['platform'] = $platform;
      $this->response['data']['campaign_id'] = $campaign_id;
      $this->response['data']['title'] = $title;
      $this->response['data']['start_date'] = $start_date;
      $this->response['data']['end_date'] = $end_date;
      $this->response['data']['budget'] = $budget;
      $this->response['data']['list'] = $campaign->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SMO Campaign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $SmoCampaignObject = SmoCampaign::withoutTrashed()->find($id);

      if (!$SmoCampaignObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "SMO Campaign"]);
        return $this->sendResponse($this->response, 401);
      }
      $SmoCampaignObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "SMO Campaign"]);
      $this->response['data'] = $SmoCampaignObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SMO Campaign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(REQUEST $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateSMOCampaign($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $smoObject = new SmoCampaign();
      $id = $request->id;
      $platform = $request->platform ?? 0;
      $campaign_id = $request->campaign_id ?? 0;
      $title = $request->title ?? 0;
      $start_date = Carbon::createFromFormat('d/m/Y g:i A', $request->start_date)->format('Y-m-d H:i:s');
      $end_date = Carbon::createFromFormat('d/m/Y g:i A', $request->end_date)->format('Y-m-d H:i:s');
      $budget = $request->budget ?? 0;
      $status = $request->status ?? 0;

      if ($id) {
        $smoObject = SmoCampaign::find($id);

        if (!$smoObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "SMO Campaign"]);
          return $this->sendResponse($this->response, 401);
        }

        $smoObject->first();
        $smoObject->updated_by = $this->userId;

        $this->response['msg'] = __('admin.updated', ['module' => "SMO Campaign"]);
      } else {

        $smoObject->created_by = $this->userId;

        $this->response['msg'] = __('admin.created', ['module' => "SMO Campaign"]);
      }

      $smoObject->platform = $platform;
      $smoObject->campaign_id = $campaign_id;
      $smoObject->title = $title;
      $smoObject->start_date = $start_date;
      $smoObject->end_date = $end_date;
      $smoObject->budget = $budget;
      $smoObject->status = $status;
      $smoObject->save();

      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating SMO Campaign: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "SMO Campaign"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $smoObject = SmoCampaign::find($id);

      if (!$smoObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "SMO Campaign"]);
        return $this->sendResponse($this->response, 401);
      }

      $smoObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "SMO Campaign"]);
      $this->response['data'] = $smoObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SMO Campaign Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addReport(REQUEST $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddReport($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $smoCampaignObject = new SmoCampaign();
      $id = $request->id;
      $total_enquiry_received = $request->total_enquiry_received;
      $report_date = $request->report_date ? Carbon::createFromFormat('d/m/Y g:i A', $request->report_date)->format('Y-m-d H:i:s') : null;

      if ($id) {
        $smoCampaignObject = SmoCampaign::find($id);

        if (!$smoCampaignObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "SMO Campaign"]);
          return $this->sendResponse($this->response, 401);
        }

        $smoCampaignObject->first();
        $smoCampaignObject->total_enquiry_received = $total_enquiry_received;
        $smoCampaignObject->report_date = $report_date;

        $this->response['msg'] = __('admin.updated', ['module' => "SMO Campaign"]);
      }

      $smoCampaignObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating SMO Campaign: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "SMO Campaign"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddReport(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'total_enquiry_received' => 'required|integer|numeric',
        'report_date' => 'nullable|date_format:d/m/Y g:i A',
      ],
      [
        'total_enquiry_received.integer' => 'Insert only integer Total value',

        'report_date.date' => 'Invalid Date Format',
        'report_date.date_format' => 'Invalid Date Format',
      ]
    )->errors();
  }

  private function validateAddUpdateSMOCampaign(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'platform' => 'required|string|in:Facebook,Instagram,LinkedIn',
        'campaign_id' => 'required|unique:smo_campaigns,campaign_id,' . $request->id . ',id,deleted_at,NULL',
        'title' => 'required',
        'start_date' => 'required|date_format:d/m/Y g:i A',
        'end_date' => 'required|date_format:d/m/Y g:i A|after:start_date',
        'budget' => 'required|numeric',
        'status' => 'sometimes|required|integer|in:0,1',
      ],
      [
        'platform.in'  => 'Invalid Platform',
        'campaign_id.unique'  => 'Campaign ID is already present with given criteria!',
      ]
    )->errors();
  }
}
