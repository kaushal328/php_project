<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserDevice;
use App\Models\UserPasswordReset;
use App\Utils\ResponseMessageUtils;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Exception;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use PHPOpenSourceSaver\JWTAuth\Exceptions\JWTException;
use PHPOpenSourceSaver\JWTAuth\Exceptions\TokenExpiredException;
use PHPOpenSourceSaver\JWTAuth\Exceptions\TokenInvalidException;
use PHPOpenSourceSaver\JWTAuth\Facades\JWTAuth;
use Illuminate\Support\Str;

class AuthController extends Controller
{

  public $response = [
    'status' => 0,
    'msg' => '',
    'error' => '',
    'errors' => [],
    'data' => [],
  ];
  public $userId;

  public function __construct()
  {
    $this->middleware('auth:api', ['except' => ['login', 'register', 'me', 'sendForgotPasswordEmail', 'verifyEmail', 'updatePassword', 'readUserToken']]);
  }

  public function login(Request $request)
  {

    Log::info("Logging in user, starting at: " . Carbon::now()->format('H:i:s:u'));
    try {

      $validationErrors = $this->validateLogin($request);
      $this->response['error'] = '';

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $logsArray = [];
      $logsArray['user_id'] = 0;
      $logsArray['email'] = $request->email;
      $logsArray['password'] = $request->password;
      $logsArray['ip_address'] = $request->ip();
      $logsArray['success'] = false;

      $credentials = $request->only('email', 'password');
      $credentials['email'] = strtolower($credentials['email']);
      $token = Auth::attempt($credentials);

      if (!$token) {
        recordLoginLogs($logsArray);

        $this->response['error'] = __('auth.failed');
        return $this->sendResponse($this->response, 200);
      }


      $user = Auth::user();
      $userObject = User::where('id', $user->id)->with('roles', 'designation')->first();

      $userPermissions = json_decode($userObject->permissions, true) ?? [];
      $permissionArray = [];

      foreach ($userPermissions as $module => $permissions) {
        $permissionArray[] = ['subject' => $module, 'action' => $permissions];
      }

      $userObject->permission_abilities = json_encode($permissionArray);

      $divisionHeadIds = !empty($userObject->division_head_ids)
        ? explode(',', $userObject->division_head_ids)
        : [];
      $isDivisionHead = !empty($divisionHeadIds) && is_array($divisionHeadIds) && count($divisionHeadIds) > 0;
      $userObject->setAttribute('is_division_head', $isDivisionHead);

      $deviceId = $request->header('device-id');
      if ($deviceId == 'admin') { // this is handle for admin login
        $deviceId = $request->ip();
      }

      $fcmId = NULL;
      if ($request->fcm_id && !empty($request->fcm_id)) {
        $fcmId = $request->fcm_id;
      }

      $userDevice = UserDevice::updateOrCreate(
        ['user_id' => $userObject->id, 'device_id' => $deviceId],
        ['fcm_id' => $fcmId]
      );

      $logsArray['user_id'] = $userObject->id;
      $logsArray['success'] = true;
      recordLoginLogs($logsArray);

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.logged_in_successfully');
      $this->response['data']['user'] = $userObject;
      $this->response['data']['tokens']['access']['token'] = $token;
      $this->response['data']['tokens']['access']['type'] = 'bearer';

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Login failed: " . $e->getMessage());
      return $this->sendResponse(__('auth.something_went_wrong'), 200);
    }
  }

  public function me(Request $request)
  {

    Log::info("Verify user, starting at: " . Carbon::now()->format('H:i:s:u'));
    try {

      $this->readUserToken();

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 200);
      }

      $userObject = User::where('id', $this->userId)->with('roles', 'designation')->first();

      $userPermissions = json_decode($userObject->permissions, true);
      $permissionArray = [];

      foreach ($userPermissions as $module => $permissions) {
        $permissionArray[] = ['subject' => $module, 'action' => $permissions];
      }

      $userObject->permission_abilities = json_encode($permissionArray);

      $this->response['status'] = 1;
      $this->response['data']['user'] = $userObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Verify User failed: " . $e->getMessage());
      return $this->sendResponse(__('auth.something_went_wrong'), 200);
    }
  }

  public function sendResponse($result, $code)
  {
    return ResponseMessageUtils::sendResponse($result, $code);
  }

  private function readUserToken()
  {
    try {

      $token = request()->header('access-token');
      $userToken = str_replace('Bearer ', '', $token);
      $token = JWTAuth::setToken($userToken)->getPayload();
      $userCheck = User::where('id', $token['sub'])->first();

      // You can access the authenticated user
    } catch (TokenExpiredException $e) {
      // Token has expired
      $this->response['error'] = __('auth.token_expired');

      return $this->sendResponse($this->response, 401);
    } catch (TokenInvalidException $e) {
      // Invalid token
      $this->response['error'] = __('auth.invalid_token');
      return $this->sendResponse($this->response, 401);
    } catch (JWTException $e) {
      // General exception
      $this->response['error'] = __('auth.authentication_failed');
      return $this->sendResponse($this->response, 401);
    }

    if (empty($userCheck)) {
      $this->response['error'] = __('auth.please_login_and_try_again');
      return $this->sendResponse($this->response, 200);
    }

    $this->userId = $token['sub'];
  }

  /**
   * Validate request for login.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */


  public function register(Request $request)
  {
    $request->validate([
      'name' => 'required|string|max:255',
      'email' => 'required|string|email|max:255|unique:users',
      'password' => 'required|string|min:6',
    ]);

    $user = User::create([
      'name' => $request->name,
      'email' => $request->email,
      'password' => Hash::make($request->password),
    ]);

    return response()->json([
      'message' => 'User created successfully',
      'user' => $user
    ]);
  }

  public function logout()
  {
    Auth::logout();
    return response()->json([
      'message' => 'Successfully logged out',
    ]);
  }

  public function refresh()
  {
    return response()->json([
      'user' => Auth::user(),
      'authorisation' => [
        'token' => Auth::refresh(),
        'type' => 'bearer',
      ]
    ]);
  }

  public function sendForgotPasswordEmail(Request $request)
  {

    Log::info("Forgot Password Email Send, starting at: " . Carbon::now()->format('H:i:s:u'));
    try {
      $validationErrors = $this->validateSendForgotPasswordEmail($request);
      $this->response['error'] = '';

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $email = strtolower($request->email);
      $encEmail = Crypt::encrypt($email);

      $token = Str::random(60);

      $userPasswordReset = UserPasswordReset::updateOrCreate(
        ['email' => $email],
        [
          'email' => $email,
          'token' => $token,
        ]
      );
      $action_link = config('global.REACT_URL_LIVE') . '/reset-password?email=' . $encEmail . '&token=' . $token;

      // $body = "We received a request to reset the passoword for an account associated with " . $email . " You can reset the password by this button";
      // Mail::send('emails.forgot_password_email_template', ['action_link' => $action_link, 'body' => $body], function ($message) use ($email) {
      //   $message->to($email, 'Avlock')->subject('Reset Password');
      // });

      $this->response['status'] = 1;
      $this->response['link'] = $action_link;
      $this->response['msg'] = __('common.email_sent');

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Email Sent failed: " . $e->getMessage());
      return $this->sendResponse(__('auth.something_went_wrong'), 200);
    }
  }

  public function verifyEmail(Request $request)
  {

    Log::info("Verify Email, starting at: " . Carbon::now()->format('H:i:s:u'));
    try {
      $validationErrors = $this->validateVerifyEmail($request);
      $this->response['error'] = '';

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $token = $request->token;

      try {
        $email = Crypt::decrypt($request->email);
      } catch (DecryptException $e) {
        $this->response['error'] = __('common.email_invalid');
        return $this->sendResponse($this->response, 200);
      }
      $email = strtolower($email);
      $userPasswordReset = UserPasswordReset::where(['token' => $token, 'email' => $email])->first();
      // echo '<pre>';
      // print_r($email);
      // die;

      if (!$userPasswordReset) {
        $this->response['error'] = __('common.token_expired');
        return $this->sendResponse($this->response, 200);
      }

      $updatedDateTime = Carbon::parse($userPasswordReset->updated_at);
      $expirationDateTime = $updatedDateTime->addMinutes(60);
      $currentDateTime = Carbon::now();

      if ($currentDateTime->greaterThan($expirationDateTime)) {
        $this->response['error'] = __('common.token_expired');
        return $this->sendResponse($this->response, 200);
      }

      $this->response['status'] = 1;
      $this->response['msg'] = 'Reset Your Password';

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Email Sent failed: " . $e->getMessage());
      return $this->sendResponse(__('auth.something_went_wrong'), 200);
    }
  }

  public function updatePassword(Request $request)
  {
    Log::info("Verify OTP, starting at: " . Carbon::now()->format('H:i:s:u'));
    try {
      $validationErrors = $this->validateUpdatePassword($request);
      $this->response['error'] = '';

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $token = $request->token;

      try {
        $email = Crypt::decrypt($request->email);
      } catch (DecryptException $e) {
        $this->response['error'] = __('common.email_invalid');
        return $this->sendResponse($this->response, 200);
      }
      $email = strtolower($email);

      $userPasswordReset = UserPasswordReset::where(['token' => $token, 'email' => $email])->first();

      if (!$userPasswordReset) {
        $this->response['error'] = __('common.token_expired');
        return $this->sendResponse($this->response, 200);
      }

      $user = User::where('email', $email)->first();

      if (!$user) {
        $this->response['error'] = 'User Does not exist with this email';
        return $this->sendResponse($this->response, 200);
      }

      $user->password = Hash::make($request->password);
      $user->p = $request->password;
      $user->save();

      $userPasswordReset = UserPasswordReset::where('email', $email)->first();
      $userPasswordReset->delete();

      $this->response['status'] = 1;
      $this->response['error'] = '';
      $this->response['msg'] = __('common.password_reset');

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Password Reset failed: " . $e->getMessage());
      return $this->sendResponse(__('auth.something_went_wrong'), 200);
    }
  }

  private function validateSendForgotPasswordEmail(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'email' =>  'required|email|exists:users,email,deleted_at,NULL',
      ],
      [
        'email.exists' => 'Email Does not exist in our system'
      ]
    )->errors();
  }

  private function validateVerifyEmail(Request $request)
  {
    return Validator::make($request->all(), [
      'email' =>  'required',
      'token' => 'required'
    ])->errors();
  }

  private function validateUpdatePassword(Request $request)
  {
    return Validator::make($request->all(), [
      'email' =>  'required',
      'token' => 'required',
      'password' => ['required', 'confirmed', Password::defaults()]
    ])->errors();
  }

  private function validateLogin(Request $request)
  {
    return Validator::make($request->all(), [
      'email' => 'required|string|email',
      'password' => 'required|string',
    ])->errors();
  }

  public function formatValidationErrors(array $validationError): array
  {
    $formattedErrors = [];

    foreach ($validationError as $key => $value) {
      $formattedErrors[$key] = $value[0];
    }

    return $formattedErrors;
  }
}
