<?php

namespace App\Http\Controllers\API;

use Exception;
use Carbon\Carbon;
use App\Models\Rfq;
use App\Models\Lead;
use App\Models\Task;
use App\Models\User;
use App\Enums\TaskFrom;
use App\Models\Activity;
use App\Models\LoginLog;
use App\Models\Reminder;
use App\Models\ProjectLog;
use App\Models\MonthlyPlan;
use App\Models\ProjectType;
use Illuminate\Http\Request;
use App\Models\PurchaseOrder;
use App\Events\TaskLogCreated;
use App\Models\UserAttendance;
use App\Models\PurchaseInvoice;
use App\Models\MonthlyPlanExcel;
use App\Models\ProjectQuotation;
use App\Models\SalesVisitReport;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Resources\LeadResource;
use App\Http\Resources\StatusResource;
use App\Models\PurchaseInvoicePayment;
use App\Http\Resources\RfqListResource;
use App\Http\Resources\ActivityResource;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\ProjectLogResource;
use App\Http\Controllers\API\AppBaseController;
use App\Http\Resources\PurchaseInvoiceResource;
use App\Http\Resources\SalesVisitReportResource;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class DashboardController extends AppBaseController
{

  public function index(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $dashboardData = [];
      $dashboardData['isUserRSM'] = $this->isUserRSM;
      $dashboardData['isUserInsideSale'] = $this->isUserInsideSale;
      $dashboardData['isUserPSM'] = $this->isUserPSM;
      $dashboardData['isUserDispatch'] = $this->isUserDispatch;

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Dashboard Data"]);
      $this->response['data'] = $dashboardData;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Dashboard Data fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function taskList(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $perPage = (isset($request->perPage) && $request->perPage != 'undefined') ? intval($request->perPage) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $perPage;

      $title = $request->title ?? '';

      // $status = Task::orWhere('fk_user_id', $this->userId )->orWhere('created_by', $this->userId )->with('statuses', 'taskType', 'lead', 'rfq')->orderBy("id", "desc");
      $status = Task::with('statuses', 'taskType', 'lead', 'rfq')->orderBy("id", "desc");

      if (!$this->isUserAdmin) {
        $status->whereHas('assignedToUsers', function ($query) {
          $query->where('created_by', $this->userId);
          $query->orWhere('fk_user_id', $this->userId);
        });
      }

      $numRows = $status->count();
      $status = $status->limit($perPage)->offset($offset)->get();

      if ($title) {
        $status->where('title', 'like', '%' . $title . '%');
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Task"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $perPage;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $perPage ? 1 : ceil($numRows / $perPage);
      $this->response['data']['title'] = $title;
      $this->response['data']['list'] = StatusResource::collection($status);
      $this->response['data']['events'] = StatusResource::collection($status);

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Task fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function taskStatList(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }


      $status = Task::where('fk_status_id', 1);
      $pendingTask = $status->count();

      $status = Task::where('fk_status_id', 2);
      $assignTask = $status->count();

      $status = Task::where('fk_status_id', 3);
      $declineTask = $status->count();

      $status = Task::where('fk_status_id', 4);
      $inprocTask = $status->count();

      $status = Task::where('fk_status_id', 4);
      $complTask = $status->count();

      $list = ['pendingTask' => $pendingTask, 'assignTask' => $assignTask, 'declineTask' => $declineTask, 'inprocTask' => $inprocTask, 'complTask' => $complTask];

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Task"]);
      $this->response['data']['page'] = 1;
      $this->response['data']['per_page'] = 5;
      $this->response['data']['num_rows'] = 0;
      $this->response['data']['total_pages'] = 0;
      $this->response['data']['list'] = $list;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Task fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function activityList(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';
      $start = $request->start ?? '';
      $end = $request->end ?? '';
      $taskType = $request->taskType ?? '';

      // $activity = Activity::orWhere('fk_user_id', $this->userId )->orWhere('created_by', $this->userId )->with('taskType', 'lead', 'rfq');
      $activity = Activity::with('taskType', 'lead', 'rfq', 'user');
      if (!$this->isUserAdmin) {
        $activity->where('fk_user_id', $this->userId);
      }
      $num_rows = $activity->count();

      if ($title) {
        $activity->where('title', 'like', '%' . $title . '%');
      }

      if ($start) {
        $activity->where('start', '>=', $this->convertToDatabaseDateForSearch($start));
      }

      if ($end) {
        $activity->where('end', '<=', $this->convertToDatabaseDateForSearch($end));
      }

      if ($taskType) {
        $activity->where('fk_task_type_id', '=', $taskType);
      }

      $activity->where('fk_user_id', '=', $this->userId);

      $result = $activity->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Activity"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['start'] = $start;
      $this->response['data']['end'] = $end;
      $this->response['data']['taskType'] = $taskType;
      $this->response['data']['list'] = ActivityResource::collection($result);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Activity fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function saleVisitList(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $visitDate = $request->visit_date ?? '';
      $reportNo = $request->report_no ?? '';
      $customerName = $request->customer_name ?? '';
      $salesPerson = $request->sales_person ?? '';

      $svr = SalesVisitReport::with('reportSalesPerson', 'product', 'user');

      if (!$this->isUserAdmin) {
        $svr->where('sales_person', $this->userId);
      }
      $num_rows = $svr->count();

      if ($visitDate) {
        $svr->where('visit_date', '>=', $this->convertToDatabaseDateForSearch($visitDate));
      }

      if ($salesPerson) {
        $svr->where('sales_person', '=', $salesPerson);
      }

      if ($customerName) {
        $svr->where('customer_name', 'like', '%' . $customerName . '%');
      }

      if ($reportNo) {
        $svr->where('report_no', 'like', '%' . $reportNo . '%');
      }

      $result = $svr->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Sales Module"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['visit_date'] = $visitDate;
      $this->response['data']['sales_person'] = $salesPerson;
      $this->response['data']['customer_name'] = $customerName;
      $this->response['data']['report_no'] = $reportNo;
      $this->response['data']['list'] = SalesVisitReportResource::collection($result);
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function leadList(REQUEST $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $enquiryDate = $request->enquiry_date ?? '';
      $fkRegionId = $request->fk_region_id ?? '';
      $customerName = $request->customer_name ?? '';
      $company = $request->company ?? '';
      $email = $request->email ?? '';
      $contactNo = $request->contact_no ?? '';
      $fkSourceId = $request->fk_source_id ?? '';
      $SMOPlatform = $request->smo_platform ?? '';
      $adwordsPlatform = $request->adwords_platform ?? '';
      $fkRsmrId = $request->fk_rsmr_id ?? '';
      $fkRsmvId = $request->fk_rsmv_id ?? '';
      $reference = $request->reference ?? '';

      $lead = Lead::with('region', 'source', 'rsmr', 'rsmv', 'designation')->orderBy('id', 'desc');
      $num_rows = $lead->count();

      if ($enquiryDate) {
        $lead->where('enquiry_date', '>=', Carbon::createFromFormat('d/m/Y g:i A', $enquiryDate)->format('Y-m-d H:i:s'));
      }

      if ($fkRegionId) {
        $lead->where('fk_region_id', '=', $fkRegionId);
      }

      if ($customerName) {
        $lead->where('customer_name', 'like', '%' . $customerName . '%');
      }

      if ($company) {
        $lead->where('company', 'like', '%' . $company . '%');
      }

      if ($email) {
        $lead->where('email', 'like', '%' . $email . '%');
      }

      if ($contactNo) {
        $lead->where('contact_no', 'like', '%' . $contactNo . '%');
      }

      if ($fkSourceId) {
        $lead->where('fk_source_id', '=', $fkSourceId);
      }

      if ($SMOPlatform) {
        $lead->where('smo_platform', 'like', '%' . $SMOPlatform . '%');
      }

      if ($adwordsPlatform) {
        $lead->where('adwords_platform', 'like', '%' . $adwordsPlatform . '%');
      }

      if ($fkRsmrId) {
        $lead->where('fk_rsmr_id', '=', $fkRsmrId);
      }

      if ($fkRsmvId) {
        $lead->where('fk_rsmv_id', '=', $fkRsmvId);
      }

      if ($reference) {
        $lead->where('reference', 'like', '%' . $reference . '%');
      }

      $result = $lead->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Lead"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['enquiry_date'] = $enquiryDate;
      $this->response['data']['fk_region_id'] = $fkRegionId;
      $this->response['data']['customer_name'] = $customerName;
      $this->response['data']['company'] = $company;
      $this->response['data']['email'] = $email;
      $this->response['data']['contact_no'] = $contactNo;
      $this->response['data']['fk_source_id'] = $fkSourceId;
      $this->response['data']['smo_platform'] = $SMOPlatform;
      $this->response['data']['adwords_platform'] = $adwordsPlatform;
      $this->response['data']['fk_rsmr_id'] = $fkRsmrId;
      $this->response['data']['fk_rsmv_id'] = $fkRsmvId;
      $this->response['data']['reference'] = $reference;
      $this->response['data']['list'] = LeadResource::collection($result);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Lead fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  function projectList(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      // $leadId = $request->lead_id ?? "";
      $rfqNumber = $request->rfq_number ?? "";

      // $lead = Lead::find($leadId);

      // if (!$lead) {
      //   $this->response['error'] = "Invalid lead selected!";
      //   return $this->sendResponse($this->response, 200);
      // }

      $rfqListResource = Rfq::with('product');
      // $rfqListResource->where('lead_id', $lead->id);
      if ($rfqNumber) $rfqListResource->where('rfq_number', 'like', "%" . $rfqNumber . "%");
      $result = $rfqListResource->get();

      $rfqList = RfqListResource::collection($result);

      $this->response['status'] = 1;
      $this->response['data'] = [
        'rfq_number' => $rfqNumber,
        'list' => $rfqList
      ];

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Rfq List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function lastLogin(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $this->userId;

      $userObject = User::find($id);

      if (!$userObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "User"]);
        return $this->sendResponse($this->response, 401);
      }

      $userLog = LoginLog::select('created_at')->where('user_id', $id)->orderBy('id', 'desc')->limit(1)->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "User"]);
      $this->response['data'] = $userLog;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("User fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function attendanceList(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $perPage = (isset($request->perPage) && $request->perPage != 'undefined') ? intval($request->perPage) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $perPage;

      $userAttendance = UserAttendance::with('user')->orderBy("id", "desc");
      $numRows = $userAttendance->count();

      if (!$this->isUserAdmin) {
        $userAttendance->where('fk_user_id', $this->userId);
      }

      $result = $userAttendance->limit($perPage)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "User Attendance"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $perPage;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $perPage ? 1 : ceil($numRows / $perPage);
      $this->response['data']['list'] = $result;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("User attendance fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function projectHistoryList(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $projectLogs = ProjectLog::with('stage', 'subStage', 'po', 'rfq.quotation')->orderBy("id", "desc");

      if (!$this->isUserAdmin) {
        $projectLogs->whereRaw("created_by = " . $this->userId . " OR FIND_IN_SET(?, curr_user_ids) > 0", [$this->userId]);
      }

      $result = $projectLogs->limit(5)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Project Logs"]);

      $this->response['data']['list'] = ProjectLogResource::collection($result);

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Project Log fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function getRsmDashboardData(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $dashboardData = $this->rsmData($this->userId);

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "RSM Dashboard Data"]);
      $this->response['data'] = $dashboardData;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("RSM Dashboard Data fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }


  private function rsmData(int $rsmUserId): array
  {

    $rawLeadCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNull('customer_name')
      ->whereNull('company')
      ->whereNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->with('svr', 'rfqs')
      ->whereDoesntHave('rfqs')
      ->whereDoesntHave('svr')
      ->count();

    $potentialLeadCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNotNull('customer_name')
      ->whereNotNull('company')
      ->whereNotNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->with('svr', 'rfqs')
      ->whereDoesntHave('rfqs')
      ->whereDoesntHave('svr')
      ->count();

    $prospectLeadCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNotNull('customer_name')
      ->whereNotNull('company')
      ->whereNotNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->whereHas('svr', function ($query) {
        $query->whereNull('application_details');
      })
      ->with('svr', 'rfqs')
      ->whereDoesntHave('rfqs')
      ->count();

    $qualifiedLeadCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNotNull('customer_name')
      ->whereNotNull('company')
      ->whereNotNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->whereHas('svr', function ($query) {
        $query->whereNotNull('application_details');
      })
      ->with('svr', 'rfqs')
      ->whereDoesntHave('rfqs')
      ->count();


    $leadFinalizedCount  = Lead::whereNotNull('contact_no')
      ->whereNotNull('email')
      ->whereNotNull('customer_name')
      ->whereNotNull('company')
      ->whereNotNull('address1')
      ->where('assigned_rsm', $rsmUserId)
      ->whereHas('svr', function ($query) {
        $query->whereNotNull('application_details');
      })
      ->with('svr', 'rfqs')
      ->whereHas('rfqs')
      ->count();

    $leadCount = Lead::where('assigned_rsm', $rsmUserId)->count();
    $rfqCount = Rfq::where('assigned_rsm', $rsmUserId)->count();

    $upComingVisitsCount = Task::with('assignedToUsers')
      ->whereMonth('start', now()->month)
      ->where('task_from', TaskFrom::MONTHLY_PLAN->value)
      ->whereHas('assignedToUsers', function ($query) use ($rsmUserId) {
        $query->where('fk_user_id', $rsmUserId);
      })->count();

    // $upComingVisitsCount = Task::with('assignedToUsers')
    // ->where('start', '>=', now())
    // ->where('start', '<=', now()->addMonths(3))
    // ->where('task_from', TaskFrom::MONTHLY_PLAN->value)
    // ->whereHas('assignedToUsers', function ($query) use ($rsmUserId) {
    //     $query->where('fk_user_id', $rsmUserId);
    // })
    // ->selectRaw('DATE_FORMAT(start, "%Y-%m") as month, COUNT(*) as count')
    // ->groupBy('month')
    // ->get();

    // foreach ($upComingVisitsCount as $monthCount) {
    //   echo "Month: " . $monthCount->month . ", Count: " . $monthCount->count . "<br>";
    // }

    $plannedVisitCount = Task::with('assignedToUsers')
      ->where('fk_status_id', '!=', 5)
      ->whereMonth('start', now()->month)
      ->where('task_from', TaskFrom::MONTHLY_PLAN->value)
      ->whereHas('assignedToUsers', function ($query) use ($rsmUserId) {
        $query->where('fk_user_id', $rsmUserId);
      })->count();

    $completedVisitCount = Task::with('assignedToUsers')
      ->where('fk_status_id', 5)
      ->whereMonth('start', now()->month)
      ->where('task_from', TaskFrom::MONTHLY_PLAN->value)
      ->whereHas('assignedToUsers', function ($query) use ($rsmUserId) {
        $query->where('fk_user_id', $rsmUserId);
      })->count();

    $taskCount = Task::with('assignedToUsers')
      ->whereHas('assignedToUsers', function ($query) use ($rsmUserId) {
        $query->where('fk_user_id', $rsmUserId);
      })->count();

    $reminderCount = Reminder::with('reminderUser')
      ->whereHas('reminderUser', function ($query) use ($rsmUserId) {
        $query->where('fk_user_id', $rsmUserId);
      })->count();

    $purchaseInvoiceCount = PurchaseInvoice::with('lead')
    ->whereHas('lead', function ($query) use ($rsmUserId) {
      $query->where('assigned_rsm', $rsmUserId);
    })->count();

    $purchaseInvoicePaymentCount = PurchaseInvoicePayment::with('lead')
    ->whereHas('lead', function ($query) use ($rsmUserId) {
      $query->where('assigned_rsm', $rsmUserId);
    })->count();

    $monthlyTargetSum = MonthlyPlanExcel::where('rsm_id', $rsmUserId)->sum('target');

    $outStandingPayment = PurchaseInvoice::with('lead')
    ->whereHas('lead', function ($query) use ($rsmUserId) {
      $query->where('assigned_rsm', $rsmUserId);
    })->sum('pi_total_amount_pending');
    
    $data = [
      'rawLeadCount' => $rawLeadCount,
      'potentialLeadCount' => $potentialLeadCount,
      'prospectLeadCount' => $prospectLeadCount,
      'qualifiedLeadCount' => $qualifiedLeadCount,
      'leadFinalizedCount' => $leadFinalizedCount,
      'leadCount' => $leadCount,
      'rfqCount' => $rfqCount,
      'upComingVisitsCount' => $upComingVisitsCount,
      'plannedVisitCount' => $plannedVisitCount,
      'completedVisitCount' => $completedVisitCount,
      'taskCount' => $taskCount,
      'reminderCount' => $reminderCount,
      'purchaseInvoiceCount' => $purchaseInvoiceCount,
      'purchaseInvoicePaymentCount' => $purchaseInvoicePaymentCount,
      'monthlyTargetSum' => $monthlyTargetSum,
      'currentMonth' => Carbon::now()->format('F'),
      'outStandingPayment' => $outStandingPayment,
    ];
    return $data;
  }

  public function getInsideSalesData(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $dashboardData = $this->insideSalesData($this->userId);

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Inside Sales Dashboard Data"]);
      $this->response['data'] = $dashboardData;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Inside Sales Dashboard Data fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function insideSalesData(int $insideSaleUserId): array
  {
    $purchaseOrderCount = getPoCount();
    $projectQuotationCount = getPoCount();
    $rfqCount = getRfqCount();

    $result = Rfq::with('product', 'lead', 'stage', 'subStage', 'projectType', 'projectSegment')
      ->whereIn('curr_sub_stage_id', config('global.INSIDE_SALES_STAGE'))
      ->whereRaw("FIND_IN_SET(?, curr_user_ids) > 0", [$insideSaleUserId])
      ->orderBy('updated_at', 'desc')->get();
    $rfqOnInsideSaleStage = RfqListResource::collection($result);

    $data = [
      'purchaseOrderCount' => $purchaseOrderCount,
      'projectQuotationCount' => $projectQuotationCount,
      'rfqCount' => $rfqCount,
      'rfqOnInsideSaleStage' => $rfqOnInsideSaleStage
    ];

    return $data;
  }

  public function getPsmData(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $dashboardData = $this->psmData($this->userId);

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "PSM Dashboard Data"]);
      $this->response['data'] = $dashboardData;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("PSM Dashboard Data fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function psmData(int $psmUserId): array
  {
    $purchaseOrderCount = getPoCount();
    $projectQuotationCount = getPoCount();
    $rfqCount = getRfqCount();

    $result = Rfq::with('product', 'lead', 'stage', 'subStage', 'projectType', 'projectSegment')
      ->whereIn('curr_sub_stage_id', config('global.PSM_STAGE'))
      ->whereRaw("FIND_IN_SET(?, curr_user_ids) > 0", [$psmUserId])
      ->orderBy('updated_at', 'desc')->get();
    $rfqOnPsmStage = RfqListResource::collection($result);

    $data = [
      'purchaseOrderCount' => $purchaseOrderCount,
      'projectQuotationCount' => $projectQuotationCount,
      'rfqCount' => $rfqCount,
      'rfqOnPsmStage' => $rfqOnPsmStage
    ];

    return $data;
  }

  public function getDispatchData(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $dashboardData = $this->dispatchData($this->userId);

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Dispatch Dashboard Data"]);
      $this->response['data'] = $dashboardData;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Dispatch Dashboard Data fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function dispatchData(int $dispatchUserId): array
  {
    $purchaseOrderCount = getPoCount();
    $projectQuotationCount = getPoCount();
    $rfqCount = getRfqCount();

    $result = Rfq::with('product', 'lead', 'stage', 'subStage', 'projectType', 'projectSegment')
      ->whereIn('curr_sub_stage_id', config('global.DISPATCH_STAGE'))
      ->whereRaw("FIND_IN_SET(?, curr_user_ids) > 0", [$dispatchUserId])
      ->orderBy('updated_at', 'desc')->get();
    $rfqOnDispatchStage = RfqListResource::collection($result);

    $data = [
      'purchaseOrderCount' => $purchaseOrderCount,
      'projectQuotationCount' => $projectQuotationCount,
      'rfqCount' => $rfqCount,
      'rfqOnDispatchStage' => $rfqOnDispatchStage
    ];

    return $data;
  }

  public function customerVisitPlanReport(Request $request){
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      // if (!$this->isAdvisor) {
      //   $this->response['error'] = __('auth.authentication_failed');
      //   return $this->sendResponse($this->response, 401);
      // }

      $validationErrors = $this->validateCustomerVisitReport($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $salesPerson = $request->sales_person;
      $month = $request->month;
      $year = $request->year;

      $weeks = $this->getWeeks($month, $year);

      $projectTypes = ProjectType::where('status', 1)->get();

      $res = [];
      foreach ($projectTypes as $key => $projectType) {
          $res[$key]['project_type'] = $projectType['name'];
          $totalPlannedVisits = 0;
          $totalCompletedVisits = 0;

          foreach ($weeks as $k => $week) {
            // $rsmUserId = $this->userId;

            $plannedVisit = Task::with('assignedToUsers', 'lead')
                ->where('fk_status_id', '!=', 5)
                ->whereBetween('start', [$week['start'], $week['end']])
                ->where('task_from', TaskFrom::MONTHLY_PLAN->value)
                ->where('fk_lead_id', '!=', 0)
                ->whereHas('assignedToUsers', function ($query) use ($salesPerson) {
                    $query->whereIn('fk_user_id', $salesPerson);
                })
                ->whereHas('lead', function ($q) use ($projectType) {
                    $q->where('customer_type', $projectType->id);
                })->count();

            $totalPlannedVisits += $plannedVisit;

            $completedVisit = Task::with('assignedToUsers', 'lead')
                ->where('fk_status_id', 5)
                ->whereBetween('start', [$week['start'], $week['end']])
                ->where('task_from', TaskFrom::MONTHLY_PLAN->value)
                ->where('fk_lead_id', '!=', 0)
                ->whereHas('assignedToUsers', function ($query) use ($salesPerson) {
                    $query->whereIn('fk_user_id', $salesPerson);
                })
                ->whereHas('lead', function ($q) use ($projectType) {
                    $q->where('customer_type', $projectType->id);
                })
                ->count();

              $totalCompletedVisits += $completedVisit;

            $res[$key][$week['title']]['plannedVisit'] = $plannedVisit;
            $res[$key][$week['title']]['completedVisit'] = $completedVisit;
        }

        $res[$key]['totalPlannedVisit'] = $totalPlannedVisits;
        $res[$key]['totalCompletedVisits'] = $totalCompletedVisits;
        
      }

      // Calculate the total of totalPlannedVisit and totalCompletedVisits across all project types
      $totalPlannedVisitAllProjectTypes = 0;
      $totalCompletedVisitsAllProjectTypes = 0;

      foreach ($res as $project) {
        $totalPlannedVisitAllProjectTypes += $project['totalPlannedVisit'];
        $totalCompletedVisitsAllProjectTypes += $project['totalCompletedVisits'];
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  'Report Generated Succesfully';
      $this->response['data']['list'] = $res;
      $this->response['data']['totalPlannedVisitAllProjectTypes'] = $totalPlannedVisitAllProjectTypes;
      $this->response['data']['totalCompletedVisitsAllProjectTypes'] = $totalCompletedVisitsAllProjectTypes;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }
  
  protected function validateCustomerVisitReport(Request $request) {
    return Validator::make(
      $request->all(),
      [
        'sales_person' => 'required',
        'month' => 'required',
        'year' => 'required',

      ],
    )->errors();
  }

  protected function getWeeks($month, $year){
    $weeks = [];

    $startDate = \Carbon\Carbon::create($year, $month, 1);
    $daysInMonth = $startDate->daysInMonth;
    
    $weekCounter = 1;
    for ($day = 1; $day <= $daysInMonth; $day++) {
      $currentDate = $startDate->copy()->day($day);

      if ($currentDate->isSunday()) {
        $week = [
          'title' => 'Week ' . $weekCounter,
          'start' => $currentDate->format('Y-m-d'),
        ];
        $week['end'] = $currentDate->copy()->addDays(6)->format('Y-m-d');
        $weekCounter++;
        $weeks[] = $week;
      }
    }
    
    return $weeks;
  }


}
