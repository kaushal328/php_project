<?php

namespace App\Http\Controllers\API;

use Exception;
use Carbon\Carbon;
use App\Models\Lead;
use App\Models\Tender;
use Illuminate\Http\Request;
use App\Models\PurchaseInvoice;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Models\TenderPurchaseInvoice;
use App\Models\PurchaseInvoicePayment;
use Illuminate\Support\Facades\Validator;
use App\Models\TenderPurchaseInvoicePayment;
use App\Http\Resources\PurchaseInvoicePaymentResource;
use App\Http\Resources\TenderPurchasePayementResource;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class TenderPurchaseInvoicePaymentsController extends AppBaseController {
  
  function index(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $fk_pi_id = $request->fk_pi_id ?? "";
      $fk_tender_id = $request->lead ?? "";
      $payment_date = $request->payment_date ?? '';
      $payment_amount = $request->payment_amount ?? '';

      $tpiPaymentObject = TenderPurchaseInvoicePayment::orderBy('id', 'desc');

      if ($fk_tender_id) $tpiPaymentObject->where("fk_tender_id", $fk_tender_id);
      if ($fk_pi_id) $tpiPaymentObject->whereRaw("FIND_IN_SET(?, fk_pi_id) > 0", [$fk_pi_id]);
      if ($payment_date) $tpiPaymentObject->where('payment_date', '>=', $this->convertToDatabaseDateForSearch($payment_date));
      if ($payment_amount) $tpiPaymentObject->where('payment_amount', 'like', '%' . $payment_amount . '%');

      $num_rows = $tpiPaymentObject->count();

      $result = $tpiPaymentObject->limit($per_page)->offset($offset)->get();
      $tpiPaymentList = TenderPurchasePayementResource::collection($result);

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Purchase Invoice"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['fk_pi_id'] = $fk_pi_id;
      $this->response['data']['payment_date'] = $payment_date;
      $this->response['data']['payment_amount'] = $payment_amount;
      $this->response['data']['list'] = $tpiPaymentList;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Purchase Payment Invoice List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function get(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $piId = $request->pi_id ?? "";

      if (!$piId) {
        $this->response['error'] = "Please select a valid Tender Purchase Invoice!";
        return $this->sendResponse($this->response, 200);
      }

      $piPaymentObject = TenderPurchaseInvoicePayment::find($piId);

      if (!$piPaymentObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Purchase Invoice"]);
        return $this->sendResponse($this->response, 200);
      }


      $this->response['status'] = 1;
      $this->response['data'] = new TenderPurchaseInvoicePaymentResource($piPaymentObject);

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Tender Purchase Invoice Payment Details fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(Request $request) {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateTenderPurchaseInvoice($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $tenderId = $request->tender;

      $tenderObject = Tender::find($tenderId);

      if (!$tenderObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Tender"]);
        return $this->sendResponse($this->response, 200);
      }

      $tpiPaymentObject = new TenderPurchaseInvoicePayment();
      $tenderPurchaseInvoices = $request->tender_purchase_invoices ?? [];

      $payment_date = Carbon::createFromFormat('d/m/Y g:i A', $request->payment_date)->format('Y-m-d H:i:s');
      $payment_amount = $request->payment_amount;
      $remark = $request->remark;

      $fk_pi_id = '';

      if (!empty($tenderPurchaseInvoices)) {
        $purchaseInvoiceIdsArray = array_column($tenderPurchaseInvoices, 'id');

        $sumOfInvoices = TenderPurchaseInvoice::whereIn('id', $purchaseInvoiceIdsArray)
          ->sum('pi_total_amount_pending');

        if (count($tenderPurchaseInvoices) == 1 && $payment_amount > $sumOfInvoices) {
          $this->response['errors'] = ['payment_amount' => "Payment Amount Should not greater than the Total invoice amount you selected i.e. " .  $sumOfInvoices];
          return $this->sendResponse($this->response, 200);
        }

        if ($sumOfInvoices != $payment_amount && count($tenderPurchaseInvoices) > 1) {
          $this->response['errors'] = ['payment_amount' => "Payment Amount Should be equal to Total the invoice amount you selected i.e. " .  $sumOfInvoices];
          return $this->sendResponse($this->response, 200);
        }

        $fk_pi_id = implode(',', $purchaseInvoiceIdsArray);
      }


      $tpiPaymentObject->fk_pi_id = $fk_pi_id;
      $tpiPaymentObject->fk_tender_id = $tenderId;
      $tpiPaymentObject->payment_date = $payment_date;
      $tpiPaymentObject->payment_amount = $payment_amount;
      $tpiPaymentObject->remark = $remark;
      $tpiPaymentObject->created_by = $this->userId;

      $tpiPaymentObject->save();

      if (!empty($tenderPurchaseInvoices)) {
        $purchaseInvoiceIdsArray = array_column($tenderPurchaseInvoices, 'id');

        if (count($tenderPurchaseInvoices) == 1) {
          TenderPurchaseInvoice::whereIn('id', $purchaseInvoiceIdsArray)
            ->update([
              'pi_total_amount_paid' => DB::raw('pi_total_amount_paid + ' . $payment_amount),
              'pi_total_amount_pending' => DB::raw('final_amount - pi_total_amount_paid '),
              'payment_done' => DB::raw("CASE WHEN pi_total_amount_pending = 0 THEN 1 ELSE 0 END"),

            ]);
        } else {
          TenderPurchaseInvoice::whereIn('id', $purchaseInvoiceIdsArray)
            ->update([
              'payment_done' => 1,
              'pi_total_amount_paid' => DB::raw('final_amount'),
              'pi_total_amount_pending' => 0,
            ]);
        }
      }

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.created', ['module' => "Purchase Invoice Payment"]);

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Creating Purchase Invoice: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Purchase Invoice"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdateTenderPurchaseInvoice(Request $request) {
    return Validator::make($request->all(), [
      'payment_date' => 'required|date_format:d/m/Y g:i A',
      'tender_purchase_invoices' => 'required',
      'payment_amount' => [
        'required',
        'numeric', // Ensure the input is numeric
        'min:0.01', // Minimum value
      ],

    ])->errors();
  }


}
