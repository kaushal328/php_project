<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use App\Models\TenderType;
use App\Http\Controllers\API\AppBaseController;

class TenderTypeController extends AppBaseController {

    
    /**
   * Display a listing of the Tender Type.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';
      $status = $request->status ?? '';

      $tenderTypeObject = TenderType::withoutTrashed()->orderBy("id", "desc");
      $num_rows = $tenderTypeObject->count();

      if ($title) {
        $tenderTypeObject->where('title', 'like', '%' . $title . '%');
      }

      if ($status) {
        $tenderTypeObject->where('status', $status);
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Tender Type"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['list'] = $tenderTypeObject->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Tender Type fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(Request $request) {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateTenderType($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $tenderTypeObject = new TenderType();
      $id = $request->id;
      $title = $request->title ?? '';
      $status = $request->status ?? 1;

      if ($id) {
        $tenderTypeObject = TenderType::find($id);

        if (!$tenderTypeObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Type"]);
          return $this->sendResponse($this->response, 500);
        }

        $tenderTypeObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Tender Type"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Tender Type"]);
      }

      $tenderTypeObject->title = $title;
      $tenderTypeObject->status = $status;

      $tenderTypeObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Tender Type: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Tender Type"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $tenderTypeObject = TenderType::find($id);

      if (!$tenderTypeObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Type"]);
        return $this->sendResponse($this->response, 500);
      }
      $tenderTypeObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Tender Type"]);
      $this->response['data'] = $tenderTypeObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Tender Type fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $tenderTypeObject = TenderType::find($id);

      if (!$tenderTypeObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Type"]);
        return $this->sendResponse($this->response, 500);
      }

      $tenderTypeObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Tender Type"]);
      $this->response['data'] = $tenderTypeObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Tender Type Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function tenderTypeList(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
      $tenderTypeList = TenderType::where('status', 1)->get();

      $this->response['status'] = 1;
      $this->response['data']['list'] = $tenderTypeList;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Tender Type List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdateTenderType(Request $request) {
    return Validator::make($request->all(), [
      'title' => 'required|string|unique:tender_types,title,' . $request->id . ',id,deleted_at,NULL',
      'status' => 'sometimes|required|integer|in:0,1',
    ])->errors();
  }

}
