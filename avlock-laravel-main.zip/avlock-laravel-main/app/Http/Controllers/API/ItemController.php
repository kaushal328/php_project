<?php

namespace App\Http\Controllers\API;

use App\Models\Item;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ItemController extends AppBaseController
{

  public function index(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $item = Item::withoutTrashed()->orderBy("id", "desc");
      $num_rows = $item->count();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Item"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = $item->limit($per_page)->offset($offset)->get();;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Item fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateItem($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $itemObject = new Item();
      $id = $request->id;
      $supplierId = $request->supplier_id;
      $itemSupplied = $request->item_supplied;
      $rawMaterial = $request->raw_material;
      $rawMaterialSupplier = $request->raw_material_supplier;
      $ppmLevelSupplier = $request->ppm_level_supplier;
      $presentSupplies = $request->present_supplies;
      $currentCapacity = $request->current_capacity;
      $capacityUtilization = $request->capacity_utilization;
      $createCapacityShortNotice = $request->create_capacity_short_notice;
      $inventoryKeptDays = $request->inventory_kept_days;
      $status = $request->status ?? 1;

      if ($id) {
        $itemObject = Item::find($id);

        if (!$itemObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Item"]);
          return $this->sendResponse($this->response, 401);
        }

        $itemObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Item"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Item"]);
      }

      $itemObject->supplier_id = $supplierId;
      $itemObject->item_supplied = $itemSupplied;
      $itemObject->raw_material = $rawMaterial;
      $itemObject->raw_material_supplier = $rawMaterialSupplier;
      $itemObject->ppm_level_supplier = $ppmLevelSupplier;
      $itemObject->present_supplies = $presentSupplies;
      $itemObject->current_capacity = $currentCapacity;
      $itemObject->capacity_utilization = $capacityUtilization;
      $itemObject->create_capacity_short_notice = $createCapacityShortNotice;
      $itemObject->inventory_kept_days = $inventoryKeptDays;
      $itemObject->status = $status;

      $itemObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Item: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Item"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $id = $request->id ?? '';
      $itemObject = Item::find($id);

      if (!$itemObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Item"]);
        return $this->sendResponse($this->response, 401);
      }

      $itemObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Item"]);
      $this->response['data']['list'] = $itemObject;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Item fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function getItem(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $supplierId = $request->supplier_id ?? '';
      $supplierObject = Supplier::find($supplierId);

      if (!$supplierObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Item"]);
        return $this->sendResponse($this->response, 401);
      }

      $item = Item::where('supplier_id', $supplierId)->withoutTrashed()->orderBy("id", "desc");
      $num_rows = $item->count();

      $result = $item->limit($per_page)->offset($offset)->get();

      $supplierObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Item"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = $result;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Item fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $itemObject = Item::find($id);

      if (!$itemObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Item"]);
        return $this->sendResponse($this->response, 401);
      }

      $itemObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Item"]);
      $this->response['data'] = $itemObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Item Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddUpdateItem(Request $request)
  {
    return Validator::make($request->all(), [
      'item_supplied' => 'required',
      'raw_material' => 'required',
    ])->errors();
  }
}
