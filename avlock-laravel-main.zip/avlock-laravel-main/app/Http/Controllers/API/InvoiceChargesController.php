<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\InvoiceCharges;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class InvoiceChargesController extends AppBaseController
{
    /**
     * Display a listing of the Charges.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $title = $request->title ?? '';

            $invoiceCharges = InvoiceCharges::withoutTrashed()->orderBy("id", "desc");

            if ($title) {
                $invoiceCharges->where('title', 'like', '%' . $title . '%');
            }
            $num_rows = $invoiceCharges->count();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Invoice Charges"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['title'] = $title;
            $this->response['data']['list'] = $invoiceCharges->limit($per_page)->offset($offset)->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Invoice Charges fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function addUpdate(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateInvoiceCharges($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $invoiceChargesObject = new InvoiceCharges();
            $id = $request->id;
            $title = $request->title ?? '';
            $gst = $request->gst ?? '';
            $status = $request->status ?? 1;



            if ($id) {
                $invoiceChargesObject = InvoiceCharges::find($id);

                if (!$invoiceChargesObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Invoice Charges"]);
                    return $this->sendResponse($this->response, 401);
                }

                $invoiceChargesObject->first();
                $this->response['msg'] = __('admin.updated', ['module' => "Invoice Charges"]);
            } else {
                $this->response['msg'] = __('admin.created', ['module' => "Invoice Charges"]);
            }

            $invoiceChargesObject->title = $title;
            $invoiceChargesObject->gst = $gst;
            $invoiceChargesObject->status = $status;

            $invoiceChargesObject->save();

            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Invoice Charges: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Invoice Charges"]);

            return $this->sendResponse($this->response, 401);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $invoiceChargeObject = InvoiceCharges::find($id);

            if (!$invoiceChargeObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Invoice Charges"]);
                return $this->sendResponse($this->response, 401);
            }
            $invoiceChargeObject->first();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Invoice Charges"]);
            $this->response['data'] = $invoiceChargeObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Invoice Charges fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $invoiceChargeObject = InvoiceCharges::find($id);

            if (!$invoiceChargeObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Invoice Charge"]);
                return $this->sendResponse($this->response, 401);
            }

            $invoiceChargeObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Invoice Charge"]);
            $this->response['data'] = $invoiceChargeObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Invoice Charge Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function invoiceChargesList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $invoiceChargesList = InvoiceCharges::where('status', 1)->get();

            $this->response['status'] = 1;
            $this->response['data'] = [
                'invoice_charges_list' => $invoiceChargesList,
            ];

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Invoice charges List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function validateAddUpdateInvoiceCharges(Request $request)
    {
        return Validator::make($request->all(), [
            'title' => 'required|string|unique:invoice_charges,title,' . $request->id . ',id,deleted_at,NULL',
            'status' => 'sometimes|required|integer|in:0,1',
        ])->errors();
    }
}
