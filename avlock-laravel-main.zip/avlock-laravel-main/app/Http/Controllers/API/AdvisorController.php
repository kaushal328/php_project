<?php

namespace App\Http\Controllers\API;

use Exception;
use Carbon\Carbon;
use App\Models\Rfq;
use App\Models\Lead;
use App\Models\Task;
use App\Enums\TaskFrom;
use App\Models\Industry;
use Carbon\CarbonPeriod;
use App\Models\ProjectType;
use Illuminate\Http\Request;
use App\Models\SalesVisitReport;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\API\AppBaseController;
use App\Http\Resources\SalesVisitReportResource;
use App\Models\Activity;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use App\Models\UserAttendance;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use PhpOffice\PhpSpreadsheet\Writer\Csv;

class AdvisorController extends AppBaseController
{

  public function generateCustomerInteractionReport(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if ($this->isAdvisor || $this->isUserAdmin || $this->isManagement) {
        $validationErrors = $this->validateGenerateSvr($request);

        if (count($validationErrors)) {
          Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
          $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
          return $this->sendResponse($this->response, 200);
        }

        $startDate = $this->convertToDatabaseDateForSearch($request->start_date) ?? '';
        $endDate = $this->convertToDatabaseDateForSearch($request->end_date) ?? '';
        $salesPersonIds = $request->sales_person ?? [];
        $industryTypeIds = $request->industries ?? [];

        $industryList = Industry::select('id', 'name')->whereIn('id', $industryTypeIds)->get()->toArray();

        $res = [];
        foreach ($industryList as $key => $industry) {
          $svrsQuery = SalesVisitReport::with('reportSalesPerson:id,name')
            ->whereIn('sales_person', $salesPersonIds)
            ->where('fk_task_type_id', 1)
            ->whereBetween('visit_date', [$startDate, $endDate]);

          $svrsQuery->where(function ($query) use ($industry) {
            $query->orWhereJsonContains('industry_type', ['id' => $industry['id']]);
          });

          $svrs = $svrsQuery->get()->toArray();

          $svrIds = array_column($svrs, 'fk_lead_id');
          $idCounts = array_count_values($svrIds);

          $leads = [];
          foreach ($svrs as $k => $svr) {
            $salesPersonName = $svr['report_sales_person']['name'] ?? '';
            $lead = Lead::find($svr['fk_lead_id']);

            if ($lead) {
              $leads[$k]['company'] = $lead['company'];
              $leads[$k]['count'] = $idCounts[$lead['id']] ?? 0;
              $leads[$k]['user'] = $salesPersonName;
            }
          }

          $res[$key]['industry'] = $industry['name'];
          $res[$key]['leads'] = $leads;
        }

        $totalCount = collect($res)->flatMap(fn($item) => $item['leads'])->sum('count');

        $this->response['status'] = 1;
        $this->response['msg'] =  'Report Generated Succesfully';
        $this->response['data']['list'] = $res;
        $this->response['data']['total_lead_count'] = $totalCount;
        return $this->sendResponse($this->response, 200);
      } else {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function exportcustomerInteraction(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if ($this->isAdvisor || $this->isUserAdmin || $this->isManagement) {

        $startDate = $this->convertToDatabaseDateForSearch($request->start_date) ?? '';
        $endDate = $this->convertToDatabaseDateForSearch($request->end_date) ?? '';
        $salesPersonIds = $request->sales_person ?? [];
        $industryTypeIds = $request->industries ?? [];

        $industryList = Industry::select('id', 'name')->whereIn('id', $industryTypeIds)->get()->toArray();

        $res = [];
        foreach ($industryList as $key => $industry) {
          $svrsQuery = SalesVisitReport::with('reportSalesPerson:id,name')
            ->whereIn('sales_person', $salesPersonIds)
            ->where('fk_task_type_id', 1)
            ->whereBetween('visit_date', [$startDate, $endDate]);

          $svrsQuery->where(function ($query) use ($industry) {
            $query->orWhereJsonContains('industry_type', ['id' => $industry['id']]);
          });

          $svrs = $svrsQuery->get()->toArray();

          $svrIds = array_column($svrs, 'fk_lead_id');
          $idCounts = array_count_values($svrIds);

          $leads = [];
          foreach ($svrs as $k => $svr) {
            $salesPersonName = $svr['report_sales_person']['name'] ?? '';
            $lead = Lead::find($svr['fk_lead_id']);

            if ($lead) {
              $leads[$k]['company'] = $lead['company'];
              $leads[$k]['count'] = $idCounts[$lead['id']] ?? 0;
              $leads[$k]['user'] = $salesPersonName;
              $leads[$k]['created'] = $lead['created_at'];
            }
          }

          $res[$key]['industry'] = $industry['name'];
          $res[$key]['leads'] = $leads;
        }

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $headers = ['Sr.No', 'Industry', 'Leads'];
        $sheetData = [$headers];

        foreach ($res as $key => $item) {
          $leadText = [];

          foreach ($item['leads'] as $lead) {
            $leadText[] = "Company: " . $lead['company'] . "\nUser: " . $lead['user'] . "\nCount: " . $lead['count'] . "\nCreated: " . Carbon::parse($lead['created'])->format('M d, Y');
          }

          $leadsString = implode("\n\n", $leadText);

          $rowData = [
            $key + 1,
            $item['industry'] ?? '',
            $leadsString,
          ];
          $sheetData[] = $rowData;
        }

        $sheet->fromArray($sheetData, null, 'A1');

        // $filePath = $this->fileAccessPath  . "/activity/Activity.xlsx";
        $filePath = "storage/app/public/uploads/report/Customer_interaction_report.csv";
        $writer = new Csv($spreadsheet);
        $writer->save($filePath);

        $this->response['status'] = 1;
        $this->response['msg'] = "File downloaded successfully";
        $this->response['filePath'] = $filePath;
        return $this->sendResponse($this->response, 200);
      } else {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function generateDateWiseReport(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if ($this->isAdvisor || $this->isUserAdmin || $this->isManagement) {

        $validationErrors = $this->validateDatewiseReport($request);

        if (count($validationErrors)) {
          Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
          $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
          return $this->sendResponse($this->response, 200);
        }

        $salesPersonIds = $request->sales_person ?? [];
        $month = $request->month;
        $year = $request->year;

        $startPeriod = Carbon::parse($year . '-' . $month)->startOfMonth();
        $endPeriod = Carbon::parse($year . '-' . $month)->endOfMonth();

        $period = CarbonPeriod::create($startPeriod, '1 day', $endPeriod)->toArray();

        $res = [];

        foreach ($period as $key => $date) {
          $formattedDate = $date->format('Y-m-d');

          $svrs = SalesVisitReport::with('reportSalesPerson:id,name')->where('fk_task_type_id', 1)
            ->whereIn('sales_person', $salesPersonIds)
            ->whereDate('visit_date', $formattedDate)
            ->get()
            ->toArray();

          $svrIds = array_column($svrs, 'fk_lead_id');
          $idCounts = array_count_values($svrIds);

          $leads = [];
          foreach ($svrs as $k => $svr) {
            $salesPersonName = $svr['report_sales_person']['name'] ?? '';

            $lead = Lead::find($svr['fk_lead_id']);
            if ($lead) {
              $leads[$k]['company'] = $lead['company'];
              $leads[$k]['count'] = $idCounts[$lead['id']] ?? 0;
              $leads[$k]['user'] = $salesPersonName;
            }
          }

          $res[$key]['date'] = $formattedDate;
          $res[$key]['leads'] = $leads;
        }


        $totalCount = collect($res)->flatMap(fn($item) => $item['leads'])->sum('count');

        $this->response['status'] = 1;
        $this->response['msg'] =  'Report Generated Successfully';
        $this->response['data']['list'] = $res;
        $this->response['data']['total_lead_count'] = $totalCount;
        return $this->sendResponse($this->response, 200);
      } else {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function exportDateWiseReport(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if ($this->isAdvisor || $this->isUserAdmin || $this->isManagement) {

        $salesPersonIds = $request->sales_person ?? [];
        $month = $request->month;
        $year = $request->year;

        $startPeriod = Carbon::parse($year . '-' . $month)->startOfMonth();
        $endPeriod = Carbon::parse($year . '-' . $month)->endOfMonth();

        $period = CarbonPeriod::create($startPeriod, '1 day', $endPeriod)->toArray();

        $res = [];

        foreach ($period as $key => $date) {
          $formattedDate = $date->format('Y-m-d');

          $svrs = SalesVisitReport::with('reportSalesPerson:id,name')->where('fk_task_type_id', 1)
            ->whereIn('sales_person', $salesPersonIds)
            ->whereDate('visit_date', $formattedDate)
            ->get()
            ->toArray();

          $svrIds = array_column($svrs, 'fk_lead_id');
          $idCounts = array_count_values($svrIds);

          $leads = [];
          foreach ($svrs as $k => $svr) {
            $salesPersonName = $svr['report_sales_person']['name'] ?? '';

            $lead = Lead::find($svr['fk_lead_id']);
            if ($lead) {
              $leads[$k]['company'] = $lead['company'];
              $leads[$k]['created'] = $lead['created_at'];
              $leads[$k]['count'] = $idCounts[$lead['id']] ?? 0;
              $leads[$k]['user'] = $salesPersonName;
            }
          }

          $res[$key]['date'] = $formattedDate;
          $res[$key]['leads'] = $leads;
        }

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $headers = ['Sr.No', 'Date', 'Leads'];
        $sheetData = [$headers];

        foreach ($res as $key => $item) {
          $leadText = [];

          foreach ($item['leads'] as $lead) {
            $leadText[] = "Company: " . $lead['company'] . "\nUser: " . $lead['user'] . "\nCount: " . $lead['count'] . "\nCreated: " . Carbon::parse($lead['created'])->format('M d, Y');
          }

          $leadsString = implode("\n\n", $leadText);

          $rowData = [
            $key + 1,
            Carbon::parse($item['date'])->format('M d, Y'),
            $leadsString,
          ];
          $sheetData[] = $rowData;
        }

        $sheet->fromArray($sheetData, null, 'A1');

        // $filePath = $this->fileAccessPath  . "/activity/Activity.xlsx";
        $filePath = "storage/app/public/uploads/report/Day_wise_report.csv";
        $writer = new csv($spreadsheet);
        $writer->save($filePath);

        $this->response['status'] = 1;
        $this->response['msg'] = "File downloaded successfully";
        $this->response['filePath'] = $filePath;
        return $this->sendResponse($this->response, 200);
      } else {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function generateCheckInOutReport(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
      if ($this->isAdvisor || $this->isUserAdmin || $this->isManagement) {
        $validationErrors = $this->validateCheckInOutReport($request);

        if (count($validationErrors)) {
          Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
          $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
          return $this->sendResponse($this->response, 200);
        }

        $salesPersonId = $request->sales_person ?? '';
        $month = $request->month;
        $year = $request->year;

        $startPeriod = Carbon::parse($year . '-' . $month)->startOfMonth();
        $endPeriod   = Carbon::parse($year . '-' . $month)->endOfMonth();

        $period = CarbonPeriod::create($startPeriod, '1 day', $endPeriod);
        $period = $period->toArray();

        $days = [];

        foreach ($period as $key => $date) {
          $days[$key]['date'] = $date->format('Y-m-d');
        }

        $res = [];

        foreach ($days as $key => $day) {
          $userAtt = UserAttendance::where('fk_user_id', $salesPersonId);
          $userAtt = $userAtt->whereDate('attendance_date', $day['date'])->get()->toArray();

          $userId = array_column($userAtt, 'fk_user_id');

          $activityCount = Activity::where('fk_user_id', $userId)->whereDate('created_at', $day['date'])->get()->count();

          $res[$key]['date'] = $day['date'];
          $res[$key]['user_attendance'] = $userAtt;
          $res[$key]['activity_count'] = $activityCount;
        }

        $this->response['status'] = 1;
        $this->response['msg'] =  'Report Generated Successfully';
        $this->response['data']['list'] = $res;
        return $this->sendResponse($this->response, 200);
      } else {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function exportDayInOut(Request $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
      if ($this->isAdvisor || $this->isUserAdmin || $this->isManagement) {
        $validationErrors = $this->validateCheckInOutReport($request);

        if (count($validationErrors)) {
          Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
          $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
          return $this->sendResponse($this->response, 200);
        }

        $salesPersonId = $request->sales_person ?? '';
        $month = $request->month;
        $year = $request->year;

        $startPeriod = Carbon::parse($year . '-' . $month)->startOfMonth();
        $endPeriod   = Carbon::parse($year . '-' . $month)->endOfMonth();

        $period = CarbonPeriod::create($startPeriod, '1 day', $endPeriod);
        $period = $period->toArray();

        $days = [];

        foreach ($period as $key => $date) {
          $days[$key]['date'] = $date->format('Y-m-d');
        }

        $res = [];

        foreach ($days as $key => $day) {
          $userAtt = UserAttendance::where('fk_user_id', $salesPersonId)
            ->whereDate('attendance_date', $day['date'])
            ->first();

          $userAttArray = [];

          if ($userAtt !== null) {
            $userAttArray = $userAtt->toArray();
          }

          $userId = !empty($userAttArray) ? $userAttArray['fk_user_id'] : null;

          $activityCount = Activity::where('fk_user_id', $userId)
            ->whereDate('created_at', $day['date'])
            ->count();

          $res[$key]['date'] = $day['date'];
          $res[$key]['user_attendance'] = $userAttArray;
          $res[$key]['activity_count'] = $activityCount;
        }


        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $headers = ['Sr.No', 'User', 'Day In', 'Day Out', 'Activity'];
        $sheetData = [$headers];

        $rowCounter = 1;
        foreach ($res as $key => $item) {
          $checkinTime = isset($item['user_attendance']['checkin_time']) ? Carbon::parse($item['user_attendance']['checkin_time'])->format('M d, Y h:i a') : '';
          $checkoutTime = isset($item['user_attendance']['checkout_time']) ? Carbon::parse($item['user_attendance']['checkout_time'])->format('M d, Y h:i a') : '';

          $rowData = [
            $rowCounter,
            Carbon::parse($item['date'])->format('M d, Y'),
            $checkinTime,
            $checkoutTime,
            (string)$item['activity_count'],
          ];

          $sheetData[] = $rowData;
          $rowCounter++;
        }


        $sheet->fromArray($sheetData, null, 'A1');

        // $filePath = $this->fileAccessPath  . "/dayinout/Day_in_out.xlsx";
        $filePath = "storage/app/public/uploads/report/Day_in_out.csv";
        $writer = new Csv($spreadsheet);
        $writer->save($filePath);

        $this->response['status'] = 1;
        $this->response['msg'] = "File downloaded successfully";
        $this->response['filePath'] = $filePath;
        return $this->sendResponse($this->response, 200);
      } else {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
    } catch (\Exception $e) {
      Log::error("File Download failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function generateInteractionReport(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if ($this->isAdvisor || $this->isUserAdmin || $this->isManagement) {
        $validationErrors = $this->validateGenerateInteraction($request);

        if (count($validationErrors)) {
          Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
          $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
          return $this->sendResponse($this->response, 200);
        }

        $startDate = $this->convertToDatabaseDateForSearch($request->start_date) ?? '';
        $endDate = $this->convertToDatabaseDateForSearch($request->end_date) ?? '';
        $salesPersonIds = $request->sales_person ?? [];

        $projectTypes = ProjectType::where('status', 1)->get()->toArray();

        $res = [];
        foreach ($projectTypes as $key => $projectType) {
          $svrs = SalesVisitReport::whereIn('sales_person', $salesPersonIds)->where('fk_task_type_id', 2)->where('fk_rfq_id', '!=', 0)->whereBetween('visit_date', [$startDate, $endDate])->get()->toArray();

          $svrIds = array_column($svrs, 'fk_rfq_id');

          $rfqFromSvr = DB::table('rfqs')
            ->select(
              'leads.company',
              'rfqs.assigned_rsm_name as user',
              DB::raw('count(rfqs.id) as rfq_count'),
              DB::raw('group_concat(rfqs.id) as ids')
            )
            ->whereIn('rfqs.id', $svrIds)
            ->leftJoin('leads', 'rfqs.lead_id', '=', 'leads.id')
            ->where('rfqs.fk_project_type_id', $projectType['id'])
            ->groupBy('leads.company', 'rfqs.assigned_rsm_name')
            ->get();

          $rfq = [];
          foreach ($rfqFromSvr as $item) {
            $rfq[] = [
              'company' => $item->company,
              'user' => $item->user,
              'rfq_count' => $item->rfq_count,
              'ids' => $item->ids
            ];
          }

          $res[$key]['project_type'] = $projectType['name'];
          $res[$key]['rfqs'] = $rfq;
        }

        $totalCount = 0;
        foreach ($res as $item) {
          foreach ($item['rfqs'] as $rfq) {
            $totalCount += $rfq['rfq_count'];
          }
        }

        $this->response['status'] = 1;
        $this->response['msg'] =  'Report Generated Succesfully';
        $this->response['data']['list'] = $res;
        $this->response['data']['total_lead_count'] = $totalCount;
        return $this->sendResponse($this->response, 200);
      } else {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }
  public function exportInteractionReport(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if ($this->isAdvisor || $this->isUserAdmin || $this->isManagement) {

        $startDate = $this->convertToDatabaseDateForSearch($request->start_date) ?? '';
        $endDate = $this->convertToDatabaseDateForSearch($request->end_date) ?? '';
        $salesPersonIds = $request->sales_person ?? [];

        $projectTypes = ProjectType::where('status', 1)->get()->toArray();

        $res = [];
        foreach ($projectTypes as $key => $projectType) {
          $svrs = SalesVisitReport::whereIn('sales_person', $salesPersonIds)->where('fk_task_type_id', 2)->where('fk_rfq_id', '!=', 0)->whereBetween('visit_date', [$startDate, $endDate])->get()->toArray();

          $svrIds = array_column($svrs, 'fk_rfq_id');

          $rfqFromSvr = DB::table('rfqs')
            ->select(
              'leads.company',
              'rfqs.created_at',
              'rfqs.assigned_rsm_name as user',
              DB::raw('count(rfqs.id) as rfq_count'),
              DB::raw('group_concat(rfqs.id) as ids')
            )
            ->whereIn('rfqs.id', $svrIds)
            ->leftJoin('leads', 'rfqs.lead_id', '=', 'leads.id')
            ->where('rfqs.fk_project_type_id', $projectType['id'])
            ->groupBy('leads.company', 'rfqs.assigned_rsm_name')
            ->get();

          $rfq = [];
          foreach ($rfqFromSvr as $item) {
            $rfq[] = [
              'company' => $item->company,
              'user' => $item->user,
              'rfq_count' => $item->rfq_count,
              'created' => $item->created_at,
              'ids' => $item->ids
            ];
          }

          $res[$key]['project_type'] = $projectType['name'];
          $res[$key]['rfqs'] = $rfq;
        }

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $headers = ['Sr.No', 'Project Type', 'Company', 'User', 'RFQ Count', 'Created'];
        $sheetData = [$headers];

        $rowCounter = 1;
        foreach ($res as $key => $item) {
          foreach ($item['rfqs'] as $rfq) {
            $rowData = [
              $rowCounter,
              $item['project_type'],
              $rfq['company'],
              $rfq['user'],
              $rfq['rfq_count'],
              Carbon::parse($rfq['created'])->format('M d, Y')
            ];
            $sheetData[] = $rowData;
            $rowCounter++;
          }
        }

        $sheet->fromArray($sheetData, null, 'A1');

        // $filePath = $this->fileAccessPath  . "/activity/Activity.xlsx";
        $filePath = "storage/app/public/uploads/report/Interaction_report.csv";
        $writer = new Csv($spreadsheet);
        $writer->save($filePath);

        $this->response['status'] = 1;
        $this->response['msg'] = "File downloaded successfully";
        $this->response['filePath'] = $filePath;
        return $this->sendResponse($this->response, 200);
      } else {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }


  public function generateLocationWiseReport(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if ($this->isAdvisor || $this->isUserAdmin || $this->isManagement) {
        $validationErrors = $this->validateGenerateLocationwise($request);

        if (count($validationErrors)) {
          Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
          $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
          return $this->sendResponse($this->response, 200);
        }

        $startDate = $this->convertToDatabaseDateForSearch($request->start_date) ?? '';
        $endDate = $this->convertToDatabaseDateForSearch($request->end_date) ?? '';
        $salesPersonIds = $request->sales_person ?? [];
        $citiesIds = $request->cities ?? [];

        $svrs = DB::table('sales_visit_reports')
          ->select([
            DB::raw('COUNT(sales_visit_reports.id) as svr_count'),
            DB::raw('GROUP_CONCAT(sales_visit_reports.id) as ids'),
            'cities.name',
            'sales_visit_reports.fk_lead_id',
            'cities.id',
          ])
          ->where('fk_task_type_id', 1)
          ->whereIn('sales_person', $salesPersonIds)
          ->whereBetween('visit_date', [$startDate, $endDate])
          ->leftJoin('cities', 'sales_visit_reports.city_id', '=', 'cities.id');

        if ($citiesIds) {
          $svrs->whereIn('city_id', $citiesIds);
        }

        $svrs = $svrs->groupBy('sales_visit_reports.city_id')->get();

        $totalCount = 0;
        foreach ($svrs as $item) {
          $totalCount += $item->svr_count;
        }

        $this->response['status'] = 1;
        $this->response['msg'] =  'Report Generated Succesfully';
        $this->response['data']['list'] = $svrs;
        $this->response['data']['total_lead_count'] = $totalCount;
        return $this->sendResponse($this->response, 200);
      } else {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function exportLoctaionReport(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      if ($this->isAdvisor || $this->isUserAdmin || $this->isManagement) {

        $startDate = $this->convertToDatabaseDateForSearch($request->start_date) ?? '';
        $endDate = $this->convertToDatabaseDateForSearch($request->end_date) ?? '';
        $salesPersonIds = $request->sales_person ?? [];
        $citiesIds = $request->cities ?? [];

        $svrs = DB::table('sales_visit_reports')
          ->select([
            DB::raw('COUNT(sales_visit_reports.id) as svr_count'),
            DB::raw('GROUP_CONCAT(sales_visit_reports.id) as ids'),
            'cities.name',
            'sales_visit_reports.fk_lead_id',
            'cities.id',
          ])
          ->where('fk_task_type_id', 1)
          ->whereIn('sales_person', $salesPersonIds)
          ->whereBetween('visit_date', [$startDate, $endDate])
          ->leftJoin('cities', 'sales_visit_reports.city_id', '=', 'cities.id');

        if ($citiesIds) {
          $svrs->whereIn('city_id', $citiesIds);
        }

        $svrs = $svrs->groupBy('sales_visit_reports.city_id')->get();

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $headers = ['Sr.No', 'City', '	No. of visit'];
        $sheetData = [$headers];

        $rowCounter = 1;
        foreach ($svrs as $item) {
          $rowData = [
            $rowCounter,
            $item->name ?? 'Other',
            $item->svr_count,
          ];
          $sheetData[] = $rowData;
          $rowCounter++;
        }

        $sheet->fromArray($sheetData, null, 'A1');

        // $filePath = $this->fileAccessPath  . "/activity/Activity.xlsx";
        $filePath = "storage/app/public/uploads/report/Location_report.csv";
        $writer = new Csv($spreadsheet);
        $writer->save($filePath);

        $this->response['status'] = 1;
        $this->response['msg'] = "File downloaded successfully";
        $this->response['filePath'] = $filePath;
        return $this->sendResponse($this->response, 200);
      } else {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
    } catch (Exception $e) {
      Log::error("Sales Report fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  protected function validateGenerateLocationwise(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'sales_person' => 'required',
        'start_date' => 'required',
        'end_date' => 'required',

      ],
    )->errors();
  }

  protected function validateCheckInOutReport(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'month' => 'required',
        'year' => 'required',
        'sales_person' => 'required',
      ],
    )->errors();
  }

  protected function validateDatewiseReport(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'month' => 'required',
        'year' => 'required',
        'sales_person' => 'required',
      ],
    )->errors();
  }

  protected function validateCustomerVisitReport(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'month' => 'required',
        'year' => 'required',
        'sales_person' => 'required',
      ],
    )->errors();
  }

  protected function validateGenerateInteraction(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'sales_person' => 'required',
        'start_date' => 'required',
        'end_date' => 'required',

      ],
    )->errors();
  }

  protected function validateGenerateSvr(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'sales_person' => 'required',
        'start_date' => 'required',
        'end_date' => 'required',
        // 'industries' => 'required',

      ],
    )->errors();
  }


  // $plannedVisitCount = Task::with('assignedToUsers', 'lead')
  //     ->where('fk_status_id', '!=', 5)
  //     ->whereMonth('start', now()->month)
  //     ->where('task_from', TaskFrom::MONTHLY_PLAN->value)
  //     ->where('fk_lead_id', '!=', 0)
  //     ->whereHas('assignedToUsers', function ($query) use ($rsmUserId) {
  //       $query->where('fk_user_id', $rsmUserId);
  //     })
  //     ->whereHas('lead', function($q) use($type){
  //       $q->where('customer_type', $type->id);
  //     })
  //     ->get();

}
