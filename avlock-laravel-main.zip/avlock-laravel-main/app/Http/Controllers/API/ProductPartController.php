<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductPart;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class ProductPartController extends AppBaseController
{
    /**
     * Display a listing of the Product Part.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $productId = $request->product_id ?? '';
            $partNo = $request->part_no ?? '';
            $status = $request->status ?? '';
            $isExport = $request->is_export ?? '';

            $productPartObj = ProductPart::with('product.category')->where('product_id', $productId)->orderBy("id", "desc");

            if ($partNo) {
                $productPartObj->where('part_no', 'like', '%' . $partNo . '%');
            }

            if ($status) {
                $productPartObj->where('status', $status);
            }

            $showDelete = false;
            $isAllowed = false;
            if ($this->isUserAdmin || $this->userId == 15) {
                $showDelete = true;
                $isAllowed = true;
            }

            $num_rows = $productPartObj->count();
            $lists = $productPartObj->limit($per_page)->offset($offset)->get();


            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Product Part"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['part_no'] = $partNo;
            $this->response['data']['show_delete_btn'] = $showDelete;
            $this->response['data']['show_add_btn'] = $isAllowed;
            $this->response['data']['list'] = $lists;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addUpdate(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateProductPart($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $productPartObj = new ProductPart();
            $id = $request->id;
            $productId = $request->product_id ?? '';
            $partNo = $request->part_no ?? '';
            $description = $request->description ?? '';
            $status = $request->status ?? 1;

            if ($id) {
                $productPartObj = ProductPart::find($id);

                if (!$productPartObj) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Product Part"]);
                    return $this->sendResponse($this->response, 401);
                }

                $productPartObj->first();
                $productPartObj->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "Product Part"]);
            } else {
                $productPartObj->created_by = $this->userId;
                $this->response['msg'] = __('admin.created', ['module' => "Product Part"]);
            }

            $productPartObj->product_id = $productId;
            $productPartObj->part_no = $partNo;
            $productPartObj->description = $description;
            $productPartObj->status = $status;

            $productPartObj->save();

            $this->response['status'] = 1;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Product Part: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Product Part"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $tenderId = $request->tender_id ?? '';

            $productPartObj = ProductPart::find($id);

            if (!$productPartObj) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product Part"]);
                return $this->sendResponse($this->response, 500);
            }
            $productPartObj->first();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Product Part"]);
            $this->response['data'] = $productPartObj;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $productPartObj = ProductPart::find($id);

            if (!$productPartObj) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product Part"]);
                return $this->sendResponse($this->response, 500);
            }

            $productPartObj->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Product Part"]);
            $this->response['data'] = $productPartObj;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    // public function productPartLists(Request $request)
    // {
    //   try {
    //     if (!$this->userId) {
    //       $this->response['error'] = __('auth.authentication_failed');
    //       return $this->sendResponse($this->response, 401);
    //     }

    //     $partNo = trim($request->part_no ?? '');
    //     $productId = $request->product_id ?? '';

    //     $productPartLists = ProductPart::with('product:id,product_name')
    //       ->when($partNo, function ($query, $partNo) {
    //         return $query->where('part_no', 'like', '%' . $partNo . '%')
    //           ->where('status', 1);
    //       })
    //       ->when($productId, function ($query, $productId) {
    //         return $query->where('product_id', $productId);
    //       })
    //       ->orWhere(function ($query) use ($partNo, $productId) {
    //         if (empty($partNo) && empty($productId)) {
    //           $query->whereNotNull('part_no');
    //         }
    //       })
    //       ->whereNull('deleted_at')
    //       ->take(20)
    //       ->orderBy('part_no')
    //       ->get();

    //     $this->response['status'] = 1;
    //     $this->response['data']['list'] = $productPartLists;

    //     return $this->sendResponse($this->response, 200);
    //   } catch (\Exception $e) {
    //     Log::error("Product Part List fetching failed: " . $e->getMessage());
    //     $this->response['error'] = __('auth.something_went_wrong');
    //     return $this->sendResponse($this->response, 200);
    //   }
    // }

    public function productPartLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $partNo = trim($request->part_no ?? '');
            $productId = $request->product_id ?? '';

            $query = ProductPart::with('product:id,product_name')
                ->whereNull('deleted_at')
                ->where('status', 1);

            if (!empty($partNo)) {
                // First try exact match
                $exactMatch = (clone $query)
                    ->where('part_no', $partNo)
                    ->first();

                if ($exactMatch) {
                    $this->response['status'] = 1;
                    $this->response['data']['list'] = [$exactMatch];
                    return $this->sendResponse($this->response, 200);
                }

                // If no exact match, then do partial match
                $query->where('part_no', 'like', '%' . $partNo . '%');
            }

            if (!empty($productId)) {
                $query->where('product_id', $productId);
            }

            // Only apply limit for search queries
            if ($partNo || $productId) {
                $query->take(20);
            }

            $productPartLists = $query->orderBy('part_no')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $productPartLists;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 200);
        }
    }

    public function productLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $productName = trim($request->product_name ?? '');
            $productId = $request->product_id ?? '';

            $productLists = Product::orderBy('product_name')
                ->when($productName, function ($query, $productName) {
                    return $query->where('product_name', 'like', '%' . $productName . '%')
                        ->where('status', 1);
                })
                ->when($productId, function ($query, $productId) {
                    return $query->where('id', $productId);
                })
                ->orWhere(function ($query) use ($productName, $productId) {
                    if (empty($productName) && empty($productId)) {
                        $query->whereNotNull('product_name');
                    }
                })
                ->whereNull('deleted_at')
                ->take(20)
                ->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $productLists;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function fetchProductPartList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $productId = $request->product_id ?? '';

            $productPartLists = ProductPart::with('product:id,product_name')->where('product_id', $productId)->orderBy('part_no')->get();


            $this->response['status'] = 1;
            $this->response['data']['list'] = $productPartLists;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 200);
        }
    }


    public function fetchPartDesc(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $partId = $request->part_id ?? '';
            $productPartLists = ProductPart::where('id', $partId)->get();

            $this->response['status'] = 1;
            $this->response['data'] = [
                'productParts' => $productPartLists,
            ];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function importProductPart(Request $request)
    {
        try {

            DB::beginTransaction();

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateImportProductPart($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $files = $request->excel ?? [];

            $highestRow = 0;
            foreach ($files as $item) {
                // $filePath = storage_path('app/public/uploads/temp/' . $item['filename']);
                // $sourcePath = 'public/uploads/temp/' .  $item['filename'];

                // if (!Storage::exists($sourcePath)) {

                //   $this->response['error'] = __('admin.file_not_found', ['file' => $item['filename']]);
                //   return $this->sendResponse($this->response, 500);
                // }

                $spreadsheet = IOFactory::load($item);
                $sheetNames = $spreadsheet->getSheetNames();
                $dataRecords = [];

                foreach ($sheetNames as $sheetName) {
                    $worksheet = $spreadsheet->getSheetByName($sheetName);
                    $cellIterator = $worksheet->getRowIterator()->current()->getCellIterator();
                    $cellIterator->setIterateOnlyExistingCells(true);

                    $headers = [];
                    foreach ($cellIterator as $cell) {
                        if ($cell->getValue() != '') {
                            $headers[] = $cell->getValue();
                        }
                    }

                    if (array_values($headers) != array_values(config('global.PRODUCT_PART_FORMAT'))) {
                        $this->response['error'] = __('admin.excel_format_error', ['file' => $item['filename'], 'sheet' => $sheetName]);
                        return $this->sendResponse($this->response, 200);
                    }

                    $highestRow = max($highestRow, $worksheet->getHighestRow());
                    $dataRecords = [];

                    for ($row = 2; $row <= $highestRow; $row++) {
                        $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
                        if (!empty(array_filter($rowData[$row]))) {
                            $dataRecords[] = $rowData[$row];
                        }
                    }
                }

                $storedParts = [];

                foreach ($dataRecords as $key => $data) {
                    if (isset($data['A']) && !empty($data['A'])) {
                        $productId = $data['A'];
                    } else {
                        $this->response['error'] = "Product Id cannot be empty: " . $sheetName . " at row: " . ($key + 2);
                        return $this->sendResponse($this->response, 200);
                    }

                    $Catname = isset($data['B']) && !empty($data['B']) ? convertToCamelCase($data['B']) : null;
                    $productName = isset($data['C']) && !empty($data['C']) ? convertToCamelCase($data['C']) : null;
                    $partNo = isset($data['D']) && !empty($data['D']) ? $data['D'] : null;
                    $partDesc = isset($data['E']) && !empty($data['E']) ? convertToCamelCase($data['E']) : null;

                    if (!empty($partNo) && !empty($partDesc)) {
                        // Check if the part number already exists for the given product ID
                        $existingPart = ProductPart::where('product_id', $productId)->where('part_no', $partNo)->first();

                        if ($existingPart) {
                            $this->response['error'] = "Part No '$partNo' already exists for Product ID '$productId' at row: " . ($key + 2);
                            return $this->sendResponse($this->response, 200);
                        } else {
                            // Add to the array if not exists
                            $storedParts[] = [
                                'product_id' => $productId,
                                'part_no' => $partNo,
                                'description' => $partDesc,
                            ];
                        }
                    }
                }

                // Save all valid parts outside the loop
                foreach ($storedParts as $part) {
                    $proPartObj = new ProductPart();
                    $proPartObj->product_id = $part['product_id'];
                    $proPartObj->part_no = $part['part_no'];
                    $proPartObj->description = $part['description'];
                    $proPartObj->save();

                    Log::info("Inserted: Product ID = {$part['product_id']}, Part No = {$part['part_no']}, Part Desc = {$part['description']}");
                }


                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.created', ['module' => "Product Part Data"]);
                DB::commit();

                return $this->sendResponse($this->response, 200);
            }
        } catch (\Exception $e) {
            Log::error("Failed Creating Product Part Data: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function validateImportProductPart(Request $request)
    {
        return Validator::make($request->all(), [
            'excel' => 'required',
        ])->errors();
    }

    private function validateAddUpdateProductPart(Request $request)
    {
        return Validator::make($request->all(), [
            'part_no' => [
                'required',
                Rule::unique('product_parts')->where(function ($query) use ($request) {
                    return $query->where('product_id', $request->product_id)
                        ->whereNull('deleted_at');
                })->ignore($request->id),
            ],
            'status' => 'sometimes|required|integer|in:0,1',
        ])->errors();
    }
}
