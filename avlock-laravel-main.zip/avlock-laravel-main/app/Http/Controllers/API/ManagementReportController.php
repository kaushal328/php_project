<?php

namespace App\Http\Controllers\API;

use App\Enums\ErrorType;
use App\Http\Controllers\Controller;
use App\Http\Resources\ProjectSheetResource;
use App\Http\Resources\RfqProjectSheetResource;
use App\Models\AvlockSalesOrder;
use App\Models\Designation;
use App\Models\Division;
use App\Models\Industry;
use App\Models\Lead;
use App\Models\MonthlyPlanExcel;
use App\Models\ProjectQuotationTemp;
use App\Models\ProjectType;
use App\Models\PurchaseOrder;
use App\Models\Region;
use App\Models\Rfq;
use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use Illuminate\Support\Facades\Validator;

class ManagementReportController extends AppBaseController
{

    public function monthlyPlanExpectated(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $isExport = $request->is_export_monthly ?? 0;
            $isExportRsm = $request->is_export_rsm ?? 0;

            $dateRange = $request->input('date_range', 'lifetime');
            $startDate = null;
            $endDate = null;
            $divisionId = $request->input('division_id', null);
            $rsmDivisionIds = [];

            $userObj = User::find($this->userId);
            $divisionIds = !empty($userObj->division_ids) ? explode(',', $userObj->division_ids) : [];


            if (!empty($divisionIds)) {
                $rsmDivisions = User::where(function ($q) use ($divisionIds) {
                    foreach ($divisionIds as $divisionId) {
                        $q->orWhereRaw("FIND_IN_SET(?, division_ids)", [$divisionId]);
                    }
                })->get(['id'])->toArray();

                $rsmDivisionIds = array_column($rsmDivisions, 'id');
            }

            $divisionName = $divisionId ? Division::where('id', $divisionId)->value('name') : null;

            if ($dateRange !== 'lifetime') {
                switch ($dateRange) {
                    case 'last_month':
                        $startDate = now()->subMonth()->startOfMonth();
                        $endDate = now()->subMonth()->endOfMonth();
                        break;
                    case 'this_month':
                        $startDate = now()->startOfMonth();
                        $endDate = now()->endOfMonth();
                        break;
                    case 'this_financial_year':
                        $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                        $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                        break;
                    case 'last_financial_year':
                        $currentYear = now()->month >= 4 ? now()->year - 1 : now()->year - 2;
                        $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                        break;
                    case 'q1_this_year':
                        $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                        $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear, 6, 30)->endOfDay();
                        break;
                    case 'q2_this_year':
                        $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                        $startDate = now()->createFromDate($currentYear, 7, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear, 9, 30)->endOfDay();
                        break;
                    case 'q3_this_year':
                        $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                        $startDate = now()->createFromDate($currentYear, 10, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear, 12, 31)->endOfDay();
                        break;
                    case 'q4_this_year':
                        $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                        $startDate = now()->createFromDate($currentYear + 1, 1, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                        break;
                    case 'custom_date':
                        $startDate = $request->input('start_date') ? Carbon::parse($request->input('start_date'))->startOfDay() : null;
                        $endDate = $request->input('end_date') ? Carbon::parse($request->input('end_date'))->endOfDay() : null;
                        break;
                    default:
                        $startDate = null;
                        $endDate = null;
                        break;
                }
            }

            $year = $startDate ? $startDate->year : (now()->month >= 4 ? now()->year : now()->subYear()->year);
            $nextYear = $year + 1;

            $aprilToDecemberData = MonthlyPlanExcel::select('month', DB::raw('SUM(target) as total_target'))
                ->where('year', $year)
                ->whereIn('month', ['april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'])
                ->when($startDate && $endDate, function ($query) use ($startDate, $endDate, $year) {
                    $startMonth = strtolower($startDate->format('F'));
                    $endMonth = strtolower($endDate->format('F'));
                    $startYear = $startDate->year;
                    $endYear = $endDate->year;

                    if ($startYear == $year) {
                        $query->where('month', '>=', $startMonth);
                    }
                    if ($endYear == $year) {
                        $query->where('month', '<=', $endMonth);
                    }
                })
                ->when(!empty($rsmDivisionIds), function ($query) use ($rsmDivisionIds) {
                    $query->whereIn('rsm_id', $rsmDivisionIds);
                })
                ->groupBy('month')
                ->get()
                ->mapWithKeys(function ($item) {
                    return [trim(strtolower($item->month)) => $item];
                });

            $januaryToMarchData = MonthlyPlanExcel::select('month', DB::raw('SUM(target) as total_target'))
                ->where('year', $nextYear)
                ->whereIn('month', ['january', 'february', 'march'])
                ->when($startDate && $endDate, function ($query) use ($startDate, $endDate, $nextYear) {
                    $startMonth = strtolower($startDate->format('F'));
                    $endMonth = strtolower($endDate->format('F'));
                    $startYear = $startDate->year;
                    $endYear = $endDate->year;

                    if ($startYear == $nextYear) {
                        $query->where('month', '>=', $startMonth);
                    }
                    if ($endYear == $nextYear) {
                        $query->where('month', '<=', $endMonth);
                    }
                })
                ->when(!empty($rsmDivisionIds), function ($query) use ($rsmDivisionIds) {
                    $query->whereIn('rsm_id', $rsmDivisionIds);
                })
                ->groupBy('month')
                ->get()
                ->mapWithKeys(function ($item) {
                    return [trim(strtolower($item->month)) => $item];
                });

            $allMonthsData = collect($aprilToDecemberData->toArray() + $januaryToMarchData->toArray());

            if ($allMonthsData->isEmpty()) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Monthly Plan"]);
                return $this->sendResponse($this->response, 404);
            }

            $months = ['april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december', 'january', 'february', 'march'];
            $formattedData = [];
            $grandTotal = 0;

            foreach ($months as $month) {
                if (isset($allMonthsData[$month])) {
                    $target = (float)$allMonthsData[$month]['total_target'];
                    $formattedData[ucfirst($month)] = $target;
                    $grandTotal += $target;
                } else {
                    $formattedData[ucfirst($month)] = 0;
                }
            }

            if ($isExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                $headers = array_merge(['Financial Year'], array_map('ucfirst', $months));
                $sheet->fromArray([$headers], null, 'A1');

                $yearFormatted = $year . '-' . substr($nextYear, -2);
                $dataRow = array_merge([$yearFormatted], array_values($formattedData));

                $sheet->fromArray([$dataRow], null, 'A2');

                $timestamp = date('Y-m-d_H-i-s');
                $store = "storage/app/public/uploads/data_analysis/monthly_$timestamp.csv";
                $filePathMonthly = "storage/uploads/data_analysis/monthly_$timestamp.csv";
                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }

            $users = User::with('roles')->orderBy("name", "asc")
                ->whereHas('roles', function ($query) {
                    $query->where('fk_department_id', 5);
                    $query->whereNot('fk_department_id', 1);
                })->pluck('id');

            $aprilToDecemberDataRSM = MonthlyPlanExcel::select('rsm_id', 'month', DB::raw('SUM(target) as total_target'))
                ->where('year', $year)
                ->whereIn('month', ['april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'])
                ->when($startDate && $endDate, function ($query) use ($startDate, $endDate, $year) {
                    $startMonth = strtolower($startDate->format('F'));
                    $endMonth = strtolower($endDate->format('F'));
                    $startYear = $startDate->year;
                    $endYear = $endDate->year;

                    if ($startYear == $year) {
                        $query->where('month', '>=', $startMonth);
                    }
                    if ($endYear == $year) {
                        $query->where('month', '<=', $endMonth);
                    }
                })
                ->groupBy('rsm_id', 'month')
                ->get()
                ->mapWithKeys(function ($item) {
                    $rsmId = trim(strtolower($item->rsm_id));
                    $month = trim(strtolower($item->month));
                    return ["{$rsmId}_{$month}" => $item];
                });

            $januaryToMarchDataRSM = MonthlyPlanExcel::select('rsm_id', 'month', DB::raw('SUM(target) as total_target'))
                ->where('year', $nextYear)
                ->whereIn('month', ['january', 'february', 'march'])
                ->when($startDate && $endDate, function ($query) use ($startDate, $endDate, $nextYear) {
                    $startMonth = strtolower($startDate->format('F'));
                    $endMonth = strtolower($endDate->format('F'));
                    $startYear = $startDate->year;
                    $endYear = $endDate->year;

                    if ($startYear == $nextYear) {
                        $query->where('month', '>=', $startMonth);
                    }
                    if ($endYear == $nextYear) {
                        $query->where('month', '<=', $endMonth);
                    }
                })
                ->groupBy('rsm_id', 'month')
                ->get()
                ->mapWithKeys(function ($item) {
                    $rsmId = trim(strtolower($item->rsm_id));
                    $month = trim(strtolower($item->month));
                    return ["{$rsmId}_{$month}" => $item];
                });

            $allRsmData = collect($aprilToDecemberDataRSM->toArray() + $januaryToMarchDataRSM->toArray());

            $rsmUsers = User::whereIn('id', $users)
                ->orderBy('name', 'asc')
                ->get();

            $rsmData = [];
            foreach ($rsmUsers as $user) {
                $rsmId = strtolower($user->id);
                $individualMonthly = [];
                $individualTotal = 0;

                foreach ($months as $m) {
                    $key = "{$rsmId}_" . strtolower($m);
                    if (isset($allRsmData[$key])) {
                        $val = (float) $allRsmData[$key]['total_target'];
                    } else {
                        $val = 0;
                    }
                    $individualMonthly[ucfirst($m)] = $val;
                    $individualTotal += $val;
                }

                $rsmData[] = [
                    'rsm_id'       => (int)$user->id,
                    'rsm_name'     => $user->name,
                    'monthly_data' => $individualMonthly,
                    'grand_total'  => moneyFormatIndia($individualTotal),
                ];
            }

            if ($isExportRsm == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                $headers = [
                    'RSM Name',
                    'April',
                    'May',
                    'June',
                    'July',
                    'August',
                    'September',
                    'October',
                    'November',
                    'December',
                    'January',
                    'February',
                    'March',
                    'Grand Total'
                ];

                $rows = [];
                foreach ($rsmData as $rsm) {
                    $rows[] = [
                        $rsm['rsm_name'],
                        $rsm['monthly_data']['April'],
                        $rsm['monthly_data']['May'],
                        $rsm['monthly_data']['June'],
                        $rsm['monthly_data']['July'],
                        $rsm['monthly_data']['August'],
                        $rsm['monthly_data']['September'],
                        $rsm['monthly_data']['October'],
                        $rsm['monthly_data']['November'],
                        $rsm['monthly_data']['December'],
                        $rsm['monthly_data']['January'],
                        $rsm['monthly_data']['February'],
                        $rsm['monthly_data']['March'],
                        $rsm['grand_total'],
                    ];
                }

                $sheet->fromArray($headers, null, 'A1');

                $sheet->fromArray($rows, null, 'A2');

                $timestamp = date('Y-m-d_H-i-s');
                $store = "storage/app/public/uploads/data_analysis/rsm_monthly_$timestamp.csv";
                $filePathRsm = "storage/uploads/data_analysis/rsm_monthly_$timestamp.csv";
                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }

            $isVisible = false;
            if ($this->userId == 4) {
                $isVisible = true;
            }


            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Monthly Plan"]);
            $this->response['data'] = [
                'monthly_targets' => $formattedData,
                'financial_year'  => $year . '-' . substr($nextYear, -2),
                'grand_total'     => moneyFormatIndia($grandTotal),
                'rsm_data'        => $rsmData,
                'rsm_id'   => $rsmId ?? '',
                'division_id'   => $divisionId ?? '',
                'division_name'  => $divisionName ?? '',
                'is_visible'        => $isVisible,
                'monthly_file_path'        => $filePathMonthly ?? '',
                'rsm_file_path'        => $filePathRsm ?? '',
                'year'        => $year,
                'date_range'        => $dateRange ?? '',
            ];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Monthly Plan fetching failed: " . $e);
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function projectSheetReport(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $dateRange = $request->input('date_range', 'lifetime');
            $startDate = null;
            $endDate = null;

            if ($dateRange !== 'lifetime') {
                switch ($dateRange) {
                    case 'last_month':
                        $startDate = now()->subMonth()->startOfMonth();
                        $endDate = now()->subMonth()->endOfMonth();
                        break;
                    case 'this_month':
                        $startDate = now()->startOfMonth();
                        $endDate = now()->endOfMonth();
                        break;
                    case 'this_financial_year':
                        $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                        $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                        break;
                    case 'last_financial_year':
                        $currentYear = now()->month >= 4 ? now()->year - 1 : now()->year - 2;
                        $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                        break;
                    case 'q1_this_year':
                        $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                        $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear, 6, 30)->endOfDay();
                        break;
                    case 'q2_this_year':
                        $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                        $startDate = now()->createFromDate($currentYear, 7, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear, 9, 30)->endOfDay();
                        break;
                    case 'q3_this_year':
                        $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                        $startDate = now()->createFromDate($currentYear, 10, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear, 12, 31)->endOfDay();
                        break;
                    case 'q4_this_year':
                        $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                        $startDate = now()->createFromDate($currentYear + 1, 1, 1)->startOfDay();
                        $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                        break;
                    case 'custom_date':
                        $startDate = $request->input('start_date') ? Carbon::parse($request->input('start_date'))->startOfDay() : null;
                        $endDate = $request->input('end_date') ? Carbon::parse($request->input('end_date'))->endOfDay() : null;
                        break;
                    default:
                        $startDate = null;
                        $endDate = null;
                        break;
                }
            }

            $year = $startDate ? $startDate->year : (now()->month >= 4 ? now()->year : now()->subYear()->year);
            $nextYear = $year + 1;
            $isExport = $request->is_export ?? 0;

            $divisionId = $request->input('division_id', null);
            $rsmId = $request->input('rsm_id', null);

            $userObj = User::find($this->userId);
            $divisionIds = !empty($userObj->division_ids) ? explode(',', $userObj->division_ids) : [];

            $rsmDivisionIds = [];
            if (!empty($divisionIds)) {
                $rsmDivisions  = User::whereIn('division_ids', [$divisionId])->get('id')->toArray();
                $rsmDivisionIds = array_column($divisionIds, 'id');
            }

            $divisionName = $divisionId ? Division::where('id', $divisionId)->value('name') : null;

            $leadIds = Lead::when($divisionId, function ($query) use ($divisionId) {
                return $query->where('division_id', $divisionId);
            })->pluck('id');

            $actualSales = PurchaseOrder::select(
                DB::raw("LOWER(MONTHNAME(po_date)) as month"),
                DB::raw("SUM(total_basic_value_in_inr) as total_actual")
            )
                ->when(!empty($leadIds), function ($query) use ($leadIds) {
                    $query->whereIn('fk_lead_id', $leadIds);
                })
                ->when($rsmId, function ($query) use ($rsmId) {
                    $query->where('created_by', $rsmId);
                })
                ->where('po_type', 1)
                ->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                    $query->whereBetween('po_date', [$startDate, $endDate]);
                })
                ->when(!empty($rsmDivisionIds), function ($query) use ($rsmDivisionIds) {
                    $query->whereIn('created_by', $rsmDivisionIds);
                })
                ->groupBy('month')
                ->get()
                ->mapWithKeys(function ($item) {
                    return [$item->month => (float) ($item->total_actual ?? 0)];
                })->all();


            $aprilToDecemberPlan = MonthlyPlanExcel::select('month', DB::raw('SUM(target) as total_target'))
                ->where('year', $year)
                ->whereIn('month', [
                    'april',
                    'may',
                    'june',
                    'july',
                    'august',
                    'september',
                    'october',
                    'november',
                    'december'
                ])
                ->when($startDate && $endDate, function ($query) use ($startDate, $endDate, $year) {
                    $startMonth = strtolower($startDate->format('F'));
                    $endMonth = strtolower($endDate->format('F'));
                    $startYear = $startDate->year;
                    $endYear = $endDate->year;

                    if ($startYear == $year) {
                        $query->where('month', '>=', $startMonth);
                    }
                    if ($endYear == $year) {
                        $query->where('month', '<=', $endMonth);
                    }
                })
                ->when(!empty($rsmDivisionIds), function ($query) use ($rsmDivisionIds) {
                    $query->whereIn('rsm_id', $rsmDivisionIds);
                })
                ->when($rsmId, function ($query) use ($rsmId) {
                    $query->where('rsm_id', $rsmId);
                })
                ->groupBy('month')
                ->get()
                ->mapWithKeys(function ($item) {
                    return [strtolower($item->month) => (float) ($item->total_target ?? 0)];
                })->all();

            $januaryToMarchPlan = MonthlyPlanExcel::select('month', DB::raw('SUM(target) as total_target'))
                ->where('year', $nextYear)
                ->whereIn('month', ['january', 'february', 'march'])
                ->when($startDate && $endDate, function ($query) use ($startDate, $endDate, $nextYear) {
                    $startMonth = strtolower($startDate->format('F'));
                    $endMonth = strtolower($endDate->format('F'));
                    $startYear = $startDate->year;
                    $endYear = $endDate->year;

                    if ($startYear == $nextYear) {
                        $query->where('month', '>=', $startMonth);
                    }
                    if ($endYear == $nextYear) {
                        $query->where('month', '<=', $endMonth);
                    }
                })
                ->when(!empty($rsmDivisionIds), function ($query) use ($rsmDivisionIds) {
                    $query->whereIn('rsm_id', $rsmDivisionIds);
                })
                ->when($rsmId, function ($query) use ($rsmId) {
                    $query->where('rsm_id', $rsmId);
                })
                ->groupBy('month')
                ->get()
                ->mapWithKeys(function ($item) {
                    return [$item->month => (float) ($item->total_target ?? 0)];
                })->all();

            $plannedSales = array_merge($aprilToDecemberPlan, $januaryToMarchPlan);

            $months = [
                'april',
                'may',
                'june',
                'july',
                'august',
                'september',
                'october',
                'november',
                'december',
                'january',
                'february',
                'march'
            ];

            $actualRow = [
                'label'       => 'Actual Sales',
                'monthly_data' => [],
                'grand_total' => 0
            ];
            foreach ($months as $m) {
                $val = $actualSales[$m] ?? 0.0;
                $actualRow['monthly_data'][ucfirst($m)] = $val;
                $actualRow['grand_total'] += $val;
            }


            $planRow = [
                'label'       => 'Planned Sales',
                'monthly_data' => [],
                'grand_total' => 0
            ];
            foreach ($months as $m) {
                $val = $plannedSales[$m] ?? 0.0;
                $planRow['monthly_data'][ucfirst($m)] = $val;
                $planRow['grand_total'] += $val;
            }

            $achievementRow = [
                'label'       => 'Achievement (%)',
                'monthly_data' => [],
                'grand_total' => 0
            ];

            $sumOfMonthlyPercent = 0;

            foreach ($months as $m) {
                $planVal   = $planRow['monthly_data'][ucfirst($m)];
                $actualVal = $actualRow['monthly_data'][ucfirst($m)];

                $percent = 0;
                if ($planVal > 0) {
                    $percent = ($actualVal / $planVal) * 100;
                }

                $achievementRow['monthly_data'][ucfirst($m)] = round($percent, 2);
                $sumOfMonthlyPercent += $percent;
            }

            if ($planRow['grand_total'] > 0) {
                $achievementRow['grand_total'] = round(
                    ($actualRow['grand_total'] / $planRow['grand_total']) * 100,
                    2
                );
            } else {
                $achievementRow['grand_total'] = 0;
            }

            if ($isExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                $headers = [
                    'Description',
                    'April',
                    'May',
                    'June',
                    'July',
                    'August',
                    'September',
                    'October',
                    'November',
                    'December',
                    'January',
                    'February',
                    'March',
                    'Grand Total'
                ];
                $sheet->fromArray($headers, null, 'A1');

                $rowData = [];

                // Row 1: Actual Sales
                $actualSalesRow = array_merge(
                    ['Actual Sales'],
                    array_values($actualRow['monthly_data']),
                    [$actualRow['grand_total']]
                );
                $rowData[] = $actualSalesRow;

                // Row 2: Planned Sales
                $plannedSalesRow = array_merge(
                    ['Planned Sales'],
                    array_values($planRow['monthly_data']),
                    [$planRow['grand_total']]
                );
                $rowData[] = $plannedSalesRow;

                // Row 3: Achievement (%)
                $achievementRowData = array_merge(
                    ['Achievement (%)'],
                    array_values($achievementRow['monthly_data']),
                    [$achievementRow['grand_total']]
                );
                $rowData[] = $achievementRowData;

                $sheet->fromArray($rowData, null, 'A2');

                $timestamp = date('Y-m-d_H-i-s');
                $store = storage_path("app/public/uploads/data_analysis/sales_performance_$timestamp.csv");
                $filePath = "storage/uploads/data_analysis/sales_performance_$timestamp.csv";

                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Project Sheet"]);
            $this->response['data'] = [
                'financial_year' => $year . '-' . substr($nextYear, -2),
                'division_id'    => $divisionId,
                'filePath'       => $filePath ?? '',
                'project_year'   => $year,
                'rsm_id'   => $rsmId ?? '',
                'division_name'  => $divisionName,
                'date_range'  => $dateRange ?? '',
                'rows' => [
                    $actualRow,
                    $planRow,
                    $achievementRow
                ]
            ];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Project Sheet fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function projectSheetQuotationReport(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $currentDate = now();

            $startYear = ($currentDate->month >= 4) ? $currentDate->year : $currentDate->year - 1;
            $endYear = $startYear + 1;

            $projectQuotationTemp = ProjectQuotationTemp::select('id', 'fk_lead_id', 'fk_rfq_id', 'requirements',)->with(['lead:id,company,application', 'rfq:id,project_segments,curr_sub_stage_id', 'rfq.subStage:id,name'])
                ->whereBetween('quotation_date', ["$startYear-04-01", "$endYear-03-31"])
                ->get();


            $isVisible = false;
            if ($this->userId === 4) {
                $isVisible = true;
            }


            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Project Sheet"]);
            $this->response['data']['list'] = ProjectSheetResource::collection($projectQuotationTemp);
            $this->response['data']['is_visible'] = $isVisible;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Project Sheet fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function pendingQuotation(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $dateRange = $request->input('date_range', 'lifetime');
            $startDate = null;
            $endDate = null;
            $rsmId = $request->input('rsm_id', null);
            $divisionId = $request->input('division_id', null);
            $productId = $request->input('product_id', null);
            $highValue = $request->input('high_value', 0);
            $partId = $request->input('part_id', null);
            $regionId = $request->input('region_id', null);

            switch ($dateRange) {
                case 'last_month':
                    $startDate = now()->subMonth()->startOfMonth();
                    $endDate = now()->subMonth()->endOfMonth();
                    break;

                case 'this_month':
                    $startDate = now()->startOfMonth();
                    $endDate = now()->endOfMonth();
                    break;

                case 'this_financial_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'last_financial_year':
                    $currentYear = now()->month >= 4 ? now()->year - 1 : now()->year - 2;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'q1_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 6, 30)->endOfDay();
                    break;

                case 'q2_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 7, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 9, 30)->endOfDay();
                    break;

                case 'q3_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 10, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 12, 31)->endOfDay();
                    break;

                case 'q4_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear + 1, 1, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'custom_date':
                    $startDate = $request->input('start_date')
                        ? Carbon::parse($request->input('start_date'))->startOfDay()
                        : now()->startOfMonth();
                    $endDate = $request->input('end_date')
                        ? Carbon::parse($request->input('end_date'))->endOfDay()
                        : now()->endOfMonth();
                    break;

                case 'lifetime':
                default:
                    $startDate = null;
                    $endDate = null;
                    break;
            }

            $query = ProjectQuotationTemp::select([
                'id',
                'fk_lead_id',
                'quotation_no',
                'quotation_date',
                'fk_rfq_id',
                'total_basic_value',
                'requirements'
            ])
                ->with([
                    'lead:id,company,fk_region_id',
                    'rfq:id,curr_sub_stage_id,rsm_id',
                    'rfq.subStage:id,name',
                    'purchaseOrder'
                ])
                ->when($startDate && $endDate, fn($q) => $q->whereBetween('quotation_date', [$startDate, $endDate]))
                ->whereHas('lead')
                ->whereDoesntHave('purchaseOrder');

            if (!empty($productId)) {
                $query->whereRaw("JSON_SEARCH(JSON_EXTRACT(requirements, '$[*].product_id'), 'one', ?) IS NOT NULL", [$productId]);
            }


            if ($highValue === 'below_5_lakh') {
                $query->where('total_basic_value', '<=', 500000);
            } elseif ($highValue === 'above_5_lakh') {
                $query->where('total_basic_value', '>', 500000);
            } elseif ($highValue === 'above_10_lakh') {
                $query->where('total_basic_value', '>', 1000000);
            } elseif ($highValue === 'above_20_lakh') {
                $query->where('total_basic_value', '>', 2000000);
            }

            if (!empty($partId)) {
                $query->whereRaw(
                    "JSON_CONTAINS(requirements, ?)",
                    [json_encode(['part_noId' => (int) $partId])]
                );
            }

            if (!empty($regionId)) {
                $query->whereHas('lead', function ($q) use ($regionId) {
                    $q->where('fk_region_id', $regionId);
                });
            }

            if (!empty($rsmId) || !empty($divisionId)) {
                $query->whereHas('rfq', function ($q) use ($rsmId, $divisionId) {
                    if (!empty($rsmId)) $q->where('rsm_id', $rsmId);
                    if (!empty($divisionId)) $q->where('division_id', $divisionId);
                });
            }

            $numRows = $query->count();
            $results = $query->get();

            $isVisible = false;
            if ($this->userId === 4) {
                $isVisible = true;
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Pending Quotations"]);
            $this->response['data']['list'] = $results;
            $this->response['data']['rsm_id'] = $rsmId;
            $this->response['data']['num_rows'] = $numRows;
            $this->response['data']['division_id'] = $divisionId;
            $this->response['data']['product_id'] = $productId;
            $this->response['data']['part_id'] = $partId;
            $this->response['data']['region_id'] = $regionId;
            $this->response['data']['is_visible'] = $isVisible;
            $this->response['data']['high_value'] = $highValue;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Pending Quotation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    public function lostQuotation(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $year = $request->year ?? '';
            $dateRange = $request->date_range ?? '';
            $highValue = $request->high_value ?? '';

            if (!empty($year) && preg_match('/^\d{4}-\d{4}$/', $year)) {
                [$startYear, $endYear] = explode('-', $year);
                $startDate = "$startYear-04-01";
                $endDate = "$endYear-03-31";
            } else {
                $currentYear = date('Y');
                $prevYear = $currentYear - 1;
                $startDate = "$prevYear-04-01";
                $endDate = "$currentYear-03-31";
            }


            $query = ProjectQuotationTemp::select('id', 'fk_lead_id', 'quotation_no', 'quotation_date', 'fk_rfq_id', 'requirements')->with(['lead:id,company', 'rfq:id,curr_sub_stage_id', 'rfq.subStage:id,name', 'purchaseOrder'])
                ->whereBetween('quotation_date', [$startDate, $endDate])
                ->whereHas('rfq', function ($q) {
                    $q->where('curr_sub_stage_id', 57);
                })
                ->whereDoesntHave('purchaseOrder');

            if ($highValue === 'below_5_lakh') {
                $query->where('total_basic_value', '<=', 500000);
            } elseif ($highValue === 'above_5_lakh') {
                $query->where('total_basic_value', '>', 500000);
            } elseif ($highValue === 'above_10_lakh') {
                $query->where('total_basic_value', '>', 1000000);
            } elseif ($highValue === 'above_20_lakh') {
                $query->where('total_basic_value', '>', 2000000);
            }

            $result = $query->get();

            $isVisible = false;
            if ($this->userId === 4) {
                $isVisible = true;
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Pending Quotations"]);
            $this->response['data']['list'] = $result;
            $this->response['data']['is_visible'] = $isVisible;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Pending Quotation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function dataAnalysis(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $rsmWiseExport = $request->is_export_rsm_wise;
            $regionWiseExport = $request->is_export_region_wise;
            $industryWiseExport = $request->is_export_industry_wise;
            $projectTypeWiseExport = $request->is_export_project_type_wise;

            $dateRange = $request->input('date_range', 'lifetime');
            $regionId = $request->input('region_id', '');
            $divisionId = $request->input('division_id', '');
            $rsmId = $request->input('rsm_id', '');
            $startDate = null;
            $endDate = null;

            switch ($dateRange) {
                case 'last_month':
                    $startDate = now()->subMonth()->startOfMonth();
                    $endDate = now()->subMonth()->endOfMonth();
                    break;

                case 'this_month':
                    $startDate = now()->startOfMonth();
                    $endDate = now()->endOfMonth();
                    break;

                case 'this_financial_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'last_financial_year':
                    $currentYear = now()->month >= 4 ? now()->year - 1 : now()->year - 2;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'q1_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 6, 30)->endOfDay();
                    break;

                case 'q2_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 7, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 9, 30)->endOfDay();
                    break;

                case 'q3_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 10, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 12, 31)->endOfDay();
                    break;

                case 'q4_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear + 1, 1, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'custom_date':
                    $startDate = $request->input('start_date')
                        ? Carbon::parse($request->input('start_date'))->startOfDay()
                        : now()->startOfMonth();
                    $endDate = $request->input('end_date')
                        ? Carbon::parse($request->input('end_date'))->endOfDay()
                        : now()->endOfMonth();
                    break;

                case 'lifetime':
                default:
                    $startDate = null;
                    $endDate = null;
                    break;
            }


            $query = User::with('roles')
                ->whereHas('roles', function ($query) {
                    $query->where('fk_department_id', 5)
                        ->whereNot('fk_department_id', 1);
                })
                ->withCount([
                    'rfqs as rfq_count' => function ($query) use ($startDate, $endDate, $regionId, $divisionId) {
                        if ($startDate && $endDate) {
                            $query->whereBetween('rfqs.rfq_date', [$startDate, $endDate]);
                        }

                        if ($divisionId) {
                            $query->where('rfqs.division_id', $divisionId);
                        }

                        if ($regionId) {
                            $query->whereHas('lead', function ($q) use ($regionId) {
                                $q->where('fk_region_id', $regionId);
                            });
                        }
                    },
                    'rfqs as quotation_count' => function ($query) use ($startDate, $endDate, $regionId, $divisionId) {
                        $query->join('project_quotation_temps', 'rfqs.id', '=', 'project_quotation_temps.fk_rfq_id');
                        if ($startDate && $endDate) {
                            $query->whereBetween('project_quotation_temps.quotation_date', [$startDate, $endDate]);
                        }

                        if ($divisionId) {
                            $query->where('rfqs.division_id', $divisionId);
                        }

                        if ($regionId) {
                            $query->whereHas('lead', function ($q) use ($regionId) {
                                $q->where('fk_region_id', $regionId);
                            });
                        }
                    },
                    'rfqs as purchase_order_count' => function ($query) use ($startDate, $endDate, $regionId, $divisionId) {
                        $query->join('purchase_orders', 'rfqs.id', '=', 'purchase_orders.fk_rfq_id');
                        if ($startDate && $endDate) {
                            $query->whereBetween('purchase_orders.po_date', [$startDate, $endDate]);
                        }

                        if ($divisionId) {
                            $query->where('rfqs.division_id', $divisionId);
                        }

                        if ($regionId) {
                            $query->whereHas('lead', function ($q) use ($regionId) {
                                $q->where('fk_region_id', $regionId);
                            });
                        }
                    },
                    'rfqs as sales_order_count' => function ($query) use ($startDate, $endDate, $regionId, $divisionId) {
                        $query->join('avlock_sales_orders', 'rfqs.id', '=', 'avlock_sales_orders.fk_rfq_id');
                        if ($startDate && $endDate) {
                            $query->whereBetween('avlock_sales_orders.so_date', [$startDate, $endDate]);
                        }

                        if ($divisionId) {
                            $query->where('rfqs.division_id', $divisionId);
                        }

                        if ($regionId) {
                            $query->whereHas('lead', function ($q) use ($regionId) {
                                $q->where('fk_region_id', $regionId);
                            });
                        }
                    },
                    'rfqs as pending_order_count' => function ($query) use ($startDate, $endDate, $regionId, $divisionId) {
                        $query->join('project_quotation_temps', 'rfqs.id', '=', 'project_quotation_temps.fk_rfq_id')
                            ->leftJoin('purchase_orders', 'project_quotation_temps.id', '=', 'purchase_orders.fk_quotation_id')
                            ->whereNull('purchase_orders.id');
                        if ($startDate && $endDate) {
                            $query->whereBetween('project_quotation_temps.quotation_date', [$startDate, $endDate]);
                        }

                        if ($divisionId) {
                            $query->where('rfqs.division_id', $divisionId);
                        }

                        if ($regionId) {
                            $query->whereHas('lead', function ($q) use ($regionId) {
                                $q->where('fk_region_id', $regionId);
                            });
                        }
                    }
                ]);

            $users = $query->get(['id', 'name']);

            $rsmWise = $users->map(function ($user) {
                return [
                    'rsm_name' => $user->name,
                    'rfq_count' => $user->rfq_count,
                    'quotation_count' => $user->quotation_count,
                    'purchase_order_count' => $user->purchase_order_count,
                    'sales_order_count' => $user->sales_order_count,
                    'pending_order_count' => $user->pending_order_count,
                ];
            });

            if ($rsmWiseExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                // Headers
                $headers = ['RSM Name', 'RFQ Count', 'Quotation Count', 'Purchase Order Count', 'Sales Order Count', 'Pending Order Count'];
                $sheet->fromArray([$headers], null, 'A1');

                $rowIndex = 2;
                foreach ($rsmWise as $rsmItem) {
                    $baseRowData = [
                        $rsmItem['rsm_name'] ?? 0,
                        $rsmItem['rfq_count'] ?? 0,
                        $rsmItem['quotation_count'] ?? 0,
                        $rsmItem['purchase_order_count'] ?? 0,
                        $rsmItem['sales_order_count'] ?? 0,
                        $rsmItem['pending_order_count'] ?? 0,
                    ];

                    $sheet->fromArray([$baseRowData], null, "A$rowIndex");
                    $rowIndex++;
                }

                $timestamp = date('Y-m-d_H-i-s');
                $store = storage_path("app/public/uploads/data_analysis/rsm_wise_$timestamp.csv");
                $rsmFilePath = "storage/uploads/data_analysis/rsm_wise_$timestamp.csv";

                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }


            //Region Wise
            $regions = Region::withCount([
                'leads',
                'leads as rfq_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('rfqs', function ($q) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $q->whereBetween('rfqs.rfq_date', [$startDate, $endDate]);
                        }
                    });
                },
                'leads as quotation_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('rfqs.quotationTemp', function ($q) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $q->whereBetween('quotation_date', [$startDate, $endDate]);
                        }
                    });
                },
                'leads as purchase_order_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('rfqs.purchaseOrder', function ($q) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $q->whereBetween('po_date', [$startDate, $endDate]);
                        }
                    });
                },
                'leads as sales_order_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('rfqs.salesOrder', function ($q) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $q->whereBetween('so_date', [$startDate, $endDate]);
                        }
                    });
                },
                'leads as pending_order_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('rfqs.quotationTemp', function ($q) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $q->whereBetween('quotation_date', [$startDate, $endDate]);
                        }
                    })->whereDoesntHave('rfqs.purchaseOrder');
                }
            ])->get(['id', 'name']);


            $regionWise = $regions->map(function ($region) {
                return [
                    'region_name' => $region->name,
                    'rfq_count' => $region->rfq_count,
                    'quotation_count' => $region->quotation_count,
                    'purchase_order_count' => $region->purchase_order_count,
                    'sales_order_count' => $region->sales_order_count,
                    'pending_order_count' => $region->pending_order_count,
                ];
            });


            if ($regionWiseExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                // Headers
                $headers = ['RSM Name', 'RFQ Count', 'Quotation Count', 'Purchase Order Count', 'Sales Order Count', 'Pending Order Count'];
                $sheet->fromArray([$headers], null, 'A1');

                $rowIndex = 2;
                foreach ($regionWise as $regionItem) {
                    $baseRowData = [
                        $regionItem['region_name'] ?? 0,
                        $regionItem['rfq_count'] ?? 0,
                        $regionItem['quotation_count'] ?? 0,
                        $regionItem['purchase_order_count'] ?? 0,
                        $regionItem['sales_order_count'] ?? 0,
                        $regionItem['pending_order_count'] ?? 0,
                    ];

                    $sheet->fromArray([$baseRowData], null, "A$rowIndex");
                    $rowIndex++;
                }

                $timestamp = date('Y-m-d_H-i-s');
                $store = storage_path("app/public/uploads/data_analysis/region_wise_$timestamp.csv");
                $regionFilePath = "storage/uploads/data_analysis/region_wise_$timestamp.csv";

                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }


            //Industry Wise
            $industries = Industry::all();
            $industryWise = [];

            foreach ($industries as $industry) {
                $rfqQuery = Rfq::with(['lead:id,fk_region_id'])->whereRaw("JSON_CONTAINS(industry, ?, '$')", [json_encode(['id' => $industry->id])]);

                if ($startDate && $endDate) {
                    $rfqQuery->whereBetween('rfq_date', [$startDate, $endDate]);
                }

                if ($divisionId) {
                    $rfqQuery->where('division_id', $divisionId);
                }

                if ($rsmId) {
                    $rfqQuery->where('rsm_id', $rsmId)
                        ->orWhere('created_by', $rsmId);
                }

                if ($regionId) {
                    $rfqQuery->whereHas('lead', function ($q) use ($regionId) {
                        $q->where('fk_region_id', $regionId);
                    });
                }

                $rfqs = $rfqQuery->pluck('id');
                $rfqCount = $rfqs->count();

                $quotationQuery = ProjectQuotationTemp::with(['lead:id,fk_region_id', 'rfq:id,division_id,rsm_id,created_by'])->whereIn('fk_rfq_id', $rfqs)
                    ->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                        return $query->whereBetween('quotation_date', [$startDate, $endDate]);
                    });

                if ($divisionId) {
                    $quotationQuery->whereHas('rfq', function ($q) use ($divisionId) {
                        $q->where('division_id', $divisionId);
                    });
                }

                if ($rsmId) {
                    $quotationQuery->whereHas('rfq', function ($q) use ($rsmId) {
                        $q->where('rsm_id', $rsmId)
                            ->orWhere('created_by', $rsmId);
                    });
                }

                if ($regionId) {
                    $quotationQuery->whereHas('lead', function ($q) use ($regionId) {
                        $q->where('fk_region_id', $regionId);
                    });
                }


                $quotationCount = $quotationQuery->count();
                $quotationSum = $quotationQuery->sum('total_basic_value');

                $purchaseOrderQuery = PurchaseOrder::with(['lead:id,fk_region_id', 'rfq:id,division_id,rsm_id,created_by'])->whereIn('fk_rfq_id', $rfqs)
                    ->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                        return $query->whereBetween('po_date', [$startDate, $endDate]);
                    });

                if ($divisionId) {
                    $purchaseOrderQuery->whereHas('rfq', function ($q) use ($divisionId) {
                        $q->where('division_id', $divisionId);
                    });
                }

                if ($rsmId) {
                    $purchaseOrderQuery->whereHas('rfq', function ($q) use ($rsmId) {
                        $q->where('rsm_id', $rsmId)
                            ->orWhere('created_by', $rsmId);
                    });
                }

                if ($regionId) {
                    $purchaseOrderQuery->whereHas('lead', function ($q) use ($regionId) {
                        $q->where('fk_region_id', $regionId);
                    });
                }


                $purchaseOrderCount = $purchaseOrderQuery->count();
                $purchaseOrderTotal = $purchaseOrderQuery->sum('total_basic_value');

                $salesOrderQuery = AvlockSalesOrder::with(['lead:id,fk_region_id', 'rfq:id,division_id,rsm_id,created_by'])->whereIn('fk_rfq_id', $rfqs)
                    ->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                        return $query->whereBetween('so_date', [$startDate, $endDate]);
                    });

                if ($divisionId) {
                    $salesOrderQuery->whereHas('rfq', function ($q) use ($divisionId) {
                        $q->where('division_id', $divisionId);
                    });
                }

                if ($rsmId) {
                    $salesOrderQuery->whereHas('rfq', function ($q) use ($rsmId) {
                        $q->where('rsm_id', $rsmId)
                            ->orWhere('created_by', $rsmId);
                    });
                }

                if ($regionId) {
                    $salesOrderQuery->whereHas('lead', function ($q) use ($regionId) {
                        $q->where('fk_region_id', $regionId);
                    });
                }

                $salesOrderCount = $salesOrderQuery->count();
                $salesOrderTotal = $salesOrderQuery->sum('final_amount');

                $pendingOrderQuery = ProjectQuotationTemp::with(['lead:id,fk_region_id', 'rfq:id,division_id,rsm_id,created_by'])
                    ->whereIn('fk_rfq_id', $rfqs)
                    ->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                        $query->whereBetween('quotation_date', [$startDate, $endDate]);
                    })
                    ->when($divisionId, function ($query) use ($divisionId) {
                        $query->whereHas('rfq', function ($q) use ($divisionId) {
                            $q->where('division_id', $divisionId);
                        });
                    })
                    ->when($rsmId, function ($query) use ($rsmId) {
                        $query->whereHas('rfq', function ($q) use ($rsmId) {
                            $q->where('rsm_id', $rsmId)
                                ->orWhere('created_by', $rsmId);
                        });
                    })
                    ->when($regionId, function ($query) use ($regionId) {
                        $query->whereHas('lead', function ($q) use ($regionId) {
                            $q->where('fk_region_id', $regionId);
                        });
                    })
                    ->whereNotIn('fk_rfq_id', PurchaseOrder::pluck('fk_rfq_id'));


                $pendingOrderCount = $pendingOrderQuery->count();
                $pendingOrderTotal = $pendingOrderQuery->sum('total_basic_value');

                $industryWise[] = [
                    'industry_name' => $industry->name,
                    'rfq_count' => $rfqCount,
                    'quotation_count' => $quotationCount,
                    'quotation_total' => moneyFormatIndia($quotationSum),
                    'purchase_order_count' => $purchaseOrderCount,
                    'purchase_order_total' => moneyFormatIndia($purchaseOrderTotal),
                    'sales_order_count' => $salesOrderCount,
                    'sales_order_total' => moneyFormatIndia($salesOrderTotal),
                    'pending_order_count' => $pendingOrderCount,
                    'pending_order_total' => moneyFormatIndia($pendingOrderTotal),
                ];
            }


            if ($industryWiseExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                // Headers
                $headers = ['RSM Name', 'RFQ Count', 'Quotation Count', 'Purchase Order Count', 'Sales Order Count', 'Pending Order Count'];
                $sheet->fromArray([$headers], null, 'A1');

                $rowIndex = 2;
                foreach ($industryWise as $industryItem) {
                    $baseRowData = [
                        $industryItem['industry_name'] ?? 0,
                        $industryItem['rfq_count'] ?? 0,
                        $industryItem['quotation_count'] ?? 0,
                        $industryItem['purchase_order_count'] ?? 0,
                        $industryItem['sales_order_count'] ?? 0,
                        $industryItem['pending_order_count'] ?? 0,
                    ];

                    $sheet->fromArray([$baseRowData], null, "A$rowIndex");
                    $rowIndex++;
                }

                $timestamp = date('Y-m-d_H-i-s');
                $store = storage_path("app/public/uploads/data_analysis/industry_wise_$timestamp.csv");
                $industryFilePath = "storage/uploads/data_analysis/industry_wise_$timestamp.csv";

                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }

            $projectTypes = ProjectType::withCount([
                'rfqs as rfq_count' => function ($query) use ($startDate, $endDate) {
                    if ($startDate && $endDate) {
                        $query->whereBetween('rfqs.rfq_date', [$startDate, $endDate]);
                    }
                },
                'rfqs as quotation_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('quotationTemp', function ($subQuery) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $subQuery->whereBetween('quotation_date', [$startDate, $endDate]);
                        }
                    });
                },
                'rfqs as purchase_order_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('purchaseOrder', function ($subQuery) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $subQuery->whereBetween('po_date', [$startDate, $endDate]);
                        }
                    });
                },
                'rfqs as sales_order_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('salesOrder', function ($subQuery) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $subQuery->whereBetween('so_date', [$startDate, $endDate]);
                        }
                    });
                },
                'rfqs as pending_order_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('quotationTemp', function ($subQuery) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $subQuery->whereBetween('quotation_date', [$startDate, $endDate]);
                        }
                    })->whereDoesntHave('purchaseOrder');
                }
            ])->get(['id', 'name']);



            //Project wise
            $projectTypeWise = $projectTypes->map(function ($projectType) {
                return [
                    'project_type_name' => $projectType->name,
                    'rfq_count' => $projectType->rfq_count ?? 0,
                    'quotation_count' => $projectType->quotation_count ?? 0,
                    'purchase_order_count' => $projectType->purchase_order_count ?? 0,
                    'sales_order_count' => $projectType->sales_order_count ?? 0,
                    'pending_order_count' => $projectType->pending_order_count ?? 0,
                ];
            });

            if ($projectTypeWiseExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                // Headers
                $headers = ['RSM Name', 'RFQ Count', 'Quotation Count', 'Purchase Order Count', 'Sales Order Count', 'Pending Order Count'];
                $sheet->fromArray([$headers], null, 'A1');

                $rowIndex = 2;
                foreach ($projectTypeWise as $projectTypeItem) {
                    $baseRowData = [
                        $projectTypeItem['project_type_name'] ?? 0,
                        $projectTypeItem['rfq_count'] ?? 0,
                        $projectTypeItem['quotation_count'] ?? 0,
                        $projectTypeItem['purchase_order_count'] ?? 0,
                        $projectTypeItem['sales_order_count'] ?? 0,
                        $projectTypeItem['pending_order_count'] ?? 0,
                    ];

                    $sheet->fromArray([$baseRowData], null, "A$rowIndex");
                    $rowIndex++;
                }

                $timestamp = date('Y-m-d_H-i-s');
                $store = storage_path("app/public/uploads/data_analysis/project_type_wise_$timestamp.csv");
                $projectTypeFilePath = "storage/uploads/data_analysis/project_type_wise_$timestamp.csv";

                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }


            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Data Analysis"]);
            $this->response['data']['rsm_file_path'] = $rsmFilePath ?? '';
            $this->response['data']['region_file_path'] = $regionFilePath ?? '';
            $this->response['data']['industry_file_path'] = $industryFilePath ?? '';
            $this->response['data']['project_type_file_path'] = $projectTypeFilePath ?? '';
            $this->response['data']['division_id'] = $divisionId ?? '';
            $this->response['data']['region_id'] = $regionId ?? '';
            $this->response['data']['rsm_id'] = $rsmId ?? '';
            $this->response['data']['rsm_wise'] = $rsmWise;
            $this->response['data']['region_wise'] = $regionWise;
            $this->response['data']['industry_wise'] = $industryWise;
            $this->response['data']['project_type_wise'] = $projectTypeWise;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("RSM data fetching failed: " . $e);
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function divisionWiseAnalysis(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $divisions = Division::withCount([
                'rfqs as rfq_count',
                'rfqs as quotation_count' => function ($query) {
                    $query->whereHas('quotationTemp');
                },
                'rfqs as purchase_order_count' => function ($query) {
                    $query->whereHas('purchaseOrder');
                },
                'rfqs as sales_order_count' => function ($query) {
                    $query->whereHas('salesOrder');
                },
                'rfqs as pending_order_count' => function ($query) {
                    $query->whereHas('quotationTemp')
                        ->whereDoesntHave('purchaseOrder');
                }
            ])
                ->with(['rfqs.purchaseOrder', 'rfqs.salesOrder', 'rfqs.quotationTemp'])
                ->get(['id', 'name']);

            $divisionWise = $divisions->map(function ($division) {
                $purchaseTotal = $division->rfqs->flatMap->purchaseOrder->pluck('total_basic_value')->sum();
                $salesTotal = $division->rfqs->flatMap->salesOrder->pluck('final_amount')->sum();
                $quotationTotal = $division->rfqs
                    ->map(function ($rfq) {
                        return optional($rfq->quotationTemp)->total_basic_value;
                    })
                    ->filter()
                    ->sum();

                return [
                    'division_name' => $division->name,
                    'rfq_count' => $division->rfq_count,
                    'quotation_count' => $division->quotation_count,
                    'purchase_order_count' => $division->purchase_order_count,
                    'sales_order_count' => $division->sales_order_count,
                    'pending_order_count' => $division->pending_order_count,
                    'total_purchase_value' => moneyFormatIndia($purchaseTotal),
                    'total_sales_value' => moneyFormatIndia($salesTotal),
                    'total_quotation_value' => moneyFormatIndia($quotationTotal),
                ];
            });

            $isvisible = false;

            $users = User::withTrashed()->with('roles.department')->where('id', $this->userId)
                ->where(function ($query) {
                    $query->whereNotNull('division_head_ids')
                        ->orWhereHas('roles.department', function ($subQuery) {
                            $subQuery->where('departments.id', 10);
                        });
                });

            if ($users->exists()) {
                $isvisible = true;
            }


            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Division Wise Analysis"]);
            $this->response['data']['division_wise'] = $divisionWise;
            $this->response['data']['show_division_wise'] = $isvisible;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Pending Quotation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function customerWiseAnalysis(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $isExport = $request->is_export ?? 0;
            $dateRange = $request->input('date_range', 'lifetime');
            $startDate = null;
            $endDate = null;

            switch ($dateRange) {
                case 'last_month':
                    $startDate = now()->subMonth()->startOfMonth();
                    $endDate = now()->subMonth()->endOfMonth();
                    break;

                case 'this_month':
                    $startDate = now()->startOfMonth();
                    $endDate = now()->endOfMonth();
                    break;

                case 'this_financial_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'last_financial_year':
                    $currentYear = now()->month >= 4 ? now()->year - 1 : now()->year - 2;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'q1_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 6, 30)->endOfDay();
                    break;

                case 'q2_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 7, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 9, 30)->endOfDay();
                    break;

                case 'q3_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 10, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 12, 31)->endOfDay();
                    break;

                case 'q4_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear + 1, 1, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'custom_date':
                    $startDate = $request->input('start_date')
                        ? Carbon::parse($request->input('start_date'))->startOfDay()
                        : now()->startOfMonth();
                    $endDate = $request->input('end_date')
                        ? Carbon::parse($request->input('end_date'))->endOfDay()
                        : now()->endOfMonth();
                    break;

                case 'lifetime':
                default:
                    $startDate = null;
                    $endDate = null;
                    break;
            }

            $leads = Lead::withCount([
                'rfqs as rfq_count' => function ($query) use ($startDate, $endDate) {
                    if ($startDate && $endDate) {
                        $query->whereBetween('rfqs.rfq_date', [$startDate, $endDate]);
                    }
                },
                'rfqs as quotation_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('quotationTemp', function ($q) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $q->whereBetween('quotation_date', [$startDate, $endDate]);
                        }
                    });
                },
                'rfqs as purchase_order_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('purchaseOrder', function ($q) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $q->whereBetween('po_date', [$startDate, $endDate]);
                        }
                    });
                },
                'rfqs as sales_order_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('salesOrder', function ($q) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $q->whereBetween('so_date', [$startDate, $endDate]);
                        }
                    });
                },
                'rfqs as pending_order_count' => function ($query) use ($startDate, $endDate) {
                    $query->whereHas('quotationTemp', function ($q) use ($startDate, $endDate) {
                        if ($startDate && $endDate) {
                            $q->whereBetween('quotation_date', [$startDate, $endDate]);
                        }
                    })->whereDoesntHave('purchaseOrder');
                }
            ])->get(['id', 'name']);

            $leadWise = $leads->map(function ($lead) {
                return [
                    'lead_name' => $lead->company,
                    'rfq_count' => $lead->rfq_count,
                    'quotation_count' => $lead->quotation_count,
                    'purchase_order_count' => $lead->purchase_order_count,
                    'sales_order_count' => $lead->sales_order_count,
                    'pending_order_count' => $lead->pending_order_count,
                ];
            });

            if ($isExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                $headers = ['Customer Name', 'RFQ Count', 'Quotation Count', 'Purchase Order Count', 'Sales Order Count', 'Pending Order Count'];
                $sheet->fromArray([$headers], null, 'A1');

                $rowIndex = 2;
                foreach ($leadWise as $leadItem) {
                    $baseRowData = [
                        $leadItem['lead_name'] ?? 0,
                        $leadItem['rfq_count'] ?? 0,
                        $leadItem['quotation_count'] ?? 0,
                        $leadItem['purchase_order_count'] ?? 0,
                        $leadItem['sales_order_count'] ?? 0,
                        $leadItem['pending_order_count'] ?? 0,
                    ];

                    $sheet->fromArray([$baseRowData], null, "A$rowIndex");
                    $rowIndex++;
                }

                $timestamp = date('Y-m-d_H-i-s');
                $store = storage_path("app/public/uploads/data_analysis/customer_wise_$timestamp.csv");
                $filePath = "storage/uploads/data_analysis/customer_wise_$timestamp.csv";

                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Customer Wise Analysis"]);
            $this->response['data']['customer_wise'] = $leadWise;
            $this->response['data']['filePath'] = $filePath ?? '';

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Customer Wise Analysis fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getConversionRatios(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $dateRange = $request->input('date_range', 'lifetime');
            $regionId = $request->input('region_id', '');
            $divisionId = $request->input('division_id', '');
            $rsmId = $request->input('rsm_id', '');
            $startDate = null;
            $endDate = null;

            switch ($dateRange) {
                case 'last_month':
                    $startDate = now()->subMonth()->startOfMonth();
                    $endDate = now()->subMonth()->endOfMonth();
                    break;

                case 'this_month':
                    $startDate = now()->startOfMonth();
                    $endDate = now()->endOfMonth();
                    break;

                case 'this_financial_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'last_financial_year':
                    $currentYear = now()->month >= 4 ? now()->year - 1 : now()->year - 2;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'q1_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 6, 30)->endOfDay();
                    break;

                case 'q2_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 7, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 9, 30)->endOfDay();
                    break;

                case 'q3_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 10, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 12, 31)->endOfDay();
                    break;

                case 'q4_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear + 1, 1, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'custom_date':
                    $startDate = $request->input('start_date')
                        ? Carbon::parse($request->input('start_date'))->startOfDay()
                        : now()->startOfMonth();
                    $endDate = $request->input('end_date')
                        ? Carbon::parse($request->input('end_date'))->endOfDay()
                        : now()->endOfMonth();
                    break;

                case 'lifetime':
                default:
                    $startDate = null;
                    $endDate = null;
                    break;
            }


            // RFQ to Quotation Ratio
            $totalRfqs = Rfq::with(['lead:id,fk_region_id'])
                ->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                    $query->whereBetween('rfq_date', [$startDate, $endDate]);
                })
                ->when($divisionId, function ($query) use ($divisionId) {
                    $query->where('division_id', $divisionId);
                })
                ->when($rsmId, function ($query) use ($rsmId) {
                    $query->where('rsm_id', $rsmId)
                        ->orWhere('created_by', $rsmId);
                })
                ->when($regionId, function ($query) use ($regionId) {
                    $query->whereHas('lead', function ($q) use ($regionId) {
                        $q->where('fk_region_id', $regionId);
                    });
                })
                ->count();

            $rfqsWithQuotations = ProjectQuotationTemp::with(['lead:id,fk_region_id', 'rfq.id,rsm_id,created_by,division_id'])
                ->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                    $query->whereBetween('quotation_date', [$startDate, $endDate]);
                })
                ->when($regionId, function ($query) use ($regionId) {
                    $query->whereHas('lead', function ($q) use ($regionId) {
                        $q->where('fk_region_id', $regionId);
                    });
                })
                ->when($divisionId, function ($query) use ($divisionId) {
                    $query->whereHas('rfq', function ($q) use ($divisionId) {
                        $q->where('division_id', $divisionId);
                    });
                })
                ->when($rsmId, function ($query) use ($rsmId) {
                    $query->whereHas('rfq', function ($q) use ($rsmId) {
                        $q->where('rsm_id', $rsmId)
                            ->orWhere('created_by', $rsmId);
                    });
                })
                ->select('fk_rfq_id')
                ->distinct()
                ->count();

            $rfqToQuotationRatio = $totalRfqs > 0
                ? round(($rfqsWithQuotations / $totalRfqs) * 100, 2) . '%'
                : '0%';

            $rfqToQuotationData = [
                'rfq_count' => $totalRfqs,
                'quotation_count' => $rfqsWithQuotations,
                'rfq_to_quotation_ratio' => $rfqToQuotationRatio
            ];

            // Quotation to Purchase Order Ratio
            $totalQuotations = ProjectQuotationTemp::with(['lead:id,fk_region_id', 'rfq.id,rsm_id,created_by,division_id'])->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                $query->whereBetween('quotation_date', [$startDate, $endDate]);
            })
                ->when($regionId, function ($query) use ($regionId) {
                    $query->whereHas('lead', function ($q) use ($regionId) {
                        $q->where('fk_region_id', $regionId);
                    });
                })
                ->when($rsmId, function ($query) use ($rsmId) {
                    $query->whereHas('rfq', function ($q) use ($rsmId) {
                        $q->where('rsm_id', $rsmId)
                            ->orWhere('created_by', $rsmId);
                    });
                })
                ->when($divisionId, function ($query) use ($divisionId) {
                    $query->whereHas('rfq', function ($q) use ($divisionId) {
                        $q->where('division_id', $divisionId);
                    });
                })
                ->count();

            $quotationWithPos = PurchaseOrder::with(['lead:id,fk_region_id', 'rfq.id,rsm_id,created_by,division_id'])->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                $query->whereBetween('po_date', [$startDate, $endDate]);
            })
                ->when($regionId, function ($query) use ($regionId) {
                    $query->whereHas('lead', function ($q) use ($regionId) {
                        $q->where('fk_region_id', $regionId);
                    });
                })->when($rsmId, function ($query) use ($rsmId) {
                    $query->whereHas('rfq', function ($q) use ($rsmId) {
                        $q->where('rsm_id', $rsmId)
                            ->orWhere('created_by', $rsmId);
                    });
                })
                ->when($divisionId, function ($query) use ($divisionId) {
                    $query->whereHas('rfq', function ($q) use ($divisionId) {
                        $q->where('division_id', $divisionId);
                    });
                })
                ->distinct('fk_quotation_id')
                ->count();

            $quotationToPoRatio = $totalQuotations > 0 ? round(($quotationWithPos / $totalQuotations) * 100, 2) . '%' : '0%';

            $quotationToPoData = [
                'quotation_count' => $totalQuotations,
                'purchase_order_count' => $quotationWithPos,
                'quotation_to_po_ratio' => $quotationToPoRatio
            ];

            // Purchase Order to Sales Order Ratio
            $totalPurchaseOrders = PurchaseOrder::with(['lead:id,fk_region_id', 'rfq.id,rsm_id,created_by,division_id'])->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                $query->whereBetween('po_date', [$startDate, $endDate]);
            })
                ->when($regionId, function ($query) use ($regionId) {
                    $query->whereHas('lead', function ($q) use ($regionId) {
                        $q->where('fk_region_id', $regionId);
                    });
                })
                ->when($rsmId, function ($query) use ($rsmId) {
                    $query->whereHas('rfq', function ($q) use ($rsmId) {
                        $q->where('rsm_id', $rsmId)
                            ->orWhere('created_by', $rsmId);
                    });
                })
                ->when($divisionId, function ($query) use ($divisionId) {
                    $query->whereHas('rfq', function ($q) use ($divisionId) {
                        $q->where('division_id', $divisionId);
                    });
                })
                ->count();
            $purchaseOrdersWithSales = AvlockSalesOrder::with(['lead:id,fk_region_id', 'rfq.id,rsm_id,created_by,division_id'])->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                $query->whereBetween('so_date', [$startDate, $endDate]);
            })
                ->when($regionId, function ($query) use ($regionId) {
                    $query->whereHas('lead', function ($q) use ($regionId) {
                        $q->where('fk_region_id', $regionId);
                    });
                })
                ->when($rsmId, function ($query) use ($rsmId) {
                    $query->whereHas('rfq', function ($q) use ($rsmId) {
                        $q->where('rsm_id', $rsmId)
                            ->orWhere('created_by', $rsmId);
                    });
                })
                ->when($divisionId, function ($query) use ($divisionId) {
                    $query->whereHas('rfq', function ($q) use ($divisionId) {
                        $q->where('division_id', $divisionId);
                    });
                })
                ->distinct('fk_po_id')
                ->count();
            $poToSalesRatio = $totalPurchaseOrders > 0
                ? round(($purchaseOrdersWithSales / $totalPurchaseOrders) * 100, 2) . '%'
                : '0%';

            $poToSalesData = [
                'purchase_order_count' => $totalPurchaseOrders,
                'sales_order_count' => $purchaseOrdersWithSales,
                'po_to_sales_ratio' => $poToSalesRatio
            ];

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Conversion Ratio"]);
            $this->response['data']['rfq_to_quotation'] = $rfqToQuotationData;
            $this->response['data']['quotation_to_po'] = $quotationToPoData;
            $this->response['data']['po_to_sales'] = $poToSalesData;


            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Pending Quotation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getProjectSheet(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $dateRange = $request->input('date_range', 'lifetime');
            $startDate = null;
            $endDate = null;

            switch ($dateRange) {
                case 'last_month':
                    $startDate = now()->subMonth()->startOfMonth();
                    $endDate = now()->subMonth()->endOfMonth();
                    break;

                case 'this_month':
                    $startDate = now()->startOfMonth();
                    $endDate = now()->endOfMonth();
                    break;

                case 'this_financial_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'last_financial_year':
                    $currentYear = now()->month >= 4 ? now()->year - 1 : now()->year - 2;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'q1_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 4, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 6, 30)->endOfDay();
                    break;

                case 'q2_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 7, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 9, 30)->endOfDay();
                    break;

                case 'q3_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear, 10, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear, 12, 31)->endOfDay();
                    break;

                case 'q4_this_year':
                    $currentYear = now()->month >= 4 ? now()->year : now()->subYear()->year;
                    $startDate = now()->createFromDate($currentYear + 1, 1, 1)->startOfDay();
                    $endDate = now()->createFromDate($currentYear + 1, 3, 31)->endOfDay();
                    break;

                case 'custom_date':
                    $startDate = $request->input('start_date')
                        ? Carbon::parse($request->input('start_date'))->startOfDay()
                        : now()->startOfMonth();
                    $endDate = $request->input('end_date')
                        ? Carbon::parse($request->input('end_date'))->endOfDay()
                        : now()->endOfMonth();
                    break;

                case 'lifetime':
                default:
                    $startDate = null;
                    $endDate = null;
                    break;
            }

            $rfqLists = Rfq::select('id', 'lead_id', 'rfq_date', 'rsm_id', 'project_segments')
                ->with([
                    'rsm:id,name',
                    'lead:id,company',
                ])
                ->whereHas('lead')
                ->when($startDate && $endDate, function ($query) use ($startDate, $endDate) {
                    $query->whereBetween('rfq_date', [$startDate, $endDate]);
                })->get();

            $result = RfqProjectSheetResource::collection($rfqLists);


            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Project Sheet"]);
            $this->response['data']['list'] = $result;


            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Project Sheet fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function divisonHeadLists(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $name = $request->name ?? '';
            $userObj = User::find($this->userId);
            $divisionIds = !empty($userObj->division_ids) ? explode(',', $userObj->division_ids) : [];

            $division = Division::whereIn('id', $divisionIds)->orderBy("name")->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Division"]);
            $this->response['data']['name'] = $name;
            $this->response['data']['list'] = $division;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Division fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }
}
