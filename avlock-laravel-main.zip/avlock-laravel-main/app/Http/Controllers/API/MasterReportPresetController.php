<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\MasterReportPreset;
use App\Models\MasterReportType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class MasterReportPresetController extends AppBaseController {

  public function presetList() {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $presetObject = MasterReportPreset::where('created_by', $this->userId)->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Master Report Type"]);
      $this->response['data']['list'] = $presetObject;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Master Report Type fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $presetObject = MasterReportPreset::find($id);

      if (!$presetObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Master Report Preset"]);
        return $this->sendResponse($this->response, 500);
      }
      $presetObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Master Report Preset"]);
      $this->response['data'] = $presetObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Master Report Preset fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }
  
  public function addUpdate(Request $request){
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdatePreset($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $presetObject = new MasterReportPreset();

      $id = $request->id;
      $title = $request->title;
      $reportTypeId = $request->report_type_id ?? 0;
      $reportFields = json_encode($request->report_fields);

      if ($id) {
        $presetObject = MasterReportPreset::find($id);

        if (!$presetObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Master Report Preset"]);
          return $this->sendResponse($this->response, 500);
        }

          $presetObject->first();
          $this->response['msg'] = __('admin.updated', ['module' => "Master Report Preset"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Master Report Preset"]);
      }

      $presetObject->title = $title;
      $presetObject->report_type_id = $reportTypeId;
      $presetObject->report_fields = $reportFields;
      $presetObject->created_by = $this->userId;
      $presetObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Master Report Preset: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Master Report Preset"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $presetObject = MasterReportPreset::find($id);

      if (!$presetObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Master report type"]);
        return $this->sendResponse($this->response, 500);
      }

      $presetObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Master report type"]);
      $this->response['data'] = $presetObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Master report type Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdatePreset(Request $request) {
    return Validator::make(
      $request->all(),
      [
        'title' => 'required|unique:master_report_presets,title,' . $request->id . ',id,deleted_at,NULL',
      ],
    )->errors();
  }


}
