<?php

namespace App\Http\Controllers\API;

use App\Models\Region;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class RegionController extends AppBaseController
{
    /**
     * Display a listing of the Region.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $name = $request->name ?? '';

            $region = Region::withoutTrashed()->orderBy("id", "desc");

            if ($name) {
                $region->where('name', 'like', '%' . $name . '%');
            }

            $num_rows = $region->count();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Region"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['name'] = $name;
            $this->response['data']['list'] = $region->limit($per_page)->offset($offset)->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Region fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function addUpdate(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateRegion($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $regionObject = new Region();
            $id = $request->id;
            $name = $request->name ?? '';
            $code = $request->code ?? '';
            $status = $request->status ?? 1;



            if ($id) {
                $regionObject = Region::find($id);

                if (!$regionObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Region"]);
                    return $this->sendResponse($this->response, 401);
                }

                $regionObject->first();
                $this->response['msg'] = __('admin.updated', ['module' => "Region"]);
            } else {
                $this->response['msg'] = __('admin.created', ['module' => "Region"]);
            }

            $regionObject->name = $name;
            $regionObject->code = $code;
            $regionObject->status = $status;

            $regionObject->save();

            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Region: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Region"]);

            return $this->sendResponse($this->response, 401);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $regionObject = Region::find($id);

            if (!$regionObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Region"]);
                return $this->sendResponse($this->response, 401);
            }
            $regionObject->first();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Region"]);
            $this->response['data'] = $regionObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Region fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $regionObject = Region::find($id);

            if (!$regionObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Region"]);
                return $this->sendResponse($this->response, 401);
            }

            $regionObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Region"]);
            $this->response['data'] = $regionObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Region Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    private function validateAddUpdateRegion(Request $request)
    {
        return Validator::make($request->all(), [
            'name' => 'required|string|unique:regions,name,' . $request->id . ',id,deleted_at,NULL',
            'code' => 'required|string',
            'status' => 'sometimes|required|integer|in:0,1',
        ])->errors();
    }
}
