<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Resources\TenderPurchaseOrderResource;
use App\Models\AvlockPurchaseInvoice;
use App\Models\AvlockSalesOrder;
use App\Models\CommonTnc;
use App\Models\DeliveryNote;
use App\Models\PackagingSlip;
use App\Models\PoDespatchDetail;
use App\Models\Product;
use App\Models\TenderQuotation;
use App\Models\TenderPurchaseOrder;
use Carbon\Carbon;
use Exception;
use App\Models\ProductPart;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderConsignee;
use App\Models\PurchaseOrderConsigneeDate;
use App\Models\PurchaseOrderDetail;
use App\Models\Tabulation;
use App\Models\Tender;
use App\Models\TenderPoDispatch;
use App\Models\TenderStageLog;
use App\Models\TenderSubStage;
use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Spatie\LaravelPdf\Enums\Format;
use Spatie\LaravelPdf\Facades\Pdf as MyPdf;

class TenderPurchaseOrderController extends AppBaseController
{

    function get(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poId = $request->po_id ?? "";

            if (!$poId) {
                $this->response['error'] = "Please select a valid Tender Purchase Order!";
                return $this->sendResponse($this->response, 200);
            }

            $poObject = PurchaseOrder::with('quotation', 'tenderQuotation', 'subStage', 'preparedBy', 'tender.division')->find($poId);
            $result = new TenderPurchaseOrderResource($poObject);

            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['data'] = $result;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Tender Purchase Order Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function tenderDetail(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poId = $request->po_id ?? "";

            if (!$poId) {
                $this->response['error'] = "Please select a valid Tender Purchase Order!";
                return $this->sendResponse($this->response, 200);
            }

            $poObject = PurchaseOrder::with([
                'tenderQuotation',
                'tenderSubStage',
                'preparedBy',
                'tender',
                'tender.division',
                'poDetail.poDetailConsignee.poDetailConsigneeDate'
            ])->find($poId);

            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            $poDetailsFormatted = [];

            foreach ($poObject->poDetail as $detail) {
                $consignees = [];

                foreach ($detail->poDetailConsignee as $consignee) {
                    $consigneeDates = [];

                    foreach ($consignee->poDetailConsigneeDate as $date) {
                        $consigneeDates[] = [
                            'id' => $date->id,
                            'delivery_start_date' => Carbon::parse($date->delivery_start_date)->format('d/m/Y'),
                            'delivery_end_date' => Carbon::parse($date->delivery_end_date)->format('d/m/Y'),
                            'qty' => $date->qty,
                        ];
                    }

                    $consignees[] = [
                        'id' => $consignee->id,
                        'name' => $consignee->name,
                        'qty' => $consignee->qty,
                        'unit' => $consignee->unit,
                        'delivery_period' => $consignee->delivery_period,
                        'consigneesDates' => $consigneeDates,
                        'basic_value' => $consignee->basic_value,
                    ];
                }

                $poDetailsFormatted[] = [
                    'id' => $detail->id,
                    'product_id' => $detail->product_id,
                    'product_part_id' => $detail->product_part_id,
                    'part_no' => $detail->part_no,
                    'qty' => $detail->qty,
                    'description' => $detail->description,
                    'avlock_description' => $detail->avlock_description,
                    'rate' => $detail->rate,
                    'consignees' => $consignees,
                    'basic_value' => $detail->basic_value,
                ];
            }

            $responseData = $poObject->toArray();
            $responseData['po_details'] = $poDetailsFormatted;

            $this->response['status'] = 1;
            $this->response['data'] = $responseData;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Tender Purchase Order Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }



    public function addUpdate(Request $request)
    {
        try {

            DB::beginTransaction();

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poNo = $request->po_no;
            if (empty($poNo)) {
                $this->response['error'] = "Please fill all PO details";
                return $this->sendResponse($this->response, 200);
            }

            $validationErrors = $this->validateAddUpdateTenderPurchaseOrder($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $poObject = new PurchaseOrder();
            $id = $request->id;
            $tenderId = $request->tender_id;
            $poDate = Carbon::createFromFormat('d/m/Y', $request->po_date)->format('Y-m-d H:i:s');
            $inspection = $request->inspection;
            $inspectionCriteria = $request->inspection_criteria ?? '';
            $inspectionAgency = $request->inspection_agency ?? '';
            $poDetails = $request->po_details ?? [];
            $currSubStageId = $request->curr_sub_stage_id ?? '';
            $currUserIds = $request->curr_user_ids ?? '';
            $comments = $request->comments ?? '';
            $from = $request->from ?? '';
            $attachments = $request->attachments ?? [];
            $cgst = $request->cgst;
            $sgst = $request->sgst;
            $igst = $request->igst;
            $cgstValue = $sgstValue = $igstValue = 0;

            if (empty($poDetails)) {
                $this->response["error"] = "Please select atleast one Product";
                return $this->sendResponse($this->response, 200);
            }

            $poDetailsEmpty = false;
            foreach ($poDetails as $key => $item) {
                if (empty($item['part_no']) || empty($item['rate'])) {
                    $poDetailsEmpty = true;
                    break;
                }
            }

            $poDetailTotal = 0;
            if ($poDetails) {
                foreach ($poDetails as $value) {
                    $consigneeDetailTotal = array_reduce($value['consignees'], function ($sum, $item) {
                        return $sum + $item['qty'];
                    }, 0);

                    $poDetailTotal = $consigneeDetailTotal * $value['rate'];
                }
            }

            $finalAmount =  $poDetailTotal;
            if ($cgst > 0) $cgstValue = ($finalAmount * floatval($cgst)) / 100;
            if ($sgst > 0) $sgstValue = ($finalAmount * floatval($sgst)) / 100;
            if ($igst > 0) $igstValue = ($finalAmount * floatval($igst)) / 100;

            $finalAmount = $finalAmountInInr = $finalAmount + $cgstValue + $sgstValue + $igstValue;


            if ($poDetailsEmpty) {
                $this->response["errors"] = ["po_details" => "Please fill all Tender Purchase Order Details"];
                return $this->sendResponse($this->response, 200);
            }

            $poDetails = json_encode($poDetails);

            if (!$attachments || !is_array($attachments) || count($attachments) < 1) {
                $this->response["errors"] = ["attachments" => "Please upload documents!"];
                return $this->sendResponse($this->response, 200);
            }

            $files = [];
            if (!empty($attachments)) {
                foreach ($attachments as $item) {
                    moveFile('project/files/', $item['filename']);
                    $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                }
            }

            $attachments = json_encode($files);

            if ($id) {
                $poObject = PurchaseOrder::find($id);

                if (!$poObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Purchase Order"]);
                    return $this->sendResponse($this->response, 200);
                }

                $poObject->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "Tender Purchase Order"]);
            } else {

                $tabulation = Tender::find($tenderId);
                $tabulation->tender_status = 1; //Won
                $tabulation->save();

                $poObject->created_by = $this->userId;
                $poObject->prepared_by = $this->userId;
                $poObject->po_status = 'active';
                $this->response['msg'] = __('admin.created', ['module' => "Tender Purchase Order"]);
            }

            $poObject->fk_quotation_id = 0;
            $poObject->fk_rfq_id = 0;
            $poObject->fk_lead_id = 0;
            $poObject->fk_tender_id = $tenderId;
            $poObject->inspection = $inspection;
            $poObject->inspection_criteria = $inspectionCriteria;
            $poObject->inspection_agency = $inspectionAgency;
            $poObject->po_no = $poNo;
            $poObject->po_date = $poDate;
            $poObject->po_details = $poDetails;
            $poObject->po_details_total = $poDetailTotal;
            $poObject->final_amount = $finalAmount ?? 0;
            $poObject->final_amount_in_inr = $finalAmountInInr ?? 0;
            $poObject->curr_sub_stage_id = $currSubStageId;
            $poObject->curr_user_ids = json_encode($currUserIds);
            $poObject->attachments = $attachments;
            $poObject->cgst = $cgst;
            $poObject->cgst_value = $cgstValue;
            $poObject->sgst = $sgst;
            $poObject->sgst_value = $sgstValue;
            $poObject->igst = $igst;
            $poObject->po_type = 2;
            $poObject->igst_value = $igstValue;
            $poObject->comments = $comments;
            $poObject->save();
            $lastInsertedPoId = $poObject->id;


            //Store Po Details Data in Po Detail Related Table
            $proIds = array_column($request->po_details, 'id');

            $proIds = array_filter($proIds, 'is_numeric');

            PurchaseOrderDetail::where('fk_po_id', $lastInsertedPoId)
                ->whereNotIn('id', $proIds)
                ->delete();

            if (!empty($request->po_details) && is_array($request->po_details)) {
                foreach ($request->po_details as $po) {
                    if (!empty($po['id'])) {
                        $poDetailsObj = PurchaseOrderDetail::find($po['id']);
                    } else {
                        $poDetailsObj = new PurchaseOrderDetail();
                        $poDetailsObj->fk_po_id = $lastInsertedPoId;
                    }

                    $poDetailsObj->product_id = $po['product_id'] ?? null;
                    $poDetailsObj->product_part_id = $po['product_part_id'] ?? '';
                    $poDetailsObj->part_no = $po['part_no'] ?? '';
                    $poDetailsObj->qty = $po['qty'] ?? '';
                    $poDetailsObj->description = $po['description'] ?? '';
                    $poDetailsObj->avlock_description = $po['avlock_description'] ?? '';
                    $poDetailsObj->rate = $po['rate'] ?? 0;
                    $poDetailsObj->basic_value = $po['basic_value'] ?? 0;
                    $poDetailsObj->po_type = 2;
                    $poDetailsObj->save();

                    $lastPoDetailsId = $poDetailsObj->id;

                    $consigneeIds = [];

                    if (!empty($po['consignees']) && is_array($po['consignees'])) {
                        foreach ($po['consignees'] as $consignee) {
                            if (!empty($consignee['id'])) {
                                $poConsigneeObj = PurchaseOrderConsignee::find($consignee['id']);
                                $consigneeIds[] = $consignee['id'];
                            } else {
                                $poConsigneeObj = new PurchaseOrderConsignee();
                            }

                            $poConsigneeObj->fk_po_id = $lastInsertedPoId;
                            $poConsigneeObj->purchase_order_detail_id = $lastPoDetailsId;
                            $poConsigneeObj->name = $consignee['name'] ?? '';
                            $poConsigneeObj->qty = $consignee['qty'] ?? '';
                            $poConsigneeObj->unit = $consignee['unit'] ?? '';
                            $poConsigneeObj->delivery_period = $consignee['delivery_period'] ?? null;
                            $poConsigneeObj->basic_value = $consignee['basic_value'] ?? '';
                            $poConsigneeObj->save();

                            $lastPoConsigneeId = $poConsigneeObj->id;

                            $dateIds = [];

                            if (!empty($consignee['consigneesDates']) && is_array($consignee['consigneesDates'])) {
                                foreach ($consignee['consigneesDates'] as $consigneeDate) {
                                    if (!empty($consigneeDate['id'])) {
                                        $poConsigneeDateObj = PurchaseOrderConsigneeDate::find($consigneeDate['id']);
                                        $dateIds[] = $consigneeDate['id'];
                                    } else {
                                        $poConsigneeDateObj = new PurchaseOrderConsigneeDate();
                                    }

                                    $poConsigneeDateObj->fk_po_id = $lastInsertedPoId;
                                    $poConsigneeDateObj->purchase_order_detail_id = $lastPoDetailsId;
                                    $poConsigneeDateObj->purchase_order_consignee_id = $lastPoConsigneeId;

                                    $poConsigneeDateObj->delivery_start_date = !empty($consigneeDate['delivery_start_date'])
                                        ? Carbon::createFromFormat('d/m/Y', $consigneeDate['delivery_start_date'])->format('Y-m-d')
                                        : null;

                                    $poConsigneeDateObj->delivery_end_date = !empty($consigneeDate['delivery_end_date'])
                                        ? Carbon::createFromFormat('d/m/Y', $consigneeDate['delivery_end_date'])->format('Y-m-d')
                                        : null;

                                    $poConsigneeDateObj->qty = $consigneeDate['qty'] ?? '';
                                    $poConsigneeDateObj->save();
                                    $dateIds[] = $poConsigneeDateObj->id;
                                }
                            }

                            if (!empty($consignee['id'])) {
                                if (!empty($dateIds)) {
                                    PurchaseOrderConsigneeDate::where('fk_po_id', $lastInsertedPoId)
                                        ->where('purchase_order_detail_id', $lastPoDetailsId)
                                        ->where('purchase_order_consignee_id', $lastPoConsigneeId)
                                        ->whereNotIn('id', $dateIds)
                                        ->delete();
                                } else {
                                    PurchaseOrderConsigneeDate::where('fk_po_id', $lastInsertedPoId)
                                        ->where('purchase_order_detail_id', $lastPoDetailsId)
                                        ->where('purchase_order_consignee_id', $lastPoConsigneeId)
                                        ->delete();
                                }
                            }
                        }
                    }

                    if (!empty($po['id'])) {
                        if (!empty($consigneeIds)) {
                            PurchaseOrderConsignee::where('fk_po_id', $lastInsertedPoId)
                                ->where('purchase_order_detail_id', $lastPoDetailsId)
                                ->whereNotIn('id', $consigneeIds)
                                ->delete();
                        } else {
                            PurchaseOrderConsignee::where('fk_po_id', $lastInsertedPoId)
                                ->where('purchase_order_detail_id', $lastPoDetailsId)
                                ->delete();
                        }
                    }
                }
            }

            if ($tenderId) {
                $tenderObj = Tender::find($tenderId);
                $tenderObj->sub_stage_id = $currSubStageId;
                $tenderObj->sub_stage_user_ids = $currUserIds;
                $tenderObj->save();
            }

            $poObject->action = $id ? 'updated' : 'created';

            $this->response['status'] = 1;
            DB::commit();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating Tender Purchase Order: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Tender Purchase Order"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    public function downloadPdf(Request $request)
    {
        try {

            $poId = $request->po_id ?? '';
            $viewPdf = $request->view_pdf ?? '';

            $poObject = PurchaseOrder::with('tenderQuotation', 'subStage', 'preparedBy', 'tender.division')->find($poId);
            $detail = new TenderPurchaseOrderResource($poObject);
            $data = [
                'details' => json_decode(json_encode($detail)),
            ];


            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "Tender Purchase Order Pdf"]);
                $this->response['data']['html'] = view('pdf.tender.tender_po', ['details' => $data['details']])->render();

                return $this->sendResponse($this->response, 200);
            }

            $path = 'pdf/po/' . str_replace(['-', '/'], '', $poObject->po_no) . '.pdf';

            MyPdf::view('pdf.tender.tender_po', ['details' => $data['details']])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Tender Purchase Order Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Tender Purchase Order pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addTenderPoDispatch(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateTenderPoDispatch($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $poId = $request->po_id;
            $currSubStageId = $request->curr_sub_stage_id;
            $poDetails = $request->poDetails ?? [];
            $userIds = $request->user_ids ?? [];

            foreach ($poDetails as $key => $value) {
                if (isset($value['id']) && !empty($value['id'])) {
                    $poDespatchObject = PoDespatchDetail::find($value['id']);
                } else {
                    $poDespatchObject = new PoDespatchDetail();
                }
                $despatchDate = Carbon::createFromFormat('d/m/Y', $value['po_despatch_date'])->format('Y-m-d');
                $poDespatchObject->po_id = $poId;
                $poDespatchObject->despatch_date = $despatchDate;
                $poDespatchObject->remark = $value['remark'] ?? '';
                $poDespatchObject->po_type = 2;
                $poDespatchObject->details = json_encode($value['details']);
                $poDespatchObject->save();
            }

            $poObject = PurchaseOrder::find($poId);
            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            $tenderObj = Tender::find($poObject->fk_tender_id);
            if (!$tenderObj) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender"]);
                return $this->sendResponse($this->response, 200);
            }

            if ($currSubStageId) {
                $poObject->curr_sub_stage_id = $currSubStageId;
                $tenderObj->sub_stage_id = $currSubStageId;
            }
            $poObject->save();

            $tenderObj->sub_stage_user_ids = json_encode($userIds);
            $tenderObj->save();



            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.updated', ['module' => "Tender Purchase Order Despatch Detail"]);

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Tender Purchase Order Despatch Detail: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Tender Purchase Order Despatch Detail"]);
            return $this->sendResponse($this->response, 500);
        }
    }


    function getTenderPoDispatch(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $dispatchId = $request->po_dispatch_id ?? '';
            $poDispatchObj = PoDespatchDetail::find($dispatchId);
            if (!$poDispatchObj) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Dispatch Detail"]);
                return $this->sendResponse($this->response, 500);
            }
            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Tender Dispatch Detail"]);
            $this->response['data'] = $poDispatchObj;
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Tender PO Dispatch Detail fetch failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function tenderPoDetail(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id ?? "";

            if (!$id) {
                $this->response['error'] = "Please select a valid Purchase Order!";
                return $this->sendResponse($this->response, 200);
            }

            $poObject = PurchaseOrder::with('quotation', 'preparedBy')->find($id);

            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            //FOR DISPATCH DATE DROPDOWN
            $poDispatchDetail = PoDespatchDetail::where('po_id', $id)->where('po_type', 2)->get()->toArray();
            $dispatchDate = [];

            if (!empty($poDispatchDetail) && is_array($poDispatchDetail)) {
                $dispatchDate = array_map(
                    fn($detail) => [
                        'id' => $detail['id'],
                        'dispatch_date' => Carbon::createFromFormat('Y-m-d', $detail['despatch_date'])->format('d/m/Y') ?? ''
                    ],
                    $poDispatchDetail
                );
            }

            if (is_array($dispatchDate) && !empty($dispatchDate)) {
                sort($dispatchDate);
            }

            //FOR PACKAGING DATE DROPDOWN
            $salesOrderObject = AvlockSalesOrder::where('fk_po_id', $id)->where('po_type', 2)->get()->toArray();
            $packagingDate = [];
            $salesOrderDate = [];

            if (!empty($salesOrderObject) && is_array($salesOrderObject)) {
                $salesOrderDate = array_map(
                    fn($detail) => [
                        'id' => $detail['id'],
                        'so_date' =>  $detail['so_no'] . ' -' .  Carbon::createFromFormat('Y-m-d', $detail['so_date'])->format('d/m/Y') ?? ''
                    ],
                    $salesOrderObject
                );
            }

            if (is_array($salesOrderDate) && !empty($salesOrderDate)) {
                sort($salesOrderDate);
            }

            //FOR DELIVERY DATE DROPDOWN
            $packagingSlipObject = PackagingSlip::where('fk_po_id', $id)->where('po_type', 2)->get()->toArray();
            $packagingDate = [];

            if (!empty($packagingSlipObject) && is_array($packagingSlipObject)) {
                $packagingDate = array_map(
                    fn($detail) => [
                        'id' => $detail['id'],
                        'packaging_slip_date' => Carbon::createFromFormat('Y-m-d', $detail['packaging_slip_date'])->format('d/m/Y') . ' (' . $detail['packaging_slip_no'] . ')' ?? ''
                    ],
                    $packagingSlipObject
                );
            }


            if (is_array($packagingDate) && !empty($packagingDate)) {
                sort($packagingDate);
            }


            //FOR E-INVOICE DATE DROPDOWN
            $deliveryNoteObj = DeliveryNote::where('fk_po_id', $id)->where('po_type', 2)->get()->toArray();
            $deliveryDate = [];

            if (!empty($deliveryNoteObj) && is_array($deliveryNoteObj)) {
                $deliveryDate = array_map(
                    fn($detail) => [
                        'id' => $detail['id'],
                        'delivery_note_date' => Carbon::createFromFormat('Y-m-d', $detail['delivery_note_date'])->format('d/m/Y') . ' (' . $detail['delivery_note_no'] . ')' ?? ''
                    ],
                    $deliveryNoteObj
                );
            }

            if (is_array($deliveryDate) && !empty($deliveryDate)) {
                sort($deliveryDate);
            }

            //FOR E-WAY BILL DATE DROPDOWN
            $invoiceObj = AvlockPurchaseInvoice::where('fk_po_id', $id)->where('po_type', 2)->get()->toArray();
            $invoiceDate = [];

            if (!empty($invoiceObj) && is_array($invoiceObj)) {
                $invoiceDate = array_map(
                    fn($detail) => [
                        'id' => $detail['id'],
                        'pi_date' => Carbon::createFromFormat('Y-m-d', $detail['pi_date'])->format('d/m/Y') . ' (' . $detail['pi_no'] . ')' ?? ''
                    ],
                    $invoiceObj
                );
            }

            if (is_array($invoiceDate) && !empty($invoiceDate)) {
                sort($invoiceDate);
            }

            $soObject = AvlockSalesOrder::where('fk_po_id', $id)->where('po_type', 2)->first();
            if ($soObject && $soObject->so_details) {
                $soDetails = json_decode($soObject->so_details);
                if (is_array($soDetails)) {
                    $partNoIds = array_map(
                        fn($detail) => $detail->product_part_id ?? $detail->part_noId,
                        $soDetails
                    );
                }

                if ($partNoIds) {
                    $partNoLists = ProductPart::whereIn('id', $partNoIds)->get();
                }
            }

            $this->response['status'] = 1;
            $this->response['data'] = $poObject;
            $this->response['data']['dispatchDate'] = $dispatchDate ?? [];
            $this->response['data']['salesOrderDate'] = $salesOrderDate ?? [];
            $this->response['data']['packagingDate'] = $packagingDate ?? [];
            $this->response['data']['deliveryDate'] = $deliveryDate ?? [];
            $this->response['data']['invoiceDate'] = $invoiceDate ?? [];
            $this->response['data']['part_no_lists'] = $partNoLists ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Purchase Order Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getTermsDetail(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $tenderId = $request->tender_id ?? '';

            $tenderObject = Tender::select('id', 'division_id')->find($tenderId);
            $divisionId = $tenderObject->division_id ?? '';

            if (!$tenderObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Tender"]);
                return $this->sendResponse($this->response, 200);
            }

            $tnc = CommonTnc::where(['division_id' => $divisionId, 'is_tender' => 0, 'status' => 1])->first();


            $this->response['status'] = 1;
            $this->response['data']['tnc'] = $tnc;
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    private function validateAddUpdateTenderPurchaseOrder(Request $request)
    {
        return Validator::make($request->all(), [
            'po_date' => 'required|date_format:d/m/Y',
            'po_no' => 'required',
            'po_details.*.part_no' => 'required',
            'po_details.*.rate' => 'required|numeric',
            'po_details.*.consignees.*.name' => 'required',
            'po_details.*.consignees.*.qty' => 'required|numeric',
            'po_details.*.consignees.*.unit' => 'required',
            'attachments' => 'required',

        ], [
            'po_details.*.part_no.required' => 'The part no is required.',
            'po_details.*.part_no.rate' => 'The rate is required.',
            'po_details.*.consignees.*.name.required' => 'The name is required.',
            'po_details.*.consignees.*.qty.required' => 'The qty is required.',
            'po_details.*.consignees.*.unit.required' => 'The unit is required.',
        ])->errors();
    }

    private function validateAddUpdateTenderPoDispatch(Request $request)
    {
        return Validator::make($request->all(), [
            'poDetails.*.po_despatch_date' => 'required|date_format:d/m/Y',
            'poDetails.*.details.*.consignees.*.despatch_qty' => 'required|numeric',
        ], [
            'poDetails.*.po_despatch_date.required' => 'The dispatch date is required',
            'poDetails.*.details.*.consignees.*.despatch_qty.required' => 'The qty is required',

        ])->errors();
    }
}
