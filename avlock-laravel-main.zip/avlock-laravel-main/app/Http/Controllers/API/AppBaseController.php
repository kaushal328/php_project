<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\DepartmentType;
use App\Models\User;
use App\Models\UserHierarchyManagement;
use App\Models\UserRole;
use App\Utils\ResponseMessageUtils;
use Illuminate\Http\Request;
use PHPOpenSourceSaver\JWTAuth\Exceptions\JWTException;
use PHPOpenSourceSaver\JWTAuth\Exceptions\TokenExpiredException;
use PHPOpenSourceSaver\JWTAuth\Exceptions\TokenInvalidException;
use PHPOpenSourceSaver\JWTAuth\Facades\JWTAuth;
use Session;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\URL;

class AppBaseController extends Controller
{

  public $response = [
    'status' => 0,
    'msg' => '',
    'error' => '',
    'errors' => [],
    'data' => [],
  ];
  public $userId;
  public $currentUserName;
  public $isUserAdmin = false;
  public $isUserHr = false;
  public $isAdvisor = false;
  public $isUserInsideSale = false;
  public $isUserPSM = false;
  public $psmUserRole = false;
  public $isMarketing = false;
  public $isManagement = false;
  public $isUserDispatch = false;
  public $isUserFinance = false;
  public $isUserProduction = false;
  public $isUserRSM = false; // mainly use fo APP and for RSM Dashboard
  public $isSuperAdmin = false;
  public $fileAccessPath = 'storage/uploads';

  public function __construct()
  {
    $this->readUserToken();
    $this->getFileAccessPath();
  }

  public function sendResponse($result, $code)
  {
    return ResponseMessageUtils::sendResponse($result, $code);
  }

  public function formatValidationErrors(array $validationError): array
  {
    $formattedErrors = [];

    foreach ($validationError as $key => $value) {
      $formattedErrors[$key] = $value[0];
    }

    return $formattedErrors;
  }

  private function readUserToken()
  {

    try {

      $token = request()->header('access-token');
      $userToken = str_replace('Bearer ', '', $token);
      $token = JWTAuth::setToken($userToken)->getPayload();
      $userCheck = User::where('id', $token['sub'])->first();

      // You can access the authenticated user
    } catch (TokenExpiredException $e) {
      // Token has expired
      $this->response['error'] = __('auth.token_expired');

      return $this->sendResponse($this->response, 401);
    } catch (TokenInvalidException $e) {
      // Invalid token
      $this->response['error'] = __('auth.invalid_token');
      return $this->sendResponse($this->response, 401);
    } catch (JWTException $e) {
      // General exception
      $this->response['error'] = __('auth.authentication_failed');
      return $this->sendResponse($this->response, 401);
    }

    if (empty($userCheck)) {
      $this->response['error'] = __('auth.please_login_and_try_again');
      return $this->sendResponse($this->response, 200);
    }

    $currUserId = $token['sub'];
    $this->userId = $currUserId;
    $this->currentUserName = $userCheck->name;

    $userRole = UserRole::where('fk_user_id', $currUserId)->where('fk_department_id', 2)->get()->toArray();
    if (!empty($userRole)) {
      $this->isUserAdmin = true;
    }

    $hrUserRole = UserRole::where('fk_user_id', $currUserId)->where('fk_department_id', 3)->get()->toArray();
    if (!empty($hrUserRole)) {
      $this->isUserHr = true;
    }

    $rsmUserRole = UserRole::where('fk_user_id', $currUserId)->where('fk_department_id', 5)->get()->toArray(); // mainly use fo APP and for RSM Dashboard
    if (!empty($rsmUserRole)) {
      $this->isUserRSM = true;
    }

    $insideSaleUserRole = UserRole::where('fk_user_id', $currUserId)->where('fk_department_id', 6)->get()->toArray();
    if (!empty($insideSaleUserRole)) {
      $this->isUserInsideSale = true;
    }

    $psmUserRole = UserRole::where('fk_user_id', $currUserId)->where('fk_department_id', 7)->get()->toArray();
    if (!empty($psmUserRole)) {
      $this->isUserPSM = true;
    }

    $advisorUserRole = UserRole::where('fk_user_id', $currUserId)->where('fk_department_type_id', 5)->get()->toArray();
    if (!empty($advisorUserRole)) {
      $this->isAdvisor = true;
    }

    $marketingUserRole = UserRole::where('fk_user_id', $currUserId)->where('fk_department_id', 4)->get()->toArray();
    if (!empty($marketingUserRole)) {
      $this->isMarketing = true;
    }

    $managementUserRole = UserRole::where('fk_user_id', $currUserId)->where('fk_department_id', 10)->get()->toArray();
    if (!empty($managementUserRole)) {
      $this->isManagement = true;
    }

    $dispatchUserRole = UserRole::where('fk_user_id', $currUserId)->where('fk_department_id', 9)->get()->toArray();
    if (!empty($dispatchUserRole)) {
      $this->isUserDispatch = true;
    }

    $financeUserRole = UserRole::where('fk_user_id', $currUserId)->where('fk_department_id', 11)->get()->toArray();
    if (!empty($financeUserRole)) {
      $this->isUserFinance = true;
    }

    $productionUserRole = UserRole::where('fk_user_id', $currUserId)->where('fk_department_id', 12)->where('fk_department_type_id', 1)->get()->toArray();
    if (!empty($productionUserRole)) {
      $this->isUserProduction = true;
    }

    $superAdminUser = UserRole::where('fk_user_id', $currUserId)->where('fk_department_id', 1)->get()->toArray();

    if (!empty($superAdminUser)) {
      $this->isSuperAdmin = true;
    }
  }

  public function convertToDatabaseDateForSearch($dateString)
  {
    $parsedDate = Carbon::createFromFormat('d-m-Y', $dateString);
    $formattedDate = $parsedDate->format('Y-m-d');
    return $formattedDate;
  }

  // public function getJuniorIds() {
  //   $role = UserRole::where('fk_user_id', $this->userId)->get();
  //   $juniorUserIds = [];

  //   foreach ($role as $r) {
  //     $departmentId = $r->fk_department_id;
  //     $departmentTypeId = $r->fk_department_type_id;
  //     $juniorDepartmentTypes = DB::table('department_types')->whereRaw('FIND_IN_SET(?, junior_ids)', [$departmentTypeId])->get()->toArray();

  //     $juniorDepartmentTypeIds = array_column($juniorDepartmentTypes, 'id');
  //     foreach ($juniorDepartmentTypes as $jdt) {
  //       $userRoles = UserRole::where('fk_department_id', $departmentId)->whereIn('fk_department_type_id', $juniorDepartmentTypeIds)->get()->toArray();

  //       $userIds = array_column($userRoles, 'fk_user_id');
  //       $juniorUserIds = array_merge($userIds, $juniorUserIds);
  //     }
  //   }

  //   return $juniorUserIds = array_unique([...$juniorUserIds, $this->userId]);
  // }

  // public function getJuniorIds($checkDivision)
  // {
  //   $role = UserRole::where('fk_user_id', $this->userId)->get();
  //   $juniorUserIds = [];

  //   foreach ($role as $r) {
  //     $departmentId = $r->fk_department_id;
  //     $departmentTypeId = $r->fk_department_type_id;
  //     $department = DepartmentType::where('id', $departmentTypeId)->first();
  //     $juniorDepartmentTypes = DepartmentType::whereIn('id', explode(',', $department->junior_ids))->get()->toArray();

  //     $juniorDepartmentTypeIds = array_column($juniorDepartmentTypes, 'id');
  //     foreach ($juniorDepartmentTypes as $jdt) {
  //       $userRoles = UserRole::where('fk_department_id', $departmentId)->whereIn('fk_department_type_id', $juniorDepartmentTypeIds)->get()->toArray();

  //       $userIds = array_column($userRoles, 'fk_user_id');
  //       $juniorUserIds = array_merge($userIds, $juniorUserIds);
  //     }
  //   }

  //   $selfDivision = User::find($this->userId);
  //   $divisionArr = explode(',', $selfDivision->division_ids);

  //   if ($checkDivision) {
  //     $filteredJuniorUserIds = [];
  //     foreach ($divisionArr as $divId) {
  //       $juniorsDivisionFiltered = User::whereIn('id', $juniorUserIds)->whereRaw("FIND_IN_SET(?, division_ids)", [$divId])->get()->toArray();

  //       $juniorsDivisionFilteredIds = array_column($juniorsDivisionFiltered, 'id');

  //       $filteredJuniorUserIds = array_merge($juniorsDivisionFilteredIds, $filteredJuniorUserIds);
  //     }

  //     return array_unique([...$filteredJuniorUserIds, $this->userId]);
  //   }

  //   return $juniorUserIds = array_unique([...$juniorUserIds, $this->userId]);
  // }

  public function getJuniorIds($checkDivision)
  {
    $uhm = UserHierarchyManagement::where('senior_user_id', $this->userId)->get();
    $juniorUserIds = [];

    foreach ($uhm as $uhmVal) {
      $juniorUserIds[] = $uhmVal->user_id;
    }

    $selfDivision = User::find($this->userId);
    $divisionArr = explode(',', $selfDivision->division_ids);

    if ($checkDivision) {
      $filteredJuniorUserIds = [];
      foreach ($divisionArr as $divId) {
        $juniorsDivisionFiltered = User::whereIn('id', $juniorUserIds)->whereRaw("FIND_IN_SET(?, division_ids)", [$divId])->get()->toArray();

        $juniorsDivisionFilteredIds = array_column($juniorsDivisionFiltered, 'id');

        $filteredJuniorUserIds = array_merge($juniorsDivisionFilteredIds, $filteredJuniorUserIds);
      }

      return array_unique([...$filteredJuniorUserIds, $this->userId]);
    }

    return $juniorUserIds = array_unique([...$juniorUserIds, $this->userId]);
  }


  public function getFileAccessPath()
  {

    $currentUrl = URL::to('/');

    if (str_contains($currentUrl, '://localhost') || str_contains($currentUrl, '://127.0.0.1')) {
      $this->fileAccessPath = 'storage/uploads';
    }
  }
}

  // public static function checkPermission($name)
  // {
  //   $roleId = Session::get('roleId');
  //   if ($roleId == 1) {
  //     return true;
  //   }
  //   $permissions = Session::get('permissions');
  //   $permission_array = Permission::whereIn('id', $permissions)->pluck('codename')->toArray();
  //   if (in_array($name, $permission_array)) {
  //     return true;
  //   } else {
  //     return false;
  //   }
  // }
