<?php

namespace App\Http\Controllers\API;

use App\Models\Status;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class StatusController extends AppBaseController {
    
  public function index(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $perPage = (isset($request->perPage) && $request->perPage != 'undefined') ? intval($request->perPage) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $perPage;

      $name = $request->name ?? '';

      $status = Status::withoutTrashed()->orderBy("id", "desc");
      $numRows = $status->count();

      if ($name) {
        $status->where('name', 'like', '%' . $name . '%');
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Status"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $perPage;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $perPage ? 1 : ceil($numRows / $perPage);
      $this->response['data']['name'] = $name;
      $this->response['data']['list'] = $status->limit($perPage)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Status fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $statusObject = Status::find($id);

      if (!$statusObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Status"]);
        return $this->sendResponse($this->response, 401);
      }

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Status"]);
      $this->response['data'] = $statusObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Status fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateStatus($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $statusObject = new Status();
      $id = $request->id;
      $name = $request->name ?? '';
      $code = $request->code ?? '';
      $status = $request->status ?? 1;

      if ($id) {
        $statusObject = Status::find($id);

        if (!$statusObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Status"]);
          return $this->sendResponse($this->response, 401);
        }

        $statusObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Status"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Status"]);
      }

      $statusObject->name = $name;
      $statusObject->code = $code;
      $statusObject->status = $status;

      $statusObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Status: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Status"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $statusObject = Status::find($id);

      if (!$statusObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Status"]);
        return $this->sendResponse($this->response, 401);
      }

      $statusObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Status"]);
      $this->response['data'] = $statusObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Status Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddUpdateStatus(Request $request) {
    return Validator::make($request->all(), [
      'name' => 'required|string|unique:statuses,name,' . $request->id . ',id,deleted_at,NULL',
      'code' => 'required|string',
      'status' => 'sometimes|required|integer|in:0,1',
    ])->errors();
  }
}
