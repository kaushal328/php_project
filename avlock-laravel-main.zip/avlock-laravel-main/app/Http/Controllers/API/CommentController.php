<?php

namespace App\Http\Controllers\API;

use App\Models\Task;
use App\Models\Comment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class CommentController extends AppBaseController
{

    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $perPage = (isset($request->perPage) && $request->perPage != 'undefined') ? intval($request->perPage) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $perPage;

            $fk_task_id = $request->fk_task_id ?? '';

            $task = Task::find($fk_task_id);

            if (!$task) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Task"]);
                return $this->sendResponse($this->response, 401);
            }
            
            $comment = $this->getNestedCommentsForTask($task, $perPage, $offset);

            $numRows = $comment->count();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Comment"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $perPage;
            $this->response['data']['num_rows'] = $numRows;
            $this->response['data']['total_pages'] = $numRows < $perPage ? 1 : ceil($numRows / $perPage);
            $this->response['data']['fk_task_id'] = $fk_task_id;
            $this->response['data']['list'] = $comment;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Comment fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function getNestedCommentsForTask($task, $perPage, $offset)
    {
        // Get the task and its root-level comments

        $rootComments = $task->comments()->where('fk_comment_id', 0)->orderBy("id", "desc")->limit($perPage)->offset($offset)->get();

        // Recursively fetch nested comments for each root comment
        foreach ($rootComments as $rootComment) {
            $rootComment->replies = $this->getRepliesForComment($rootComment);
        }

        return $rootComments;
    }

    private function getRepliesForComment($comment)
    {
        // Fetch replies for the given comment
        $replies = Comment::where('fk_comment_id', $comment->id)->get();

        // Recursively fetch nested comments for each reply
        foreach ($replies as $reply) {
            $reply->replies = $this->getRepliesForComment($reply);
        }

        return $replies;
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $commentObject = Comment::find($id);

            if (!$commentObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Comment"]);
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Comment"]);
            $this->response['data'] = $commentObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Comment fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function addUpdate(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateComment($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $commentObject = new Comment();
            $id = $request->id;
            $message = $request->message ?? '';
            $fk_task_id  = $request->fk_task_id  ?? '';
            $fk_comment_id  = $request->fk_comment_id  ?? '';

            if ($id) {
                $commentObject = Comment::find($id);

                if (!$commentObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Comment"]);
                    return $this->sendResponse($this->response, 401);
                }

                $commentObject->first();
                $this->response['msg'] = __('admin.updated', ['module' => "Comment"]);
            } else {
                $this->response['msg'] = __('admin.created', ['module' => "Comment"]);
            }

            $commentObject->message = $message;
            $commentObject->fk_task_id = $fk_task_id;
            $commentObject->fk_comment_id = $fk_comment_id;
            $commentObject->save();

            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Comment: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Comment"]);

            return $this->sendResponse($this->response, 401);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $comObject = Comment::find($id);

            if (!$comObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Comment"]);
                return $this->sendResponse($this->response, 401);
            }

            $comObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Comment"]);
            $this->response['data'] = $comObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Comment Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    private function validateAddUpdateComment(Request $request)
    {
        return Validator::make($request->all(), [
            'message' => 'required|string',
            'fk_task_id' => 'required|integer',
            'fk_comment_id' => 'integer',
        ])->errors();
    }
}
