<?php

namespace App\Http\Controllers\API;

use Exception;
use Carbon\Carbon;
use App\Models\Rfq;
use App\Models\User;
use App\Models\UserRole;
use App\Models\Department;
use Illuminate\Http\Request;
use App\Models\ProjectSampling;
use App\Models\ProjectSamplingLog;
use Illuminate\Support\Facades\Log;
use App\Http\Resources\AllUserResource;
use App\Models\ProjectSamplingSubStage;
use App\Events\ProjectSamplingLogCreated;
use App\Http\Resources\SamplingListResource;
use App\Models\ProjectSamplingPdrQuality;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\TenderListResource;
use App\Models\ProjectSamplingPurchaseInvoice;
use App\Http\Resources\UserRoleTenderHistoryResource;
use App\Jobs\SendSamplingChangeStageNotification;
use App\Models\ProjectSamplingDeliveryUpdate;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\URL;

class ProjectSamplingController extends AppBaseController
{
    private $PI_PREPARED_UPLOADED_SUB_STAGE_ID = 15;
    private $PDR_PREPARED_UPLOADED_SUB_STAGE_ID = 13;
    private $DELIVERY = 17;


    function index(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $samplingId = $request->sampling_id ?? '';

            $projectSamplings = ProjectSampling::with(['subStageUsers.designation', 'currentSubStage'])->where('fk_rfq_id', $samplingId)->orderBy('updated_at', 'desc')->get();
            if (!$projectSamplings) {
                $this->response['error'] = "Project Sampling not found!";
                return $this->sendResponse($this->response, 200);
            }

            $showButton = false;

            if ($this->isUserRSM) {
                $showButton = true;
            }

            $data['showButton'] = $showButton;

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Project Sampling"]);
            $this->response['data']['list'] = SamplingListResource::collection($projectSamplings);
            $this->response['data']['showButton'] = $showButton;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Project Sampling fetch failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function view(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $rfq_id = $request->rfq_id;
            $sampling_id = $request->sampling_id;
            $selected_sub_stage_id = $request->sub_stage_id;

            $rfq = Rfq::find($rfq_id);
            if (!$rfq) {
                $this->response['error'] = 'RFQ details not found!';
                return $this->sendResponse($this->response, 200);
            }

            $attachments = [];

            if ($sampling_id) {
                $sampling = ProjectSampling::with(['currentSubStage', 'subStageUsers'])->find($sampling_id);
                if (!$sampling) {
                    $this->response['error'] = 'Sampling details not found!';
                    return $this->sendResponse($this->response, 200);
                }

                //for current Stage users
                $usersIds = $sampling->sub_stage_user_ids;
                $currUsers = User::with('designation:id,title')->whereIn('id', $usersIds)->get();

                $currStageUser = [];

                foreach ($currUsers as $currUser) {
                    $desTitle = $currUser->designation->title ?? '';
                    $userId = $currUser->id ?? '';
                    $userName = $currUser->name ?? '';

                    $currUserString = $userName . ' ' . '(' . $desTitle . ')';

                    $currStageUser[] = ['id' => $userId, 'user_designation' => $currUserString];
                }

                $data['curr_stage_users'] = $currStageUser;

                $nextSubStageIds = $sampling->currentSubStage->next_sub_stage_ids;
                // $nextSubStageIds = json_decode($nextSubStageIds, true) ?? [];

                $nextSubStages = [];
                if (count($nextSubStageIds)) $nextSubStages = ProjectSamplingSubStage::whereIn('id', $nextSubStageIds)->get()->toArray();

                // $data['current_sub_stage'] = $sampling->currentSubStage;
                // $data['next_sub_stages'] = $nextSubStages;

                $currentSubStage = $sampling->toArray()['current_sub_stage'];
                if ($currentSubStage) $currentSubStage['name'] = 'Current Stage (' . $currentSubStage['name'] . ')';
                if ($currentSubStage['is_last_stage'] == 1) {
                    $data['sub_stages'] = $nextSubStages;
                } else {
                    $data['sub_stages'] = array_merge([$currentSubStage], $nextSubStages);
                }

                // User and Department List
                $department_ids = [];
                if ($selected_sub_stage_id) {
                    $selectedSubStage = ProjectSamplingSubStage::find($selected_sub_stage_id);
                    $department_ids = explode(',', $selectedSubStage->to_departments);
                } else {
                    $department_ids = explode(',', $sampling->currentSubStage->to_departments);
                }

                $departmentAndUsers = $this->getDepartmentAndUserList($department_ids);
                $usersArr = $departmentAndUsers['users']->toArray($request);
                $users = [];

                $i = 0;
                foreach ($usersArr as $key => $user) {
                    $users[$i] = $user;
                    $users[$i]['selected'] = $selected_sub_stage_id == $currentSubStage['id'] && in_array($user['id'], $sampling->sub_stage_user_ids) ? 1 : 0;
                    // $users[$i]['selected'] = $selected_sub_stage_id == $currentSubStage['id'] && in_array($user['id'], json_decode($sampling->sub_stage_user_ids ?? '[]', true)) ? 1 : 0;
                    $i++;
                }

                if ($selected_sub_stage_id == $currentSubStage['id']) {
                    $attachments = json_decode($sampling->sub_stage_attachments);
                }

                $showFormFor = '';

                if ($selected_sub_stage_id == $this->DELIVERY) {
                    $showFormFor = 'DELIVERY';

                    $deliveryUpdate = ProjectSamplingDeliveryUpdate::where(['fk_rfq_id' => $rfq->id])->orderBy('id', 'desc')->first();
                    if ($deliveryUpdate) {
                        $data['delivery_id'] = $deliveryUpdate->id;
                        $data['delivery_date'] = $deliveryUpdate->delivery_date;
                        $data['received_by'] = $deliveryUpdate->recieved_by;
                        $data['attachments'] = $deliveryUpdate->attachments;
                    }
                }

                if ($selected_sub_stage_id == $this->PI_PREPARED_UPLOADED_SUB_STAGE_ID) {
                    $showFormFor = 'PI_PREPARED_UPLOADED';

                    $pi = ProjectSamplingPurchaseInvoice::where(['fk_rfq_id' => $rfq->id])->orderBy('id', 'desc')->first();
                    if ($pi) {
                        $data['pi_id'] = $pi->id;
                        $data['pi_date'] = $pi->pi_date;
                        $data['pi_no'] = $pi->pi_no;
                        $data['pi_details'] = $pi->pi_details;
                        $data['pi_total_amount'] = $pi->pi_total_amount;
                        $data['invoice_charges_detail'] = $pi->invoice_charges_detail;
                        $data['pi_remark'] = $pi->remark;
                    }
                }

                if ($selected_sub_stage_id == $this->PDR_PREPARED_UPLOADED_SUB_STAGE_ID) {
                    $showFormFor = 'PDR_PREPARED_UPLOADED';

                    $quality_report = ProjectSamplingPdrQuality::where(['fk_rfq_id' => $rfq->id])->orderBy('id', 'desc')->first();
                    if ($quality_report) {
                        $data['quality_id'] = $quality_report->quality_id;
                        $data['quality_report_date'] = $quality_report->quality_report_date;
                        $data['quality_report_no'] = $quality_report->quality_report_no;
                        $data['quality_report_remark'] = $quality_report->remark;
                        $data['quality_rmtc_no'] = $quality_report->quality_rmtc_no;
                    }
                }

                $data['user_departments'] = $departmentAndUsers['departments'];
                $data['user_list'] = $users;
                $data['remark'] = $selected_sub_stage_id == $currentSubStage['id'] ? $sampling->sub_stage_remark : '';
                $data['attachments'] = $attachments;
                $data['show_form_for'] = $showFormFor;
            } else {
                $subStages = ProjectSamplingSubStage::whereIn('id', [1])->get()->toArray();

                $department_ids = explode(',', $subStages[0]['to_departments']);

                $departmentAndUsers = $this->getDepartmentAndUserList($department_ids);
                $usersArr = $departmentAndUsers['users']->toArray($request);
                $users = [];

                $i = 0;
                foreach ($usersArr as $key => $user) {
                    $users[$i] = $user;
                    $users[$i]['selected'] = 0;
                    // $users[$i]['selected'] = $selected_sub_stage_id == $currentSubStage['id'] && in_array($user['id'], json_decode($sampling->sub_stage_user_ids ?? '[]', true)) ? 1 : 0;
                    $i++;
                }

                $data['sub_stages'] = $subStages;
                $data['curr_stage_users'] = [];
                $data['user_departments'] = $departmentAndUsers['departments'];
                $data['user_list'] = $users;
                $data['remark'] = '';
                $data['attachments'] = [];
                $data['show_form_for'] = '';
            }

            $this->response['status'] = 1;
            $this->response['data'] = $data;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("RFQ view failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function updateStage(Request $request)
    {
        DB::beginTransaction();
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateProjectSamplingStageChange($request);

            if (count($validationErrors)) {
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $rfq_id = $request->rfq_id;
            $sampling_id = $request->sampling_id;
            $requested_sub_stage_id = $request->sub_stage_id;
            $user_ids = $request->user_ids ?? [];
            $remark = $request->remark ?? '';

            $rfq = Rfq::with('lead')->find($rfq_id);
            if (!$rfq) {
                $this->response['error'] = 'RFQ details not found!';
                return $this->sendResponse($this->response, 200);
            }

            $sampling = new ProjectSampling();
            if ($sampling_id) {
                $sampling = ProjectSampling::find($sampling_id);
                if (!$sampling) {
                    $this->response['error'] = 'Project sampling details not found!';
                    return $this->sendResponse($this->response, 200);
                }
            }

            $requestSubStage = ProjectSamplingSubStage::where('id', $requested_sub_stage_id)->first();
            $stageActionDepartments = $requestSubStage->action_departments ?? '';

            $actionDepartmentIds = [];
            if ($stageActionDepartments != '') {
                $actionDepartmentIds = explode(",", $stageActionDepartments);
            }

            $user = UserRole::with('user', 'department')->whereIn('fk_department_id', $actionDepartmentIds)->groupBy('fk_user_id')->get();

            if ($user->isEmpty()) {
                $this->response["error"] = "Current Stage has no user";
                return $this->sendResponse($this->response, 200);
            }

            if (!$user->contains('user.id', $this->userId)) {
                $this->response["error"] = "You are not authorized to change this stage";
                return $this->sendResponse($this->response, 200);
            }

            $currentToUserDepartments = UserRole::whereIn('fk_user_id', $user_ids)
                ->with('department')
                ->groupBy('fk_department_id')
                ->get()->toArray();

            $departmentTitles = [];

            foreach ($currentToUserDepartments as $userDepartment) {
                // Assuming that 'department' is the name of the relationship in the UserRole model
                $departmentTitles[] = $userDepartment['department']['title'];
            }

            $files = [];
            if (isset($request->attachments)) {
                if (count($request->attachments) > 0) {
                    foreach ($request->attachments as $item) {
                        moveFile('project/files/', $item['filename']);
                        $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                    }
                }
            }

            $attachments = $files ?? [];

            // PI PREPARED/UPLOADED
            if ($requestSubStage->id == $this->PI_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $validationErrors = $this->validatePi($request);
                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $pi_date = Carbon::createFromFormat('d/m/Y g:i A', $request->pi_date)->format('Y-m-d H:i:s');
                // $pi_no = $request->pi_no;
                $pi_details = $request->pi_details ?? [];
                $invoice_charges_detail = $request->invoice_charges_detail ?? [];
                $pi_remark = $request->pi_remark;


                if (empty($pi_details)) {
                    $this->response["errors"] = ["pi_details" => "Please Fill the Purchase Invoice Details"];
                    return $this->sendResponse($this->response, 200);
                }

                $poDetailsEmpty = false;

                foreach ($pi_details as $key => $item) {
                    if (empty($item['part_no']) || empty($item['qty']) || empty($item['rate'])) {
                        $poDetailsEmpty = true;
                        break;
                    }
                }

                if ($poDetailsEmpty) {
                    $this->response["errors"] = ["pi_details" => "Please fill all Purchase Order Details"];
                    return $this->sendResponse($this->response, 200);
                }

                ProjectSamplingPurchaseInvoice::where(['fk_sampling_id' => $sampling->id])->update(['is_latest' => 0]);

                $piId = $request->pi_id;
                $piObject = ProjectSamplingPurchaseInvoice::find($piId);
                if (!$piObject) {
                    $piObject = new ProjectSamplingPurchaseInvoice();
                    $piObject->created_by = $this->userId;
                }

                $lastEntry = ProjectSamplingPurchaseInvoice::latest('id')->first();
                $lastId = $lastEntry ? $lastEntry->id : 0;
                $pi_no = generateUniqueNumber($lastId, "AVL-PIS");

                $pi_total_amount = array_reduce($pi_details, function ($carry, $item) {
                    $carry += $item['total_amount'];
                    return $carry;
                });

                $invoice_charges_amount = 0;
                if ($invoice_charges_detail) {
                    $invoice_charges_amount = array_reduce($invoice_charges_detail, function ($carry, $item) {
                        $carry += $item['total_amount'];
                        return $carry;
                    });
                }

                $piObject->fk_sampling_id = $sampling->id;
                $piObject->fk_rfq_id = $rfq->id;
                $piObject->fk_lead_id = $rfq->lead->id;
                $piObject->pi_no = $pi_no;
                $piObject->pi_date = $pi_date;
                $piObject->pi_details = json_encode($pi_details);
                $piObject->invoice_charges_detail = json_encode($invoice_charges_detail);
                $piObject->invoice_charges_amount = $invoice_charges_amount;
                $piObject->pi_total_amount = $pi_total_amount;
                $piObject->final_amount = $pi_total_amount + $invoice_charges_amount;
                $piObject->pi_total_amount_paid =  $piObject->pi_total_amount_paid ?? 0;
                $piObject->pi_total_amount_pending =  max(0, $pi_total_amount - ($piObject->pi_total_amount_paid ?? 0));
                $piObject->payment_done = $piObject->pi_total_amount_pending > 0  ?  0 : 1;
                $piObject->remark = $pi_remark;
                $piObject->updated_by = $this->userId;
                $piObject->save();
            }

            // PDR PREPARED/UPLOADED
            if ($requestSubStage->id == $this->PDR_PREPARED_UPLOADED_SUB_STAGE_ID) {
                $validationErrors = $this->validateQualityReport($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $quality_report_date = Carbon::createFromFormat('d/m/Y g:i A', $request->quality_report_date)->format('Y-m-d H:i:s');
                $quality_report_no = $request->quality_report_no;
                $quality_rmtc_no = $request->quality_rmtc_no;
                $quality_report_remark = $request->quality_report_remark ?? '';
                $attachments = $request->attachments ?? '';

                ProjectSamplingPdrQuality::where(['fk_sampling_id' => $sampling->id])->update(['is_latest' => 0]);

                $qualityReportId = $request->quality_report_id;
                $qualityReportObject = ProjectSamplingPdrQuality::find($qualityReportId);
                if (!$qualityReportObject) {
                    $qualityReportObject = new ProjectSamplingPdrQuality();
                    $qualityReportObject->created_by = $this->userId;
                }

                $files = [];
                if (!empty($attachments)) {
                    foreach ($attachments as $item) {
                        moveFile('project/files/', $item['filename']);
                        $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                    }
                }

                $attachments = json_encode($files);

                $qualityReportObject->fk_sampling_id = $sampling->id;
                $qualityReportObject->fk_rfq_id = $rfq->id;
                $qualityReportObject->fk_lead_id = $rfq->lead->id;
                $qualityReportObject->quality_report_no = $quality_report_no;
                $qualityReportObject->quality_report_date = $quality_report_date;
                $qualityReportObject->quality_rmtc_no = $quality_rmtc_no;
                $qualityReportObject->attachments = $attachments;
                $qualityReportObject->remark = $quality_report_remark;

                $qualityReportObject->save();
            }

            if ($requestSubStage->id == $this->DELIVERY) { //For delivery
                $validationErrors = $this->validateDelivery($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $deliveryDate = Carbon::createFromFormat('d/m/Y g:i A', $request->delivery_date)->format('Y-m-d H:i:s');
                $receivedBy = $request->received_by;
                $attachments = $request->attachments;

                ProjectSamplingDeliveryUpdate::where(['fk_sampling_id' => $sampling->id]);

                $deliveryId = $request->delivery_id;
                $deliveryObject = ProjectSamplingDeliveryUpdate::find($deliveryId);
                if (!$deliveryObject) {
                    $deliveryObject = new ProjectSamplingDeliveryUpdate();
                    $deliveryObject->created_by = $this->userId;
                }

                $files = [];
                if (!empty($attachments)) {
                    foreach ($attachments as $item) {
                        moveFile('project/files/', $item['filename']);
                        $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                    }
                }

                $attachments = json_encode($files);

                $deliveryObject->fk_rfq_id = $rfq->id;
                $deliveryObject->fk_lead_id = $rfq->lead->id;
                $deliveryObject->delivery_date = $deliveryDate;
                $deliveryObject->recieved_by = $receivedBy;
                $deliveryObject->attachments = $attachments;
                $deliveryObject->updated_by = $this->userId;
                $deliveryObject->save();
            }


            $sampling->fk_rfq_id = $rfq->id;
            $sampling->lead_id = $rfq->lead->id;
            $sampling->main_sub_stage_id = $rfq->curr_sub_stage_id ?? 0;
            $sampling->sub_stage_id = $requested_sub_stage_id;
            $sampling->sub_stage_user_ids = $user_ids;
            $sampling->sub_stage_remark = $remark;
            $sampling->sub_stage_attachments = json_encode($attachments);
            $sampling->{$sampling_id ? 'updated_by' : 'created_by'} = $this->userId;
            $sampling->updated_by = $this->userId;
            $sampling->save();

            $this->response['status'] = 1;
            $this->response['msg'] = "Stage updated successfully";

            $sampling->action = 'updated';
            $sampling->action_from = 'sampling';
            ProjectSamplingLogCreated::dispatch($sampling);

            // $requestData = $request->all();
            // $ids = $user_ids;

            // // Send Email Notification
            // $currentUrl = URL::to('/');
            // if (!str_contains($currentUrl, 'localhost')) {
            //     SendSamplingChangeStageNotification::dispatch($ids, $requestData);
            // }

            DB::commit();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("Project Sampling updateStage failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function history(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $sampling_id = $request->sampling_id;

            $sampling = ProjectSampling::find($sampling_id);
            if (!$sampling) {
                $this->response['error'] = 'Project Sampling details not found!';
                return $this->sendResponse($this->response, 200);
            }

            $stages = ProjectSamplingLog::with(['subStage:id,name', 'users.roles.department'])
                ->where(['fk_sampling_id' => $sampling->id])
                ->orderBy('id', 'desc')
                ->get();

            $stages = UserRoleTenderHistoryResource::collection($stages);

            $this->response['status'] = 1;
            $this->response['data']['list'] = $stages;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Project Sampling History failed: " . $e);
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function piList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;
            $pspi = ProjectSamplingPurchaseInvoice::where('fk_sampling_id', $id)->get();

            if (!$pspi) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project Sampling Purchase Invoice"]);
                return $this->sendResponse($this->response, 500);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Project Sampling Purchase Invoice"]);
            $this->response['data']['list'] = $pspi;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Project Sampling Purchase Invoice fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getLatestComment(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $samplingId = $request->sampling_id ?? '';
            $projectObject = ProjectSamplingLog::with('updatedBy:id,name')->where(['fk_sampling_id' => $samplingId])->get(['sub_stage_remark', 'updated_by', 'updated_at']);

            $stageRemarks = [];
            foreach ($projectObject as $project) {
                $userName = $project->updatedBy->name ?? '';
                $formattedDate = $project->updated_at->format('Y-m-d H:i:s');
                if ($project->sub_stage_remark != '') {
                    $stageRemarks[] = [
                        'user' => $userName,
                        'comment' => $project->sub_stage_remark,
                        'date' => $formattedDate,
                    ];
                }
            }


            if (!$projectObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project Sampling Comment"]);
                return $this->sendResponse($this->response, 500);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Project Sampling Comment"]);
            $this->response['data'] = $stageRemarks;


            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Project Sampling Comment fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    ////////////////////// VALIDATION ////////////////////////

    private function validateProjectSamplingStageChange(Request $request)
    {
        $validationArray = [
            'sub_stage_id' => 'required',
            'user_ids' => 'required',
            'remark' => '',
        ];

        $requested_sub_stage = ProjectSamplingSubStage::find($request->sub_stage_id);
        if ($requested_sub_stage) {
            if ($requested_sub_stage->attachment_required == 1) $validationArray['attachments'] = 'required';
        }

        return Validator::make($request->all(), $validationArray, [
            'sub_stage_id.required' => 'Stage is required',
            'user_ids.required' => 'User selection is required'
        ])->errors();
    }

    private function validatePi(Request $request)
    {
        return Validator::make($request->all(), [
            'pi_date' => 'required|date_format:d/m/Y g:i A',
            // 'agreement_no' => 'required',

        ])->errors();
    }

    private function validateDelivery(Request $request)
    {
        return Validator::make($request->all(), [
            'delivery_date' => 'required|date_format:d/m/Y g:i A',
            // 'agreement_no' => 'required',
        ])->errors();
    }

    private function validateQualityReport(Request $request)
    {
        return Validator::make($request->all(), [
            'quality_report_date' => 'required|date_format:d/m/Y g:i A',
            'quality_report_no' => 'required',

        ])->errors();
    }
    ////////////////////// VALIDATION ////////////////////////


    ////////////////////// HELPERS ///////////////////////////
    function getDepartmentAndUserList($department_ids = [])
    {
        $data['user_departments'] = [];
        $data['user_list'] = [];

        if (!count($department_ids)) return $data;

        $userDepartmentList = Department::whereIn('id', $department_ids)->get()->toArray();
        $userDepartmentList = implode(', ', array_column($userDepartmentList, 'title'));

        $users = UserRole::with('user.roles.department', 'user.roles.departmentType', 'department')
            ->whereHas('user.roles', function ($q) {
                $q->whereNotNull('id');
            })
            ->whereIn('fk_department_id', $department_ids)
            ->groupBy('fk_user_id')
            ->get()->sortBy(function ($item) {
                return $item->user->name;
            }); // For RSM department id is 5

        $userList =  AllUserResource::collection($users);

        $data['departments'] = $userDepartmentList;
        $data['users'] = $userList;

        return $data;
    }

    function generateRandomNumber()
    {
        $randomNumber = mt_rand(1000, 9999);
        $result = 'AVL-' . $randomNumber;
        return $result;
    }

    ////////////////////// HELPERS ///////////////////////////
}
