<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductImage;
use App\Models\ProductParameter;
use App\Models\ProductPart;
use App\Models\RfqProduct;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\Writer\Csv;

class ProductController extends AppBaseController
{
    /**
     * Display a listing of the Products.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $product_name = $request->product_name ?? '';
            $category = $request->category ?? '';
            $isExport = $request->is_export ?? '';

            $product = Product::with('category')->select('*', 'status as is_active')->withoutTrashed()->orderBy("product_name");

            if ($product_name) {
                $product->where('product_name', 'like', '%' . $product_name . '%');
            }

            if ($category) {
                $categories = ProductCategory::find($category);
                $categoryIds = explode(',', $categories->child_id);
                if ($categoryIds && count($categoryIds)) {
                    $product->whereIn('product_category_id', $categoryIds);
                } else {
                    $product->where('product_category_id', $category);
                }
            }

            $num_rows = $product->count();
            $result = ProductResource::collection($product->limit($per_page)->offset($offset)->get());

            if ($isExport == 1) {
                $pro = Product::with('category')->get();
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                $headers = ['Product Id', 'Category Name', 'Product Name', 'Part No', 'Part No Desc'];
                $sheetData = [$headers];

                foreach ($pro as $key => $item) {
                    $rowData = [
                        $item->id,
                        $item->Category->category_name ?? '',
                        $item->product_name ?? '',
                    ];

                    $sheetData[] = $rowData;
                }

                $sheet->fromArray($sheetData, null, 'A1');

                $store = "storage/app/public/uploads/product/product_list.csv";
                $filePath = "storage/uploads/product/product_list.csv";
                $writer = new Csv($spreadsheet);
                $writer->save($store);
            }

            $showButton = false;
            if ($this->isUserAdmin) {
                $showButton = true;
            }

            $isAllowed = false;
            if ($this->isUserAdmin || $this->userId == 15) {
                $isAllowed = true;
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Product"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['filePath'] = $filePath ?? '';
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['product_name'] = $product_name;
            $this->response['data']['category'] = $category;
            $this->response['data']['showButton'] = $showButton;
            $this->response['data']['show_add_btn'] = $isAllowed;
            $this->response['data']['list'] = $result;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addUpdate(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdateProduct($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $productObject = new Product();
            $id = $request->id;
            $product_category_id = $request->product_category_id ?? 0;
            $product_name = $request->product_name;
            $hsn = $request->hsn;
            $short_description = $request->short_description ?? '';
            $long_description = $request->long_description ?? '';
            $product_field_count = $request->product_field_count ?? 5;

            $status = $request->is_active ?? 1;



            if ($id) {
                $productObject = Product::find($id);

                if (!$productObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Product"]);
                    return $this->sendResponse($this->response, 401);
                }

                $productObject->first();
                $productObject->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "Product"]);
            } else {
                $productObject->created_by = $this->userId;
                $this->response['msg'] = __('admin.created', ['module' => "Product"]);
            }

            $productObject->product_category_id = $product_category_id;
            $productObject->product_name = $product_name;
            $productObject->hsn = $hsn;
            $productObject->short_description = $short_description;
            $productObject->long_description = $long_description;
            $productObject->product_field_count = $product_field_count;
            $productObject->status = $status;
            $productObject->save();

            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Product: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Product"]);

            return $this->sendResponse($this->response, 401);
        }
    }

    public function addParameter(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddParameter($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $id = $request->id;
            $productId = $request->product_id;
            $name = $request->name;
            $value = $request->value ? json_encode($request->value) : json_encode([]);
            $valueType = $request->value_type;
            $isMultiple = $request->is_multiple ?? 0;
            $is_qty = $request->is_qty ?? 0;
            $status = $request->status ?? 0;

            $productParameterObject = new ProductParameter();


            if ($id) {
                $productParameterObject = ProductParameter::find($id);

                if (!$productParameterObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Product Parameter"]);
                    return $this->sendResponse($this->response, 200);
                }

                $productParameterObject->first();
                $this->response['msg'] = __('admin.updated', ['module' => 'Product Parameter']);
            } else {
                $this->response['msg'] = __('admin.created', ['module' => "Product Parameter"]);
            }

            if ($is_qty == "1") {
                $checkDuplicateIsQty = ProductParameter::where('product_id', $productId)->where('is_qty', '1');

                if ($id) {
                    $checkDuplicateIsQty->where('id', '!=', $id);
                }

                $duplicateCount = $checkDuplicateIsQty->count();

                if ($duplicateCount > 0) {
                    $this->response['errors'] = ['is_qty' => 'This Product already has Is Quantity Parameter'];
                    return $this->sendResponse($this->response, 200);
                }
            }

            $productParameterObject->product_id = $productId;
            $productParameterObject->name = $name;
            $productParameterObject->value = $value;
            $productParameterObject->value_type = $valueType;
            $productParameterObject->is_qty = $is_qty;
            $productParameterObject->is_multiple = $isMultiple;
            $productParameterObject->status = $status;

            $productParameterObject->save();
            $this->response['status'] = 1;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Product Parameters: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Product Parameter"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    public function addSingleImage(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateParaImage($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $productImageObject = new ProductImage();
            $id = $request->id;
            $product_id = $request->product_id;
            $title = $request->title ?? '';
            $images = $request->images ?? [];
            $status = $request->status ?? 0;

            if ($id) {
                $productImageObject = ProductImage::find($id);

                if (!$productImageObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "product parameter image"]);
                    return $this->sendResponse($this->response, 401);
                }

                $productImageObject->first();
                $this->response['msg'] = __('admin.updated', ['module' => "product parameter image"]);
            } else {
                $this->response['msg'] = __('admin.created', ['module' => "product parameter image"]);
            }

            foreach ($images as $item) {

                moveFile('product/image/', $item['filename']);
                $image = $item['filename'];
                $path = $this->fileAccessPath . "/product/image/" . $item['filename'];
                $productImageObject->image = $image;
                $productImageObject->path = $path;
            }

            $productImageObject->product_id = $product_id;
            $productImageObject->title = $title;
            $productImageObject->status = $status;

            $productImageObject->save();

            $this->response['status'] = 1;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating product parameter image: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "product parameter image"]);

            return $this->sendResponse($this->response, 401);
        }
    }

    public function addImage(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddImage($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $productId = $request->id;

            if (count($request->images) > 0) {
                foreach ($request->images as $item) {

                    moveFile('product/image/', $item['filename']);

                    $title = $item['title'] ?? NULL;
                    $image = $item['filename'];
                    $path = $this->fileAccessPath . "/product/image/" . $item['filename'];
                    $productImageId = $item['id'];

                    $productImageObject = new ProductImage();

                    if ($productImageId) {
                        $productImageObject = ProductImage::find($productImageId);

                        if (!$productImageObject) {
                            $this->response['error'] = __('admin.id_not_found', ['module' => "Product Parameter"]);
                            return $this->sendResponse($this->response, 200);
                        }
                    }

                    if ($image != "") {
                        $productImageObject->product_id = $productId;
                        $productImageObject->title = $title;
                        $productImageObject->image = $image;
                        $productImageObject->path = $path;
                        $productImageObject->save();
                    }
                }
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.updated', ['module' => "Product Image"]);

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Product Images: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Product Image"]);

            return $this->sendResponse($this->response, 401);
        }
    }

    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $productObject = Product::with('category', 'parameters', 'images')->select('*', 'status as is_active')->find($id);

            if (!$productObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product"]);
                return $this->sendResponse($this->response, 401);
            }
            $result =  new ProductResource($productObject);

            $showButton = false;
            if ($this->isUserAdmin) {
                $showButton = true;
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Product"]);
            $this->response['data'] = $result;
            $this->response['data']['showButton'] = $showButton;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $productObject = Product::find($id);

            if (!$productObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product"]);
                return $this->sendResponse($this->response, 401);
            }

            $productObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Product"]);
            $this->response['data'] = $productObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function getParameters(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $productId = $request->product_id ?? '';
            $productObject = Product::find($productId);

            if (!$productObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product"]);
                return $this->sendResponse($this->response, 401);
            }


            $productParameters = ProductParameter::where('product_id', $productId)->withoutTrashed()->orderBy("sequence");
            $num_rows = $productParameters->count();

            $result = $productParameters->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Product Parameters"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['list'] = $result;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Parameters fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getParam(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id ?? '';
            $productObject = ProductParameter::find($id);

            if (!$productObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product Parameter"]);
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Product Parameter"]);
            $this->response['data']['list'] = $productObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Parameters fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function getImage(REQUEST $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id ?? '';
            $productObject = ProductImage::find($id);

            if (!$productObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product Parameter Image"]);
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Product Parameter Image"]);
            $this->response['data']['list'] = $productObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Parameters fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function getImages(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $productId = $request->product_id ?? '';
            $productObject = Product::find($productId);

            if (!$productObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product"]);
                return $this->sendResponse($this->response, 401);
            }

            $productImages = ProductImage::where('product_id', $productId)->withoutTrashed()->orderBy("id", "desc");
            $num_rows = $productImages->count();

            $result = $productImages->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Product Images"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['list'] = $result;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Images fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function deleteParameter(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $productParameterObject = ProductParameter::find($id);

            if (!$productParameterObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product Parameter"]);
                return $this->sendResponse($this->response, 401);
            }

            $productParameterObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Product Parameter"]);
            $this->response['data'] = $productParameterObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Parameter Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function deleteImage(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $productImageObject = ProductImage::find($id);

            if (!$productImageObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Product Image"]);
                return $this->sendResponse($this->response, 401);
            }

            $productImageObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Product Image"]);
            $this->response['data'] = $productImageObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Image Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function organizeParameterList(Request $request)
    {
        $sequenceData = $request->input('order');
        $productId = $request->input('product_id');
        foreach ($sequenceData as $sequence => $itemData) {
            $itemArray = explode('/', $itemData);
            $newSequence = $sequence + 1;
            $id = $itemArray[0];
            $table = DB::table('product_parameters');
            $table->where('id', $id)->where('product_id', $productId)->update(['sequence' => $newSequence + ($itemArray[2] * ($itemArray[1] - 1))]);
        }

        $this->response['status'] = 1;
        $this->response['msg'] = __('admin.deleted', ['module' => "Parameter reordered successfully"]);
        return $this->sendResponse($this->response, 200);
    }

    public function organizeProductList(Request $request)
    {
        $sequenceData = $request->input('order');
        $rfqId = $request->rfq_id ?? '';
        DB::beginTransaction();
        try {
            foreach ($sequenceData as $index => $item) {
                $newSequence = $index + 1;
                DB::table('rfq_products')
                    ->where('id', $item['id'])
                    ->where('rfq_id', $rfqId)
                    ->update(['sequence' => $newSequence]);
            }

            DB::commit();

            $this->response['status'] = 1;
            $this->response['msg'] = "Product reordered successfully";
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            DB::rollBack();

            $this->response['status'] = 0;
            $this->response['msg'] = __('admin.error', ['module' => "Error reordering products"]);
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function exportPartNo(Request $request)
    {

        try {

            $lists = ProductPart::with('product', 'product.category')->orderBy("id", "desc")->get();

            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $headers = ['Sr.No', 'Product Category', 'Product', 'Part No', 'HSN', 'Description'];
            $sheetData = [$headers];

            foreach ($lists as $key => $item) {
                $proCatName = isset($item->product) && isset($item->product->category) ? $item->product->category->category_name : '';
                $proName = isset($item->product) ? $item->product->product_name : '';
                $hsn = isset($item->product) ? $item->product->hsn : '';

                $rowData = [
                    $key + 1,
                    $proCatName,
                    trim($proName),
                    $item->part_no ?? '',
                    $hsn,
                    $item->description ?? '',
                ];
                $sheetData[] = $rowData;
            }

            $sheet->fromArray($sheetData, null, 'A1');

            $store = "storage/app/public/uploads/product/part_no_list.csv";
            $filePath = "storage/uploads/product/part_no_list.csv";
            $writer = new Csv($spreadsheet);
            $writer->save($store);

            $this->response['status'] = 1;
            $this->response['msg'] = "File downloaded successfully";
            $this->response['data']['filePath'] = $filePath ?? '';
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Download failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    private function validateAddUpdateProduct(Request $request)
    {
        return Validator::make($request->all(), [
            'product_category_id' => 'required|integer|exists:product_categories,id',
            'product_name' => 'required|string|unique:products,product_name,' . $request->id . ',id,deleted_at,NULL',
            'status' => 'sometimes|required|integer|in:0,1',
        ])->errors();
    }

    private function validateAddParameter(REQUEST $request)
    {
        return Validator::make(
            $request->all(),
            [
                'name' => 'required',
                'value_type' => 'required',
                'value' => 'required_if:value_type,select',
            ],
        )->errors();
    }

    private function validateParaImage(Request $request)
    {
        return Validator::make($request->all(), [
            'title' => 'required',
        ])->errors();
    }

    private function validateAddImage(Request $request)
    {
        return Validator::make($request->all(), [
            'id' => 'required|integer|exists:products,id',
        ])->errors();
    }
}
