<?php

namespace App\Http\Controllers\API;

use App\Events\ProjectSamplingLogCreated;
use App\Http\Controllers\Controller;
use App\Models\Department;
use App\Models\ProjectSampling;
use App\Models\ProjectSamplingLog;
use App\Models\ProjectSamplingPdrQuality;
use App\Models\ProjectSamplingPurchaseInvoice;
use App\Models\Rfq;
use App\Models\SubStage;
use App\Models\UserRole;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class ProjectSamplingControllerOld extends AppBaseController
{
    function updateStage(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateUpdateStage($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $id = $request->rfq_id;

            $projectObject = Rfq::find($id);
            if (!$projectObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Project"]);
                return $this->sendResponse($this->response, 200);
            }

            $curr_sub_stage_id = $request->curr_sub_stage_id;
            $currUser = $request->curr_user;
            $main_sub_stage_id = $projectObject->curr_sub_stage_id;

            $uniqueArray = [];
            foreach ($currUser as $item) {
                if (!in_array($item['id'], array_column($uniqueArray, 'id'))) {
                    $uniqueArray[] = $item;
                }
            }

            $curr_user = json_encode($uniqueArray);

            $comments = $request->comments ?? '';
            $files = [];
            if (isset($request->attachments)) {
                if (count($request->attachments) > 0) {
                    foreach ($request->attachments as $item) {
                        moveFile('project/files/', $item['filename']);
                        $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                    }
                }
            }

            $attachments = json_encode($files) ?? '';

            $ids = '';

            if (!empty($request->curr_user)) {
                $ids = implode(',', array_column($uniqueArray, 'id'));
            }

            $subStageObject = SubStage::where('is_sampling_stage', 1)->find($curr_sub_stage_id);

            if (!$subStageObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Sampling Stage"]);
                return $this->sendResponse($this->response, 200);
            }

            $curr_stage_id = $subStageObject->stage_id;
            $stageActionDepartments = $subStageObject->action_departments ?? '';

            $actionDepartmentIds = [];
            if ($stageActionDepartments != '') {
                $actionDepartmentIds = explode(",", $stageActionDepartments);
            }



            $user = UserRole::with('user', 'department')->whereIn('fk_department_id', $actionDepartmentIds)->groupBy('fk_user_id')->get();

            if ($user->isEmpty()) {
                $this->response["error"] = "Please select user to proceed!";
                return $this->sendResponse($this->response, 200);
            }

            if (!$user->contains('user.id', $this->userId)) {
                $this->response["error"] = "You can not change stage!";
                return $this->sendResponse($this->response, 200);
            }

            $stageToDepartments = $subStageObject->to_departments ?? '';

            $toDepartmentIds = [];
            if ($stageToDepartments != '') {
                $toDepartmentIds = explode(",", $stageToDepartments);
            }
            $toDepartments = Department::whereIn('id', $toDepartmentIds)->pluck('title')->toArray();
            $currentToUserDepartments = UserRole::whereIn('fk_user_id', array_column($request->curr_user, 'id'))
                ->with('department')
                ->groupBy('fk_department_id')
                ->get()->toArray();

            $departmentTitles = [];

            foreach ($currentToUserDepartments as $userDepartment) {
                // Assuming that 'department' is the name of the relationship in the UserRole model
                $departmentTitles[] = $userDepartment['department']['title'];
            }

            $allDepartmentUSerFound = true;

            foreach ($toDepartments as $department) {
                if (!in_array($department, $departmentTitles)) {
                    $allDepartmentUSerFound = false;
                    break;
                }
            }

            if (!$allDepartmentUSerFound) {
                $this->response["errors"] =  ["curr_user" => "Select at least one user from each department"];
                return $this->sendResponse($this->response, 200);
            }

            $fk_rfq_id = $projectObject->id;
            $fk_lead_id = $projectObject->lead_id;

            if ($curr_sub_stage_id == 16) { // For Purchase Invoice
                $validationErrors = $this->validatePi($request);
                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $pi_date = Carbon::createFromFormat('d/m/Y g:i A', $request->pi_date)->format('Y-m-d H:i:s');
                // $pi_no = $request->pi_no;
                $pi_details = $request->pi_details ?? [];
                $pi_total_amount = $request->pi_total_amount;
                $pi_remark = $request->pi_remark;


                if (empty($pi_details)) {
                    $this->response["errors"] = ["pi_details" => "Please Fill the Purchase Invoice Details"];
                    return $this->sendResponse($this->response, 200);
                }

                $piDetailsEmpty = false;

                foreach ($pi_details as $key => $item) {
                    if (empty($item['part_no']) || empty($item['qty']) || empty($item['rate'])) {
                        $piDetailsEmpty = true;
                        break;
                    }
                }

                if ($piDetailsEmpty) {
                    $this->response["errors"] = ["pi_details" => "Please fill all Purchase Orde Details"];
                    return $this->sendResponse($this->response, 200);
                }

                $pi_details = json_encode($pi_details);

                $piObject = ProjectSamplingPurchaseInvoice::find($request->pi_id);
                if (!$request->pi_id) {
                    $piObject = new ProjectSamplingPurchaseInvoice();
                    $piObject->created_by = $this->userId;
                }

                $lastEntry = ProjectSamplingPurchaseInvoice::latest('id')->first();
                $lastId = $lastEntry ? $lastEntry->id : 0;
                $pi_no = generateUniqueNumber($lastId, "AVL-PIS");

                $piObject->fk_rfq_id = $fk_rfq_id;
                $piObject->fk_lead_id = $fk_lead_id;
                $piObject->pi_no = $pi_no;
                $piObject->pi_date = $pi_date;
                $piObject->pi_details = $pi_details;
                $piObject->pi_total_amount = $pi_total_amount;
                $piObject->pi_total_amount_paid =  $piObject->pi_total_amount_paid ?? 0;
                $piObject->pi_total_amount_pending =  max(0, $pi_total_amount - ($piObject->pi_total_amount_paid ?? 0));
                $piObject->payment_done = $piObject->pi_total_amount_pending > 0  ?  0 : 1;
                $piObject->updated_by = $this->userId;

                $piObject->remark = $pi_remark;
                $piObject->save();
            }

            if ($curr_sub_stage_id == 14) { // for Quality Report
                $validationErrors = $this->validateQualityReport($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $quality_report_date = Carbon::createFromFormat('d/m/Y g:i A', $request->quality_report_date)->format('Y-m-d H:i:s');
                $quality_report_no = $request->quality_report_no;
                $quality_rmtc_no = $request->quality_rmtc_no;
                $quality_report_ramark = $request->quality_report_ramark;

                $pdrQualityObject = new ProjectSamplingPdrQuality();
                $pdrQualityObject->created_by = $this->userId;

                $quality_report_id = $request->quality_report_id ?? 0;

                if ($quality_report_id != 0) {
                    $pdrQualityObject = ProjectSamplingPdrQuality::find($quality_report_id);

                    if (!$pdrQualityObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Quality Report not found!"]);
                        return $this->sendResponse($this->response, 200);
                    }
                }

                $pdrQualityObject->fk_rfq_id = $fk_rfq_id;
                $pdrQualityObject->fk_lead_id = $fk_lead_id;
                $pdrQualityObject->quality_report_no = $quality_report_no;
                $pdrQualityObject->quality_rmtc_no = $quality_rmtc_no;
                $pdrQualityObject->quality_report_date = $quality_report_date;
                $pdrQualityObject->remark = $quality_report_ramark;
                $pdrQualityObject->save();
            }

            $attachments = json_encode($files) ?? '';

            if ($curr_sub_stage_id == 18) { // When Delivery Status Updated

                $validationErrors = $this->validateDeliveryConfirmation($request);

                if (count($validationErrors)) {
                    Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                    $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                    return $this->sendResponse($this->response, 200);
                }

                $deliveryDate = Carbon::createFromFormat('d/m/Y g:i A', $request->delivery_date)->format('Y-m-d H:i:s');
                $recievedBy = $request->recieved_by;

                $deliveryObject = new ProjectSamplingPurchaseInvoice();
                $deliveryObject->created_by = $this->userId;

                $deliveryId = $request->delivery_id ?? 0;

                if ($deliveryId != 0) {
                    $deliveryObject = ProjectSamplingPurchaseInvoice::find($deliveryId);

                    if (!$deliveryObject) {
                        $this->response['error'] = __('admin.id_not_found', ['module' => "Delivery Confirmation"]);
                        return $this->sendResponse($this->response, 401);
                    }
                }

                $deliveryObject->delivery_date = $deliveryDate;
                $deliveryObject->recieved_by = $recievedBy;
                $deliveryObject->attachments = $attachments;
                $deliveryObject->updated_by = $this->userId;
                $deliveryObject->save();
            }

            $samplingObject = ProjectSampling::where('fk_rfq_id', $projectObject->id)->first();
            if (!$samplingObject) {
                $samplingObject = new ProjectSampling();
                $samplingObject->created_by = $this->userId;;
            }

            $samplingObject->curr_stage_id = $curr_stage_id;
            $samplingObject->curr_sub_stage_id = $curr_sub_stage_id;
            $samplingObject->main_sub_stage_id = $main_sub_stage_id;
            $samplingObject->curr_user = $curr_user;
            $samplingObject->curr_user_ids = $ids;
            $samplingObject->attachments = $attachments;
            $samplingObject->comments = $comments;
            $samplingObject->updated_by = $this->userId;

            if ($curr_sub_stage_id == 8) {
                $samplingObject->fk_supplier_id = $request->fk_supplier_id;
            }

            $samplingObject->save();

            $projectObject->action = 'updated';
            $projectObject->action_from = 'project';
            ProjectSamplingLogCreated::dispatch($projectObject);

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.updated', ['module' => "Sampling"]);

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed Updating Sampling: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function validateUpdateStage(Request $request)
    {
        return Validator::make($request->all(), [
            // 'curr_stage_id' => 'required',
            'curr_sub_stage_id' => 'required',
            'curr_user' => in_array($request->curr_sub_stage_id, [17, 18, 27, 32, 33, 51]) ? '' : 'required', // not require when project heading towards client
            'fk_supplier_id' => in_array($request->curr_sub_stage_id, [8]) ? 'required' : '', // Supplier is require when Supplier Selection By PSM
            'credit_limit' => [
                'required_if:curr_sub_stage_id,22', // Require credit_limit if curr_sub_stage_id is RFQ Approved
                'not_in:0',
            ],
            'credit_days' => [
                'required_if:curr_sub_stage_id,22', // Require credit_limit if curr_sub_stage_id is RFQ Approved
            ],
            'client_type' => [
                'required_if:curr_sub_stage_id,22', // Require client_type if curr_sub_stage_id RFQ Approved
            ],
            // 'attachments' => in_array($request->curr_sub_stage_id, [34, 37, 41, 43, 44, 45, 46, 47]) ? 'required' : '',
            'attachments' => in_array($request->curr_sub_stage_id, config('global.ATTACHMENT_REQUIRED_STAGE')) ? 'required' : '',
        ], [
            'fk_supplier_id.required' => "Please Select Supplier",
            'credit_limit.required_if' => "Credit Limit is required",
            'credit_days.required_if' => "Credit Days is required",
            'client_type.required_if' => "Client Type is required",
            'credit_limit.not_in' => "Credit Limit Cannot Be Zero",
        ])->errors();
    }

    private function validatePi(Request $request)
    {
        return Validator::make($request->all(), [
            'pi_date' => 'required|date_format:d/m/Y g:i A',
            // 'agreement_no' => 'required',

        ])->errors();
    }

    private function validateQualityReport(Request $request)
    {
        return Validator::make($request->all(), [
            'quality_report_date' => 'required|date_format:d/m/Y g:i A',
            'quality_report_no' => 'required',
            'quality_rmtc_no' => 'required',

        ])->errors();
    }

    private function validateDeliveryConfirmation(Request $request)
    {
        return Validator::make($request->all(), [
            'delivery_date' => 'required|date_format:d/m/Y g:i A',
            'recieved_by' => 'required',

        ])->errors();
    }
}
