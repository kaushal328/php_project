<?php

namespace App\Http\Controllers\API;

use App\Enums\PoStatus;
use App\Events\PoLogCreated;
use App\Http\Controllers\Controller;
use App\Http\Resources\PurchaseOrderResource;
use App\Models\Product;
use App\Models\ProjectQuotation;
use App\Models\PurchaseOrder;
use App\Models\Rfq;
use App\Models\RfqProduct;
use Carbon\Carbon;
use Exception;
use App\Enums\DispatchDocument;
use App\Models\AvlockPurchaseInvoice;
use App\Models\AvlockSalesOrder;
use App\Models\DeliveryNote;
use App\Models\EwayBill;
use App\Models\PackagingSlip;
use App\Models\PackagingSlipDetail;
use App\Models\PoDespatchDetail;
use App\Models\ProductPart;
use App\Models\ProjectQuotationTemp;
use App\Models\PurchaseOrderDetail;
use App\Models\PurchaseOrderService;
use App\Models\PurchaseOrderType;
use App\Models\SubStage;
use App\Models\Tender;
use App\Models\User;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Spatie\LaravelPdf\Enums\Format;
use Spatie\LaravelPdf\Facades\Pdf as MyPdf;
use PDF;


class PurchaseOrderController extends AppBaseController
{
    function index(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $fk_quotation_id = $request->fk_quotation_id ?? "";
            $fk_rfq_id = $request->fk_rfq_id ?? "";
            $fk_lead_id = $request->fk_lead_id ?? "";
            $po_date = $request->po_date ?? '';
            $po_no = $request->po_no ?? '';
            $prepared_by = $request->prepared_by ?? "";

            $poObject = PurchaseOrder::with('quotation', 'preparedBy', 'lead', 'rfq', 'rfq.designation');

            if ($fk_quotation_id) $poObject->where('fk_quotation_id',  $fk_quotation_id);
            if ($fk_rfq_id) $poObject->where('fk_rfq_id',  $fk_rfq_id);
            if ($fk_lead_id) $poObject->where('fk_lead_id',  $fk_lead_id);
            if ($po_date) $poObject->where('po_date', '>=', $this->convertToDatabaseDateForSearch($po_date));
            if ($po_no) $poObject->where('po_no', 'like', '%' . $po_no . '%');
            if ($prepared_by) $poObject->where('prepared_by',  $prepared_by);

            $num_rows = $poObject->count();

            $result = $poObject->limit($per_page)->offset($offset)->get();
            $poList = PurchaseOrderResource::collection($result);


            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Purchase Order"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['fk_rfq_id'] = $fk_rfq_id;
            $this->response['data']['fk_lead_id'] = $fk_lead_id;
            $this->response['data']['po_date'] = $po_date;
            $this->response['data']['po_no'] = $po_no;
            $this->response['data']['prepared_by'] = $prepared_by;
            $this->response['data']['list'] = $poList;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Purchase Order List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function get(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poId = $request->po_id ?? "";

            if (!$poId) {
                $this->response['error'] = "Please select a valid Purchase Order!";
                return $this->sendResponse($this->response, 200);
            }

            $poObject = PurchaseOrder::with('quotation', 'preparedBy', 'lead', 'rfq', 'rfq.designation', 'poType')->find($poId);

            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            if (isset($poObject->rfq->id)) {
                $rfqProduct = RfqProduct::where('rfq_id', $poObject->rfq->id)->get()->toArray();
                if (!empty($rfqProduct)) {

                    $productIds = array_column($rfqProduct, 'product_id');
                    $poObject->rfq_products = Product::select('id', 'product_name')->whereIn('id', $productIds)->get();
                }
            }


            $this->response['status'] = 1;
            $this->response['data'] = $poObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Purchase Order Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function getQuotationDetails(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $quotationId = $request->quotation_id ?? "";

            if (!$quotationId) {
                $this->response['error'] = "Please select a valid Quotation!";
                return $this->sendResponse($this->response, 200);
            }

            $rfqObject = ProjectQuotation::with('lead', 'rfq.designation', 'lead.region', 'lead.source', 'rfq.subStage', 'rfq.product', 'preparedBy')->find($quotationId);

            if (!$rfqObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Quotation"]);
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['data'] = $rfqObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Quotation Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addUpdate(Request $request)
    {
        try {

            DB::beginTransaction();

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdatePurchaseOrder($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $poObject = new PurchaseOrder();
            $id = $request->id;
            $rfqId = $request->rfq_id ?? 0;
            $leadId = $request->lead_id ?? 0;
            $quotationId = $request->quotation_id ?? 0;
            $poTypeId = $request->po_type_id;
            $serviceDetails = $request->service_details ?? [];
            $poDetails = $request->po_details ?? [];
            $poNo = $request->po_no;
            $currSubStageId = $request->curr_sub_stage_id ?? '';
            $currUser = $request->curr_user ?? [];
            $commUsers = $request->comm_users ?? [];
            $currUserIds = $request->curr_user_ids ?? '';
            $comments = $request->comments ?? '';
            $from = $request->from ?? '';
            $attachments = $request->attachments ?? [];
            $poDate = Carbon::createFromFormat('d/m/Y', $request->po_date)->format('Y-m-d H:i:s');
            $cgst = $request->cgst;
            $sgst = $request->sgst;
            $igst = $request->igst;
            $cgstValue = $sgstValue = $igstValue = 0;

            if (empty($poDetails) && empty($serviceDetails)) {
                $this->response["error"] = "Please select atleast one Product Or Service";
                return $this->sendResponse($this->response, 200);
            }

            $poDetailsEmpty = false;
            foreach ($poDetails as $key => $item) {
                if (empty($item['product_id']) || empty($item['part_no']) || empty($item['qty']) || empty($item['rate'])) {
                    $poDetailsEmpty = true;
                    break;
                }
            }

            $serviceTotal = 0;
            if ($serviceDetails) {
                $serviceTotal = array_reduce($serviceDetails, function ($carry, $item) {
                    return $carry + (isset($item['total_amount']) ? intval($item['total_amount']) : 0);
                }, 0);
            }

            $poDetailTotal = 0;
            if ($poDetails) {
                $poDetailTotal = array_reduce($poDetails, function ($carry, $item) {
                    return $carry + (isset($item['total_amount']) ? intval($item['total_amount']) : 0);
                }, 0);
            }

            $finalAmount = $totalBaiscValue = $poDetailTotal + $serviceTotal;

            $rfqObject = Rfq::with('quotationTemp', 'currencyData')->find($rfqId);
            if (empty($request->quotation_id)) {
                $quotationId = isset($rfqObject->quotationTemp) ? $rfqObject->quotationTemp->id : null;
            }

            $currency = $rfqObject->currencyData ?? null;

            if ($currency) {
                $usdToInrRateResponse = getCurrencyToInrRate($currency->title);
                if (isset($usdToInrRateResponse['error']) && !empty($usdToInrRateResponse['error'])) {
                    $this->response['error'] = $usdToInrRateResponse['error'];
                    return $this->sendResponse($this->response, 200);
                }

                $currencyToInrRate = $usdToInrRateResponse['data'];

                $totalBasicValueInInr = $totalBaiscValue * floatval($currencyToInrRate);
            }


            if ($cgst > 0) $cgstValue = ($finalAmount * floatval($cgst)) / 100;
            if ($sgst > 0) $sgstValue = ($finalAmount * floatval($sgst)) / 100;
            if ($igst > 0) $igstValue = ($finalAmount * floatval($igst)) / 100;

            $finalAmount = $finalAmountInInr = $finalAmount + $cgstValue + $sgstValue + $igstValue;

            if ($poDetailsEmpty) {
                $this->response["errors"] = ["po_details" => "Please fill all Purchase Order Details"];
                return $this->sendResponse($this->response, 200);
            }

            $serviceDetails = json_encode($serviceDetails);
            $poDetails = json_encode($poDetails);

            if (!$attachments || !is_array($attachments) || count($attachments) < 1) {
                $this->response["errors"] = ["attachments" => "Please upload documents!"];
                return $this->sendResponse($this->response, 200);
            }

            $files = [];
            if (!empty($attachments)) {
                foreach ($attachments as $item) {
                    moveFile('project/files/', $item['filename']);
                    $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
                }
            }

            $attachments = json_encode($files);



            if ($currency) {
                $usdToInrRateResponse = getCurrencyToInrRate($currency->title);
                if (isset($usdToInrRateResponse['error']) && !empty($usdToInrRateResponse['error'])) {
                    $this->response['error'] = $usdToInrRateResponse['error'];
                    return $this->sendResponse($this->response, 200);
                }

                $currencyToInrRate = $usdToInrRateResponse['data'];

                $finalAmountInInr = $finalAmount * floatval($currencyToInrRate);
            }

            if ($id) {
                $poObject = PurchaseOrder::find($id);

                if (!$poObject) {
                    $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                    return $this->sendResponse($this->response, 200);
                }

                $poObject->updated_by = $this->userId;
                $this->response['msg'] = __('admin.updated', ['module' => "Purchase Order"]);
            } else {
                $poObject->created_by = $this->userId;
                $poObject->prepared_by = $this->userId;
                $poObject->po_status = 'active';
                $this->response['msg'] = __('admin.created', ['module' => "Purchase Order"]);
            }

            $poObject->fk_quotation_id = $quotationId;
            $poObject->fk_rfq_id = $rfqId;
            $poObject->fk_lead_id = $leadId;
            $poObject->po_no = $poNo;
            $poObject->po_date = $poDate;
            $poObject->po_type_id = $poTypeId ?? 1;
            $poObject->po_details = $poDetails;
            $poObject->service_details = $serviceDetails;
            $poObject->po_details_total = $poDetailTotal;
            $poObject->total_basic_value = $totalBaiscValue;
            $poObject->total_basic_value_in_inr = $totalBasicValueInInr ?? 0;
            $poObject->cgst = $cgst;
            $poObject->cgst_value = $cgstValue;
            $poObject->sgst = $sgst;
            $poObject->sgst_value = $sgstValue;
            $poObject->igst = $igst;
            $poObject->igst_value = $igstValue;
            $poObject->final_amount = $finalAmount ?? 0;
            $poObject->final_amount_in_inr = $finalAmountInInr ?? 0;
            $poObject->service_total = $serviceTotal;
            $poObject->po_status = PoStatus::ACTIVE;
            $poObject->curr_sub_stage_id = $currSubStageId;
            $poObject->curr_user = json_encode($currUser);
            $poObject->curr_user_ids = $currUserIds;
            $poObject->comm_users = json_encode($commUsers);
            $poObject->attachments = $attachments;
            $poObject->comments = $comments;
            $poObject->po_type = 1;
            $poObject->save();
            $lastInsertedId = $poObject->id;

            //Product Detail Store
            $proIds = array_column($request->po_details, 'id');
            $proIds = array_filter($proIds, 'is_numeric');

            PurchaseOrderDetail::where('fk_po_id', $lastInsertedId)
                ->whereNotIn('id', $proIds)
                ->delete();

            if (!empty($request->po_details) && is_array($request->po_details)) {
                foreach ($request->po_details as $po) {
                    if (!empty($po['id'])) {
                        $podObj = PurchaseOrderDetail::find($po['id']);
                    } else {
                        $podObj = new PurchaseOrderDetail();
                        $podObj->fk_po_id = $lastInsertedId;
                    }

                    $podObj->product_id = isset($po['product_id']) ? $po['product_id'] : '';
                    $podObj->product_part_id = isset($po['part_noId']) ? $po['part_noId'] : '';
                    $podObj->part_no = isset($po['part_no']) ? $po['part_no'] : '';
                    $podObj->description = isset($po['description']) ? $po['description'] : '';
                    $podObj->hsn = isset($po['hsn']) ? $po['hsn'] : '';
                    $podObj->unit = isset($po['unit']) ? $po['unit'] : '';
                    $podObj->qty = isset($po['qty']) ? $po['qty'] : '';
                    $podObj->rate = isset($po['rate']) ? $po['rate'] : '';
                    $podObj->total_amount = isset($po['total_amount']) ? $po['total_amount'] : '';
                    $podObj->po_type = 1;
                    $podObj->save();
                }
            }

            //Service Detail Store
            $proServiceIds = array_column($request->service_details, 'id');
            $proServiceIds = array_filter($proServiceIds, 'is_numeric');

            PurchaseOrderService::where('fk_po_id', $lastInsertedId)
                ->whereNotIn('id', $proIds)
                ->delete();

            if (!empty($request->service_details) && is_array($request->service_details)) {
                foreach ($request->service_details as $so) {
                    if (!empty($so['id'])) {
                        $posObj = PurchaseOrderService::find($so['id']);
                    } else {
                        $posObj = new PurchaseOrderService();
                        $posObj->fk_po_id = $lastInsertedId;
                    }

                    $posObj->part_no = isset($so['part_no']) ? $so['part_no'] : '';
                    $posObj->hsn = isset($so['hsn']) ? $so['hsn'] : '';
                    $posObj->label = isset($so['label']) ? $so['label'] : '';
                    $posObj->set_name = isset($so['set_name']) ? $so['set_name'] : '';
                    $posObj->qty = isset($so['qty']) ? $so['qty'] : '';
                    $posObj->rate = isset($so['rate']) ? $so['rate'] : '';
                    $posObj->total_amount = isset($so['total_amount']) ? $so['total_amount'] : '';
                    $posObj->save();
                }
            }


            if (empty($id)) {
                $currentUrl = URL::to('/');
                if (!str_contains($currentUrl, 'localhost')) {
                    $rfq = RFQ::with('lead', 'quotationTemp')->find($rfqId);
                    $currSubStage = SubStage::find($currSubStageId);

                    $user = User::find($rfq->rsm_id)->toArray();
                    $divisionHead = getDivisionHead($rfq->division_id, 5);
                    $insideSales = getDivisionHead($rfq->division_id, 6, false);
                    $mailUsers = array_merge([$user], $divisionHead, $insideSales);

                    if (!empty($mailUsers)) {
                        $emails = array_unique(array_column($mailUsers, 'email'));
                    }

                    $url = 'https://crm.avlock.in/project/form/' . $leadId . '/' . $rfqId;
                    if (!empty($lastInsertedId)) {
                        $url .= '?po_id=' . custom_encrypt($lastInsertedId);
                    }

                    $mailData = [
                        'rfq' => $rfq,
                        'currSubStage' => $currSubStage,
                        'title' => 'Hi Inside Sales Team,',
                        'subject' => 'PO Added Successfully - Please Process for Order',
                        'headingOne' => 'PO Added Successfully',
                        'headingTwo' => 'Kindly proceed with processing the order at your earliest convenience.',
                        'emailAddresses' => $emails,
                        'ccAddresses' => 'avlockcrm@gmail.com',
                        // 'ccAddresses' => 'shoeb.digiinterface@gmail.com',
                        'qtnInEmail' => 1,
                        'bccAddresses' => 'rakesh.digiinterface@gmail.com',
                        'url' => $url,
                        'poNo' => isset($poObject->po_no) ? $poObject->po_no : '',
                    ];

                    if ($currSubStage && !empty($emails)) {
                        Mail::send('mail_templates.stage_change', $mailData, function ($mail) use ($mailData) {
                            $mail->from(env('MAIL_FROM_ADDRESS'), 'Avlock CRM');
                            // $mail->to('altamash.digiinterface@gmail.com');
                            $mail->to($mailData['emailAddresses']);
                            $mail->subject($mailData['subject']);

                            // Add CC
                            if (!empty($mailData['ccAddresses'])) {
                                $mail->cc($mailData['ccAddresses']);
                            }

                            // Add BCC
                            if (!empty($mailData['bccAddresses'])) {
                                $mail->bcc($mailData['bccAddresses']);
                            }
                        });
                    }
                }
            }

            $poObject->action = $id ? 'updated' : 'created';
            PoLogCreated::dispatch($poObject);

            $this->response['status'] = 1;
            DB::commit();

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Failed Creating Purchase Order: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            DB::rollBack();
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Purchase Order"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    public function addPoDespatchDetail(Request $request)
    {

        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateAddUpdatePoDispatch($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $poId = $request->po_id;
            $currSubStageId = $request->curr_sub_stage_id;
            $poDetails = $request->poDetails ?? [];
            foreach ($poDetails as $key => $value) {
                if (isset($value['id']) && !empty($value['id'])) {
                    $poDespatchObject = PoDespatchDetail::find($value['id']);
                } else {
                    $poDespatchObject = new PoDespatchDetail();
                }
                $despatchDate = Carbon::createFromFormat('d/m/Y', $value['po_despatch_date'])->format('Y-m-d');
                $poDespatchObject->po_id = $poId;
                $poDespatchObject->despatch_date = $despatchDate;
                $poDespatchObject->po_type = 1;
                $poDespatchObject->details = json_encode($value['details']);
                $poDespatchObject->service_details = json_encode($value['service_details']);
                $poDespatchObject->save();
            }

            $poObject = PurchaseOrder::find($poId);
            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            if ($currSubStageId) {
                $poObject->curr_sub_stage_id = $currSubStageId;
                $poObject->save();
            }



            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.updated', ['module' => "Purchase Order Despatch Detail"]);

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Failed Creating Purchase Order Despatch Detail: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Purchase Order Despatch Detail"]);
            return $this->sendResponse($this->response, 500);
        }
    }


    public function downloadPdf(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poId = $request->po_id ?? '';
            $viewPdf = $request->view_pdf;

            $poDetails = PurchaseOrder::with(['quotation', 'preparedBy', 'lead', 'rfq', 'rfq.banner', 'rfq.footer', 'rfq.designation'])->find($poId);
            $detail = new PurchaseOrderResource($poDetails);

            if (!$poDetails) {
                $this->response['error'] = "PUrchase Order details not found!";
                return $this->sendResponse($this->response, 200);
            }

            $data = [
                'details' => json_decode(json_encode($detail)),
            ];

            if ($viewPdf == 1) {
                $this->response['status'] = 1;
                $this->response['msg'] = __('admin.fetched', ['module' => "Purchase Order Pdf"]);
                $this->response['data']['html'] = view('pdf.po.view', ['details' => $data['details']])->render();

                return $this->sendResponse($this->response, 200);
            }

            $path = 'pdf/po/' . str_replace(['-', '/'], '', $poDetails->po_no) . '.pdf';

            MyPdf::view('pdf.po.view', ['details' => $data['details']])
                ->format(Format::A4)
                ->margins(10, 10, 10, 10)
                ->save(storage_path('app/public/uploads/' . $path));

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Purchase Order Pdf"]);
            $this->response['data'] = $this->fileAccessPath . '/' . $path;
            $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Purchase Order pdf Generation Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function delete(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id;

            $purchaseOrderObject = PurchaseOrder::find($id);

            if (!$purchaseOrderObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 500);
            }

            $purchaseOrderObject->delete();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.deleted', ['module' => "Purchase Order"]);
            $this->response['data'] = $purchaseOrderObject;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Purchase Order Delete failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    function poDetail(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id ?? "";

            if (!$id) {
                $this->response['error'] = "Please select a valid Purchase Order!";
                return $this->sendResponse($this->response, 200);
            }

            $poObject = PurchaseOrder::with('quotation', 'preparedBy', 'lead', 'rfq', 'rfq.designation')->withCount('quotation')->find($id);

            if (!$poObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
                return $this->sendResponse($this->response, 200);
            }

            if (isset($poObject->lead->id)) {
                $quotationCount = ProjectQuotationTemp::where('fk_lead_id', $poObject->lead->id)->count();
                $qCount = $quotationCount;
            }

            if (isset($poObject->rfq->id)) {
                $rfqProduct = RfqProduct::where('rfq_id', $poObject->rfq->id)->get()->toArray();
                if (!empty($rfqProduct)) {

                    $productIds = array_column($rfqProduct, 'product_id');
                    $poObject->rfq_products = Product::select('id', 'product_name')->whereIn('id', $productIds)->get();
                }
            }


            //FOR DISPATCH DATE DROPDOWN
            $poDispatchDetail = PoDespatchDetail::where('po_id', $id)->get()->toArray();
            $dispatchDate = [];

            if (!empty($poDispatchDetail) && is_array($poDispatchDetail)) {
                $dispatchDate = array_map(
                    fn($detail) => [
                        'id' => $detail['id'],
                        'dispatch_date' => Carbon::createFromFormat('Y-m-d', $detail['despatch_date'])->format('d/m/Y') ?? ''
                    ],
                    $poDispatchDetail
                );
            }

            if (is_array($dispatchDate) && !empty($dispatchDate)) {
                sort($dispatchDate);
            }

            //FOR PACKAGING DATE DROPDOWN
            $salesOrderObject = AvlockSalesOrder::where('fk_po_id', $id)->get()->toArray();
            $packagingDate = [];
            $salesOrderDate = [];

            if (!empty($salesOrderObject) && is_array($salesOrderObject)) {
                $salesOrderDate = array_map(
                    fn($detail) => [
                        'id' => $detail['id'],
                        'so_date' =>  $detail['so_no'] . ' -' .  Carbon::createFromFormat('Y-m-d', $detail['so_date'])->format('d/m/Y') ?? ''
                    ],
                    $salesOrderObject
                );
            }

            if (is_array($salesOrderDate) && !empty($salesOrderDate)) {
                sort($salesOrderDate);
            }

            //FOR DELIVERY DATE DROPDOWN
            $packagingSlipObject = PackagingSlip::where('fk_po_id', $id)->get()->toArray();
            $packagingDate = [];

            if (!empty($packagingSlipObject) && is_array($packagingSlipObject)) {
                $packagingDate = array_map(
                    fn($detail) => [
                        'id' => $detail['id'],
                        'packaging_slip_date' => Carbon::createFromFormat('Y-m-d', $detail['packaging_slip_date'])->format('d/m/Y') . ' (' . $detail['packaging_slip_no'] . ')' ?? ''
                    ],
                    $packagingSlipObject
                );
            }


            if (is_array($packagingDate) && !empty($packagingDate)) {
                sort($packagingDate);
            }


            //FOR E-INVOICE DATE DROPDOWN
            $deliveryNoteObj = DeliveryNote::where('fk_po_id', $id)->get()->toArray();
            $deliveryDate = [];

            if (!empty($deliveryNoteObj) && is_array($deliveryNoteObj)) {
                $deliveryDate = array_map(
                    fn($detail) => [
                        'id' => $detail['id'],
                        'delivery_note_date' => Carbon::createFromFormat('Y-m-d', $detail['delivery_note_date'])->format('d/m/Y') . ' (' . $detail['delivery_note_no'] . ')' ?? ''
                    ],
                    $deliveryNoteObj
                );
            }

            if (is_array($deliveryDate) && !empty($deliveryDate)) {
                sort($deliveryDate);
            }

            //FOR E-WAY BILL DATE DROPDOWN
            $invoiceObj = AvlockPurchaseInvoice::where('fk_po_id', $id)->get()->toArray();
            $invoiceDate = [];

            if (!empty($invoiceObj) && is_array($invoiceObj)) {
                $invoiceDate = array_map(
                    fn($detail) => [
                        'id' => $detail['id'],
                        'pi_date' => Carbon::createFromFormat('Y-m-d', $detail['pi_date'])->format('d/m/Y') . ' (' . $detail['pi_no'] . ')' ?? ''
                    ],
                    $invoiceObj
                );
            }

            if (is_array($invoiceDate) && !empty($invoiceDate)) {
                sort($invoiceDate);
            }

            $soObject = AvlockSalesOrder::where('fk_po_id', $id)->first();
            if ($soObject && $soObject->so_details) {
                $soDetails = json_decode($soObject->so_details);
                if (is_array($soDetails)) {
                    $partNoIds = array_map(
                        fn($detail) => $detail->product_part_id ?? $detail->part_noId,
                        $soDetails
                    );
                }

                if ($partNoIds) {
                    $partNoLists = ProductPart::whereIn('id', $partNoIds)->get();
                }
            }

            $this->response['status'] = 1;
            $this->response['data'] = $poObject;
            $this->response['data']['quotation_count'] = $qCount ?? 0;
            $this->response['data']['dispatchDate'] = $dispatchDate ?? [];
            $this->response['data']['salesOrderDate'] = $salesOrderDate ?? [];
            $this->response['data']['packagingDate'] = $packagingDate ?? [];
            $this->response['data']['deliveryDate'] = $deliveryDate ?? [];
            $this->response['data']['invoiceDate'] = $invoiceDate ?? [];
            $this->response['data']['part_no_lists'] = $partNoLists ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Purchase Order Details fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getDispatchDocument(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $id = $request->id ?? '';

            $isEnable = false;
            $saleOrder = AvlockSalesOrder::where('fk_po_id', $id)->first();
            // $packaging = PackagingSlip::where('fk_po_id', $id)->first();
            $deliveryNote = DeliveryNote::where('fk_po_id', $id)->first();
            $eInvoice = AvlockPurchaseInvoice::where('fk_po_id', $id)->first();

            $salesOrderIsEnabled = true;
            $packagingIsEnabled = $saleOrder ? true : false;
            $deliveryNoteIsEnabled = $saleOrder ? true : false;
            $invoiceIsEnabled = $deliveryNote ? true : false;
            $eWayBillIsEnabled = $eInvoice ? true : false;



            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Dispatch Document"]);
            $this->response['data']['list'] = DispatchDocument::getListForHTML();
            $this->response['data']['sales_order_enable'] = $salesOrderIsEnabled;
            $this->response['data']['packaging_enable'] = $packagingIsEnabled;
            $this->response['data']['delivery_note_enable'] = $deliveryNoteIsEnabled;
            $this->response['data']['invoice_enable'] = $invoiceIsEnabled;
            $this->response['data']['eway_enable'] = $eWayBillIsEnabled;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Dispatch Document fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getPoType(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $list = PurchaseOrderType::get();

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Dispatch Document"]);
            $this->response['data']['list'] = $list;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Dispatch Document fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function poDispatchDetail(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $poId = $request->po_id ?? '';

            $poObject = PurchaseOrder::find($poId)->toArray();
            $products = [];

            foreach (json_decode($poObject['po_details']) as $value) {
                $productId = $value->product_id ?? "";
                $proName = Product::where('id', $productId)->pluck('product_name')->first();
                $description = $value->description ?? "";
                $qty = $value->qty ?? "";
                $rate = $value->rate ?? "";
                $totaAmnt = $value->total_amount ?? "";

                $products['purchase_details'][] = [
                    "product_id" => $productId,
                    "product_name" => $proName,
                    "description" => $description,
                    "qty" => $qty,
                    "rate" => $rate,
                    "total_amount" => $totaAmnt
                ];
            }

            $list = array_merge($poObject, $products);


            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Purchase Order"]);
            $this->response['data']['list'] = $list;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Purchase Order List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    private function validateAddUpdatePoDispatch(Request $request)
    {
        return Validator::make($request->all(), [
            'poDetails.*.po_despatch_date' => 'required|date_format:d/m/Y',
            'poDetails.*.details.*.despatch_qty' => 'required|numeric',
        ], [
            'poDetails.*.po_despatch_date.required' => 'The dispatch date is required',
            'poDetails.*.details.*.despatch_qty.required' => 'The qty is required',

        ])->errors();
    }


    private function validateAddUpdatePurchaseOrder(Request $request)
    {
        return Validator::make($request->all(), [
            'po_date' => 'required|date_format:d/m/Y',
            'po_no' => 'required',
            // 'attachments' => 'required|array',

        ])->errors();
    }
}
