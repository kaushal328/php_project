<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Controllers\API\AppBaseController;
use App\Models\TypeTask;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class TypeTaskController extends AppBaseController {
     /**
   * Display a listing of the Type of Task.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $name = $request->name ?? '';
      $status = $request->status ?? '';

      $typeTaskObject = TypeTask::withoutTrashed()->orderBy("id", "desc");
      $num_rows = $typeTaskObject->count();

      if ($name) {
        $typeTaskObject->where('name', 'like', '%' . $name . '%');
      }

      if ($status) {
        $typeTaskObject->where('status', $status);
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Type Of Task"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['name'] = $name;
      $this->response['data']['list'] = $typeTaskObject->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Type Of Task fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(Request $request) {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateTypeTask($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $typeTaskObject = new TypeTask();
      $id = $request->id;
      $name = $request->name ?? '';
      $status = $request->status ?? 1;

      if ($id) {
        $typeTaskObject = TypeTask::find($id);

        if (!$typeTaskObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Type Of Task"]);
          return $this->sendResponse($this->response, 401);
        }

        $typeTaskObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Type Of Task"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Type Of Task"]);
      }

      $typeTaskObject->name = $name;
      $typeTaskObject->status = $status;

      $typeTaskObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Type Of Task: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Type Of Task"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $typeTaskObject = TypeTask::find($id);

      if (!$typeTaskObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Type Of Task"]);
        return $this->sendResponse($this->response, 500);
      }
      $typeTaskObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Type Of Task"]);
      $this->response['data'] = $typeTaskObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Type Of Task fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $typeTaskObject = TypeTask::find($id);

      if (!$typeTaskObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Type Of Task"]);
        return $this->sendResponse($this->response, 500);
      }

      $typeTaskObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Type Of Task"]);
      $this->response['data'] = $typeTaskObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Type Of Task Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdateTypeTask(Request $request) {
    return Validator::make($request->all(), [
      'name' => 'required|string|unique:type_tasks,name,' . $request->id . ',id,deleted_at,NULL',
      'status' => 'sometimes|required|integer|in:0,1',
    ])->errors();
  }

}
