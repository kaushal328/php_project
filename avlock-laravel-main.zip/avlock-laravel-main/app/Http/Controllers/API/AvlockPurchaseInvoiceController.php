<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Resources\PurchaseInvoiceResource;
use App\Models\AvlockPurchaseInvoice;
use App\Models\Division;
use App\Models\Product;
use App\Models\PurchaseOrder;
use App\Models\Rfq;
use App\Models\RfqProduct;
use App\Models\Tender;
use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Spatie\LaravelPdf\Facades\Pdf as MyPdf;
use Spatie\LaravelPdf\Enums\Format;

class AvlockPurchaseInvoiceController extends AppBaseController
{

  function index(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $poId = $request->po_id;
      $fk_quotation_id = $request->fk_quotation_id ?? "";
      $fk_rfq_id = $request->fk_rfq_id ?? "";
      $fk_lead_id = $request->fk_lead_id ?? "";
      $pi_date = $request->pi_date ?? '';
      $pi_no = $request->pi_no ?? '';
      $payment_done = $request->payment_done ?? '';


      $piObject = AvlockPurchaseInvoice::with('po', 'quotation', 'lead', 'rfq', 'rfq.designation', 'salesOrderDate.dispatch')->where('fk_po_id', $poId);

      if ($fk_quotation_id) $piObject->where('fk_quotation_id',  $fk_quotation_id);
      if ($fk_rfq_id) $piObject->where('fk_rfq_id',  $fk_rfq_id);
      if ($fk_lead_id) $piObject->where('fk_lead_id',  $fk_lead_id);
      if ($pi_date) $piObject->where('pi_date', '>=', $this->convertToDatabaseDateForSearch($pi_date));
      if ($pi_no) $piObject->where('pi_no', 'like', '%' . $pi_no . '%');
      if ($payment_done == 'no') $piObject->where('payment_done',  0);

      $result = $piObject->limit($per_page)->offset($offset)->get();

      $num_rows = $piObject->count();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Purchase Invoice"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['fk_rfq_id'] = $fk_rfq_id;
      $this->response['data']['fk_quotation_id'] = $fk_quotation_id;
      $this->response['data']['fk_lead_id'] = $fk_lead_id;
      $this->response['data']['pi_date'] = $pi_date;
      $this->response['data']['pi_no'] = $pi_no;
      $this->response['data']['list'] = $result;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Purchase Invoice List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function get(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $piId = $request->pi_id ?? "";

      if (!$piId) {
        $this->response['error'] = "Please select a valid Purchase Invoice!";
        return $this->sendResponse($this->response, 200);
      }

      $piObject = AvlockPurchaseInvoice::with('po', 'quotation', 'lead', 'rfq', 'deliveryNoteDate', 'rfq.designation')->find($piId);

      if (!$piObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Invoice"]);
        return $this->sendResponse($this->response, 200);
      }

      if (isset($piObject->rfq->id)) {
        $rfqProduct = RfqProduct::where('rfq_id', $piObject->rfq->id)->get()->toArray();
        if (!empty($rfqProduct)) {

          $productIds = array_column($rfqProduct, 'product_id');
          $piObject->rfq_products = Product::select('id', 'product_name')->whereIn('id', $productIds)->get();
        }
      }


      $this->response['status'] = 1;
      $this->response['data'] = $piObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Purchase Invoice Details fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(Request $request)
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateAvlockPurchaseInvoice($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $piObject = new AvlockPurchaseInvoice();
      $id = $request->id;
      $poId = $request->po_id;
      $rfqId = $request->fk_rfq_id ?? 0;
      $leadId = $request->fk_lead_id ?? 0;
      $quotationId = $request->quotation_id ?? 0;
      $serviceDetails = $request->service_details ?? [];
      $piDetails = $request->pi_details ?? [];
      $currSubStageId = $request->curr_sub_stage_id ?? '';
      $currUser = $request->curr_user ?? [];
      $commUsers = $request->comm_users ?? [];
      $currUserIds = $request->curr_user_ids ?? '';
      $comments = $request->comments ?? '';
      $from = $request->from ?? '';
      $attachments = $request->attachments ?? [];
      $formattedDate = Carbon::createFromFormat('d/m/Y', $request->pi_date);
      $piMonth = $formattedDate->format('M');
      $piDate = $formattedDate->format('Y-m-d');
      $monthNumber = $formattedDate->format('n');
      $year = $formattedDate->format('Y');
      $financialYearStart = $monthNumber >= 4 ? $year : $year - 1;
      $shortFinYearStart = substr($financialYearStart, -2);
      $shortFinYearEnd = substr($financialYearStart + 1, -2);

      $cgst = $request->cgst;
      $sgst = $request->sgst;
      $igst = $request->igst;
      $remark = $request->remark;
      $cgstValue = $sgstValue = $igstValue = 0;
      $yourInvoiceNo = $request->your_invoice_no ?? '';
      $deliveryNoteDate = $request->delivery_note_date ?? '';
      $soNo = $request->sales_order_id ?? '';
      $invoiceAmount = $request->invoice_amount ?? '';
      $poType = $request->po_type ?? '';

      $poObject = PurchaseOrder::find($poId);
      if (!$poObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Order"]);
        return $this->sendResponse($this->response, 200);
      }

      if ($poObject->minimum_document_generated == 0) {
        $this->response["error"] = "Please generate the document first.";
        return $this->sendResponse($this->response, 200);
      }

      if (empty($piDetails) && empty($serviceDetails)) {
        $this->response["error"] = "Please select atleast one Product Or Service.";
        return $this->sendResponse($this->response, 200);
      }

      $piDetailsEmpty = false;
      foreach ($piDetails as $key => $item) {
        if (empty($item['product_id']) || empty($item['part_no']) || empty($item['qty']) || empty($item['rate'])) {
          $piDetailsEmpty = true;
          break;
        }
      }

      $serviceTotal = 0;
      if ($serviceDetails) {
        $serviceTotal = array_reduce($serviceDetails, function ($carry, $item) {
          return $carry + (isset($item['total_amount']) ? intval($item['total_amount']) : 0);
        }, 0);
      }

      $piDetailTotal = 0;
      if ($piDetails) {
        $piDetailTotal = array_reduce($piDetails, function ($carry, $item) {
          return $carry + (isset($item['total_amount']) ? intval($item['total_amount']) : 0);
        }, 0);
      }

      $finalAmount = $piDetailTotal + $serviceTotal;
      if ($cgst > 0) $cgstValue = ($finalAmount * floatval($cgst)) / 100;
      if ($sgst > 0) $sgstValue = ($finalAmount * floatval($sgst)) / 100;
      if ($igst > 0) $igstValue = ($finalAmount * floatval($igst)) / 100;

      $finalAmount = $finalAmountInInr = $finalAmount + $cgstValue + $sgstValue + $igstValue;

      if ($piDetailsEmpty) {
        $this->response["error"] = ["pi_details" => "Please fill all Purchase Invoice Details"];
        return $this->sendResponse($this->response, 200);
      }

      $serviceDetails = json_encode($serviceDetails);
      $piDetails = json_encode($piDetails);

      $files = [];
      if (!empty($attachments)) {
        foreach ($attachments as $item) {
          moveFile('project/files/', $item['filename']);
          $files[] = ['title' => $item['title'], 'filename' => $item['filename'], 'path' => $this->fileAccessPath . "/project/files/" . $item['filename']];
        }
      }

      $attachments = json_encode($files);

      $rfqObject = Rfq::find($rfqId);

      $isCurrencyUsd = $rfqObject->currency ?? null;

      if ($isCurrencyUsd) {
        $usdToInrRateResponse = getUsdToInrRate();
        if (isset($usdToInrRateResponse['error']) && !empty($usdToInrRateResponse['error'])) {
          $this->response['error'] = $usdToInrRateResponse['error'];
          return $this->sendResponse($this->response, 200);
        }

        $usdToInrRate = $usdToInrRateResponse['data'];

        $finalAmountInInr = $piDetailTotal * floatval($usdToInrRate);
      }

      if ($poType === 1) {
        $rfqObject = Rfq::find($rfqId);
        $division = Division::find($rfqObject->division_id);
      } else {
        $tenderObject = Tender::find($poObject->fk_tender_id);
        $division = Division::find($tenderObject->division_id);
      }

      if (!$division) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Division"]);
        return $this->sendResponse($this->response, 200);
      }

      if ($id) {
        $piObject = AvlockPurchaseInvoice::find($id);

        if (!$piObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Invoice"]);
          return $this->sendResponse($this->response, 200);
        }

        $piObject->updated_by = $this->userId;
        $this->response['msg'] = __('admin.updated', ['module' => "Purchase Invoice"]);
      } else {
        $baseString = strtoupper('IN/'  . $division->name . '/' . $shortFinYearStart . '-' . $shortFinYearEnd . '/' . $piMonth . '/');
        $piObject->pi_no = generateSeries($baseString, 'avlock_purchase_invoices', 'pi_no');
        $piObject->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => "Purchase Invoice"]);
      }

      $piObject->fk_quotation_id = $quotationId;
      $piObject->fk_rfq_id = $rfqId;
      $piObject->fk_po_id = $poId;
      $piObject->fk_lead_id = $leadId;
      $piObject->po_type = $poType;
      $piObject->delivery_note_date = $deliveryNoteDate;
      $piObject->sales_order_id = $soNo;
      $piObject->your_pi_no = $yourInvoiceNo;
      $piObject->pi_date = $piDate;
      $piObject->pi_details = $piDetails;
      $piObject->service_details = $serviceDetails;
      $piObject->cgst = $cgst;
      $piObject->cgst_value = $cgstValue;
      $piObject->sgst = $sgst;
      $piObject->sgst_value = $sgstValue;
      $piObject->igst = $igst;
      $piObject->igst_value = $igstValue;
      $piObject->final_amount = $finalAmount ?? 0;
      $piObject->final_amount_in_inr = $finalAmountInInr ?? 0;
      $piObject->service_total = $serviceTotal;
      $piObject->pi_total_amount = $piDetailTotal;
      $piObject->pi_total_amount_paid =  $piObject->pi_total_amount_paid ?? 0;
      $piObject->pi_total_amount_pending =  max(0, $piDetailTotal - ($piObject->pi_total_amount_paid ?? 0));
      $piObject->payment_done =  $piObject->pi_total_amount_pending > 0  ?  0 : 1;
      $piObject->curr_sub_stage_id = $currSubStageId;
      $piObject->curr_user = json_encode($currUser);
      $piObject->curr_user_ids = $currUserIds;
      $piObject->attachments = $attachments;
      $piObject->pi_amount = $invoiceAmount;
      $piObject->remark = $remark;
      $piObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Creating Purchase Invoice: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Purchase Invoice"]);
      return $this->sendResponse($this->response, 500);
    }
  }

  public function downloadInvoicePdf(Request $request)
  {
    try {

      $invoiceId = $request->invoice_id ?? '';
      $viewPdf = $request->view_pdf;
      $invoiceObject = AvlockPurchaseInvoice::with(['po', 'lead', 'rfq.banner', 'rfq.footer', 'rfq.currencyData', 'deliveryNoteDate'])->find($invoiceId);
      $details = new PurchaseInvoiceResource($invoiceObject);
      $details = json_decode(json_encode($details));
      $view = 'pdf.dispatch.invoice_view';

      if ($viewPdf == 1) {
        $this->response['status'] = 1;
        $this->response['msg'] = __('admin.fetched', ['module' => "Invoice"]);
        $this->response['data']['html'] = view($view, ['details' => $details])->render();
        return $this->sendResponse($this->response, 200);
      }

      $path = 'pdf/dispatch/' . str_replace(['-', '/'], '', $invoiceObject->pi_no) . '.pdf';

      MyPdf::view($view, ['details' => $details])
        ->format(Format::A4)
        ->margins(10, 10, 10, 10)
        ->save(storage_path('app/public/uploads/' . $path));

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Invoice Pdf"]);
      $this->response['data'] = $this->fileAccessPath . '/' . $path;
      $this->response['filePath'] = $this->fileAccessPath . '/' . $path;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Invoice pdf Generation Failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $rfqObject = AvlockPurchaseInvoice::find($id);

      if (!$rfqObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Purchase Invoice"]);
        return $this->sendResponse($this->response, 500);
      }

      $rfqObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Purchase Invoice"]);
      $this->response['data'] = $rfqObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Purchase Invoice deleting failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdateAvlockPurchaseInvoice(Request $request)
  {
    return Validator::make($request->all(), [
      'pi_date' => 'required|date_format:d/m/Y',

    ])->errors();
  }
}
