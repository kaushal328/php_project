<?php

namespace App\Http\Controllers\API;

use Exception;
use App\Models\Rfq;
use App\Models\Lead;
use App\Models\Task;
use App\Models\User;
use App\Models\Region;
use App\Models\Activity;
use App\Models\Industry;
use App\Models\Reminder;
use App\Models\UserRole;
use App\Models\LeadDesignation;
use App\Models\ProjectLog;
use App\Models\ProjectType;
use Illuminate\Http\Request;
use App\Models\PurchaseOrder;
use App\Models\ProjectSegment;
use App\Models\UserAttendance;
use Illuminate\Support\Carbon;
use App\Models\PurchaseInvoice;
use App\Models\MonthlyPlanExcel;
use App\Models\SalesVisitReport;
use App\Models\MasterReportPreset;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\ProjectQuotationTemp;
use App\Models\PurchaseOrderDneInvoice;
use App\Models\PurchaseOrderPdrQuality;
use App\Http\Resources\ActivityResource;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Writer\Csv;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use App\Http\Controllers\API\AppBaseController;
use App\Http\Resources\NewDashboardVisitResource;
use App\Http\Resources\PoDispatchResource;
use App\Http\Resources\SalesOrderResource;
use App\Http\Resources\ProjectSheetResource;
use App\Models\AvlockSalesOrder;
use App\Models\DeliveryConfirmation;
use App\Models\Division;
use App\Models\PoDespatchDetail;
use App\Models\Product;
use App\Models\ProjectSampling;
use App\Models\ProjectSamplingPdrQuality;
use App\Models\ProjectSamplingDeliveryUpdate;
use App\Models\ProjectSamplingPurchaseInvoice;

class NewDashboardController extends AppBaseController
{
    private $piSubStageId = 16;
    private $rfqApproveSubStageId = 22;
    private $poApproveSubStageId = 35;
    private $dnSubStageId = 45;
    private $pdrSubStageId = 46;
    private $deliverySubStageId = 49;

    private $dashboardArray = [
        10 => [ //Management
            'basic_counts' => ['rfq', 'svr', 'quotation', 'po', 'invoice', 'open_rfq', 'closed_rfq', 'sales_order', 'dispatch', 'today_dispatch', 'delivered_dispatch', 'sampling', 'delivery_updates', 'pdr_qualities', 'purchase_invoice'],
            'pending_rfqs' => false,
            'task' => true,
            'reminder' => true,
            'quick_report' => false,
            'day_in_out' => true,
        ],
        2 => [ //Admin
            'day_in_out' => true,
        ],
        11 => [ //Finance
            'basic_counts' => ['po', 'invoice', 'sales_order', 'dispatch', 'today_dispatch', 'delivered_dispatch', 'sampling', 'delivery_updates', 'pdr_qualities', 'purchase_invoice'],
            'pending_rfqs' => false,
            'task' => true,
            'reminder' => true,
            'quick_report' => false,
        ],
        12 => [ //Production
            'basic_counts' => ['rfq', 'svr', 'quotation', 'po', 'sales_order', 'invoice', 'open_rfq', 'dispatch', 'today_dispatch', 'delivered_dispatch', 'sampling', 'delivery_updates', 'pdr_qualities', 'purchase_invoice', 'closed_rfq'],
            'pending_rfqs' => false,
            'task' => true,
            'reminder' => true,
            'quick_report' => false,
        ],
        7 => [ //PSM
            'basic_counts' => ['rfq', 'svr', 'quotation', 'po', 'sales_order', 'invoice', 'open_rfq', 'closed_rfq', 'dispatch', 'today_dispatch', 'delivered_dispatch', 'sampling', 'delivery_updates', 'pdr_qualities', 'purchase_invoice'],
            'pending_rfqs' => true,
            'task' => true,
            'reminder' => true,
            'quick_report' => false,
        ],
        6 => [ //INSIDE_SALES
            'basic_counts' => ['rfq', 'svr', 'quotation', 'po', 'sales_order', 'invoice', 'open_rfq', 'dispatch', 'today_dispatch', 'delivered_dispatch', 'sampling', 'delivery_updates', 'pdr_qualities', 'purchase_invoice', 'closed_rfq'],
            'pending_rfqs' => true,
            'task' => true,
            'reminder' => true,
            'quick_report' => false,
        ],
        8 => [ //QUALITY
            'basic_counts' => ['quotation', 'po', 'invoice', 'sales_order', 'dispatch', 'today_dispatch', 'delivered_dispatch', 'sampling', 'delivery_updates', 'pdr_qualities', 'purchase_invoice', 'pdr', 'delivery_note'],
            'pending_rfqs' => true,
            'task' => true,
            'reminder' => true,
            'quick_report' => false,
        ],
        9 => [ //DISPATCH
            'basic_counts' => ['quotation', 'po', 'sales_order', 'invoice', 'dispatch', 'today_dispatch', 'delivered_dispatch', 'sampling', 'delivery_updates', 'pdr_qualities', 'purchase_invoice', 'pdr', 'delivery_note'],
            'pending_rfqs' => true,
            'task' => true,
            'reminder' => true,
            'quick_report' => false,
        ],
        4 => [ //MARKETING
            'basic_counts' => ['rfq', 'svr', 'quotation', 'po', 'sales_order', 'dispatch', 'today_dispatch', 'delivered_dispatch', 'sampling', 'delivery_updates', 'pdr_qualities', 'purchase_invoice', 'invoice', 'open_rfq', 'closed_rfq'],
            'pending_rfqs' => true,
            'task' => true,
            'reminder' => true,
            'quick_report' => false,
            'visit' => true,
            'statistics' => false,
            'lead' => false,
        ],
        5 => [ //SALES
            'basic_counts' => ['rfq', 'svr', 'quotation', 'po', 'invoice', 'dispatch', 'today_dispatch', 'delivered_dispatch', 'sampling', 'delivery_updates', 'pdr_qualities', 'purchase_invoice', 'open_rfq', 'closed_rfq', 'pdr', 'delivery_note'],
            'pending_rfqs' => true,
            'task' => true,
            'reminder' => true,
            'quick_report' => false,
            'visit' => true,
            'statistics' => false,
            'day_in_out' => true,
            // 'type_of_client' => true,
            // 'segment' => true,
            // 'industry' => true,
            // 'zone' => true,
        ],
        3 => [
            'task' => true,
            'reminder' => false,
            'day_in_out' => true,
        ],
        'NATIONAL_HEAD' => [
            'basic_counts' => ['rfq', 'svr', 'quotation', 'po', 'sales_order', 'invoice', 'dispatch', 'today_dispatch', 'open_rfq', 'closed_rfq', 'pdr', 'delivery_note'],
            'task' => false,
            'reminder' => false,
            'quick_report' => false,
            'visit' => false,
            'statistics' => false,
            'type_of_client' => true,
            'segment' => true,
            'industry' => true,
            'zone' => true,
            'lead' => true,
            'day_in_out' => true,
        ]
    ];

    private function getFiscalYearDates()
    {
        $currentMonth = (int)date('m');
        $currentYear = (int)date('Y');

        return [
            'currentMonth' => $currentMonth,
            'fiscalYear' => ($currentMonth >= 1 && $currentMonth <= 3) ? $currentYear - 1 : $currentYear,
        ];
    }

    private function applyFiscalMonthScope($query, $fiscalYear, $currentMonth, $dateColumn)
    {
        return $query->where(function ($q) use ($fiscalYear, $currentMonth, $dateColumn) {
            if ($currentMonth >= 4) {
                $q->whereYear($dateColumn, $fiscalYear)
                    ->whereMonth($dateColumn, $currentMonth);
            } else {
                $q->whereYear($dateColumn, $fiscalYear + 1)
                    ->whereMonth($dateColumn, $currentMonth);
            }
        });
    }

    private function applyFiscalYearScope($query, $fiscalYear, $dateColumn)
    {
        return $query->where(function ($q) use ($fiscalYear, $dateColumn) {
            $q->where(function ($inner) use ($fiscalYear, $dateColumn) {
                $inner->whereYear($dateColumn, $fiscalYear)
                    ->whereMonth($dateColumn, '>=', 4);
            })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                $inner->whereYear($dateColumn, $fiscalYear + 1)
                    ->whereMonth($dateColumn, '<=', 3);
            });
        });
    }

    function index(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $data = [];

            $basicCountResult = [];
            $pendingRfqData = [];
            $taskData = [];
            $reminderData = [];
            $quickReportData = [];
            $visitData = [];
            $statisticsData = [];
            $typeOfClientData = [];
            $industryData = [];
            $segmentData = [];
            $zoneData = [];
            $leadData = [];
            $dayInOutData = [];

            $basicCountReportParams = [];
            $shouldGeneratePendingRfqReport = false;
            $shouldGenerateTaskReport = false;
            $shouldGenerateReminderReport = false;
            $shouldGenerateQuickReport = false;
            $shouldGenerateVisitReport = false;
            $shouldGenerateStatisticsReport = false;
            $shouldGenerateTypeOfClientReport = false;
            $shouldGenerateIndustryReport = false;
            $shouldGenerateSegmentReport = false;
            $shouldGenerateZoneReport = false;
            $shouldGenerateLeadReport = false;
            $shouldGenerateDayInOutReport = false;
            $shouldGenerateReporting = false;

            $user = User::find($this->userId);

            $isNationalHead = in_array($user->fk_designation_id, [1]);

            $userRole = UserRole::with('department')->where('fk_user_id', $user->id)->get()->toArray();
            $departmentIds = array_column(array_column($userRole, 'department'), 'id');

            if (!$isNationalHead) {
                foreach ($departmentIds as $departmentId) {
                    $basicReportParams = @$this->dashboardArray[$departmentId]['basic_counts'] ?? [];
                    if (count($basicReportParams)) {
                        $basicCountReportParams = array_merge(array_values($basicReportParams), $basicCountReportParams);
                    }

                    $pendingRfqReport = @$this->dashboardArray[$departmentId]['pending_rfqs'] ?? false;
                    if ($pendingRfqReport) $shouldGeneratePendingRfqReport = true;

                    $taskReport = @$this->dashboardArray[$departmentId]['task'] ?? false;
                    if ($taskReport) $shouldGenerateTaskReport = true;

                    $reminderReport = @$this->dashboardArray[$departmentId]['reminder'] ?? false;
                    if ($reminderReport) $shouldGenerateReminderReport = true;

                    $quickReport = @$this->dashboardArray[$departmentId]['quick_report'] ?? false;
                    if ($quickReport) $shouldGenerateQuickReport = true;

                    $visitReport = @$this->dashboardArray[$departmentId]['visit'] ?? false;
                    if ($visitReport) $shouldGenerateVisitReport = true;

                    $statisticsReport = @$this->dashboardArray[$departmentId]['statistics'] ?? false;
                    if ($statisticsReport) $shouldGenerateStatisticsReport = true;

                    $typeOfClientReport = @$this->dashboardArray[$departmentId]['type_of_client'] ?? false;
                    if ($typeOfClientReport) $shouldGenerateTypeOfClientReport = true;

                    $industryReport = @$this->dashboardArray[$departmentId]['industry'] ?? false;
                    if ($industryReport) $shouldGenerateIndustryReport = true;

                    $segmentReport = @$this->dashboardArray[$departmentId]['segment'] ?? false;
                    if ($segmentReport) $shouldGenerateSegmentReport = true;

                    $zoneReport = @$this->dashboardArray[$departmentId]['zone'] ?? false;
                    if ($zoneReport) $shouldGenerateZoneReport = true;

                    $leadReport = @$this->dashboardArray[$departmentId]['lead'] ?? false;
                    if ($leadReport) $shouldGenerateLeadReport = true;

                    $dayInOutReport = @$this->dashboardArray[$departmentId]['day_in_out'] ?? false;
                    if ($dayInOutReport) $shouldGenerateDayInOutReport = true;
                }
            } else {

                $basicReportParams = @$this->dashboardArray['NATIONAL_HEAD']['basic_counts'] ?? [];
                if (count($basicReportParams)) {
                    $basicCountReportParams = array_values($basicReportParams);
                }

                $pendingRfqReport = @$this->dashboardArray['NATIONAL_HEAD']['pending_rfqs'] ?? false;
                if ($pendingRfqReport) $shouldGeneratePendingRfqReport = true;

                $taskReport = @$this->dashboardArray['NATIONAL_HEAD']['task'] ?? false;
                if ($taskReport) $shouldGenerateTaskReport = true;

                $reminderReport = @$this->dashboardArray['NATIONAL_HEAD']['reminder'] ?? false;
                if ($reminderReport) $shouldGenerateReminderReport = true;

                $quickReport = @$this->dashboardArray['NATIONAL_HEAD']['quick_report'] ?? false;
                if ($quickReport) $shouldGenerateQuickReport = true;

                $visitReport = @$this->dashboardArray['NATIONAL_HEAD']['visit'] ?? false;
                if ($visitReport) $shouldGenerateVisitReport = true;

                $statisticsReport = @$this->dashboardArray['NATIONAL_HEAD']['statistics'] ?? false;
                if ($statisticsReport) $shouldGenerateStatisticsReport = true;

                $typeOfClientReport = @$this->dashboardArray['NATIONAL_HEAD']['type_of_client'] ?? false;
                if ($typeOfClientReport) $shouldGenerateTypeOfClientReport = true;

                $industryReport = @$this->dashboardArray['NATIONAL_HEAD']['industry'] ?? false;
                if ($industryReport) $shouldGenerateIndustryReport = true;

                $segmentReport = @$this->dashboardArray['NATIONAL_HEAD']['segment'] ?? false;
                if ($segmentReport) $shouldGenerateSegmentReport = true;

                $zoneReport = @$this->dashboardArray['NATIONAL_HEAD']['zone'] ?? false;
                if ($zoneReport) $shouldGenerateZoneReport = true;

                $leadReport = @$this->dashboardArray['NATIONAL_HEAD']['lead'] ?? false;
                if ($leadReport) $shouldGenerateLeadReport = true;

                $dayInOutReport = @$this->dashboardArray['NATIONAL_HEAD']['day_in_out'] ?? false;
                if ($dayInOutReport) $shouldGenerateDayInOutReport = true;
            }

            $basicCountReportParams = array_unique($basicCountReportParams);
            if (count($basicCountReportParams)) {
                $basicCountResult = $this->generateBasicCountReport($basicCountReportParams, $isNationalHead);
                $data['basic_count_data'] = ['title' => 'Counts (' . date("F") . ')', 'result' => $basicCountResult];
            }

            if ($shouldGeneratePendingRfqReport) {
                $pendingRfqData = $this->generatePendingRfqReport($isNationalHead);
                $data['pending_rfq_data'] = ['title' => 'In-Pipeline / Pending RFQ', 'result' => $pendingRfqData];
            }

            if ($shouldGenerateTaskReport) {
                $taskData = $this->generateTaskReport($isNationalHead);
                $data['task_data'] = ['title' => 'Task', 'result' => $taskData];
            }

            if ($shouldGenerateReminderReport) {
                $reminderData = $this->generateReminderReport($isNationalHead);
                $data['reminder_data'] = ['title' => 'Reminder', 'result' => $reminderData];
            }

            if ($shouldGenerateQuickReport) {
                $quickReportData = $this->generateQuickReport($isNationalHead);
                $data['quick_report_data'] = ['title' => 'Quick Report', 'result' => $quickReportData];
            }

            if ($shouldGenerateVisitReport) {
                $visitData = $this->generateVisitDataReport($isNationalHead);
                $data['visit_data'] = ['title' => 'Visit This Month', 'result' => $visitData];
            }

            if ($shouldGenerateStatisticsReport) {
                $statisticsData = $this->generateStatisticsReport($isNationalHead);
                $data['statistics_data'] = ['title' => 'Statistics', 'result' => $statisticsData];
            }

            if ($shouldGenerateTypeOfClientReport) {
                $typeOfClientData = $this->generateTypeOfClientReport($isNationalHead);
                $data['type_of_client_data'] = ['title' => 'Type of Client', 'result' => $typeOfClientData];
            }

            if ($shouldGenerateIndustryReport) {
                $industryData = $this->generateIndustryReport($isNationalHead);
                $data['industry_data'] = ['title' => 'Industry (RFQs)', 'result' => $industryData];
            }

            if ($shouldGenerateSegmentReport) {
                $segmentData = $this->generateSegmentReport($isNationalHead);
                $data['segment_data'] = ['title' => 'Segment (RFQs)', 'result' => $segmentData];
            }

            if ($shouldGenerateZoneReport) {
                $zoneData = $this->generateZoneReport($isNationalHead);
                $data['zone_data'] = ['title' => 'Zone Wise (Leads)', 'result' => $zoneData];
            }

            if ($shouldGenerateLeadReport) {
                $leadData = $this->generateLeadReport($isNationalHead);
                $data['lead_data'] = ['title' => 'Lead List', 'result' => $leadData, 'color' => [
                    'RawleadColor' => '#fffd08',
                    'PotentialleadColor' => '#04ffff',
                    'ProspectleadColor' => '#4d87e9',
                    'FinalizedleadColor' => '#d0dfe4',
                ]];
            }

            if ($shouldGenerateDayInOutReport) {
                $dayInOutData = $this->generateDayInOutReport($isNationalHead);
                $data['day_in_out_data'] = ['title' => 'Day In / Day Out', 'result' => $dayInOutData];
            }

            $toggleDispatchBtn = false;
            if ($this->isUserDispatch) {
                $toggleDispatchBtn = true;
            }

            $showQuickLink = true;
            if ($this->isUserHr) {
                $showQuickLink = false;
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "New Dashboard Data"]);
            $this->response['data'] = $data;
            $this->response['data']['toggle_dispatch_btn']  = $toggleDispatchBtn;
            $this->response['data']['show_quick_link']  = $showQuickLink;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("New Dashboard Data fetching failed: " . $e);
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function generateBasicCountReport($basicCountReportParams = [], $isNationalHead = false)
    {
        $basicCountResult = [];

        $dates = $this->getFiscalYearDates();
        $fiscalYear = $dates['fiscalYear'];
        $currentMonth = $dates['currentMonth'];

        $juniorUserIds = $this->getJuniorIds(true);
        rsort($juniorUserIds);

        // rfq count
        if (in_array('rfq', $basicCountReportParams)) {
            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);
            $dateColumn = 'rfq_date';

            if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                //From RFQ table
                $rfqFromRfq = Rfq::select('id as rfq_id')->orderBy('id', 'desc');

                $rfqFromRfqThisMonth = clone $rfqFromRfq;
                $rfqFromRfqThisYear = clone $rfqFromRfq;

                $rfqFromRfqThisMonth = $this->applyFiscalMonthScope($rfqFromRfqThisMonth, $fiscalYear, $currentMonth, $dateColumn)->get()->toArray();

                $rfqFromRfqThisYear = $this->applyFiscalYearScope($rfqFromRfqThisYear, $fiscalYear, $dateColumn)->get()->toArray();

                //From Project Logs table
                $rfqFromProjectLogs = ProjectLog::with('rfq')->select('fk_rfq_id as rfq_id')->distinct()->groupBy('fk_rfq_id');
                $rfqFromProjectLogsThisMonth = clone $rfqFromProjectLogs;
                $rfqFromProjectLogsThisYear = clone $rfqFromProjectLogs;

                //THIS WAS BEFORE FISCAL YEAR QUERY
                // $rfqFromProjectLogsThisYear = $rfqFromProjectLogsThisYear->whereHas('rfq', function ($q) {
                //     $q->whereYear('rfq_date', date('Y'));
                // })->get()->pluck('rfq_id')->toArray();

                $rfqFromProjectLogsThisMonth = (clone $rfqFromProjectLogs)
                    ->whereHas('rfq', function ($q) use ($fiscalYear, $currentMonth, $dateColumn) {
                        return $this->applyFiscalMonthScope($q, $fiscalYear, $currentMonth, $dateColumn);
                    })->get()->pluck('rfq_id')->toArray();

                $rfqFromProjectLogsThisYear = (clone $rfqFromProjectLogs)
                    ->whereHas('rfq', function ($q) use ($fiscalYear, $dateColumn) {
                        return $this->applyFiscalYearScope($q, $fiscalYear, $dateColumn);
                    })->get()->pluck('rfq_id')->toArray();

                //Sum up after distinct
                $rfqThisMonth = array_unique(array_column(array_merge($rfqFromRfqThisMonth, $rfqFromProjectLogsThisMonth), 'rfq_id'));
                $rfqThisYear = array_unique(array_column(array_merge($rfqFromRfqThisYear, $rfqFromProjectLogsThisYear), 'rfq_id'));

                $rfqCountThisMonth = RFQ::whereIn('id', $rfqThisMonth)->count();
                $rfqCountThisYear = RFQ::whereIn('id', $rfqThisYear)->count();

                //RFQ Export Count
                $exportRfq = Rfq::select('id as rfq_id')->with(['lead'])
                    ->whereHas('lead', function ($q) {
                        $q->where('is_export', 1);
                    });

                $exportRfqThisMonth = $this->applyFiscalMonthScope(clone $exportRfq, $fiscalYear, $currentMonth, $dateColumn)->pluck('rfq_id')->toArray();
                $exportRfqThisYear = $this->applyFiscalYearScope(clone $exportRfq, $fiscalYear, $dateColumn)->pluck('rfq_id')->toArray();

                $exportRfqThisMonthCount = Rfq::whereIn('id', $exportRfqThisMonth)->count();
                $exportRfqThisYearCount = Rfq::whereIn('id', $exportRfqThisYear)->count();
            } else if ($this->isUserInsideSale || $this->psmUserRole) {
                //From RFQ table
                // $uid = $this->userId;

                $insideSaleDivisions = User::find($this->userId)->division_ids;
                $divisionIdsArray = explode(',', $insideSaleDivisions);

                $rfqFromRfq = Rfq::where(function ($q) use ($divisionIdsArray) {
                    $q->whereIn('division_id', $divisionIdsArray);
                });

                $rfqFromRfqThisMonth = clone $rfqFromRfq;
                $rfqFromRfqThisYear = clone $rfqFromRfq;

                $rfqFromRfqThisMonth = $this->applyFiscalMonthScope($rfqFromRfqThisMonth, $fiscalYear, $currentMonth, $dateColumn)->get()->pluck('id')->toArray();

                $rfqFromRfqThisYear = $this->applyFiscalYearScope($rfqFromRfqThisYear, $fiscalYear, $dateColumn)->get()->pluck('id')->toArray();

                //From Project Logs table
                $rfqFromProjectLogs = ProjectLog::with('rfq')->select('fk_rfq_id as rfq_id')
                    ->where(function ($q) use ($juniorUserIds) {
                        foreach ($juniorUserIds as $key => $value) {
                            $q->orWhereRaw('FIND_IN_SET(?, curr_user_ids)', [$value]);
                        }
                    })
                    ->whereHas('rfq', function ($q) use ($divisionIdsArray) {
                        $q->whereIn('division_id', $divisionIdsArray);
                    })
                    ->distinct()->groupBy('fk_rfq_id');

                $rfqFromProjectLogsThisMonth = clone $rfqFromProjectLogs;
                $rfqFromProjectLogsThisYear = clone $rfqFromProjectLogs;

                $rfqFromProjectLogsThisMonth = $rfqFromProjectLogsThisMonth
                    ->whereHas('rfq', function ($q) use ($fiscalYear, $currentMonth, $dateColumn) {
                        return $this->applyFiscalMonthScope($q, $fiscalYear, $currentMonth, $dateColumn);
                    })->get()->pluck('rfq_id')->toArray();

                $rfqFromProjectLogsThisYear = $rfqFromProjectLogsThisYear
                    ->whereHas('rfq', function ($q) use ($fiscalYear, $dateColumn) {
                        return $this->applyFiscalYearScope($q, $fiscalYear, $dateColumn);
                    })->get()->pluck('rfq_id')->toArray();

                //Sum up after distinct
                $rfqThisMonth = array_unique(array_merge($rfqFromRfqThisMonth, $rfqFromProjectLogsThisMonth));
                $rfqThisYear = array_unique(array_merge($rfqFromRfqThisYear, $rfqFromProjectLogsThisYear));

                $rfqCountThisMonth = RFQ::whereIn('id', $rfqThisMonth)->count();
                $rfqCountThisYear = RFQ::whereIn('id', $rfqThisYear)->count();


                //RFQ Export Count
                $exportRfq = Rfq::select('id as rfq_id')->with(['lead'])
                    ->where(function ($query) use ($divisionIdsArray) {
                        $query->whereIn('division_id', $divisionIdsArray);
                    })
                    ->whereHas('lead', function ($q) {
                        $q->where('is_export', 1);
                    });

                $exportRfqThisMonth = $this->applyFiscalMonthScope(clone $exportRfq, $fiscalYear, $currentMonth, $dateColumn)->pluck('rfq_id')->toArray();
                $exportRfqThisYear = $this->applyFiscalYearScope(clone $exportRfq, $fiscalYear, $dateColumn)->pluck('rfq_id')->toArray();

                $exportRfqThisMonthCount = Rfq::whereIn('id', $exportRfqThisMonth)->count();
                $exportRfqThisYearCount = Rfq::whereIn('id', $exportRfqThisYear)->count();
            } else {
                //From RFQ table
                // $uid = $this->userId;

                $rfqFromRfq = Rfq::where(function ($q) use ($juniorUserIds) {
                    $q->whereIn('created_by', $juniorUserIds)->orWhereIn('rsm_id', $juniorUserIds);
                });


                $rfqFromRfqThisMonth = clone $rfqFromRfq;
                $rfqFromRfqThisYear = clone $rfqFromRfq;

                $rfqFromRfqThisMonth = $this->applyFiscalMonthScope($rfqFromRfqThisMonth, $fiscalYear, $currentMonth, $dateColumn)->get()->pluck('id')->toArray();

                $rfqFromRfqThisYear = $this->applyFiscalYearScope($rfqFromRfqThisYear, $fiscalYear, $dateColumn)->get()->pluck('id')->toArray();

                //From Project Logs table
                $rfqFromProjectLogs = ProjectLog::with('rfq')->select('fk_rfq_id as rfq_id')
                    ->where(function ($q) use ($juniorUserIds) {
                        foreach ($juniorUserIds as $key => $value) {
                            $q->orWhereRaw('FIND_IN_SET(?, curr_user_ids)', [$value]);
                        }
                    })
                    ->distinct()->groupBy('fk_rfq_id');

                $rfqFromProjectLogsThisMonth = clone $rfqFromProjectLogs;
                $rfqFromProjectLogsThisYear = clone $rfqFromProjectLogs;

                $rfqFromProjectLogsThisMonth = $rfqFromProjectLogsThisMonth
                    ->whereHas('rfq', function ($q) use ($fiscalYear, $currentMonth, $dateColumn) {
                        return $this->applyFiscalMonthScope($q, $fiscalYear, $currentMonth, $dateColumn);
                    })->get()->pluck('rfq_id')->toArray();

                $rfqFromProjectLogsThisYear = $rfqFromProjectLogsThisYear
                    ->whereHas('rfq', function ($q) use ($fiscalYear, $dateColumn) {
                        return $this->applyFiscalYearScope($q, $fiscalYear, $dateColumn);
                    })->get()->pluck('rfq_id')->toArray();

                //Sum up after distinct
                $rfqThisMonth = array_unique(array_merge($rfqFromRfqThisMonth, $rfqFromProjectLogsThisMonth));
                $rfqThisYear = array_unique(array_merge($rfqFromRfqThisYear, $rfqFromProjectLogsThisYear));

                $rfqCountThisMonth = RFQ::whereIn('id', $rfqThisMonth)->count();
                $rfqCountThisYear = RFQ::whereIn('id', $rfqThisYear)->count();


                //RFQ Export Count
                $exportRfq = Rfq::select('id as rfq_id')->with(['lead'])
                    ->where(function ($query) use ($juniorUserIds) {
                        $query->whereIn('created_by', $juniorUserIds)->orWhereIn('rsm_id', $juniorUserIds);
                    })
                    ->whereHas('lead', function ($q) {
                        $q->where('is_export', 1);
                    });

                $exportRfqThisMonth = $this->applyFiscalMonthScope(clone $exportRfq, $fiscalYear, $currentMonth, $dateColumn)->pluck('rfq_id')->toArray();
                $exportRfqThisYear = $this->applyFiscalYearScope(clone $exportRfq, $fiscalYear, $dateColumn)->pluck('rfq_id')->toArray();

                $exportRfqThisMonthCount = Rfq::whereIn('id', $exportRfqThisMonth)->count();
                $exportRfqThisYearCount = Rfq::whereIn('id', $exportRfqThisYear)->count();
            }

            $result = ['title' => 'RFQ', 'this_month' => $rfqCountThisMonth, 'this_year' => $rfqCountThisYear];
            $exportResult = ['title' => 'RFQ Export', 'this_month' => $exportRfqThisMonthCount, 'this_year' =>
            $exportRfqThisYearCount];
            $basicCountResult[] = $result;
            $basicCountResult[] = $exportResult;
        }

        //quotation count
        if (in_array('quotation', $basicCountReportParams)) {
            $dateColumn = 'quotation_date';
            if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing) {
                $quotationCount = ProjectQuotationTemp::orderBy('id', 'desc');

                //Export Quotation
                $exportQuotationCount = ProjectQuotationTemp::with(['lead'])
                    ->whereHas('lead', function ($query) {
                        $query->where('is_export', 1);
                    })
                    ->orderBy('id', 'desc');
            } else if ($this->isUserInsideSale || $this->psmUserRole) {
                $insideSaleDivisions = User::find($this->userId)->division_ids;
                $divisionIdsArray = explode(',', $insideSaleDivisions);

                $quotationCount = ProjectQuotationTemp::with('rfq')
                    ->whereHas('rfq', function ($q) use ($divisionIdsArray) {
                        $q->whereIn('division_id', $divisionIdsArray);
                    })
                    ->orderBy('id', 'desc');

                $exportQuotationCount = ProjectQuotationTemp::with(['lead:id,is_export', 'rfq:id,division_id'])
                    ->whereHas('lead', function ($query) {
                        $query->where('is_export', 1);
                    })
                    ->whereHas('rfq', function ($query) use ($divisionIdsArray) {
                        $query->whereIn('division_id', $divisionIdsArray);
                    })
                    ->orderBy('id', 'desc');
            } else {
                if ($this->isUserDispatch) {
                    $quotationCount = ProjectQuotationTemp::with('purchaseOrder')->whereHas('purchaseOrder', function ($query) {
                        $query->whereNotNull('id');
                    })
                        ->orderBy('id', 'desc');

                    $exportQuotationCount = ProjectQuotationTemp::with(['lead:id,is_export', 'purchaseOrder:id'])
                        ->whereHas('purchaseOrder', function ($query) {
                            $query->whereNotNull('id');
                        })
                        ->whereHas('lead', function ($query) {
                            $query->where('is_export', 1);
                        })
                        ->orderBy('id', 'desc');
                }

                // $quotationCount = ProjectQuotationTemp::where('prepared_by', $this->userId)->orderBy('id', 'desc');
                $quotationCount = ProjectQuotationTemp::with('purchaseOrder')->where(function ($q) use ($juniorUserIds) {
                    $q->whereIn('prepared_by', $juniorUserIds);
                    $q->orWhereIn('sales_person', $juniorUserIds);
                });

                $exportQuotationCount = ProjectQuotationTemp::with(['lead:id,is_export', 'purchaseOrder:id'])
                    ->whereHas('purchaseOrder', function ($query) use ($juniorUserIds) {
                        $query->whereIn('prepared_by', $juniorUserIds);
                        $query->orWhereIn('sales_person', $juniorUserIds);
                    })
                    ->whereHas('lead', function ($query) {
                        $query->where('is_export', 1);
                    })
                    ->orderBy('id', 'desc');
            }

            $quotationThisMonth = clone $quotationCount;
            $quotationCountThisMonth = $this->applyFiscalMonthScope($quotationThisMonth, $fiscalYear, $currentMonth, $dateColumn)->count();
            $quotationAmountThisMonth = $this->applyFiscalMonthScope($quotationThisMonth, $fiscalYear, $currentMonth, $dateColumn)->sum('total_basic_value'); //before it was final_amount_in_inr

            $quotationThisYear = clone $quotationCount;
            $quotationCountThisYear = $this->applyFiscalYearScope($quotationThisYear, $fiscalYear, $dateColumn)->count();
            $quotationAmountThisYear = $this->applyFiscalYearScope($quotationThisYear, $fiscalYear, $dateColumn)->sum('total_basic_value');

            //Export Quotation Count
            $exportQtnCountThisMonth = $this->applyFiscalMonthScope($exportQuotationCount, $fiscalYear, $currentMonth, $dateColumn)->count();
            $exportQtnAmountThisMonth = $this->applyFiscalMonthScope($exportQuotationCount, $fiscalYear, $currentMonth, $dateColumn)->sum('total_basic_value'); //before it was final_amount_in_inr

            $exportQtnCountThisYear = $this->applyFiscalYearScope($exportQuotationCount, $fiscalYear, $dateColumn)->count();
            $exportQtnAmountThisYear = $this->applyFiscalYearScope($exportQuotationCount, $fiscalYear, $dateColumn)->sum('total_basic_value'); //before it was final_amount_in_inr


            $result = ['title' => 'Quotation', 'this_month' => $quotationCountThisMonth, 'this_year' => $quotationCountThisYear, 'this_month_amount' => 'INR ' . formatIndianRupees($quotationAmountThisMonth, 2), 'this_year_amount' => 'INR ' . formatIndianRupees($quotationAmountThisYear, 2)];

            //Export Quotation Count
            $exportQtnResult = ['title' => 'Export Quotation', 'this_month' => $exportQtnCountThisMonth, 'this_year' => $exportQtnCountThisYear, 'this_month_amount' => 'INR ' . formatIndianRupees($exportQtnAmountThisMonth, 2), 'this_year_amount' => 'INR ' . formatIndianRupees($exportQtnAmountThisYear, 2)];
            $basicCountResult[] = $result;
            $basicCountResult[] = $exportQtnResult;
        }

        //po count
        if (in_array('po', $basicCountReportParams)) {
            // Determine the base query depending on the user's role
            $dateColumn = 'po_date';
            if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $poCount = PurchaseOrder::whereHas('rfq', function ($q) {
                    $q->whereNotNull('id');
                })
                    ->whereHas('lead', function ($q) {
                        $q->whereNotNull('id');
                    })
                    ->where('po_type', 1)->orderBy('id', 'desc');

                //Export PO
                $exportPoCount = PurchaseOrder::with(['lead:id,is_export', 'rfq:id'])
                    ->whereHas('rfq', function ($q) {
                        $q->whereNotNull('id');
                    })
                    ->whereHas('lead', function ($q) {
                        $q->whereNotNull('id');
                        $q->where('is_export', 1);
                    })
                    ->where('po_type', 1)->orderBy('id', 'desc');
            } elseif ($this->isUserInsideSale || $this->psmUserRole) {
                $insideSaleDivisions = User::find($this->userId)->division_ids;
                $divisionIdsArray = explode(',', $insideSaleDivisions);

                $poCount = PurchaseOrder::whereHas('rfq', function ($query) use ($divisionIdsArray) {
                    $query->whereNotNull('id');
                    $query->whereIn('division_id', $divisionIdsArray);
                })
                    ->whereHas('lead', function ($q) {
                        $q->whereNotNull('id');
                    })
                    ->where('po_type', 1)->orderBy('id', 'desc');

                //Export PO Count
                $exportPoCount = PurchaseOrder::with(['lead:id,is_export', 'rfq:id,division_id'])
                    ->whereHas('rfq', function ($q) use ($divisionIdsArray) {
                        $q->whereNotNull('id');
                        $q->whereIn('division_id', $divisionIdsArray);
                    })
                    ->whereHas('lead', function ($q) {
                        $q->whereNotNull('id');
                        $q->where('is_export', 1);
                    })
                    ->where('po_type', 1)->orderBy('id', 'desc');
            } else {

                $poCount = PurchaseOrder::where(function ($query) use ($juniorUserIds) {
                    $query->where('prepared_by', $this->userId)
                        ->orWhere(function ($q) use ($juniorUserIds) {
                            $q->whereIn('prepared_by', $juniorUserIds);
                        })
                        ->orWhereHas('lead', function ($q) {
                            $q->where('created_by', $this->userId)->whereNotNull('id');
                        })
                        ->orWhereHas('rfq', function ($q) {
                            $q->where('created_by', $this->userId)->whereNotNull('id');
                            $q->orWhere('rsm_id', $this->userId)->whereNotNull('id');
                        });
                })->where('po_type', 1)->orderBy('id', 'desc');

                //Export PO Count
                $exportPoCount = PurchaseOrder::with([
                    'lead:id,is_export',
                    'rfq:id,division_id',
                ])
                    ->where('po_type', 1)
                    ->whereHas('lead', fn($q) => $q->where('is_export', 1))
                    ->where(function ($query) use ($juniorUserIds) {
                        $query->where('prepared_by', $this->userId)
                            ->orWhereIn('prepared_by', $juniorUserIds)
                            ->orWhereHas(
                                'lead',
                                fn($q) =>
                                $q->where('created_by', $this->userId)
                            )
                            ->orWhereHas(
                                'rfq',
                                fn($q) =>
                                $q->where('created_by', $this->userId)
                                    ->orWhere('rsm_id', $this->userId)
                            );
                    })
                    ->orderByDesc('id');
            }

            // Clone the query and filter for the current month and year
            $poCountThisMonthQuery = clone $poCount;

            $poCountThisMonth = $this->applyFiscalMonthScope($poCountThisMonthQuery, $fiscalYear, $currentMonth, $dateColumn)->count();
            $poAmountThisMonth = $this->applyFiscalMonthScope($poCountThisMonthQuery, $fiscalYear, $currentMonth, $dateColumn)->sum('total_basic_value'); //before it was final_amount_in_inr

            //Export Po count
            $exportPoCountThisMonth = $this->applyFiscalMonthScope($exportPoCount, $fiscalYear, $currentMonth, $dateColumn)->count();
            $exportPoAmountThisMonth = $this->applyFiscalMonthScope($exportPoCount, $fiscalYear, $currentMonth, $dateColumn)->sum('total_basic_value'); //before it was final_amount_in_inr

            // Clone the query and filter for the current year
            $poCountThisYearQuery = clone $poCount;
            $poCountThisYear = $this->applyFiscalYearScope($poCountThisYearQuery, $fiscalYear, $dateColumn)->count();
            $poAmountThisYear = $this->applyFiscalYearScope($poCountThisYearQuery, $fiscalYear, $dateColumn)->sum('total_basic_value'); //before it was final_amount_in_inr

            $exportPoCountThisYear = $this->applyFiscalYearScope($exportPoCount, $fiscalYear, $dateColumn)->count();
            $exportPoAmountThisYear = $this->applyFiscalYearScope($exportPoCount, $fiscalYear, $dateColumn)->sum('total_basic_value'); //before it was final_amount_in_inr

            $result = ['title' => 'Purchase Order', 'this_month' => $poCountThisMonth, 'this_year' => $poCountThisYear, 'this_month_amount' => 'INR ' . formatIndianRupees($poAmountThisMonth, 2), 'this_year_amount' => 'INR ' . formatIndianRupees($poAmountThisYear, 2)];

            $exportPoResult = ['title' => 'Export Purchase Order', 'this_month' => $exportPoCountThisMonth, 'this_year' => $exportPoCountThisYear, 'this_month_amount' => 'INR ' . formatIndianRupees($exportPoAmountThisMonth, 2), 'this_year_amount' => 'INR ' . formatIndianRupees($exportPoAmountThisYear, 2)];


            $basicCountResult[] = $result;
            $basicCountResult[] = $exportPoResult;
        }

        if (in_array('svr', $basicCountReportParams)) {

            $dateColumn = 'visit_date';
            $currUser = User::find($this->userId);
            $divisionIds = explode(',', $currUser->division_ids);

            if ($this->isMarketing || $this->isManagement) {
                $svr = SalesVisitReport::orderBy('id', 'desc');
            } else {
                $svr = SalesVisitReport::with('division')->whereIn('created_by', $juniorUserIds);
            }

            $svrThisMonth = clone $svr;
            $svrThisMonth = $this->applyFiscalMonthScope($svrThisMonth, $fiscalYear, $currentMonth, $dateColumn)->count();

            $svrThisYear = clone $svr;
            $svrThisYear = $this->applyFiscalYearScope($svrThisYear, $fiscalYear, $dateColumn)->count();

            $result = ['title' => 'Sales Visits', 'this_month' => $svrThisMonth, 'this_year' => $svrThisYear];
            $basicCountResult[] = $result;
        }


        //invoice count
        // if (in_array('invoice', $basicCountReportParams)) {
        //     if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        //         $invoiceCount = PurchaseInvoice::orderBy('id', 'desc');
        //     } else {
        //         $invoiceCount = PurchaseInvoice::where('created_by', $this->userId)->orderBy('id', 'desc');
        //     }

        //     $invoiceCountThisMonth = clone $invoiceCount;
        //     $invoiceCountThisMonth = $invoiceCountThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();

        //     $invoiceCountThisYear = clone $invoiceCount;
        //     $invoiceCountThisYear = $invoiceCountThisYear->whereYear('updated_at', date('Y'))->count();


        //     $result = ['title' => 'Invoice', 'this_month' => $invoiceCountThisMonth, 'this_year' => $invoiceCountThisYear];
        //     $basicCountResult[] = $result;
        // }

        if (in_array('sales_order', $basicCountReportParams)) {
            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);
            $dateColumn = 'so_date';

            if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $invoiceCount = AvlockSalesOrder::where('po_type', 1)->orderBy('id', 'desc');
            } else {
                $invoiceCount = AvlockSalesOrder::where(function ($query) use ($juniorUserIds) {
                    $query->where('created_by', $this->userId)
                        ->orWhere(function ($q) use ($juniorUserIds) {
                            $q->whereIn('created_by', $juniorUserIds);
                        });
                })->where('po_type', 1)->orderBy('id', 'desc');
            }

            $invoiceCountThisMonth = clone $invoiceCount;
            $invoiceCountThisMonth = $this->applyFiscalMonthScope($invoiceCountThisMonth, $fiscalYear, $currentMonth, $dateColumn)->count();

            $invoiceCountThisYear = clone $invoiceCount;
            $invoiceCountThisYear = $this->applyFiscalYearScope($invoiceCountThisYear, $fiscalYear, $dateColumn)->count();

            $result = ['title' => 'Sales Order', 'this_month' => $invoiceCountThisMonth, 'this_year' => $invoiceCountThisYear];
            $basicCountResult[] = $result;
        }

        if (in_array('dispatch', $basicCountReportParams)) {
            $dateColumn = 'despatch_date';
            $invoiceCount = PoDespatchDetail::where('po_type', 1)->orderBy('id', 'desc');

            $invoiceCountThisMonth = clone $invoiceCount;
            $invoiceCountThisMonth = $this->applyFiscalMonthScope($invoiceCountThisMonth, $fiscalYear, $currentMonth, $dateColumn)->count();

            $invoiceCountThisYear = clone $invoiceCount;
            $invoiceCountThisYear = $this->applyFiscalYearScope($invoiceCountThisYear, $fiscalYear, $dateColumn)->count();

            $result = ['title' => 'Dispatch', 'this_month' => $invoiceCountThisMonth, 'this_year' => $invoiceCountThisYear];
            $basicCountResult[] = $result;
        }

        if (in_array('today_dispatch', $basicCountReportParams)) {

            $invoiceCount = PoDespatchDetail::where('po_type', 1)->orderBy('id', 'desc');

            $invoiceCount = clone $invoiceCount;
            $invoiceCount = $invoiceCount->whereDate('despatch_date', Carbon::today())->count();

            $result = ['title' => 'Todays Dispatch', 'this_month' => $invoiceCount];
            $basicCountResult[] = $result;
        }

        if (in_array('delivered_dispatch', $basicCountReportParams)) {

            $dateColumn = 'dc_date';
            $dcCount = DeliveryConfirmation::where('po_type', 1)->with('so')->orderBy('id', 'desc');
            $dcCountThisMonth = clone $dcCount;
            $dcCountThisMonth = $this->applyFiscalMonthScope($dcCountThisMonth, $fiscalYear, $currentMonth, $dateColumn)->count();

            $dcCountThisYear = clone $dcCount;
            $dcCountThisYear = $this->applyFiscalYearScope($dcCountThisYear, $fiscalYear, $dateColumn)->count();
            $result = ['title' => 'Delivered Despatch', 'this_month' => $dcCountThisMonth, 'this_year' => $dcCountThisYear];
            $basicCountResult[] = $result;
        }

        if (in_array('sampling', $basicCountReportParams)) {

            $dateColumn = 'created_at';
            $samplingCount = ProjectSampling::orderBy('id', 'desc');
            $samplingCountThisMonth = clone $samplingCount;
            $samplingCountThisMonth = $this->applyFiscalMonthScope($samplingCountThisMonth, $fiscalYear, $currentMonth, $dateColumn)->count();

            $samplingCountThisYear = clone $samplingCount;
            $samplingCountThisYear = $this->applyFiscalYearScope($samplingCountThisYear, $fiscalYear, $dateColumn)->count();
            $result = ['title' => 'Project Sampling', 'this_month' => $samplingCountThisMonth, 'this_year' => $samplingCountThisYear];
            $basicCountResult[] = $result;
        }

        if (in_array('delivery_updates', $basicCountReportParams)) {

            $dateColumn = 'created_at';
            $samplingCount = ProjectSamplingDeliveryUpdate::orderBy('id', 'desc');
            $samplingCountThisMonth = clone $samplingCount;
            $samplingCountThisMonth = $this->applyFiscalMonthScope($samplingCountThisMonth, $fiscalYear, $currentMonth, $dateColumn)->count();

            $samplingCountThisYear = clone $samplingCount;
            $samplingCountThisYear = $this->applyFiscalYearScope($samplingCountThisYear, $fiscalYear, $dateColumn)->count();
            $result = ['title' => 'Delivery Updates', 'this_month' => $samplingCountThisMonth, 'this_year' => $samplingCountThisYear];
            $basicCountResult[] = $result;
        }

        if (in_array('pdr_qualities', $basicCountReportParams)) {

            $dateColumn = 'created_at';
            $samplingCount = ProjectSamplingPdrQuality::orderBy('id', 'desc');
            $samplingCountThisMonth = clone $samplingCount;
            $samplingCountThisMonth = $this->applyFiscalMonthScope($samplingCountThisMonth, $fiscalYear, $currentMonth, $dateColumn)->count();

            $samplingCountThisYear = clone $samplingCount;
            $samplingCountThisYear = $this->applyFiscalYearScope($samplingCountThisYear, $fiscalYear, $dateColumn)->count();
            $result = ['title' => 'PDR Quality', 'this_month' => $samplingCountThisMonth, 'this_year' => $samplingCountThisYear];
            $basicCountResult[] = $result;
        }

        if (in_array('purchase_invoice', $basicCountReportParams)) {

            $dateColumn = 'created_at';
            $samplingCount = ProjectSamplingPurchaseInvoice::orderBy('id', 'desc');
            $samplingCountThisMonth = clone $samplingCount;
            $samplingCountThisMonth = $this->applyFiscalMonthScope($samplingCountThisMonth, $fiscalYear, $currentMonth, $dateColumn)->count();

            $samplingCountThisYear = clone $samplingCount;
            $samplingCountThisYear = $this->applyFiscalYearScope($samplingCountThisYear, $fiscalYear, $dateColumn)->count();
            $result = ['title' => 'Purchase Invoice', 'this_month' => $samplingCountThisMonth, 'this_year' => $samplingCountThisYear];
            $basicCountResult[] = $result;
        }

        //open_rfq count
        if (in_array('rfq', $basicCountReportParams) && in_array('closed_rfq', $basicCountReportParams) && in_array('open_rfq', $basicCountReportParams)) {
            $totalRfqsThisMonth = 0;
            $totalRfqsThisYear = 0;

            foreach ($basicCountResult as $bcr) {
                if ($bcr['title'] == 'RFQ') {
                    $totalRfqsThisMonth = $bcr['this_month'];
                    $totalRfqsThisYear = $bcr['this_year'];
                }
            }

            if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $closedRfq = ProjectLog::where('curr_sub_stage_id', $this->deliverySubStageId)->distinct()->groupBy('fk_rfq_id');
                $closedRfqThisMonth = clone $closedRfq;
                $closedRfqThisYear = clone $closedRfq;

                $closedRfqThisMonth = $closedRfqThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
                $closedRfqThisYear = $closedRfqThisYear->whereYear('updated_at', date('Y'))->count();
            } else {
                $closedRfq = ProjectLog::where('curr_sub_stage_id', $this->deliverySubStageId)->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])->distinct()->groupBy('fk_rfq_id');
                $closedRfqThisMonth = clone $closedRfq;
                $closedRfqThisYear = clone $closedRfq;

                $closedRfqThisMonth = $closedRfqThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
                $closedRfqThisYear = $closedRfqThisYear->whereYear('updated_at', date('Y'))->count();
            }

            $result = ['title' => 'Closed RFQ', 'this_month' => $closedRfqThisMonth, 'this_year' => $closedRfqThisYear];
            // $basicCountResult[] = $result;

            $result = ['title' => 'Open RFQ', 'this_month' => (int)$totalRfqsThisMonth - (int)$closedRfqThisMonth, 'this_year' => $totalRfqsThisYear - $closedRfqThisYear];
            // $basicCountResult[] = $result;
        }

        //pdr count
        // if (in_array('pdr', $basicCountReportParams)) {
        //     if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        //         $pdrCount = PurchaseOrderPdrQuality::orderBy('id', 'desc');
        //     } else {
        //         $pdrCount = PurchaseOrderPdrQuality::where('created_by', $this->userId)->orderBy('id', 'desc');
        //     }

        //     $pdrCountThisMonth = clone $pdrCount;
        //     $pdrCountThisYear = clone $pdrCount;

        //     $pdrCountThisMonth = $pdrCountThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
        //     $pdrCountThisYear = $pdrCountThisYear->whereYear('updated_at', date('Y'))->count();

        //     $result = ['title' => 'PDR', 'this_month' => $pdrCountThisMonth, 'this_year' => $pdrCountThisYear];
        //     $basicCountResult[] = $result;
        // }

        //delivery_note count
        // if (in_array('delivery_note', $basicCountReportParams)) {
        //     if ($isNationalHead || $this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
        //         $dnCount = PurchaseOrderDneInvoice::orderBy('id', 'desc');
        //     } else {
        //         $dnCount = PurchaseOrderDneInvoice::where('created_by', $this->userId)->orderBy('id', 'desc');
        //     }

        //     $dnCountThisMonth = clone $dnCount;
        //     $dnCountThisYear = clone $dnCount;

        //     $dnCountThisMonth = $dnCountThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->count();
        //     $dnCountThisYear = $dnCountThisYear->whereYear('updated_at', date('Y'))->count();

        //     $result = ['title' => 'Delivery Note', 'this_month' => $dnCountThisMonth, 'this_year' => $dnCountThisYear];
        //     $basicCountResult[] = $result;
        // }

        return $basicCountResult;
    }

    public function rfqList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $rfqNumber = $request->rfq_number ?? "";
            $rfqType = $request->tab ?? "";
            $rsmName = $request->rsm_name ?? "";
            $company = preg_replace('/\s+/', ' ', $request->company) ?? '';
            $customerName = $request->customer_name ?? "";
            $isExportLead = $request->is_export_lead ?? "";
            $startDate = $request->start_date ?? "";
            $endDate = $request->end_date ?? "";
            $divisionId = $request->division_id ?? "";
            $productId = $request->product_id ?? "";
            $partId = $request->part_no_id ?? "";
            $regionId = $request->region_id ?? "";
            $subStageId = $request->current_stage_id ?? "";
            $isExport = $request->is_export ?? 0;
            $dateRange = strtolower($request->date_range);

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'rfq_date';


            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $rfqFromRfq = Rfq::select('id')->orderBy('updated_at', 'desc');
                $rfqFromProjectLogs = ProjectLog::with('rfq')->select('fk_rfq_id as id')->distinct()->groupBy('fk_rfq_id');
            } elseif ($this->isUserInsideSale || $this->psmUserRole) {
                $insideSaleDivisions = User::find($this->userId)->division_ids;
                $divisionIdsArray = explode(',', $insideSaleDivisions);

                $rfqFromRfq = Rfq::where(function ($q) use ($divisionIdsArray) {
                    $q->whereIn('division_id', $divisionIdsArray);
                })
                    ->orderBy('updated_at', 'desc');

                $rfqFromProjectLogs = ProjectLog::with('rfq')
                    ->select('fk_rfq_id as id')
                    ->whereHas('rfq', function ($q) use ($divisionIdsArray) {
                        $q->whereIn('division_id', $divisionIdsArray);
                    })
                    ->distinct()
                    ->groupBy('fk_rfq_id');
            } else {
                $rfqFromRfq = Rfq::select('id')->where(function ($query) use ($juniorUserIds) {
                    $query->whereIn('rsm_id', $juniorUserIds)
                        ->orWhereIn('created_by', $juniorUserIds);
                });

                $rfqFromProjectLogs = ProjectLog::with('rfq')->select('fk_rfq_id as id')
                    ->where(function ($q) use ($juniorUserIds) {
                        foreach ($juniorUserIds as $key => $value) {
                            $q->orWhereRaw('FIND_IN_SET(?, curr_user_ids)', [$value]);
                        }
                    })
                    ->distinct()->groupBy('fk_rfq_id');
            }

            $rfqCount = $this->getRfqCount($rfqFromRfq, $rfqFromProjectLogs);
            $rfqList = $this->getRfqList($rfqCount);

            if ($rfqNumber) {
                $rfqList->where('rfq_number', 'like', "%" . $rfqNumber . "%");
            }

            if ($divisionId) {
                $rfqList->where('division_id', $divisionId);
            }

            if ($rsmName) {
                $rfqList->where('assigned_rsm',  $rsmName);
            }

            if ($productId) {
                $rfqList->whereHas('products', function ($query) use ($productId) {
                    $query->where('product_id', $productId);
                });
            }

            if ($partId) {
                $rfqList->whereHas('products.productPart', function ($query) use ($partId) {
                    $query->where('id', $partId);
                });
            }


            if ($company) {
                $rfqList->whereHas('lead', function ($query) use ($company) {
                    $query->where('company', 'like', '%' . $company . '%');
                });
            }

            if ($subStageId) {
                $rfqList->where('curr_sub_stage_id', $subStageId);
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $rfqList->whereDate('rfq_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $rfqList->whereDate('rfq_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $rfqList->whereDate('rfq_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $rfqList->whereDate('rfq_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $rfqList->whereDate('rfq_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $rfqList->whereDate('rfq_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $rfqList->whereDate('rfq_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $rfqList->whereDate('rfq_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $rfqList->whereMonth('rfq_date', date('m'))->whereYear('rfq_date', date('Y'));
                }

                if ($dateRange == 'last_month') {
                    $rfqList->whereMonth('rfq_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('rfq_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $rfqList->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $rfqList->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear - 1)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }


                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $rfqList->whereDate('rfq_date', '>=', $startDate);

                        if ($endDate) {
                            $rfqList->whereDate('rfq_date', '<=', $endDate);
                        }
                    }
                }
            }

            if ($customerName) {
                $rfqList->whereHas('lead', function ($query) use ($customerName) {
                    $query->where('customer_name', 'like', '%' . $customerName . '%');
                });
            }

            if ($isExportLead) {
                $rfqList->whereHas('lead', function ($query) use ($isExportLead) {
                    $query->where('is_export', $isExportLead);
                });
            }

            if ($regionId) {
                $rfqList->whereHas('lead', function ($query) use ($regionId) {
                    $query->where('fk_region_id', $regionId);
                });
            }

            $num_rows = $rfqList->count();
            $total_pages = ceil($num_rows / $per_page);

            if ($isExport == 1) {
                $rfqList = $rfqList->get();
            } else {
                $rfqList = $rfqList->limit($per_page)->offset($offset)->get();
            }

            if ($isExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                $headers = ['RFQ No', 'RFQ Date', 'Division', 'Company Name', 'Address 1', 'Address 2', 'City', 'State', 'Pincode', 'Contact Person Name', 'Contact Person Designation', 'Contact Person Email', 'Contact Person Phone', 'Product Name', 'Part No.', 'Product Description (Avlock)', 'RSM', 'Updated At', 'Source', 'Verified?', 'Current Stage'];
                $sheetData = [$headers];

                foreach ($rfqList as $item) {
                    $industryString = '';
                    $industry = json_decode($item->industry, true);
                    if (!is_null($industry)) {
                        foreach ($industry as $key => $ind) {
                            $industryString .= isset($ind['name']) ? ($key + 1) . ". {$ind['name']}\n" : '';
                        }
                    }


                    $source = isset($item->source) ? $item->source->name : '';
                    $sourceVerified = isset($item->source) && $item->is_source_verified == 1 ? 'Yes' : 'No';

                    $designations = $item->lead->designations ?? [];

                    if (is_string($designations)) {
                        $designationIds = explode(',', $designations);
                    } elseif (is_array($designations)) {
                        $designationIds = $designations;
                    } else {
                        $designationIds = [];
                    }

                    $designationIds = array_map('trim', $designationIds);
                    $designationIds = array_filter($designationIds);

                    if (!empty($designationIds)) {
                        $designationNames = LeadDesignation::whereIn('id', $designationIds)->pluck('name')->implode(', ');
                    } else {
                        $designationNames = '';
                    }

                    $baseRowData = [
                        $item->rfq_number,
                        Carbon::parse($item->rfq_date)->format('d/m/y'),
                        isset($item->division) ? $item->division->name : '',
                        isset($item->lead) ? $item->lead->company : '',
                        $item->address1 ?? '',
                        $item->address2 ?? '',
                        $item->city ?? '',
                        $item->state ?? '',
                        $item->pincode ?? '',
                        $item->customer_name,
                        $designationNames ?? '',
                        $item->email ?? '',
                        $item->contact_no ?? '',
                        '', // Placeholder for Product Name
                        '', // Placeholder for Part No
                        '', // Placeholder for Product Description
                        $item->rsm_name,
                        Carbon::parse($item->updated_at)->format('d/m/y'),
                        $source,
                        $sourceVerified,
                        isset($item->subStage) ? $item->subStage->name : '',
                    ];

                    if (!is_null($item->products) && count($item->products) > 0) {
                        foreach ($item->products as $key => $pro) {
                            $rowData = $baseRowData;
                            $productName = isset($pro->product->product_name) ? $pro->product->product_name : '';
                            $proDescription = isset($pro->product->short_description) ? $pro->product->short_description : '';
                            $partNo = isset($pro->productPart->part_no) ? $pro->productPart->part_no : '';
                            $rowData[13] = $productName;
                            $rowData[14] = $partNo;
                            $rowData[15] = $proDescription;
                            $sheetData[] = $rowData;

                            // if ($key < count($item->products) - 1) {
                            //   $baseRowData = array_fill(0, count($baseRowData), '');
                            // }
                        }
                    } else {
                        $sheetData[] = $baseRowData;
                    }
                }

                $sheet->fromArray($sheetData, null, 'A1');
                $store = "storage/app/public/uploads/rfq/rfq_$rfqType.csv";
                $filePath = "storage/uploads/rfq/rfq_$rfqType.csv";
                $writer = new Csv($spreadsheet);
                $writer->save($store);
            }

            $showModal = false;
            if ($this->isMarketing) {
                $showModal = true;
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Rfq Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['filePath'] = $filePath ?? '';
            $this->response['data']['total_pages'] = $total_pages;
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['rfq_number'] = $rfqNumber;
            $this->response['data']['rsm_name'] = $rsmName;
            $this->response['data']['company'] = $company;
            $this->response['data']['current_stage_id'] = $subStageId;
            $this->response['data']['customer_name'] = $customerName;
            $this->response['data']['division_id'] = $divisionId;
            $this->response['data']['is_export_lead'] = $isExportLead;
            $this->response['data']['product_id'] = $productId;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['region_id'] = $regionId;
            $this->response['data']['show_modal'] = $showModal;
            $this->response['data']['list'] = $rfqList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Rfq Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    private function getRfqCount($queryBuilder, $queryPro)
    {
        $rfq = $queryBuilder->get()->pluck('id')->toArray();
        $project = $queryPro->whereHas('rfq')->get()->pluck('id')->toArray();
        return array_unique(array_merge($rfq, $project));
    }


    // private function getRfqCount($queryBuilder, $queryPro, $timeFrame)
    // {
    //     $queryBuilderClone = clone $queryBuilder;

    //     if ($timeFrame === 'thisMonth') {

    //         $rfq = $queryBuilderClone->whereYear('rfq_date', date('Y'))->whereMonth('rfq_date', date('m'))->get()->pluck('id')->toArray();
    //         $project = $queryPro->whereHas('rfq', function ($q) {
    //             $q->whereYear('rfq_date', date('Y'))->whereMonth('rfq_date', date('m'));
    //         })
    //             ->get()->pluck('id')->toArray();

    //         $rfqThisMonth = array_unique(array_merge($rfq, $project));
    //         return $rfqThisMonth;
    //     } elseif ($timeFrame === 'thisYear') {
    //         $rfq = $queryBuilderClone->whereYear('rfq_date', date('Y'))->get()->pluck('id')->toArray();
    //         $project = $queryPro->whereHas('rfq', function ($q) {
    //             $q->whereYear('rfq_date', date('Y'));
    //         })
    //             ->get()->pluck('id')->toArray();

    //         $rfqThisYear = array_unique(array_merge($rfq, $project));
    //         return $rfqThisYear;
    //     }

    //     return [];
    // }

    private function getRfqList($rfqIds)
    {
        $query = RFQ::with('subStage:id,name', 'designation:id,name', 'source:id,name', 'division:id,name', 'products.product', 'products.productPart', 'lead')
            ->whereIn('id', $rfqIds)
            ->orderBy('created_at', 'desc');

        return $query;
    }


    public function purchaseOrderList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $poType = $request->tab ?? '';
            $company = preg_replace('/\s+/', ' ', $request->company) ?? '';
            $rsmId = $request->rsm_id ?? '';
            $purchaseOrderNo = $request->po_no ?? '';
            $divisionId = $request->division_id ?? '';
            $productId = $request->product_id ?? '';
            $partId = $request->part_no_id ?? '';
            $regionId = $request->region_id ?? '';
            $isExportLead = $request->is_export_lead ?? '';
            $startDate = $request->start_date ?? "";
            $endDate = $request->end_date ?? "";
            $currSubStageId = $request->current_stage_id ?? "";
            $highValue = $request->high_value ?? "";
            $isExport = $request->is_export;
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'po_date';


            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $po = PurchaseOrder::with(['preparedBy', 'poDespatchDetail.so', 'lead', 'rfq', 'rfq.currencyData', 'subStage:id,name', 'updatedBy:id,name', 'quotation:id,quotation_no', 'poType'])
                    ->whereHas('rfq', function ($q) {
                        $q->whereNotNull('id');
                    })
                    ->whereHas('lead', function ($q) {
                        $q->whereNotNull('id');
                    })
                    ->where('po_type', 1)
                    ->orderBy('updated_at', 'desc');
            } elseif ($this->isUserInsideSale || $this->psmUserRole) {
                $insideSaleDivisions = User::find($this->userId)->division_ids;
                $divisionIdsArray = explode(',', $insideSaleDivisions);

                $this->response['data']['dids'] = $divisionIdsArray;

                $po = PurchaseOrder::with(['preparedBy', 'poDespatchDetail', 'rfq.source', 'lead', 'rfq', 'rfq.currencyData', 'subStage:id,name', 'updatedBy:id,name', 'quotation:id,quotation_no', 'poType'])
                    ->whereHas('rfq', function ($q) use ($divisionIdsArray) {
                        $q->whereNotNull('id');
                        $q->whereIn('division_id', $divisionIdsArray);
                    })
                    ->whereHas('lead', function ($q) {
                        $q->whereNotNull('id');
                    })
                    ->where('po_type', 1)->orderBy('updated_at', 'desc');
            } else {
                $po = PurchaseOrder::with(['preparedBy', 'poDespatchDetail', 'lead', 'rfq', 'rfq.currencyData', 'subStage:id,name', 'updatedBy:id,name', 'quotation:id,quotation_no', 'poType'])
                    ->where(function ($query) use ($juniorUserIds) {
                        $query->where(function ($subQuery) use ($juniorUserIds) {
                            $subQuery->where('prepared_by', $this->userId);
                            $subQuery->orWhereIn('prepared_by', $juniorUserIds);
                        });
                        $query->orWhereHas('lead', function ($q) {
                            $q->where('created_by', $this->userId)->whereNotNull('id');
                        });
                        $query->orWhereHas('rfq', function ($q) {
                            $q->where('created_by', $this->userId)->whereNotNull('id');
                            $q->orWhere('rsm_id', $this->userId)->whereNotNull('id');
                        });
                    })
                    ->where('po_type', 1)
                    ->orderBy('updated_at', 'desc');
            }

            if ($company) {
                $po->whereHas('lead', function ($query) use ($company) {
                    $query->where('company', $company);
                });
            }

            if ($isExportLead) {
                $po->whereHas('lead', function ($query) use ($isExportLead) {
                    $query->where('is_export', $isExportLead);
                });
            }

            if ($productId) {
                $po->whereRaw("JSON_SEARCH(JSON_EXTRACT(po_details, '$[*].product_id'), 'one', ?) IS NOT NULL", [$productId]);
            }

            if ($partId) {
                $po->whereRaw(
                    "JSON_CONTAINS(po_details, ?)",
                    [json_encode(['part_noId' => (int)$partId])]
                );
            }

            if ($currSubStageId) {
                $po->where('curr_sub_stage_id', $currSubStageId);
            }

            if ($highValue === 'below_5_lakh') {
                $po->where('total_basic_value', '<=', 500000);
            } elseif ($highValue === 'above_5_lakh') {
                $po->where('total_basic_value', '>', 500000);
            } elseif ($highValue === 'above_10_lakh') {
                $po->where('total_basic_value', '>', 1000000);
            } elseif ($highValue === 'above_20_lakh') {
                $po->where('total_basic_value', '>', 2000000);
            }

            if ($regionId) {
                $po->whereHas('lead', function ($query) use ($regionId) {
                    $query->where('fk_region_id', $regionId);
                });
            }

            if ($rsmId) {
                $po->whereHas('rfq', function ($query) use ($rsmId) {
                    $query->where('rsm_id', $rsmId);
                });
            }

            if ($divisionId) {
                $po->whereHas('rfq', function ($query) use ($divisionId) {
                    $query->where('division_id', $divisionId)
                        ->whereNotNull('division_id');
                });
            }

            if ($purchaseOrderNo) {
                $po->where('po_no', 'like', '%' . $purchaseOrderNo . '%');
            }


            if ($dateRange) {
                if ($dateRange == 'today') {
                    $po->whereDate('po_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $po->whereDate('po_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $po->whereDate('po_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $po->whereDate('po_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $po->whereDate('po_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $po->whereDate('po_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $po->whereDate('po_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $po->whereDate('po_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $po->whereMonth('po_date', date('m'))->whereYear('po_date', date('Y'));
                }

                if ($dateRange == 'last_month') {
                    $po->whereMonth('po_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('po_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $po->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $po->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $po->whereDate('po_date', '>=', $startDate);

                        if ($endDate) {
                            $po->whereDate('po_date', '<=', $endDate);
                        }
                    }
                }
            }

            $sumQuery = clone $po;
            $totalFinalAmount = $sumQuery->sum('total_basic_value');

            $num_rows = $po->count();
            if ($isExport == 1) {
                $poList = $po->get();
            } else {
                $poList = $po->limit($per_page)->offset($offset)->get();
            }

            if ($isExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                $headers = ['PO No', 'Quotation No', 'RFQ No', 'Division', 'PO Date', 'Company', 'Source', 'Product', 'Part No', 'Qty', 'Rate', 'Currency', 'PO Value', 'PO Type', 'Updated By', 'RSM', 'Current Stage'];
                $sheetData = [$headers];

                foreach ($poList as $item) {
                    $quotationNo = isset($item->quotation) ? $item->quotation->quotation_no : '';
                    $company = isset($item->lead) ? $item->lead->company : '';
                    $poType = isset($item->poType) ? $item->poType->title : '';
                    $updatedBy = isset($item->updatedBy) ? $item->updatedBy->name : '';
                    $rsmName = isset($item->rfq) ? $item->rfq->rsm_name : '';
                    $source = (isset($item->rfq) && isset($item->rfq->source)) ? $item->rfq->source->name : '';
                    $divisionName = isset($item->rfq) ? ($item->rfq->division->name ?? '') : '';
                    $rfqNo = isset($item->rfq) ? $item->rfq->rfq_number : '';
                    $subStage = isset($item->subStage) ? $item->subStage->name : '';
                    $products = isset($item->po_details) ? json_decode($item->po_details) : [];
                    $services = isset($item->service_details) ? json_decode($item->service_details) : [];

                    $baseRowData = [
                        $item->po_no ?? '',
                        $quotationNo,
                        $rfqNo,
                        $divisionName,
                        Carbon::parse($item->po_date)->format('d/m/y'),
                        $company,
                        $source,
                        '', // Placeholder for Product Name
                        '', // Placeholder for Part No
                        '', // Placeholder for Qty
                        '', // Placeholder for Rate
                        isset($item->rfq->currencyData) ? $item->rfq->currencyData->symbol : '',
                        '', // Placeholder for PO Value
                        $poType,
                        $updatedBy,
                        $rsmName,
                        $subStage,
                    ];

                    // Add product rows
                    if (!empty($products)) {
                        foreach ($products as $pro) {
                            $productName = isset($pro->product_id) ? Product::where('id', $pro->product_id)->value('product_name') : '';
                            $partNo = $pro->part_no ?? '';
                            $qty = $pro->qty ?? '';
                            $rate = $pro->rate ?? '';
                            $total = ($qty * $rate) ?? 0;

                            $rowData = $baseRowData;
                            $rowData[7] = $productName;
                            $rowData[8] = $partNo;
                            $rowData[9] = $qty;
                            $rowData[10] = $rate;
                            $rowData[12] = formatIndianRupees($total) ?? 0;

                            $sheetData[] = $rowData;
                        }
                    }

                    // Add service rows under products
                    if (!empty($services)) {
                        foreach ($services as $service) {
                            $rowData = $baseRowData;
                            $rowData[7] = $service->label ?? '';  // Product Name (Service Label)
                            $rowData[8] = $service->part_no ?? '';  // Part No
                            $rowData[9] = $service->qty ?? '';  // Qty/Set
                            $rowData[10] = $service->rate ?? '';  // Rate
                            $rowData[12] = $service->total_amount ?? '';  // Total Amount
                            $sheetData[] = $rowData;
                        }
                    }

                    if (empty($products) && empty($services)) {
                        $sheetData[] = $baseRowData;
                    }
                }

                $sheet->fromArray($sheetData, null, 'A1');
                $timestamp = date('Y-m-d_H-i-s');
                $store = "storage/app/public/uploads/po/po_{$poType}_$timestamp.csv";
                $filePath = "storage/uploads/po/po_{$poType}_$timestamp.csv";
                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }

            $poList = PoDispatchResource::collection($poList);

            // $totalFinalAmount = 0;
            // if ($poList && $poList->isNotEmpty()) {
            //     $totalFinalAmount = $poList->sum(function ($item) {
            //         return isset($item['total_basic_value']) ? $item['total_basic_value'] : 0;
            //     });
            // }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Purchase Order Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['list'] = $poList ?? [];
            $this->response['data']['filePath'] = $filePath ?? [];
            $this->response['data']['po_no'] = $purchaseOrderNo;
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['division_id'] = $divisionId;
            $this->response['data']['is_export_lead'] = $isExportLead;
            $this->response['data']['current_stage_id'] = $currSubStageId;
            $this->response['data']['company'] = $company;
            $this->response['data']['region_id'] = $regionId;
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['date_range'] = $dateRange;
            $this->response['data']['total_final_amount'] = moneyFormatIndia($totalFinalAmount) ?? 0;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }


    public function quotationList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $quotationType = $request->tab;
            $quotationNo = $request->quotation_no ?? '';
            $preparedBy = $request->prepared_by ?? '';
            $salesPerson = $request->sales_person ?? '';
            $divisionId = $request->division ?? '';
            $isExportLead = $request->is_export_lead ?? '';
            $startDate = $request->start_date;
            $endDate = $request->end_date;
            $dateRange = strtolower($request->date_range);
            $quotationStatus = $request->quotation_status ?? '';
            $company = strtolower(preg_replace('/\s+/', ' ', $request->company ?? ''));
            $curStageId = $request->current_stage_id ?? '';
            $finalAmount = $request->final_amount ?? '';
            $productId = $request->product_id ?? '';
            $partId = $request->part_no_id ?? '';
            $highValue = $request->high_value ?? '';
            $isExport = $request->is_export ?? 0;

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'quotation_date';



            if ($this->isUserAdmin || $this->isManagement || $this->isMarketing) {
                $quotation = ProjectQuotationTemp::with(['salesPerson', 'preparedBy', 'lead.region', 'rfq', 'rfq.division', 'rfq.subStage', 'rfq.designation', 'rfq.currencyData', 'rfq.source'])->orderBy('id', 'desc');
            } else if ($this->isUserInsideSale || $this->psmUserRole) {
                $insideSaleDivisions = User::find($this->userId)->division_ids;
                $divisionIdsArray = explode(',', $insideSaleDivisions);

                $quotation = ProjectQuotationTemp::with(['salesPerson', 'preparedBy', 'lead.region', 'rfq', 'rfq.division', 'rfq.subStage', 'rfq.designation', 'rfq.currencyData', 'rfq.source'])
                    ->whereHas('rfq', function ($q) use ($divisionIdsArray) {
                        $q->whereIn('division_id', $divisionIdsArray);
                    })
                    ->orderBy('id', 'desc');
            } else {
                $juniorUserIds = $this->getJuniorIds(true);
                rsort($juniorUserIds);

                $quotation = ProjectQuotationTemp::with(['salesPerson', 'preparedBy', 'lead.region', 'rfq', 'rfq.division', 'rfq.subStage', 'rfq.designation', 'rfq.currencyData', 'rfq.source'])->where(function ($q) use ($juniorUserIds) {
                    $q->whereIn('prepared_by', $juniorUserIds);
                    $q->orWhereIn('sales_person', $juniorUserIds);
                })
                    ->orderBy('id', 'desc');

                if ($this->isUserDispatch) {
                    $quotation = ProjectQuotationTemp::with(['purchaseOrder', 'rfq.division', 'salesPerson', 'preparedBy', 'lead.region', 'rfq', 'rfq.subStage', 'rfq.designation', 'rfq.currencyData', 'rfq.source'])->whereHas('purchaseOrder', function ($query) {
                        $query->whereNotNull('id');
                    })
                        ->orderBy('id', 'desc');
                }
            }

            $quotation->select('*', DB::raw("
                CASE 
                    WHEN set_value IS NOT NULL THEN (set_value * COALESCE(requirement_total, 0)) + COALESCE(service_total, 0)
                    ELSE COALESCE(requirement_total, 0) + COALESCE(service_total, 0)
                END AS total
            "));

            if ($quotationNo) $quotation->where('quotation_no', 'like', '%' . $quotationNo . '%');
            if ($finalAmount) $quotation->where('final_amount', 'like', '%' . $finalAmount . '%');
            if ($quotationStatus) $quotation->where('quotation_status', 'like', '%' . $quotationStatus . '%');

            if ($highValue === 'below_5_lakh') {
                $quotation->having('total', '<=', 500000);
            } elseif ($highValue === 'above_5_lakh') {
                $quotation->having('total', '>', 500000);
            } elseif ($highValue === 'above_10_lakh') {
                $quotation->having('total', '>', 1000000);
            } elseif ($highValue === 'above_20_lakh') {
                $quotation->having('total', '>', 2000000);
            }

            if ($productId) {
                $quotation->whereRaw("JSON_SEARCH(JSON_EXTRACT(requirements, '$[*].product_id'), 'one', ?) IS NOT NULL", [$productId]);
            }

            if ($partId) {
                $quotation->whereRaw(
                    "JSON_CONTAINS(requirements, ?)",
                    [json_encode(['part_noId' => (int)$partId])]
                );
            }


            if ($dateRange) {
                if ($dateRange == 'today') {
                    $quotation->whereDate('quotation_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $quotation->whereDate('quotation_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $quotation->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $quotation->whereDate('quotation_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $quotation->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $quotation->whereDate('quotation_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $quotation->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $quotation->whereDate('quotation_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $quotation->whereMonth('quotation_date', date('m'))->whereYear('quotation_date', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $quotation->whereMonth('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $quotation->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $quotation->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $quotation->whereDate('quotation_date', '>=', $startDate);

                        if ($endDate) {
                            $quotation->whereDate('quotation_date', '<=', $endDate);
                        }
                    }
                }
            }

            if ($preparedBy) {
                $quotation->whereHas('preparedBy', function ($query) use ($preparedBy) {
                    $query->where('name', 'like', '%' . $preparedBy . '%');
                });
            }

            if ($salesPerson) {
                $quotation->where('sales_person', $salesPerson);
            }

            if ($divisionId) {
                $quotation->whereHas('rfq', function ($query) use ($divisionId) {
                    $query->where('division_id', $divisionId);
                });
            }

            if ($curStageId) {
                $quotation->whereHas('rfq', function ($query) use ($curStageId) {
                    $query->where('curr_sub_stage_id', $curStageId);
                });
            }


            if ($company) {
                $quotation->whereHas('lead', function ($query) use ($company) {
                    $query->where('company', 'like', '%' . $company . '%');
                });
            }

            if ($isExportLead) {
                $quotation->whereHas('lead', function ($query) use ($isExportLead) {
                    $query->where('is_export', $isExportLead);
                });
            }


            $sumQuery = clone $quotation;
            $totalFinalAmount = $sumQuery->sum('total_basic_value');

            $num_rows = $quotation->count();
            if ($isExport == 1) {
                $quotation = $quotation->get();
            } else {
                $quotation = $quotation->limit($per_page)->offset($offset)->get();
            }

            if ($isExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                $headers = ['RFQ No', 'RFQ Date', 'Quotation No', 'Quotation Date', 'Division', 'Response Time (Days)', 'Company Name', 'Industry', 'Segment', 'Address 1', 'Address 2', 'City', 'State', 'Pincode', 'Region', 'Contact Person Name', 'Contact Person Designation', 'Contact Person Email', 'Contact Person Phone', 'Product Category', 'Product Name', 'Part No.', 'Product Description (Avlock)', 'Product Description (Customer)', 'HSN', 'MOQ', 'Material Per Lot Dispatch', 'Qty/Set', 'Set Name', 'Set Value', 'Rate', 'Currency', 'Total', 'Total (With set value)', 'Prepared By', 'RSM', 'Updated At', 'Type of Quotation', 'Source', 'Current Stage'];

                $sheetData = [$headers];

                foreach ($quotation as $key => $item) {
                    $requirementsString = '';
                    $requirements = json_decode($item->requirements, true);
                    $services = json_decode($item->service_detail, true);

                    $requirements = is_array($requirements) ? $requirements : [];
                    $services = is_array($services) ? $services : [];

                    $salesPersonName = isset($item->salesPerson->name) ? $item->salesPerson->name : '';
                    $divisionName = isset($item->rfq->division) ? $item->rfq->division->name : '';
                    $preparedByName = isset($item->preparedBy->name) ? $item->preparedBy->name : '';
                    $leadCompany = isset($item->lead) ? $item->lead->company : '';
                    $rfqNo = isset($item->rfq) ? $item->rfq->rfq_number : '';
                    $rfqDateFromRfq = isset($item->rfq) ? Carbon::parse($item->rfq->rfq_date)->format('d/m/y') : '';
                    $source = isset($item->rfq) && isset($item->rfq->source) ? $item->rfq->source->name : '';
                    $region = isset($item->lead) && isset($item->lead->region) ? $item->lead->region->name : '';
                    // $sourceVerified = isset($item->rfq) && $item->rfq->is_source_verified == 1 ? 'Yes' : 'No';
                    $desg = $item->lead->designations ?? [];
                    $designationNames = LeadDesignation::whereIn('id', $desg)->pluck('name')->implode(', ');

                    $industries = isset($item->rfq) ? json_decode($item->rfq->industry, true) : [];
                    $segmentIds = isset($item->rfq) ? json_decode($item->rfq->project_segments, true) : [];

                    $segments = ProjectSegment::whereIn('id', $segmentIds)->get();

                    if ($segments->isNotEmpty()) {
                        $segmentNames = $segments->map(function ($segment) {
                            return $segment->name;
                        })->toArray();

                        $segmentNamesString = implode(', ', $segmentNames);
                    } else {
                        $segmentNamesString = '';
                    }

                    if (is_array($industries) && !empty($industries)) {
                        $industrieNames = array_map(function ($industry) {
                            return $industry['name'];
                        }, $industries);

                        $industrieNamesString = implode(', ', $industrieNames);
                    } else {
                        $industrieNamesString = '';
                    }

                    $rfqDate = $item->rfq && $item->rfq->rfq_date ? Carbon::parse($item->rfq->rfq_date) : null;
                    $quotationDate = $item->quotation_date ? Carbon::parse($item->quotation_date) : null;

                    if ($rfqDate && $quotationDate) {
                        $diffDate = $rfqDate->diffInDays($quotationDate);
                        $diffDateString = $diffDate;
                    } else {
                        $diffDateString = '';
                    }


                    $baseRowData = [
                        $rfqNo,
                        $rfqDateFromRfq,
                        $item->quotation_no,
                        Carbon::parse($item->quotation_date)->format('d/m/y'),
                        $divisionName,
                        $diffDateString,
                        $leadCompany,
                        $industrieNamesString,
                        $segmentNamesString,
                        isset($item->rfq) ? $item->rfq->address1 : '',
                        isset($item->rfq) ? $item->rfq->address2 : '',
                        isset($item->rfq) ? $item->rfq->city : '',
                        isset($item->rfq) ? $item->rfq->state : '',
                        isset($item->rfq) ? $item->rfq->pincode : '',
                        $region,
                        $item->lead->customer_name ?? '',
                        $designationNames,
                        $item->rfq->email ?? '',
                        $item->rfq->contact_no ?? '',
                        '',  // Product Category
                        '',  // Product Name
                        '',  // Part No.
                        '',  // Product Description (Avlock)
                        '',  // Product Description (Customer)
                        '',  // HSN
                        '',  // MOQ
                        '',  // Material Per Lot Dispatch
                        '',  // Qty/Set
                        '',  // Set Name
                        '',  // Set Value
                        '',  // Rate
                        isset($item->rfq->currencyData) ? $item->rfq->currencyData->symbol : '',
                        '',  // Total
                        '',  // Total (With set value)
                        $preparedByName,
                        $salesPersonName,
                        Carbon::parse($item->updated_at)->format('M d, Y h:i a'),
                        '',  // Type of Quotation
                        $source,
                        isset($item->rfq) && isset($item->rfq->subStage) ? $item->rfq->subStage->name : ''
                    ];

                    $allRows = [];

                    // Process products
                    foreach ($requirements as $requirement) {
                        $rowData = $baseRowData;
                        $productCatModel = Product::with('category:id,category_name')->find($requirement['product_id']);
                        $productCat = isset($productCatModel->category) ? $productCatModel->category->category_name : '';

                        $rowData[19] = $productCat ?? '';  // Product Category
                        $rowData[20] = $requirement['product_name'] ?? '';  // Product Name
                        $rowData[21] = $requirement['part_no'] ?? '';  // Part No.
                        $rowData[22] = $requirement['description'] ?? '';  // Product Description (Avlock)
                        $rowData[23] = $requirement['cust_description'] ?? '';  // Product Description (Customer)
                        $rowData[24] = $requirement['hsn'] ?? '';  // HSN
                        $rowData[25] = $requirement['moq'] ?? '';  // MOQ
                        $rowData[26] = $requirement['material_per_lot_dispatch'] ?? '';  // Material Per Lot Dispatch
                        $rowData[27] = $requirement['qty'] ?? '';  // Qty/Set
                        $rowData[28] = $item->set_name ?? '';  // Set Name
                        $rowData[29] = $item->set_value ?? '';  // Set Value
                        $rowData[30] = $requirement['rate'] ?? '';  // Rate
                        $rowData[32] = $requirement['total'] ?? ($requirement['total_amount'] ?? '');  // Total
                        $rowData[33] = isset($item->set_value) ? $item->set_value * $requirement['qty'] * $requirement['rate'] : '';  // Total (With set value)

                        $allRows[] = $rowData;
                    }

                    // Process services
                    foreach ($services as $service) {
                        $rowData = $baseRowData;
                        $rowData[20] = $service['label'] ?? '';  // Product Name (Service Label)
                        $rowData[21] = $service['part_no'] ?? '';  // Part No.
                        $rowData[24] = $service['hsn'] ?? '';  // HSN
                        $rowData[27] = $service['qty'] ?? '';  // Qty/Set
                        $rowData[28] = $service['set_name'] ?? '';  // Set Name
                        $rowData[30] = $service['rate'] ?? '';  // Rate
                        $rowData[32] = $service['total_amount'] ?? '';  // Total
                        $allRows[] = $rowData;
                    }

                    if (empty($allRows)) {
                        $allRows[] = $baseRowData;
                    }

                    $sheetData = array_merge($sheetData, $allRows);
                }

                $sheet->fromArray($sheetData, null, 'A1');
                $store = "storage/app/public/uploads/quotation/Quotation_$quotationType.csv";
                $filePath = "storage/uploads/quotation/Quotation_$quotationType.csv";
                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }

            // $totalFinalAmount = 0;
            // if ($quotation && $quotation->isNotEmpty()) {
            //     $totalFinalAmount = $quotation->sum(function ($item) {
            //         return isset($item['total_basic_value_in_inr']) ? $item['total_basic_value_in_inr'] : 0;
            //     });
            // }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Quotation Lists"]);
            $this->response['filePath'] = $filePath ?? '';
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['quotation_no'] = $quotationNo;
            $this->response['data']['prepared_by'] = $preparedBy;
            $this->response['data']['quotation_status'] = $quotationStatus;
            $this->response['data']['company'] = $company;
            $this->response['data']['division'] = $divisionId;
            $this->response['data']['sales_person'] = $salesPerson;
            $this->response['data']['final_amount'] = $finalAmount;
            $this->response['data']['product_id'] = $productId;
            $this->response['data']['is_export_lead'] = $isExportLead;
            $this->response['data']['high_value'] = $highValue;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['current_stage_id'] = $curStageId;
            $this->response['data']['total_final_amount'] = moneyFormatIndia($totalFinalAmount) ?? 0;
            $this->response['data']['list'] = $quotation ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Quotation Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function DispatchList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $dispatchType = $request->tab;
            $poNo = $request->po_no ?? '';
            $soNo = $request->so_no ?? '';
            $company = $request->company ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'despatch_date';

            $poDispatchObj = PoDespatchDetail::with(['po', 'po.lead', 'so', 'so.dc'])->where('po_type', 1)->orderBy('id', 'desc');

            if ($poNo) {
                $poDispatchObj->whereHas('po', function ($q) use ($poNo) {
                    $q->where('po_no', 'like', '%' . $poNo . '%');
                });
            }

            if ($soNo) {
                $poDispatchObj->whereHas('so', function ($q) use ($soNo) {
                    $q->where('so_no', 'like', '%' . $soNo . '%');
                });
            }

            if ($company) {
                $poDispatchObj->whereHas('po.lead', function ($q) use ($company) {
                    $q->where('company', 'like', '%' . $company . '%');
                });
            }


            if ($dateRange) {
                if ($dateRange == 'today') {
                    $poDispatchObj->whereDate('despatch_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $poDispatchObj->whereDate('despatch_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $poDispatchObj->whereDate('despatch_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $poDispatchObj->whereDate('despatch_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $poDispatchObj->whereDate('despatch_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $poDispatchObj->whereDate('despatch_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $poDispatchObj->whereDate('despatch_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $poDispatchObj->whereDate('despatch_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $poDispatchObj->whereMonth('despatch_date', date('m'))->whereYear('despatch_date', date('Y'));
                }

                if ($dateRange == 'last_month') {
                    $poDispatchObj->whereMonth('despatch_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('despatch_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $poDispatchObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $poDispatchObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $poDispatchObj->whereDate('despatch_date', '>=', $startDate);

                        if ($endDate) {
                            $poDispatchObj->whereDate('despatch_date', '<=', $endDate);
                        }
                    }
                }
            }
            $num_rows = $poDispatchObj->count();
            $dispatchList = $poDispatchObj->limit($per_page)->offset($offset)->get();
            // $result = PoDispatchResource::collection($dispatchList);

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Invoice Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['list'] = $dispatchList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function svrList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $reportNo = $request->report_no ?? '';
            $customer = $request->customer ?? '';
            $salesPerson = $request->sales_person ?? '';
            $company = $request->company ?? '';
            $curStageId = $request->current_stage_id ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'visit_date';

            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            $currUser = User::find($this->userId);
            $divisionIds = explode(',', $currUser->division_ids);

            if ($this->isMarketing || $this->isManagement) {
                $svrObj = SalesVisitReport::with(['reportSalesPerson', 'division:id,name', 'product', 'lead', 'rfq.subStage']);
            } else {
                $svrObj = SalesVisitReport::with(['reportSalesPerson', 'division:id,name', 'product', 'lead', 'rfq.subStage'])->whereIn('created_by', $juniorUserIds);
            }

            if ($customer) {
                $svrObj->where('fk_lead_id', $customer);
            }

            if ($salesPerson) {
                $svrObj->where('sales_person', '=', $salesPerson);
            }

            if ($curStageId) {
                $svrObj->whereHas('rfq', function ($query) use ($curStageId) {
                    $query->where('curr_sub_stage_id', $curStageId);
                });
            }

            if ($reportNo) {
                $svrObj->where('report_no', 'like', '%' . $reportNo . '%');
            }

            if ($company) {
                $svrObj->whereHas('lead', function ($q) use ($company) {
                    $q->where('company', 'like', '%' . $company . '%');
                });
            }


            if ($dateRange) {
                if ($dateRange == 'today') {
                    $svrObj->whereDate('visit_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $svrObj->whereDate('visit_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $svrObj->whereDate('visit_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $svrObj->whereDate('visit_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $svrObj->whereDate('visit_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $svrObj->whereDate('visit_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $svrObj->whereDate('visit_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $svrObj->whereDate('visit_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $svrObj->whereMonth('visit_date', date('m'))->whereYear('visit_date', date('Y'));
                }

                if ($dateRange == 'last_month') {
                    $svrObj->whereMonth('visit_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('visit_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $svrObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $svrObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $svrObj->whereDate('visit_date', '>=', $startDate);

                        if ($endDate) {
                            $svrObj->whereDate('visit_date', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $svrObj->count();
            $svrList = $svrObj->limit($per_page)->offset($offset)->get();
            // $result = PoDispatchResource::collection($dispatchList);

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Sales Visit Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['list'] = $svrList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function todayDispatchList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $poNo = $request->po_no ?? '';
            $soNo = $request->so_no ?? '';
            $company = $request->company ?? '';

            $poDispatchObj = PoDespatchDetail::with(['po', 'po.lead', 'so', 'so.dc'])->where('po_type', 1)->whereDate('despatch_date', Carbon::today())->orderBy('id', 'desc');

            if ($poNo) {
                $poDispatchObj->whereHas('po', function ($q) use ($poNo) {
                    $q->where('po_no', 'like', '%' . $poNo . '%');
                });
            }

            if ($soNo) {
                $poDispatchObj->whereHas('so', function ($q) use ($soNo) {
                    $q->where('so_no', 'like', '%' . $soNo . '%');
                });
            }

            if ($company) {
                $poDispatchObj->whereHas('po.lead', function ($q) use ($company) {
                    $q->where('company', 'like', '%' . $company . '%');
                });
            }


            $num_rows = $poDispatchObj->count();
            $dispatchList = $poDispatchObj->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Po Dispatch Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['list'] = $dispatchList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function deliveredDispatchList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;
            $poNo = $request->po_no ?? '';
            $soNo = $request->so_no ?? '';
            $company = $request->company ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'dc_date';

            $poDispatchObj = DeliveryConfirmation::with(['so', 'so.lead', 'so.po'])->where('po_type', 1)->orderBy('id', 'desc');

            if ($poNo) {
                $poDispatchObj->whereHas('so.po', function ($q) use ($poNo) {
                    $q->where('po_no', 'like', '%' . $poNo . '%');
                });
            }

            if ($soNo) {
                $poDispatchObj->whereHas('so', function ($q) use ($soNo) {
                    $q->where('so_no', 'like', '%' . $soNo . '%');
                });
            }

            if ($company) {
                $poDispatchObj->whereHas('so.lead', function ($q) use ($company) {
                    $q->where('company', 'like', '%' . $company . '%');
                });
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $poDispatchObj->whereDate('dc_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $poDispatchObj->whereDate('dc_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $poDispatchObj->whereDate('dc_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $poDispatchObj->whereDate('dc_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $poDispatchObj->whereDate('dc_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $poDispatchObj->whereDate('dc_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $poDispatchObj->whereDate('dc_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $poDispatchObj->whereDate('dc_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $poDispatchObj->whereMonth('dc_date', date('m'))->whereYear('dc_date', date('Y'));
                }

                if ($dateRange == 'last_month') {
                    $poDispatchObj->whereMonth('dc_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('dc_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $poDispatchObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $poDispatchObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $poDispatchObj->whereDate('dc_date', '>=', $startDate);

                        if ($endDate) {
                            $poDispatchObj->whereDate('dc_date', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $poDispatchObj->count();
            $dispatchList = $poDispatchObj->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Delivery Confirmation Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['list'] = $dispatchList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function projectSamplingList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;
            $rfqNo = $request->rfq_number ?? '';
            $company = $request->company ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $isExport = $request->is_export ?? 0;
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'created_at';

            $poDispatchObj = ProjectSampling::with(['rfq:id,rfq_number', 'lead:id,company', 'currentSubStage:id,name', 'pdrQuality:id,fk_sampling_id,attachments']);

            if ($company) {
                $poDispatchObj->whereHas('lead', function ($q) use ($company) {
                    $q->where('company', 'like', '%' . $company . '%');
                });
            }

            if ($rfqNo) {
                $poDispatchObj->whereHas('rfq', function ($q) use ($rfqNo) {
                    $q->where('rfq_number', 'like', '%' . $rfqNo . '%');
                });
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $poDispatchObj->whereDate('created_at', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $poDispatchObj->whereDate('created_at', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-14 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-28 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $poDispatchObj->whereMonth('created_at', date('m'))->whereYear('created_at', date('Y'));
                }

                if ($dateRange == 'last_month') {
                    $poDispatchObj->whereMonth('created_at', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('created_at', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $poDispatchObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $poDispatchObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $poDispatchObj->whereDate('created_at', '>=', $startDate);

                        if ($endDate) {
                            $poDispatchObj->whereDate('created_at', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $poDispatchObj->count();
            if ($isExport == 1) {
                $dispatchList = $poDispatchObj->get();
            } else {
                $dispatchList = $poDispatchObj->limit($per_page)->offset($offset)->get();
            }


            if ($isExport == 1) {
                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();

                $headers = ['RFQ No', 'Company', 'Current Stage', 'Remark'];

                $sheetData = [$headers];

                foreach ($dispatchList as $key => $item) {
                    $rfqNo = $item->rfq->rfq_number ?? '';
                    $company = $item->lead->company ?? '';

                    $baseRowData = [
                        $rfqNo ?? '',
                        $company ?? '',
                        $item->currentSubStage->name ?? '',
                        $item->sub_stage_remark ?? '',
                    ];

                    $sheetData[] = $baseRowData;
                }

                $sheet->fromArray($sheetData, null, 'A1');
                $store = "storage/app/public/uploads/sampling/sampling.csv";
                $filePath = "storage/uploads/sampling/sampling.csv";
                $writer = new Csv($spreadsheet);
                $writer->setUseBOM(true);
                $writer->save($store);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Project Sampling Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['filePath'] = $filePath ?? '';
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['list'] = $dispatchList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Project Sampling Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function samplingDeliveryUpdate(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;
            $company = $request->company ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'dc_date';

            $poDispatchObj = ProjectSamplingDeliveryUpdate::with(['rfq:id,rfq_number', 'lead:id,company'])->orderBy('id', 'desc');


            if ($company) {
                $poDispatchObj->whereHas('lead', function ($q) use ($company) {
                    $q->where('company', 'like', '%' . $company . '%');
                });
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $poDispatchObj->whereDate('created_at', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $poDispatchObj->whereDate('created_at', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-14 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-28 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $poDispatchObj->whereMonth('created_at', date('m'))->whereYear('created_at', date('Y'));
                }

                if ($dateRange == 'last_month') {
                    $poDispatchObj->whereMonth('created_at', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('created_at', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $poDispatchObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $poDispatchObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $poDispatchObj->whereDate('created_at', '>=', $startDate);

                        if ($endDate) {
                            $poDispatchObj->whereDate('created_at', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $poDispatchObj->count();
            $dispatchList = $poDispatchObj->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Project Sampling Delivery Update Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['list'] = $dispatchList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Project Sampling Delivery Update Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function pdrQuality(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;
            $company = $request->company ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'dc_date';

            $poDispatchObj = ProjectSamplingPdrQuality::with(['rfq:id,rfq_number', 'lead:id,company'])->where('is_latest', 1)->orderBy('id', 'desc');


            if ($company) {
                $poDispatchObj->whereHas('lead', function ($q) use ($company) {
                    $q->where('company', 'like', '%' . $company . '%');
                });
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $poDispatchObj->whereDate('created_at', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $poDispatchObj->whereDate('created_at', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-14 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-28 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $poDispatchObj->whereMonth('created_at', date('m'))->whereYear('created_at', date('Y'));
                }

                if ($dateRange == 'last_month') {
                    $poDispatchObj->whereMonth('created_at', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('created_at', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $poDispatchObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $poDispatchObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $poDispatchObj->whereDate('created_at', '>=', $startDate);

                        if ($endDate) {
                            $poDispatchObj->whereDate('created_at', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $poDispatchObj->count();
            $dispatchList = $poDispatchObj->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Project Sampling PDR Quality Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['list'] = $dispatchList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Project Sampling PDR Quality Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function samplingPurchaseInvoice(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;
            $company = $request->company ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'dc_date';

            $poDispatchObj = ProjectSamplingPurchaseInvoice::with(['rfq:id,rfq_number', 'lead:id,company'])->where('is_latest', 1)->orderBy('id', 'desc');


            if ($company) {
                $poDispatchObj->whereHas('lead', function ($q) use ($company) {
                    $q->where('company', 'like', '%' . $company . '%');
                });
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $poDispatchObj->whereDate('created_at', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $poDispatchObj->whereDate('created_at', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-14 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $poDispatchObj->whereDate('created_at', '>=', date('Y-m-d', strtotime('-28 days')));
                    $poDispatchObj->whereDate('created_at', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $poDispatchObj->whereMonth('created_at', date('m'))->whereYear('created_at', date('Y'));
                }

                if ($dateRange == 'last_month') {
                    $poDispatchObj->whereMonth('created_at', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('created_at', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $poDispatchObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $poDispatchObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $poDispatchObj->whereDate('created_at', '>=', $startDate);

                        if ($endDate) {
                            $poDispatchObj->whereDate('created_at', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $poDispatchObj->count();
            $dispatchList = $poDispatchObj->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Project Sampling Purchase Invoice Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['list'] = $dispatchList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Project Sampling Purchase Invoice Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function SalesOrderList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $soNo = $request->so_no ?? '';
            $poNo = $request->po_no ?? '';
            $divisionId = $request->division_id ?? '';
            $company = preg_replace('/\s+/', ' ', $request->company) ?? '';
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'so_date';

            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $salesOrderObj = AvlockSalesOrder::with(['dispatch', 'po', 'lead', 'rfq:id,division_id'])
                    ->where('po_type', 1)
                    ->orderBy('id', 'desc');
            } else {
                $salesOrderObj = AvlockSalesOrder::with(['dispatch', 'po', 'lead', 'rfq:id,division_id'])->where(function ($query) use ($juniorUserIds) {
                    $query->where('created_by', $this->userId)
                        ->orWhere(function ($q) use ($juniorUserIds) {
                            $q->whereIn('created_by', $juniorUserIds);
                        });
                })->where('po_type', 1)->orderBy('id', 'desc');
            }

            if ($soNo) {
                $salesOrderObj->where('your_so_no', $soNo);
            }

            if ($divisionId) {
                $salesOrderObj->whereHas('rfq', function ($query) use ($divisionId) {
                    $query->where('division_id', $divisionId);
                });
            }

            if ($poNo) {
                $salesOrderObj->whereHas('po', function ($query) use ($poNo) {
                    $query->where('po_no', $poNo);
                });
            }

            if ($company) {
                $salesOrderObj->whereHas('lead', function ($q) use ($company) {
                    $q->where('company', 'like', '%' . $company . '%');
                });
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $salesOrderObj->whereDate('so_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $salesOrderObj->whereDate('so_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $salesOrderObj->whereDate('so_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $salesOrderObj->whereDate('so_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $salesOrderObj->whereDate('so_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $salesOrderObj->whereDate('so_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $salesOrderObj->whereDate('so_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $salesOrderObj->whereDate('so_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $salesOrderObj->whereMonth('so_date', date('m'))->whereYear('so_date', date('Y'));
                }

                if ($dateRange == 'last_month') {
                    $salesOrderObj->whereMonth('so_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('so_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $salesOrderObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $salesOrderObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $salesOrderObj->whereDate('so_date', '>=', $startDate);

                        if ($endDate) {
                            $salesOrderObj->whereDate('so_date', '<=', $endDate);
                        }
                    }
                }
            }

            $num_rows = $salesOrderObj->count();
            $salesOrderList = $salesOrderObj->limit($per_page)->offset($offset)->get();
            $result = SalesOrderResource::collection($salesOrderList);



            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Sales Order Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['list'] = $result ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function pendingOrderList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $quotationNo = $request->quotation_no ?? '';
            $preparedBy = $request->prepared_by ?? '';
            $salesPerson = $request->sales_person ?? '';
            $divisionId = $request->division ?? '';
            $startDate = $request->start_date;
            $endDate = $request->end_date;
            $dateRange = strtolower($request->date_range);
            $company = strtolower(preg_replace('/\s+/', ' ', $request->company ?? ''));
            $curStageId = $request->current_stage_id ?? '';
            $productId = $request->product_id ?? '';
            $partId = $request->part_no_id ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'quotation_date';

            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            $pendingOrderObj = ProjectQuotationTemp::with(['salesPerson:id,name', 'preparedBy:id,name', 'lead.region', 'rfq', 'rfq.division', 'rfq.subStage', 'rfq.designation', 'rfq.currencyData', 'rfq.source'])
                ->whereDoesntHave('purchaseOrder')
                ->orderBy('id', 'desc');

            if ($quotationNo) $pendingOrderObj->where('quotation_no', 'like', '%' . $quotationNo . '%');

            if ($divisionId) {
                $pendingOrderObj->whereHas('rfq', function ($query) use ($divisionId) {
                    $query->where('division_id', $divisionId);
                });
            }

            if ($productId) {
                $pendingOrderObj->whereRaw("JSON_SEARCH(JSON_EXTRACT(requirements, '$[*].product_id'), 'one', ?) IS NOT NULL", [$productId]);
            }

            if ($partId) {
                $pendingOrderObj->whereRaw(
                    "JSON_CONTAINS(requirements, ?)",
                    [json_encode(['part_noId' => (int)$partId])]
                );
            }


            if ($dateRange) {
                if ($dateRange == 'today') {
                    $pendingOrderObj->whereDate('quotation_date', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $pendingOrderObj->whereDate('quotation_date', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $pendingOrderObj->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-7 days')));
                    $pendingOrderObj->whereDate('quotation_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $pendingOrderObj->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-14 days')));
                    $pendingOrderObj->whereDate('quotation_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $pendingOrderObj->whereDate('quotation_date', '>=', date('Y-m-d', strtotime('-28 days')));
                    $pendingOrderObj->whereDate('quotation_date', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $pendingOrderObj->whereMonth('quotation_date', date('m'))->whereYear('quotation_date', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $pendingOrderObj->whereMonth('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('quotation_date', explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $pendingOrderObj->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $pendingOrderObj->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $pendingOrderObj->whereDate('quotation_date', '>=', $startDate);

                        if ($endDate) {
                            $pendingOrderObj->whereDate('quotation_date', '<=', $endDate);
                        }
                    }
                }
            }

            if ($preparedBy) {
                $pendingOrderObj->whereHas('preparedBy', function ($query) use ($preparedBy) {
                    $query->where('name', 'like', '%' . $preparedBy . '%');
                });
            }

            if ($salesPerson) {
                $pendingOrderObj->where('sales_person', $salesPerson);
            }

            if ($curStageId) {
                $pendingOrderObj->whereHas('rfq', function ($query) use ($curStageId) {
                    $query->where('curr_sub_stage_id', $curStageId);
                });
            }


            if ($company) {
                $pendingOrderObj->whereHas('lead', function ($query) use ($company) {
                    $query->where('company', 'like', '%' . $company . '%');
                });
            }


            $num_rows = $pendingOrderObj->count();
            $salesOrderList = $pendingOrderObj->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Pending Order Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['total_pages'] = $num_rows < $per_page ?: ceil($num_rows / $per_page);
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['list'] = $salesOrderList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Pending Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function invoiceList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $dispatchType = $request->tab;
            $startDate = $request->start_date ?? '';
            $endDate = $request->end_date ?? '';
            $piNo = $request->pi_no ?? '';
            $piAmount = $request->pi_amount ?? '';

            if ($this->isUserAdmin || $this->isManagement || $this->isMarketing || $this->isUserDispatch) {
                $pi = PurchaseInvoice::orderBy('id', 'desc');
            } else {
                $pi = PurchaseInvoice::where('created_by', $this->userId)->orderBy('id', 'desc');
            }

            if ($piNo) {
                $pi->where('pi_no', 'like', "%" . $piNo . "%");
            }

            if ($piAmount) {
                $pi->where('pi_total_amount', 'like', "%" . $piAmount . "%");
            }

            if ($startDate && $endDate) {
                $pi->whereBetween('pi_date', [$startDate, $endDate]);
            } elseif ($startDate) {
                $pi->whereDate('pi_date', $startDate);
            }

            $num_rows = $pi->count();

            if ($dispatchType === 'thismonth') {
                $piThisMonth = clone $pi;
                $piList = $piThisMonth
                    ->whereYear('updated_at', '=', date('Y'))
                    ->whereMonth('updated_at', '=', date('m'))
                    ->limit($per_page)->offset($offset)->get();
            } elseif ($dispatchType === 'thisyear') {
                $piThisYear = clone $pi;
                $piList = $piThisYear
                    ->whereYear('updated_at', '=', date('Y'))
                    ->limit($per_page)->offset($offset)->get();
            } else {
                $this->response['error'] = 'Invalid purchase invoice type provided.';
                return $this->sendResponse($this->response, 500);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Invoice Lists"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['pi_no'] = $piNo;
            $this->response['data']['pi_amount'] = $piAmount;
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['list'] = $piList ?? [];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function toggleRfqList()
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            //From RFQ Table
            $rfqFromRfq = Rfq::select('id as rfq_id')->orderBy('id', 'desc');
            $rfqFromRfqThisMonth = clone $rfqFromRfq;
            $rfqFromRfqThisYear = clone $rfqFromRfq;
            $rfqFromRfqThisMonth = $rfqFromRfqThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->toArray(); //7
            $rfqFromRfqThisYear = $rfqFromRfqThisYear->whereYear('updated_at', date('Y'))->get()->toArray(); //25

            //From Project Logs table
            $rfqFromProjectLogs = ProjectLog::select('fk_rfq_id as rfq_id')->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])->distinct()->groupBy('fk_rfq_id');

            $rfqFromProjectLogsThisMonth = $rfqFromProjectLogs->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->toArray(); //6
            $rfqFromProjectLogsThisYear = $rfqFromProjectLogs->whereYear('updated_at', date('Y'))->get()->toArray(); //33

            //Merging Array From Both table
            $rfqCountThisMonthIds = array_unique(array_column(array_merge($rfqFromRfqThisMonth, $rfqFromProjectLogsThisMonth), 'rfq_id'));
            $rfqCountThisYearIds = array_unique(array_column(array_merge($rfqFromRfqThisYear, $rfqFromProjectLogsThisYear), 'rfq_id'));

            //Closed RFQ
            $closedRfq = ProjectLog::where('curr_sub_stage_id', $this->deliverySubStageId)->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])->distinct()->groupBy('fk_rfq_id');

            $rfqMonthArray = $closedRfq->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get()->toArray();

            $rfqYearArray = $closedRfq->whereYear('updated_at', date('Y'))->get()->toArray();

            //For Array Difference from merged Array and closed Array
            $rfqClosedMonthIds = array_column($rfqMonthArray, 'fk_rfq_id');
            $rfqClosedYearIds = array_column($rfqYearArray, 'fk_rfq_id');

            $diffMonthIds = array_diff($rfqCountThisMonthIds, $rfqClosedMonthIds);
            $diffYearIds = array_diff($rfqCountThisYearIds, $rfqClosedYearIds);

            //Fetching value from diffIds
            $finalRfqMonthList = RFQ::with('subStage:id,name', 'products.product:id,product_name')->whereIn('id', $diffMonthIds)->get();
            $finalRfqYearList = RFQ::with('subStage:id,name', 'products.product:id,product_name')->whereIn('id', $diffYearIds)->get();

            $openRfq = [
                'this_month' => $finalRfqMonthList,
                'this_year' => $finalRfqYearList,
            ];

            $closedRfq = [
                'this_month' => $rfqMonthArray,
                'this_year' => $rfqYearArray,
            ];

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Rfq Lists"]);
            $this->response['data']['open_rfq'] = $openRfq;
            $this->response['data']['closed_rfq'] = $closedRfq;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Rfq Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }


    public function purchaseOrderPdrList()
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $pdrCount = PurchaseOrderPdrQuality::where('created_by', $this->userId)->orderBy('id', 'desc');
            $pdrThisMonth = clone $pdrCount;
            $pdrThisYear = clone $pdrCount;

            $pdrThisMonth = $pdrThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get();
            $pdrThisYear = $pdrThisYear->whereYear('updated_at', date('Y'))->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Purchase Order PDR Quality Lists"]);
            $this->response['data']['pdrThisMonth'] = $pdrThisMonth;
            $this->response['data']['pdrThisYear'] = $pdrThisYear;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order PDR Quality Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function deliveryNoteList()
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $dnCount = PurchaseOrderDneInvoice::where('created_by', $this->userId)->orderBy('id', 'desc');
            $dnThisMonth = clone $dnCount;
            $dnThisYear = clone $dnCount;

            $dnThisMonth = $dnThisMonth->whereYear('updated_at', date('Y'))->whereMonth('updated_at', date('m'))->get();
            $dnThisYear = $dnThisYear->whereYear('updated_at', date('Y'))->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Dashboard Purchase Order Delivery Note Lists"]);
            $this->response['data']['dnThisMonth'] = $dnThisMonth;
            $this->response['data']['dnThisYear'] = $dnThisYear;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Dashboard Purchase Order PDR Quality Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function generatePendingRfqReport($isNationalHead = false)
    {
        $pendingRfqData = ProjectLog::with('rfq.products.product', 'rfq.lead', 'subStage')
            ->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])
            ->where('curr_sub_stage_id', '!=', $this->deliverySubStageId)
            ->whereHas('rfq', function ($query) {
                $query->whereHas('lead');
            })
            ->groupBy('fk_rfq_id')->take(6)->get();

        return $pendingRfqData;
    }

    function generateTaskReport($isNationalHead = false)
    {
        $juniorUserIds = $this->getJuniorIds(false);
        rsort($juniorUserIds);

        if ($this->isManagement || $this->isUserAdmin || $this->isMarketing || $this->isUserHr) {
            $taskData = Task::with('assignedToUsers.user', 'lead', 'rfq', 'assignedBy')->take(6)->orderBy('updated_at', 'desc')->get();
        } else {
            $taskData = Task::with('assignedToUsers.user', 'lead', 'rfq', 'assignedBy')
                ->whereHas('assignedToUsers', function ($query) use ($juniorUserIds) {
                    $query->whereIn('created_by', $juniorUserIds);
                    $query->orWhereIn('fk_user_id', $juniorUserIds);
                })->take(6)->orderBy('updated_at', 'desc')->get();
        }

        return $taskData;
    }

    function taskReport(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $title = $request->title ?? '';
            $fk_status_id = $request->fk_status_id ?? '';
            $fk_rfq_id = $request->fk_rfq_id ?? '';
            $startDate = $request->start ?? '';
            $endDate = $request->end ?? '';
            $dateRange = strtolower($request->date_range) ?? '';
            $fk_task_type_id = $request->fk_task_type_id ?? '';
            $fk_user_id = $request->fk_user_id ?? '';
            $created_by = $request->created_by ?? '';

            if ($this->isManagement || $this->isUserAdmin || $this->isMarketing || $this->isUserHr) {
                $taskData = Task::with('assignedToUsers.user', 'lead', 'rfq', 'assignedBy')->orderBy('updated_at', 'desc');
            } else {
                $taskData = Task::with('assignedToUsers.user', 'lead', 'rfq', 'assignedBy')
                    ->whereHas('assignedToUsers', function ($query) {
                        $query->where('created_by', $this->userId);
                        $query->orWhere('fk_user_id', $this->userId);
                    });
            }

            if ($title) {
                $taskData->where('title', 'like', '%' . $title . '%');
            }

            if ($fk_status_id) {
                $taskData->where('fk_status_id', $fk_status_id);
            }

            if ($fk_rfq_id) {
                $taskData->where('fk_rfq_id', $fk_rfq_id);
            }

            if ($fk_task_type_id) {
                $taskData->where('fk_task_type_id', $fk_task_type_id);
            }

            if ($fk_user_id) {
                $taskData->whereHas('assignedToUsers', function ($query) use ($fk_user_id) {
                    $query->where('fk_user_id', $fk_user_id);
                });
            }

            if ($created_by) {
                $taskData->where('created_by', $created_by);
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $taskData->whereDate('start', date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $taskData->whereDate('start', date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $taskData->whereDate('start', '>=', date('Y-m-d', strtotime('-7 days')));
                    $taskData->whereDate('start', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $taskData->whereDate('start', '>=', date('Y-m-d', strtotime('-14 days')));
                    $taskData->whereDate('start', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $taskData->whereDate('start', '>=', date('Y-m-d', strtotime('-28 days')));
                    $taskData->whereDate('start', '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $taskData->whereMonth('start', date('m'))->whereYear('start', date('Y'));
                }
                if ($dateRange == 'last_month') {
                    $taskData->whereMonth('start', date('m', strtotime('-1 month')));
                }
                if ($dateRange == 'this_year') {
                    $taskData->whereYear('start', date('Y'));
                }
                if ($dateRange == 'last_year') {
                    $taskData->whereYear('start', date('Y', strtotime('-1 year')));
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $taskData->whereDate('start', '>=', $this->convertToDatabaseDateForSearch($startDate));

                        if ($endDate) {
                            $taskData->whereDate('start', '<=', $this->convertToDatabaseDateForSearch($endDate));
                        }
                    }
                }
            }

            $num_rows = $taskData->count();
            $lists = $taskData->limit($per_page)->offset($offset)->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Task"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['list'] = $lists;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Task Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function generateReminderReport($isNationalHead = false)
    {
        $reminderData = Reminder::with('reminderUser.user', 'reminderBy')
            ->whereHas('reminderUser', function ($query) {
                $query->where('created_by', $this->userId);
                $query->orWhere('fk_user_id', $this->userId);
            })->take(6)->get();

        return $reminderData;
    }

    function reminderReport()
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $reminderData = Reminder::with('reminderUser.user', 'reminderBy')
                ->whereHas('reminderUser', function ($query) {
                    $query->where('created_by', $this->userId);
                    $query->orWhere('fk_user_id', $this->userId);
                })->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Reminder"]);
            $this->response['data']['list'] = $reminderData;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Reminder Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function generateQuickReport($isNationalHead = false)
    {
        $quickReportData = MasterReportPreset::where('created_by', $this->userId)->get();
        return $quickReportData;
    }

    function generateVisitDataReport($isNationalHead = false)
    {
        $visitData = SalesVisitReport::with(['lead', 'rfq'])
            ->where('sales_person', $this->userId)
            ->whereMonth('created_at', date('m'))
            ->whereYear('created_at', date('Y'))
            ->orderBy('created_at', 'desc')->take(6)
            ->get();
        $visitData = NewDashboardVisitResource::collection($visitData);

        return $visitData;
    }

    function saleVisitReport()
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $visitData = SalesVisitReport::with(['lead', 'rfq'])
                ->where('sales_person', $this->userId)
                ->whereMonth('created_at', date('m'))
                ->whereYear('created_at', date('Y'))
                ->orderBy('created_at', 'desc')->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Sales Visit Report"]);
            $this->response['data']['list'] = NewDashboardVisitResource::collection($visitData);
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Sales Visit Report Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function pendingRfq()
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $pendingRfqData = ProjectLog::with('rfq.products.product', 'rfq.lead', 'subStage')
                ->whereRaw('FIND_IN_SET(?, curr_user_ids)', [$this->userId])
                ->where('curr_sub_stage_id', '!=', $this->deliverySubStageId)
                ->whereHas('rfq', function ($query) {
                    $query->whereHas('lead');
                })
                ->groupBy('fk_rfq_id')
                ->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Pending RFQ"]);
            $this->response['data']['list'] = $pendingRfqData;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Pending RFQ Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function generateStatisticsReport($isNationalHead = false)
    {
        if ($isNationalHead) {
            $plan = MonthlyPlanExcel::where('month', strtolower(date('F')))->where('year', date('Y'))->get();

            $statisticsData['monthlyTarget'] = array_sum(array_column($plan->toArray(), 'target'));

            $statisticsData['achievedTarget'] = PurchaseOrder::where('is_verified', 1)
                ->whereMonth('po_date', date('m'))
                ->whereYear('po_date', date('Y'))
                ->sum('po_details_total');

            $statisticsData['plannedVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->count();

            $statisticsData['actualVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->where('fk_status_id', 5)->count();
        } else {
            $plan = MonthlyPlanExcel::where('rsm_id', $this->userId)
                ->where('month', strtolower(date('F')))
                ->where('year', date('Y'))
                ->get();

            $statisticsData['monthlyTarget'] = array_sum(array_column($plan->toArray(), 'target'));

            $statisticsData['achievedTarget'] = PurchaseOrder::where('prepared_by', $this->userId)
                ->where('is_verified', 1)
                ->whereMonth('po_date', date('m'))
                ->whereYear('po_date', date('Y'))
                ->sum('po_details_total');

            $statisticsData['plannedVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->count();

            $statisticsData['actualVisit'] = Task::whereIn('monthly_plan_id', array_column($plan->toArray(), 'id'))->where('fk_status_id', 5)->count();
        }

        return $statisticsData;
    }

    function generateTypeOfClientReport($isNationalHead = false)
    {
        $typeOfClientData = ProjectType::withCount('leads')->get();
        return $typeOfClientData;
    }

    function typeOfClientReport()
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $typeOfClientData = ProjectType::with('leads.designation')->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Client Report"]);
            $this->response['data']['list'] = $typeOfClientData;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Client Report Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function generateIndustryReport($isNationalHead = false)
    {
        $industryList = Industry::select('id', 'name')->get()->toArray();

        foreach ($industryList as &$industry) {
            $rfqs = Rfq::where(function ($query) use ($industry) {
                $query->orWhereJsonContains('industry', ['id' => $industry['id']]);
            })->get()->toArray();

            $industry['rfq_count'] = count($rfqs);
        }

        usort($industryList, function ($object1, $object2) {
            return $object1['rfq_count'] < $object2['rfq_count'];
        });

        $industries = array_slice($industryList, 0, 6);

        return $industries;
    }

    function generateSegmentReport($isNationalHead = false)
    {
        $segmentList = ProjectSegment::select('id', 'name')->where('status', 1)->get()->toArray();

        foreach ($segmentList as &$segment) {
            $rfqs = Rfq::where(function ($query) use ($segment) {
                $query->orWhereJsonContains('project_segments', [$segment['id']]);
            })->get()->toArray();

            $segment['rfq_count'] = count($rfqs);
        }

        usort($segmentList, function ($object1, $object2) {
            return $object1['rfq_count'] < $object2['rfq_count'];
        });

        $segments = array_slice($segmentList, 0, 6);

        return $segments;
    }

    function generateZoneReport($isNationalHead = false)
    {
        $zoneList = Region::select('id', 'name')->withCount('lead')->where('status', 1)->get()->toArray();

        return $zoneList;
    }

    private function generateLeadReport($isNationalHead = false): array
    {

        $rsmUserId = $this->userId;

        $rawLeadCount  = Lead::whereNotNull('contact_no')
            ->whereNotNull('email')
            ->whereNull('customer_name')
            ->whereNull('company')
            ->whereNull('address1')
            ->where('assigned_rsm', $rsmUserId)
            ->with('svr', 'rfqs')
            ->whereDoesntHave('rfqs')
            ->whereDoesntHave('svr')
            ->take(1)->get()->toArray();

        $potentialLeadCount  = Lead::whereNotNull('contact_no')
            ->whereNotNull('email')
            ->whereNotNull('customer_name')
            ->whereNotNull('company')
            ->whereNotNull('address1')
            ->where('assigned_rsm', $rsmUserId)
            ->with('svr', 'rfqs')
            ->whereDoesntHave('rfqs')
            ->whereDoesntHave('svr')
            ->take(1)->get()->toArray();

        $prospectLeadCount  = Lead::whereNotNull('contact_no')
            ->whereNotNull('email')
            ->whereNotNull('customer_name')
            ->whereNotNull('company')
            ->whereNotNull('address1')
            ->where('assigned_rsm', $rsmUserId)
            ->whereHas('svr', function ($query) {
                $query->whereNull('application_details');
            })
            ->with('svr', 'rfqs')
            ->whereDoesntHave('rfqs')
            ->take(1)->get()->toArray();


        $leadFinalizedCount  = Lead::whereNotNull('contact_no')
            ->whereNotNull('email')
            ->whereNotNull('customer_name')
            ->whereNotNull('company')
            ->whereNotNull('address1')
            ->where('assigned_rsm', $rsmUserId)
            ->whereHas('svr', function ($query) {
                $query->whereNotNull('application_details');
            })
            ->with('svr', 'rfqs')
            ->whereHas('rfqs')
            ->take(1)->get()->toArray();

        $data = [
            'rawLeadCount' => $rawLeadCount,
            'potentialLeadCount' => $potentialLeadCount,
            'prospectLeadCount' => $prospectLeadCount,
            'leadFinalizedCount' => $leadFinalizedCount,

        ];
        return $data;
    }

    public function generateDayInOutReport($isNationalHead)
    {
        $juniorUserIds = $this->getJuniorIds(true);
        rsort($juniorUserIds);

        // if (count($juniorUserIds) < 2) {
        //   return [];
        // }

        $todayDate = date('Y-m-d');

        if ($this->isManagement || $this->isUserAdmin || $this->isMarketing || $this->isUserHr) {
            $rsmUsers = UserRole::where('fk_department_id', 5)->get();
        } else {
            $rsmUsers = UserRole::where('fk_department_id', 5)->whereIn('fk_user_id', $juniorUserIds)->get();
        }

        $rsmUserIds = $rsmUsers->map(function ($item) {
            return $item->fk_user_id;
        });

        $userAtt = UserAttendance::with('user:id,name')
            ->whereIn('fk_user_id', $rsmUserIds)
            ->whereDate('attendance_date', $todayDate)
            ->orderBy('created_at', 'desc')
            ->take(5)
            ->get()
            ->toArray();


        foreach ($userAtt as &$user) {
            $activityCount = Activity::where('fk_user_id', $user['fk_user_id'])->whereDate('created_at', $todayDate)->count();
            $user['activity_count'] = $activityCount;
        }

        return $userAtt;
    }

    function zoneReport()
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $zoneList = Region::select('id', 'name')->with('lead')->where('status', 1)->get()->toArray();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Zone Report"]);
            $this->response['data']['list'] = $zoneList;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Zone Report Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function industryReport()
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $industryList = Industry::select('id', 'name')->get()->toArray();

            foreach ($industryList as &$industry) {
                $rfqs = Rfq::where(function ($query) use ($industry) {
                    $query->orWhereJsonContains('industry', ['id' => $industry['id']]);
                })->get()->toArray();

                $industry['rfq_count'] = count($rfqs);
            }

            usort($industryList, function ($object1, $object2) {
                return $object1['rfq_count'] < $object2['rfq_count'];
            });

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Segment Report"]);
            $this->response['data']['list'] = $industryList;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Segment Report Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function industryReportLists(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $industryId = $request->id;

            $rfqs = Rfq::whereJsonContains('industry', ['id' => $industryId])->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Industry Report"]);
            $this->response['data']['list'] = $rfqs;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Industry Report Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function segmentReport()
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $segmentList = ProjectSegment::select('id', 'name')->where('status', 1)->get()->toArray();

            foreach ($segmentList as &$segment) {
                $rfqs = Rfq::where(function ($query) use ($segment) {
                    $query->orWhereJsonContains('project_segments', [$segment['id']]);
                })->get()->toArray();

                $segment['rfq_count'] = count($rfqs);
            }

            usort($segmentList, function ($object1, $object2) {
                return $object1['rfq_count'] < $object2['rfq_count'];
            });

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Segment Report"]);
            $this->response['data']['list'] = $segmentList;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Segment Report Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    function segmentReportLists(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $segmentId = $request->id;

            $rfqs = Rfq::whereJsonContains('project_segments', [$segmentId])->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Segment Report"]);
            $this->response['data']['list'] = $rfqs;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Segment Report Lists fetching failed: " . $e->getMessage());
            $this->response['error'] = $e->getMessage();
            return $this->sendResponse($this->response, 500);
        }
    }

    public function leadReport()
    {

        $rsmUserId = $this->userId;

        $rawLeadCount  = Lead::whereNotNull('contact_no')
            ->whereNotNull('email')
            ->whereNull('customer_name')
            ->whereNull('company')
            ->whereNull('address1')
            ->where('assigned_rsm', $rsmUserId)
            ->with('svr', 'rfqs')
            ->whereDoesntHave('rfqs')
            ->whereDoesntHave('svr')
            ->get();

        $potentialLeadCount  = Lead::whereNotNull('contact_no')
            ->whereNotNull('email')
            ->whereNotNull('customer_name')
            ->whereNotNull('company')
            ->whereNotNull('address1')
            ->where('assigned_rsm', $rsmUserId)
            ->with('svr', 'rfqs')
            ->whereDoesntHave('rfqs')
            ->whereDoesntHave('svr')
            ->get();

        $prospectLeadCount  = Lead::whereNotNull('contact_no')
            ->whereNotNull('email')
            ->whereNotNull('customer_name')
            ->whereNotNull('company')
            ->whereNotNull('address1')
            ->where('assigned_rsm', $rsmUserId)
            ->whereHas('svr', function ($query) {
                $query->whereNull('application_details');
            })
            ->with('svr', 'rfqs')
            ->whereDoesntHave('rfqs')
            ->get();

        $leadFinalizedCount  = Lead::whereNotNull('contact_no')
            ->whereNotNull('email')
            ->whereNotNull('customer_name')
            ->whereNotNull('company')
            ->whereNotNull('address1')
            ->where('assigned_rsm', $rsmUserId)
            ->whereHas('svr', function ($query) {
                $query->whereNotNull('application_details');
            })
            ->with('svr', 'rfqs')
            ->whereHas('rfqs')
            ->get();

        $data = [
            'rawLeadCount' => $rawLeadCount,
            'potentialLeadCount' => $potentialLeadCount,
            'prospectLeadCount' => $prospectLeadCount,
            'leadFinalizedCount' => $leadFinalizedCount,

        ];
        return $data;
    }

    public function DayInOut(Request $request)
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $rsmUsers = $request->fk_user_id ?? '';
            $fkRsmId = explode(',', $rsmUsers);
            $fkRsmId = array_filter($fkRsmId, 'strlen');
            $startDate = $request->start_date ?? date('Y-m-d');
            $endDate = $request->end_date;
            $dateRange = strtolower($request->date_range) ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'attendance_date';

            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            if ($this->isManagement || $this->isUserAdmin || $this->isMarketing || $this->isUserHr) {
                $rsmUsers = UserRole::where('fk_department_id', 5)->get();
            } else {
                $rsmUsers = UserRole::where('fk_department_id', 5)->whereIn('fk_user_id', $juniorUserIds)->get();
            }

            $rsmUserIds = $rsmUsers->map(function ($item) {
                return $item->fk_user_id;
            });

            $userAtt = UserAttendance::with('user:id,name')
                ->whereIn('fk_user_id', $rsmUserIds)
                ->orderBy('created_at', 'desc');

            if ($startDate && $endDate) {
                $userAtt->whereBetween('attendance_date', [$startDate, $endDate]);
            } else {
                $userAtt->whereDate('attendance_date', $startDate);
            }

            if ($dateRange) {
                if ($dateRange == 'today') {
                    $userAtt->whereDate($dateColumn, date('Y-m-d'));
                }
                if ($dateRange == 'yesterday') {
                    $userAtt->whereDate($dateColumn, date('Y-m-d', strtotime('-1 day')));
                }
                if ($dateRange == 'last_7_days') {
                    $userAtt->whereDate($dateColumn, '>=', date('Y-m-d', strtotime('-7 days')));
                    $userAtt->whereDate($dateColumn, '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_14_days') {
                    $userAtt->whereDate($dateColumn, '>=', date('Y-m-d', strtotime('-14 days')));
                    $userAtt->whereDate($dateColumn, '<=', date('Y-m-d'));
                }
                if ($dateRange == 'last_28_days') {
                    $userAtt->whereDate($dateColumn, '>=', date('Y-m-d', strtotime('-28 days')));
                    $userAtt->whereDate($dateColumn, '<=', date('Y-m-d'));
                }
                if ($dateRange == 'this_month') {
                    $userAtt->whereMonth($dateColumn, date('m'))->whereYear($dateColumn, date('Y'));
                }

                if ($dateRange == 'last_month') {
                    $userAtt->whereMonth($dateColumn, explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear($dateColumn, explode('-', date('Y-m', strtotime('-1 month')))[0]);
                }

                if ($dateRange == 'this_year') {
                    $userAtt->where(function ($query) use ($fiscalYear, $dateColumn) {
                        $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear)
                                ->whereMonth($dateColumn, '>=', 4);
                        })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                            $inner->whereYear($dateColumn, $fiscalYear + 1)
                                ->whereMonth($dateColumn, '<=', 3);
                        });
                    });
                }

                if ($dateRange == 'last_year') {
                    $userAtt->where(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear - 1)
                            ->whereMonth($dateColumn, '>=', 4);
                    })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
                        $inner->whereYear($dateColumn, $fiscalYear)
                            ->whereMonth($dateColumn, '<=', 3);
                    });
                }

                if ($dateRange == 'custom_date') {
                    if ($startDate) {
                        $userAtt->whereDate($dateColumn, '>=', $startDate);

                        if ($endDate) {
                            $userAtt->whereDate($dateColumn, '<=', $endDate);
                        }
                    }
                }
            }

            if (!empty($fkRsmId) && !empty($rsmUsers)) {
                $userAtt->whereIn('fk_user_id', $fkRsmId);
            }

            $userAtt = $userAtt->get();

            $num_rows = $userAtt->count();

            foreach ($userAtt as $user) {
                $activityCount = Activity::where('fk_user_id', $user->fk_user_id)->whereDate('created_at', $user->attendance_date)->count();
                $user->activity_count = $activityCount;
            }

            $result = $userAtt->slice($offset)->take($per_page)->values();

            $showButton = false;

            if ($this->isManagement || $this->isUserAdmin || $this->isMarketing) {
                $showButton = true;
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Day In / Day Out"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['selectRsm'] = $showButton;
            $this->response['data']['fk_user_id'] = $fkRsmId;
            $this->response['data']['date_range'] = $dateRange ?? '';
            $this->response['data']['list'] = $result;
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Day In Day Out fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function activityList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
            $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
            $offset = ($page - 1) * $per_page;

            $startDate = $request->start_date;
            $endDate = $request->end_date;
            $userId = $request->fk_user_id ?? '';
            $comment = $request->comment ?? '';
            $taskType = $request->taskType ?? '';
            $customer = $request->customer ?? '';
            $rsmId = $request->rsm_id ?? '';
            $activityType = $request->activity_type ?? '';
            $isPhysicalVisit = $request->is_physical_visit ?? '';
            $rfq = $request->rfq ?? '';
            $dateRange = $request->date_range ?? '';
            $isExport = $request->is_export ?? '';

            $dates = $this->getFiscalYearDates();
            $fiscalYear = $dates['fiscalYear'];
            $dateColumn = 'created_at';

            $activities = Activity::with('activityType', 'createdBy:id,name', 'latestActivityLog', 'taskType', 'lead', 'rfq', 'svr')
                ->where('fk_user_id', $rsmId)
                ->orderBy('start_time', 'desc');

            // if ($dateRange) {
            //     if ($dateRange == 'today') {
            //         $activities->whereDate('created_at', date('Y-m-d'));
            //     }
            //     if ($dateRange == 'yesterday') {
            //         $activities->whereDate('created_at', date('Y-m-d', strtotime('-1 day')));
            //     }
            //     if ($dateRange == 'last_7_days') {
            //         $activities->whereDate('created_at', '>=', date('Y-m-d', strtotime('-7 days')));
            //         $activities->whereDate('created_at', '<=', date('Y-m-d'));
            //     }
            //     if ($dateRange == 'last_14_days') {
            //         $activities->whereDate('created_at', '>=', date('Y-m-d', strtotime('-14 days')));
            //         $activities->whereDate('created_at', '<=', date('Y-m-d'));
            //     }
            //     if ($dateRange == 'last_28_days') {
            //         $activities->whereDate('created_at', '>=', date('Y-m-d', strtotime('-28 days')));
            //         $activities->whereDate('created_at', '<=', date('Y-m-d'));
            //     }
            //     if ($dateRange == 'this_month') {
            //         $activities->whereMonth('created_at', date('m'))->whereYear('created_at', date('Y'));
            //     }

            //     if ($dateRange == 'last_month') {
            //         $activities->whereMonth('created_at', explode('-', date('Y-m', strtotime('-1 month')))[1])->whereYear('created_at', explode('-', date('Y-m', strtotime('-1 month')))[0]);
            //     }

            //     if ($dateRange == 'this_year') {
            //         $activities->where(function ($query) use ($fiscalYear, $dateColumn) {
            //             $query->where(function ($inner) use ($fiscalYear, $dateColumn) {
            //                 $inner->whereYear($dateColumn, $fiscalYear)
            //                     ->whereMonth($dateColumn, '>=', 4);
            //             })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
            //                 $inner->whereYear($dateColumn, $fiscalYear + 1)
            //                     ->whereMonth($dateColumn, '<=', 3);
            //             });
            //         });
            //     }

            //     if ($dateRange == 'last_year') {
            //         $activities->where(function ($inner) use ($fiscalYear, $dateColumn) {
            //             $inner->whereYear($dateColumn, $fiscalYear - 1)
            //                 ->whereMonth($dateColumn, '>=', 4);
            //         })->orWhere(function ($inner) use ($fiscalYear, $dateColumn) {
            //             $inner->whereYear($dateColumn, $fiscalYear)
            //                 ->whereMonth($dateColumn, '<=', 3);
            //         });
            //     }

            //     if ($dateRange == 'custom_date') {
            //         if ($startDate) {
            //             $activities->whereDate('created_at', '>=', $startDate);

            //             if ($endDate) {
            //                 $activities->whereDate('created_at', '<=', $endDate);
            //             }
            //         }
            //     }
            // }


            if ($startDate && $endDate) {
                $activities->whereBetween('created_at', [$startDate, $endDate]);
            } else {
                $activities->whereDate('created_at', $startDate);
            }

            if ($customer) {
                $activities->whereHas('lead', function ($q) use ($customer) {
                    if ($customer) $q->where(['id' => $customer, 'status' => 1]);
                });
            }

            if ($rfq) {
                $activities->where('fk_rfq_id', $rfq);
            }

            if ($comment) {
                $activities->where('comment', 'like', '%' . $comment . '%');
            }

            if ($taskType) {
                $activities->where('fk_task_type_id', '=', $taskType);
            }

            if ($activityType) {
                $activities->where('fk_activity_type_id', '=', $activityType);
            }

            if ($isPhysicalVisit) {
                $activities->where('is_physical_visit', '=', $isPhysicalVisit);
            }

            $getDepartment = UserRole::where('fk_user_id', $this->userId)
                ->whereIn('fk_department_id', [2, 4, 3, 10])->get();

            $juniorUserIds = $this->getJuniorIds(true);
            rsort($juniorUserIds);

            if (!$getDepartment->isEmpty() || count($juniorUserIds) > 1) {
                $showRsmFilter = true;
            } else {
                $showRsmFilter = false;
            }

            $num_rows = $activities->count();
            // $result = $activities->skip($offset)->take($per_page)->get();

            if ($isExport == 1) {
                $activityList = $activities->get();
            } else {
                $activityList = $activities->limit($per_page)->offset($offset)->get();
            }

            foreach ($activityList as $res) {
                $attendanceRecord = UserAttendance::where('fk_user_id', $res->fk_user_id)
                    ->whereDate('attendance_date', $res->created_at)
                    ->first();

                if ($attendanceRecord) {
                    $res->checkinTime = $attendanceRecord->checkin_time;
                    $res->checkoutTime = $attendanceRecord->checkout_time;
                } else {
                    $res->checkinTime = null;
                    $res->checkoutTime = null;
                }
            }

            if ($isExport == 1) {

                $spreadsheet = new Spreadsheet();
                $sheet = $spreadsheet->getActiveSheet();
                $headers = ['Sr.No', 'DayIn', 'DayOut', 'Activity Type', 'SVR No.', 'Activity For', 'Location', 'Activity Start Time', 'Activity End Time', 'Total Time', 'Status', 'Comment'];
                $sheetData = [$headers];

                foreach ($activityList as $key => $item) {
                    $totalTime = '-';

                    if (!empty($item->start_time) && !empty($item->end_time)) {
                        $startTime = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->start_time);
                        $endTime = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->end_time);

                        $duration = $endTime->diff($startTime);

                        $hours = $duration->h;
                        $minutes = $duration->i;

                        $totalTime = "{$hours} hrs {$minutes} min";
                    }

                    $activityFor = '';
                    if ($item->taskType && $item->taskType->code == 'other') {
                        $activityFor = 'Other';
                    } elseif ($item->taskType && $item->taskType->code == 'lead') {
                        $activityFor = $item->lead->company . ' (' . $item->lead->customer_name . ')';
                    } elseif ($item->taskType && $item->taskType->code == 'rfq') {
                        $activityFor = $item->rfq->customer_name;
                    }

                    $rowData = [
                        $key + 1,
                        Carbon::parse($item->checkinTime)->format('M d, Y h:i a'),
                        Carbon::parse($item->checkoutTime)->format('M d, Y h:i a'),
                        $item->activityType->title,
                        $item->svr->report_no ?? '-',
                        $activityFor,
                        $item->latestActivityLog->location ?? '-',
                        Carbon::parse($item->start_time)->format('M d, Y h:i a'),
                        Carbon::parse($item->end_time)->format('M d, Y h:i a'),
                        $totalTime,
                        (!empty($item->end_time) ? 'Completed' : 'Ongoing'),
                        $item->comment ?? '-',
                    ];

                    $sheetData[] = $rowData;
                }

                $sheet->fromArray($sheetData, null, 'A1');
                $store = "storage/app/public/uploads/activity/activity.csv";
                $filePath = "storage/uploads/activity/activity.csv";
                $writer = new Csv($spreadsheet);
                $writer->save($store);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Activity"]);
            $this->response['data']['page'] = $page;
            $this->response['data']['per_page'] = $per_page;
            $this->response['data']['filePath'] = $filePath ?? '';
            $this->response['data']['num_rows'] = $num_rows;
            $this->response['data']['start_date'] = $startDate;
            $this->response['data']['end_date'] = $endDate;
            $this->response['data']['task_type'] = $taskType;
            $this->response['data']['activity_type'] = $activityType;
            $this->response['data']['comment'] = $comment;
            $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
            $this->response['data']['list'] = ActivityResource::collection($activityList);
            $this->response['data']['showRsmFilter'] = $showRsmFilter;
            $this->response['data']['rsm_id'] = $rsmId;
            $this->response['data']['date_range'] = $dateRange;
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Lead fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function exportDayInOut(Request $request)
    {

        try {

            $rsmUsers = $request->fk_user_id ?? '';
            $fkRsmId = explode(',', $rsmUsers);
            $fkRsmId = array_filter($fkRsmId, 'strlen');
            $startDate = $request->start_date ?? date('Y-m-d');
            $endDate = $request->end_date;


            $rsmUsers = UserRole::where('fk_department_id', 5)->get();
            $rsmUserIds = $rsmUsers->map(function ($item) {
                return $item->fk_user_id;
            });

            $userAtt = UserAttendance::with('user:id,name')
                ->whereIn('fk_user_id', $rsmUserIds)
                ->orderBy('created_at', 'desc');

            if ($startDate && $endDate) {
                $userAtt->whereBetween('attendance_date', [$startDate, $endDate]);
            } else {
                $userAtt->whereDate('attendance_date', $startDate);
            }

            if (!empty($fkRsmId) && !empty($rsmUsers)) {
                $userAtt->whereIn('fk_user_id', $fkRsmId);
            }

            $userAtt = $userAtt->get();

            foreach ($userAtt as $user) {
                $activityCount = Activity::where('fk_user_id', $user->fk_user_id)
                    ->whereDate('created_at', $user->attendance_date)
                    ->count();
                $user->activity_count = $activityCount;
                if ($activityCount === 0) {
                    $user->activity_count = 0;
                }
            }

            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $headers = ['Sr.No', 'User', 'Day In', 'Day Out', 'Activity'];
            $sheetData = [$headers];

            foreach ($userAtt as $key => $item) {
                $rowData = [
                    $key + 1,
                    $item->user->name,
                    Carbon::parse($item->checkin_time)->format('M d, Y h:i a'),
                    Carbon::parse($item->checkout_time)->format('M d, Y h:i a'),
                    (string)$item->activity_count,
                ];

                $sheetData[] = $rowData;
            }

            $sheet->fromArray($sheetData, null, 'A1');

            // $filePath = $this->fileAccessPath  . "/dayinout/Day_in_out.csv";
            $filePath = "storage/app/public/uploads/dayinout/Day_in_out.csv";
            $writer = new Csv($spreadsheet);
            $writer->save($filePath);

            $this->response['status'] = 1;
            $this->response['msg'] = "File downloaded successfully";
            $this->response['filePath'] = $filePath;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Download failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function exportActivity(Request $request)
    {

        try {

            $startDate = $request->start_date ?? date("Y-m-d");
            $userId = $request->fk_user_id ?? '';
            $endDate = $request->end_date;
            $comment = $request->comment ?? '';
            $taskType = $request->taskType ?? '';
            $customer = $request->customer ?? '';
            $rsmId = $request->rsm_id ?? '';
            $activityType = $request->activity_type ?? '';
            $isPhysicalVisit = $request->is_physical_visit ?? '';
            $rfq = $request->rfq ?? '';

            $activities = Activity::with('activityType', 'latestActivityLog', 'taskType', 'lead', 'rfq', 'svr')
                ->where('fk_user_id', $rsmId)
                ->orderBy('start_time', 'desc');

            if ($startDate && $endDate) {
                $activities->whereBetween('created_at', [$startDate, $endDate]);
            } else {
                $activities->whereDate('created_at', $startDate);
            }

            if ($customer) {
                $activities->whereHas('lead', function ($q) use ($customer) {
                    if ($customer) $q->where(['id' => $customer, 'status' => 1]);
                });
            }

            if ($rfq) {
                $activities->where('fk_rfq_id', $rfq);
            }

            if ($comment) {
                $activities->where('comment', 'like', '%' . $comment . '%');
            }

            if ($taskType) {
                $activities->where('fk_task_type_id', '=', $taskType);
            }

            if ($activityType) {
                $activities->where('fk_activity_type_id', '=', $activityType);
            }

            if ($isPhysicalVisit) {
                $activities->where('is_physical_visit', '=', $isPhysicalVisit);
            }

            $result = $activities->get();


            foreach ($result as $res) {
                $attendanceRecord = UserAttendance::where('fk_user_id', $res->fk_user_id)
                    ->whereDate('attendance_date', $res->created_at)
                    ->first();

                if ($attendanceRecord) {
                    $res->checkinTime = $attendanceRecord->checkin_time;
                    $res->checkoutTime = $attendanceRecord->checkout_time;
                } else {
                    $res->checkinTime = null;
                    $res->checkoutTime = null;
                }
            }

            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $headers = ['Sr.No', 'DayIn', 'DayOut', 'Activity Type', 'SVR No.', 'Activity For', 'Location', 'Activity Start Time', 'Activity End Time', 'Total Time', 'Status', 'Comment'];
            $sheetData = [$headers];

            foreach ($result as $key => $item) {
                $totalTime = '-';

                if (!empty($item->start_time) && !empty($item->end_time)) {
                    $startTime = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->start_time);
                    $endTime = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item->end_time);

                    $duration = $endTime->diff($startTime);

                    $hours = $duration->h;
                    $minutes = $duration->i;

                    $totalTime = "{$hours} hrs {$minutes} min";
                }

                $activityFor = '';
                if ($item->taskType && $item->taskType->code == 'other') {
                    $activityFor = 'Other';
                } elseif ($item->taskType && $item->taskType->code == 'lead') {
                    $activityFor = $item->lead->company . ' (' . $item->lead->customer_name . ')';
                } elseif ($item->taskType && $item->taskType->code == 'rfq') {
                    $activityFor = $item->rfq->customer_name;
                }

                $rowData = [
                    $key + 1,
                    Carbon::parse($item->checkinTime)->format('M d, Y h:i a'),
                    Carbon::parse($item->checkoutTime)->format('M d, Y h:i a'),
                    $item->activityType->title,
                    $item->svr->report_no ?? '-',
                    $activityFor,
                    $item->latestActivityLog->location ?? '-',
                    Carbon::parse($item->start_time)->format('M d, Y h:i a'),
                    Carbon::parse($item->end_time)->format('M d, Y h:i a'),
                    $totalTime,
                    (!empty($item->end_time) ? 'Completed' : 'Ongoing'),
                    $item->comment ?? '-',
                ];

                $sheetData[] = $rowData;
            }

            $sheet->fromArray($sheetData, null, 'A1');

            // $filePath = $this->fileAccessPath  . "/activity/Activity.csv";
            $filePath = "storage/app/public/uploads/activity/Activity.csv";
            $writer = new Csv($spreadsheet);
            $writer->save($filePath);

            $this->response['status'] = 1;
            $this->response['msg'] = "File downloaded successfully";
            $this->response['filePath'] = $filePath;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Download failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }
}
