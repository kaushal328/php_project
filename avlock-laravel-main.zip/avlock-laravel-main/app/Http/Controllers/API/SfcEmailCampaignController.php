<?php

namespace App\Http\Controllers\API;

use App\Models\SfcEmailData;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Models\SfcEmailCampaign;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use App\Http\Controllers\API\AppBaseController;
use App\Http\Resources\SfcEmailCampaignResource;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class SfcEmailCampaignController extends AppBaseController
{

  public function index(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';
      $campaignId = $request->campaign_id ?? '';
      $startDate = $request->start_date ?? '';
      $endDate = $request->end_date ?? '';
      $budget = $request->budget ?? '';

      $sfcEmailCampaign = SfcEmailCampaign::withoutTrashed()->orderBy("id", "desc");
      $numRows = $sfcEmailCampaign->count();

      if ($campaignId) {
        $sfcEmailCampaign->where('campaign_id', 'like', '%' . $campaignId . '%');
      }

      if ($title) {
        $sfcEmailCampaign->where('title', 'like', '%' . $title . '%');
      }

      if ($startDate) {
        $sfcEmailCampaign->where('start_date', '>=', $this->convertToDatabaseDateForSearch($startDate));
      }

      if ($endDate) {
        $sfcEmailCampaign->where('end_date', '<=', $this->convertToDatabaseDateForSearch($endDate));
      }

      if ($budget) {
        $sfcEmailCampaign->where('budget', $budget);
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "SFC Email Campaign"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $per_page ? 1 : ceil($numRows / $per_page);
      $this->response['data']['title'] = $title;
      $this->response['data']['campaign_id'] = $campaignId;
      $this->response['data']['start_date'] = $startDate;
      $this->response['data']['end_date'] = $endDate;
      $this->response['data']['list'] = $sfcEmailCampaign->limit($per_page)->offset($offset)->get();
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SMS Email Campaign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addUpdate(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateSfcEmailCampaign($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $sfcEmailCampaign = new SfcEmailCampaign();
      $id = $request->id;
      $title = $request->title;
      $campaignId = $request->campaign_id;
      $startDate = Carbon::createFromFormat('d/m/Y g:i A', $request->start_date)->format('Y-m-d H:i:s');
      $endDate = Carbon::createFromFormat('d/m/Y g:i A', $request->end_date)->format('Y-m-d H:i:s');
      $budget = $request->budget;
      $status = $request->status;

      if ($id) {
        $sfcEmailCampaign = SfcEmailCampaign::find($id);

        if (!$sfcEmailCampaign) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "SFC Email Campaign"]);
          return $this->sendResponse($this->response, 401);
        }

        $sfcEmailCampaign->first();
        $sfcEmailCampaign->updated_by = $this->userId;
        $this->response['msg'] = __('admin.updated', ['module' => "SFC Email Campaign"]);
      } else {
        $sfcEmailCampaign->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => "SFC Email Campaign"]);
      }

      $sfcEmailCampaign->title = $title;
      $sfcEmailCampaign->campaign_id = $campaignId;
      $sfcEmailCampaign->start_date = $startDate;
      $sfcEmailCampaign->end_date = $endDate;
      $sfcEmailCampaign->budget = $budget;
      $sfcEmailCampaign->status = $status;

      $sfcEmailCampaign->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating SFC Email Campaign: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "SFC Email Campaign"]);
      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $sfcEmailCampaign = SfcEmailCampaign::withoutTrashed()->find($id);
      
      $totalData = SfcEmailData::withoutTrashed()->where('fk_sfc_email_campaign_id', $id)->count();
      
      if (!$sfcEmailCampaign) {
        $this->response['error'] = __('admin.id_not_found', ['module' => 'SFC Email Campaign']);
        return $this->sendResponse($this->response, 400);
      }
    
      $sfcEmailCampaign->first();
      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => 'SFC Email Campaign']);
      $this->response['data'] = $sfcEmailCampaign;
      $this->response['data']['total'] = $totalData;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SFC Email Campaign fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $sfcEmailCampaign = SfcEmailCampaign::find($id);

      if (!$sfcEmailCampaign) {
        $this->response['error'] = __('admin.id_not_found', ['module' => 'SFC Email Campaign']);
        return $this->sendResponse($this->response, 400);
      }

      $sfcEmailCampaign->delete();
      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => 'SFC Email Campaign']);
      $this->response['data'] = $sfcEmailCampaign;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SFC Email Campign deleting failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addReport(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddReport($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      // $sfcEmailCampaign = new SfcEmailCampaign();
      // $totalEmailSent = $request->total_email_sent;
      // $totalEmailDelivered = $request->total_email_delivered;
      // $totalEmailOpened = $request->total_email_opened;
      // $totalEmailClicked = $request->total_email_clicked;
      // $totalEmailBounced = $request->total_email_bounced;
      // $totalEmailFailed = $request->total_email_failed;
      
      $reportDate = $request->report_date ? Carbon::createFromFormat('d/m/Y g:i A', $request->report_date)->format('Y-m-d H:i:s') : null;
      $id = $request->id;
      $totalData = $request->total_data;
      $delivered = $request->delivered;
      $deliveryRate = $request->delivery_rate;
      $opens = $request->opens;
      $openRate = $request->open_rate;
      $enquireNow = $request->enquire_now;
      $facebook = $request->facebook;
      $twitter = $request->twitter;
      $instagram = $request->instagram;
      $linkedin = $request->linkedin;
      $pinterest = $request->pinterest;
      $website = $request->website;
      $totalClicks = $request->total_clicks;
      // $clicks = $request->clicks;
      $clickToOpenRate = $request->click_to_open_rate;
      $unsubscribe = $request->unsubscribe;
      $unsubscribeRate = $request->unsubscribe_rate;
      $bounce = $request->bounce;
      $bounceRate = $request->bounce_rate;

      if ($id) {
        $sfcEmailCampaign = SfcEmailCampaign::find($id);

        if (!$sfcEmailCampaign) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "SFC Email Campaign"]);
          return $this->sendResponse($this->response, 400);
        }

        $sfcEmailCampaign->first();
        // $sfcEmailCampaign->total_email_sent = $totalEmailSent;
        // $sfcEmailCampaign->total_email_delivered = $totalEmailDelivered;
        // $sfcEmailCampaign->total_email_opened = $totalEmailOpened;
        // $sfcEmailCampaign->total_email_clicked = $totalEmailClicked;
        // $sfcEmailCampaign->total_email_bounced = $totalEmailBounced;
        // $sfcEmailCampaign->total_email_failed = $totalEmailFailed;
        $sfcEmailCampaign->report_date = $reportDate;
        $sfcEmailCampaign->total_data = $totalData;
        $sfcEmailCampaign->delivered = $delivered;
        $sfcEmailCampaign->delivery_rate = $deliveryRate;
        $sfcEmailCampaign->opens = $opens;
        $sfcEmailCampaign->open_rate = $openRate;
        $sfcEmailCampaign->enquire_now = $enquireNow;
        $sfcEmailCampaign->facebook = $facebook;
        $sfcEmailCampaign->twitter = $twitter;
        $sfcEmailCampaign->instagram = $instagram;
        $sfcEmailCampaign->linkedin = $linkedin;
        $sfcEmailCampaign->pinterest = $pinterest;
        $sfcEmailCampaign->website = $website;
        $sfcEmailCampaign->total_clicks = $totalClicks;
        // $sfcEmailCampaign->clicks = $clicks;
        $sfcEmailCampaign->click_to_open_rate = $clickToOpenRate;
        $sfcEmailCampaign->unsubscribe = $unsubscribe;
        $sfcEmailCampaign->unsubscribe_rate = $unsubscribeRate;
        $sfcEmailCampaign->bounce = $bounce;
        $sfcEmailCampaign->bounce_rate = $bounceRate;
        $sfcEmailCampaign->updated_by = $this->userId;

        $sfcEmailCampaign->save();
        $this->response['msg'] = __('admin.updated', ['module' => "SFC Email Campaign"]);
      }

      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Report: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "SFC Email Campaign"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function listData(REQUEST $request)
  {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $fkSfcEmailCampaignId = $request->sfc_email_campaign_id ?? '';
      $name = $request->name ?? '';
      $address = $request->address ?? '';
      $city = $request->city ?? '';
      $mobile = $request->mobile ?? '';
      $email = $request->email ?? '';

      $sfcEmailData = SfcEmailData::with('campaign');
      $numRows = $sfcEmailData->count();

      if ($fkSfcEmailCampaignId) {
        $sfcEmailData->whereHas('campaign', function ($query) use ($fkSfcEmailCampaignId) {
          $query->where('fk_sfc_email_campaign_id', $fkSfcEmailCampaignId);
        });
      }

      if ($name) {
        $sfcEmailData->where('name', 'like', '%' . $name . '%');
      }

      if ($address) {
        $sfcEmailData->where('address', 'like', '%' . $address . '%');
      }

      if ($city) {
        $sfcEmailData->where('city', 'like', '%' . $city . '%');
      }

      if ($mobile) {
        $sfcEmailData->where('mobile', 'like', '%' . $mobile . '%');
      }

      if ($email) {
        $sfcEmailData->where('email', 'like', '%' . $email . '%');
      }

      $sfcEmailData = $sfcEmailData->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "SFC Email Data"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $numRows;
      $this->response['data']['total_pages'] = $numRows < $per_page ? 1 : ceil($numRows / $per_page);
      $this->response['data']['sfc_email_campaign_id'] = $fkSfcEmailCampaignId;
      $this->response['data']['name'] = $name;
      $this->response['data']['address'] = $address;
      $this->response['data']['city'] = $city;
      $this->response['data']['email'] = $email;
      $this->response['data']['mobile'] = $mobile;
      $this->response['data']['list'] = SfcEmailCampaignResource::collection($sfcEmailData);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SFC Email Data fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function addData(REQUEST $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $files = $request->excel ?? [];

      $validationErrors = $this->validateAddData($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }
      foreach ($files as $item) {

        $filePath = storage_path('app/public/uploads/temp/' . $item['filename']);
        $sourcePath = 'public/uploads/temp/' .  $item['filename'];

        if (!Storage::exists($sourcePath)) {

          $this->response['error'] = __('admin.file_not_found', ['file' => $item['filename']]);
          return $this->sendResponse($this->response, 401);
        }

        $spreadsheet = IOFactory::load($filePath);
        $sheetNames = $spreadsheet->getSheetNames();
        $dataRecords = [];

        foreach ($sheetNames as $sheetName) {
          $worksheet = $spreadsheet->getSheetByName($sheetName);
          $cellIterator = $worksheet->getRowIterator()->current()->getCellIterator();
          $cellIterator->setIterateOnlyExistingCells(true);

          $headers = [];
          foreach ($cellIterator as $cell) {
            if ($cell->getValue() != '') {
              $headers[] = $cell->getValue();
            }
          }

          if (array_values($headers) != array_values(config('global.SFCEMAILCAMPAIGN_DATA_HEADER_FORMAT'))) {
            $this->response['error'] = __('admin.excel_format_error', ['file' => $item['filename'], 'sheet' => $sheetName]);
            return $this->sendResponse($this->response, 200);
          }


          $highestRow = $worksheet->getHighestRow();
          $dataRecords = [];

          for ($row = 2; $row <= $highestRow; $row++) {
            $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
            $dataRecords[] = $rowData[$row];
          }
        }

        foreach ($dataRecords as $data) {
          SfcEmailData::create([
            'name' => convertToCamelCase($data['A']),
            'mobile' => $data['B'],
            'email' => $data['C'],
            'address' => convertToCamelCase($data['D']),
            'city' => convertToCamelCase($data['E']),
            'fk_sfc_email_campaign_id' => $id
          ]);
        }

        $this->response['status'] = 1;
        $this->response['msg'] = __('admin.created', ['module' => "SFC Email Data"]);
        return $this->sendResponse($this->response, 200);
      }
    } catch (\Exception $e) {
      Log::error("Failed Creating SFC Email Excel Data: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "SFC Email Data"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function addDataSingle(REQUEST $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddDataSingle($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $sfcEmailData = new SfcEmailData();
      $id = $request->id;
      $sfcEmailCampaignId = $id;
      $name = $request->name;
      $address = $request->address;
      $city = $request->city;
      $email = $request->email;
      $mobile = $request->mobile;

      if ($id) {
        $sfcEmailData = new SfcEmailData();

        if (!$sfcEmailData) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "SFC Email Data"]);
          return $this->sendResponse($this->response, 401);
        }

        $sfcEmailData->fk_sfc_email_campaign_id = $sfcEmailCampaignId;
        $sfcEmailData->name = $name;
        $sfcEmailData->address = $address;
        $sfcEmailData->city = $city;
        $sfcEmailData->email = $email;
        $sfcEmailData->mobile = $mobile;
      }

      $sfcEmailData->save();
      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.created', ['module' => "SFC Email Data"]);
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating SFC Email Data: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "SFC Email Data"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function deleteData(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $sfcEmailData = SfcEmailData::find($id);

      if (!$sfcEmailData) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "SFC Email Data"]);
        return $this->sendResponse($this->response, 401);
      }

      $sfcEmailData->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "SFC Email Data"]);
      $this->response['data'] = $sfcEmailData;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("SFC Email Data deleting failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }


  private function validateAddDataSingle(REQUEST $request)
  {
    return Validator::make(
      $request->all(),
      [
        'id' => 'required|exists:sfc_email_campaigns,id,deleted_at,NULL',
        'name' => 'required',
        'address' => 'required',
        'city' => 'required',
        'email' => 'required',
        'mobile' => 'required',
      ],
      [
        'id.exists' => "SFC Email Campaign doesn't exists with provided id",
      ]
    )->errors();
  }

  private function validateAddData(REQUEST $request)
  {
    return Validator::make(
      $request->all(),
      [
        'id' => 'required|exists:email_campaigns,id,deleted_at,NULL',
        'excel' => 'required',
      ],
      [
        'id.exists' => "Campaign doesn't exists with provided id",
      ]
    )->errors();
  }

  private function validateAddReport(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'report_date' => 'nullable|date_format:d/m/Y g:i A',
        'total_data' => 'nullable|integer',
        'delivered' => 'nullable|integer',
        'delivery_rate' => 'nullable|numeric',
        'opens' => 'nullable|integer',
        'open_rate' => 'nullable|numeric',
        'enquire_now' => 'nullable|integer',
        'facebook' => 'nullable|integer',
        'twitter' => 'nullable|integer',
        'instagram' => 'nullable|integer',
        'linkedin' => 'nullable|integer',
        'pinterest' => 'nullable|integer',
        'website' => 'nullable|integer',
        'total_clicks' => 'nullable|integer',
        // 'clicks' => 'nullable|integer',
        'click_to_open_rate' => 'nullable|numeric',
        'unsubscribe' => 'nullable|integer',
        'unsubscribe_rate' => 'nullable|numeric',
        'bounce' => 'nullable|integer',
        'bounce_rate' => 'nullable|numeric',
      ],
      [
        'report_date.date_format' => 'Invalid Date Format',
      ]
    )->errors();
  }

  private function validateAddUpdateSfcEmailCampaign(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'title' => 'required|string|unique:sfc_email_campaigns,title,' . $request->id . ',id,deleted_at,NULL',
        'campaign_id' => 'required|string|unique:sfc_email_campaigns,campaign_id,' . $request->id . ',id,deleted_at,NULL',
        'start_date' => 'required|date_format:d/m/Y g:i A',
        'end_date' => 'required|date_format:d/m/Y g:i A|after:start_date',
        'budget' => 'sometimes|required|numeric',
        'status' => 'sometimes|required|integer|in:0,1',
      ],
      [
        'title.unique' => 'Campaign name already exist',
        'campaign_id.unique' => 'Campaign ID already exist',
        'start_date.date_format' => 'Invalid Date Format',
        'end_date.date_format' => 'Invalid Date Format',
      ]
    )->errors();
  }
}
