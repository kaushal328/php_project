<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\LoginLog;
use App\Models\User;
use App\Models\UserRole;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;

class ProfileController extends AppBaseController
{
    public function get(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $userId = $this->userId;
            $userObject = User::where('id', $userId)->first();

            if (!$userObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "User"]);
                return $this->sendResponse($this->response, 200);
            }

            $userRoles = UserRole::select('id', 'fk_department_id as department_id', 'fk_department_type_id as department_type_id')->where('fk_user_id', $userId)->get();
            $userObject->department_and_role = $userRoles;

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "User Profile"]);
            $this->response['data'] = $userObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("User Profile fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function update(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $validationErrors = $this->validateUpdateProfile($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $userId = $this->userId;
            $userObject = User::where('id', $userId)->first();

            if (!$userObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "User"]);
                return $this->sendResponse($this->response, 200);
            }


            $name = $request->name;
            $email = $request->email;
            $mobile = $request->mobile;
            $address = $request->address ?? '';
            $images = $request->image;

            $userObject->name = $name;
            $userObject->email = $email;
            $userObject->mobile = $mobile;
            $userObject->address = $address;
            foreach ($images as $item) {
                moveFile('profile/image/', $item['filename']);
                $path = $this->fileAccessPath . "/profile/image/" . $item['filename'];
                $userObject->image = $path;
            }
            $userObject->save();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.updated', ['module' => "User Profile"]);

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed Updating Profile: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Task"]);

            return $this->sendResponse($this->response, 500);
        }
    }

    public function loginHistory(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $userId = $this->userId;
            $userObject = User::where('id', $userId)->first();

            if (!$userObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "User"]);
                return $this->sendResponse($this->response, 200);
            }

            $userLoginHistoryObject = LoginLog::where('email', $userObject->email)->orderBy('id', 'desc')->get();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.fetched', ['module' => "Login History"]);
            $this->response['data'] = $userLoginHistoryObject;

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Login History fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function changePassword(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            if (!$this->isUserAdmin) {
                $this->response['error'] = "Change password is disabled by admin!";
                return $this->sendResponse($this->response, 200);
            }

            $validationErrors = $this->validateChangePassword($request);

            if (count($validationErrors)) {
                Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
                $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
                return $this->sendResponse($this->response, 200);
            }

            $userId = $this->userId;
            $userObject = User::where('id', $userId)->first();

            if (!$userObject) {
                $this->response['error'] = __('admin.id_not_found', ['module' => "User"]);
                return $this->sendResponse($this->response, 200);
            }


            $currentPassword = $request->current_password;
            $password = $request->password;

            if (!Hash::check($currentPassword, $userObject->password)) {
                $this->response['error'] = 'The current password is incorrect.';
                return $this->sendResponse($this->response, 200);
            }

            $userObject->password = Hash::make($password);
            $userObject->p = $password;
            $userObject->save();

            $this->response['status'] = 1;
            $this->response['msg'] = __('admin.updated', ['module' => "Password"]);

            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed Updating Password: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Task"]);

            return $this->sendResponse($this->response, 401);
        }
    }

    private function validateUpdateProfile(Request $request)
    {
        return Validator::make(
            $request->all(),
            [
                'name' => 'required|string',
                'email' => 'required|string|email|max:255|unique:users,email,' . $this->userId . ',id,deleted_at,NULL',
                'mobile' => 'required|string|regex:/^[6-9]\d{9}$/|unique:users,mobile,' . $this->userId . ',id,deleted_at,NULL',
            ]
        )->errors();
    }

    private function validateChangePassword(Request $request)
    {
        return Validator::make(
            $request->all(),
            [
                'current_password' => 'required',
                'password' => ['required', 'confirmed', Password::defaults()]
            ]
        )->errors();
    }
}
