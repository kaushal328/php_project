<?php

namespace App\Http\Controllers\API;

use Exception;
use App\Models\Division;
use App\Models\Industry;
use App\Models\NewCampaign;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Models\NewCampaignData;
use App\Models\NewCampaignType;
use App\Models\NewCampaignReport;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Models\NewCampaignMasterData;
use App\Models\NewCampaignTypePlatform;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Illuminate\Support\Facades\Validator;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use App\Models\NewCampaignMasterDataEntry;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use App\Http\Controllers\API\AppBaseController;
use Dompdf\Dompdf;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class NewCampaignController extends AppBaseController {

  function masterDataList(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $list = NewCampaignMasterData::withCount('entries')->orderBy('updated_at', 'desc')->get()->toArray();

      foreach ($list as &$ncd) {
        $ncd['industries'] = Industry::whereIn('id', $ncd['industry_ids'])->get()->pluck('name')->implode(', ');
        $ncd['divisions'] = Division::whereIn('id', $ncd['division_ids'])->get()->pluck('name')->implode(', ');
      }

      $this->response['status'] = 1;
      $this->response['data']['list'] = $list;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Campaign viewMasterData failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function getCampaignDetail(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id ?? '';
      $newCampaign = NewCampaign::find($id);

      $data = NewCampaignData::with('masterDataEntry:id')->where('campaign_id', $id)->get();
      $entriesIds = $data->pluck('masterDataEntry.id')->toArray();
      $camapignDetailVals = compact('newCampaign', 'entriesIds');


      $this->response['status'] = 1;
      $this->response['data'] = $camapignDetailVals;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Campaign viewMasterData failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function viewMasterData(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $masterDataId = $request->id;
      $masterData = NewCampaignMasterData::withCount('entries')->find($masterDataId)->toArray();

      $masterData['industries'] = Industry::whereIn('id', $masterData['industry_ids'])->get()->pluck('name')->implode(', ');
      $masterData['divisions'] = Division::whereIn('id', $masterData['division_ids'])->get()->pluck('name')->implode(', ');

      if (!$masterData) {
        $this->response['error'] = 'Master Data details not found! Please try again.';
        return $this->sendResponse($this->response, 200);
      }

      $masterDataEntries = NewCampaignMasterDataEntry::where('master_data_id', $masterData['id'])->get();

      $data = [
        'master_data' => $masterData,
        'master_data_entries' => $masterDataEntries
      ];

      $this->response['status'] = 1;
      $this->response['data'] = $data;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Campaign viewMasterData failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function masterDataEntry(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $masterId = $request->id ?? "";
      $company = $request->company ?? "";
      $industry = $request->industry ?? "";
      $designation = $request->designation ?? '';

      $masterDataObject = NewCampaignMasterDataEntry::where('master_data_id',  $masterId);

      if ($company) $masterDataObject->where('company', 'like', '%' . $company . '%');
      if ($industry) $masterDataObject->where('industry', 'like', '%' . $industry . '%');
      if ($designation) $masterDataObject->where('designation', 'like', '%' . $designation . '%');

      $num_rows = $masterDataObject->count();

      $result = $masterDataObject->limit($per_page)->offset($offset)->get();


      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Master Data"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['company'] = $company;
      $this->response['data']['industry'] = $industry;
      $this->response['data']['designation'] = $designation;
      $this->response['data']['list'] = $result;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Master Data List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function saveMasterData(Request $request) {
    try {

      ini_set('memory_limit', '256M');
      DB::beginTransaction();
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->saveMasterDataValidation($request->post());
      if (count($validationErrors)) {
        $this->response['errors'] = $this->formatValidationErrors($validationErrors);
        return $this->sendResponse($this->response, 200);
      }

      $masterDataId = $request->id;

      $masterData = new NewCampaignMasterData();
      $masterData->created_by = $this->userId;

      if ($masterDataId) {
        $masterData = NewCampaignMasterData::find($masterDataId);
        if (!$masterData) {
          $this->response['error'] = "Master Data record not found! Please try again.";
          return $this->sendResponse($this->response, 200);
        }
      }

      $masterData->title = $request->title ?? '';
      $masterData->division_ids = implode(',', $request->division_ids) ?? '';
      $masterData->industry_ids = implode(',', $request->industry_ids) ?? '';
      $masterData->updated_by = $this->userId;
      $masterData->save();

      $masterDataFile = $request->file;
      $masterDataId = $masterData->id;

      if (empty($request->id)) {
        $filePath = storage_path('app/public/uploads/temp/' . $masterDataFile);
        $spreadsheet = IOFactory::load($filePath);
        $sheetNames = $spreadsheet->getSheetNames();

        $sheetName = $sheetNames[0];
        $worksheet = $spreadsheet->getSheetByName($sheetName);

        $cellIterator = $worksheet->getRowIterator()->current()->getCellIterator();
        $cellIterator->setIterateOnlyExistingCells(true);

        $headers = [];
        foreach ($cellIterator as $cell) {
          if ($cell->getValue() != '') {
            $headers[] = $cell->getValue();
          }
        }

        if (array_values($headers) != array_values(config('global.MASTER_CAMPAIGN_FILE_HEADER_FORMAT'))) {
          $this->response['error'] = __('admin.excel_format_error', ['file' => $masterDataFile, 'sheet' => $sheetName]);
          return $this->sendResponse($this->response, 200);
        }

        $highestRow = $worksheet->getHighestRow();
        $chunkSize = 100;

        for ($startRow = 2; $startRow <= $highestRow; $startRow += $chunkSize) {
          $endRow = min($startRow + $chunkSize - 1, $highestRow);

          $dataRecords = [];
          for ($row = $startRow; $row <= $endRow; $row++) {
            $rowData = $worksheet->rangeToArray('A' . $row . ':' . Coordinate::stringFromColumnIndex(count($headers)) . $row, null, true, true, true);
            if (!empty(array_filter($rowData[$row]))) {
              $dataRecords[] = $rowData[$row];
            }
          }
          foreach ($dataRecords as $record) {
            $masterDataEntry = new NewCampaignMasterDataEntry();
            $masterDataEntry->master_data_id = $masterDataId;
            $masterDataEntry->company = $record['B'] ?? '';
            $masterDataEntry->industry = $record['C'] ?? '';
            $masterDataEntry->address_1 = $record['D'] ?? '';
            $masterDataEntry->address_2 = $record['E'] ?? '';
            $masterDataEntry->city = $record['F'] ?? '';
            $masterDataEntry->state = $record['G'] ?? '';
            $masterDataEntry->pincode = $record['H'] ?? '';
            $masterDataEntry->email = $record['I'] ?? '';
            $masterDataEntry->contact_number = $record['J'] ?? '';
            $masterDataEntry->contact_person = $record['K'] ?? '';
            $masterDataEntry->designation = $record['L'] ?? '';
            $masterDataEntry->product_focus = $record['M'] ?? '';
            $masterDataEntry->created_by = $this->userId;
            $masterDataEntry->updated_by = $this->userId;

            $masterDataEntry->save();
          }
        }
      }
      DB::commit();

      $this->response['status'] = 1;
      $this->response['msg'] = "Master Data updated successfully";
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Campaign saveMasterData failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function getMasterDataEntryList(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $masterDataId = $request->master_data_id;

      $list = NewCampaignMasterDataEntry::where('master_data_id', $masterDataId)->orderBy('updated_at', 'desc');

      $data['list'] = $list->get();

      $this->response['status'] = 1;
      $this->response['data'] = $data;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Campaign downloadCampaignData failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function masterDataEntryCampaign(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $masterDataId = $request->master_data_id ?? '';

      $list = NewCampaignMasterDataEntry::where('master_data_id', $masterDataId)->get();

      $this->response['status'] = 1;
      $this->response['data']['list'] = $list;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Campaign viewMasterData failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function deleteMasterCampaign(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $masterDataObject = NewCampaignMasterData::find($id);

      if (!$masterDataObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "New Master Campaign"]);
        return $this->sendResponse($this->response, 401);
      }

      $masterDataObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "New Master Campaign"]);
      $this->response['data'] = $masterDataObject;



      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("New Master Campaign Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function saveCampaign(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->saveCampaignValidation($request->post());
      if (count($validationErrors)) {
        $this->response['errors'] = $this->formatValidationErrors($validationErrors);
        return $this->sendResponse($this->response, 200);
      }

      $campaignId = $request->id;

      $campaign = new NewCampaign();
      $campaign->created_by = $this->userId;

      if ($campaignId) {
        $campaign = NewCampaign::find($campaignId);
        if (!$campaign) {
          $this->response['error'] = "Campaign record not found! Please try again.";
          return $this->sendResponse($this->response, 200);
        }
        $this->response['msg'] = __('admin.updated', ['module' => "Campaign"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Campaign"]);
      }

      $masterDataEntryIds = $request->master_data_entry_ids ?? [];
      if (count($masterDataEntryIds) == 0) {
        $this->response['error'] = 'Please select at least one entry';
        return $this->sendResponse($this->response, 200);
      }

      $campaignType = NewCampaignType::find($request->campaign_type_id);

      if ($campaignType->department_type == 1 && empty($request->rsm_user_id)) {
        $this->response['errors']['rsm_user_id'] = 'Please select RSM User';
        return $this->sendResponse($this->response, 200);
      }

      if ($campaignType->department_type == 2 && empty($request->marketing_user_id)) {

        $this->response['errors']['marketing_user_id'] = 'Please select Marketing User';
        return $this->sendResponse($this->response, 200);
      }

      $campaign->title = $request->title ?? '';
      $campaign->our_campaign_id = $request->our_campaign_id ?? '';
      $campaign->their_campaign_id = $request->their_campaign_id ?? '';
      $campaign->campaign_type_id = $request->campaign_type_id ?? '';
      $campaign->campaign_platform_id = $request->campaign_platform_id ?? '';
      $campaign->rsm_user_id = $request->rsm_user_id ?? '';
      $campaign->marketing_user_id = $request->marketing_user_id ?? '';
      $campaign->master_data_id = $request->master_data_id ?? '';
      $campaign->start_date = Carbon::createFromFormat('d/m/Y', $request->start_date)->format('Y-m-d H:i:s') ?? '';
      $campaign->end_date = Carbon::createFromFormat('d/m/Y', $request->end_date)->format('Y-m-d H:i:s') ?? '';
      $campaign->budget = $request->budget ?? '';
      $campaign->save();

      $campaignId = $campaign->id;

      NewCampaignData::where('campaign_id', $campaignId)->delete();
      foreach ($masterDataEntryIds as $entry) {
        $deletedEntry = NewCampaignData::withTrashed()->where(['campaign_id' => $campaignId, 'master_data_entry_id' => $entry])->first();
        if ($deletedEntry) {
          $deletedEntry->restore();
        } else {
          $campaignData = new NewCampaignData();
          $campaignData->campaign_id = $campaignId;
          $campaignData->master_data_entry_id = $entry;
          $campaignData->save();
        }
      }
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Campaign saveCampaign failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function commonCampaignLists() {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $campaignTypeList = NewCampaignType::where('status', 1)->get();
      $campaignMasterDataList = NewCampaignMasterData::where('status', 1)->get();

      $this->response['status'] = 1;
      $this->response['data'] = [
        'camapignType' => $campaignTypeList,
        'campaignMasterData' => $campaignMasterDataList,
      ];

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Common Campaign List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function CampaignTypePlatformLists(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $campaignTypeId = $request->campaign_type_id;

      $campaignTypePlatformList = NewCampaignTypePlatform::where('status', 1)->where('campaign_type_id', $campaignTypeId)->get();

      $this->response['status'] = 1;
      $this->response['data'] = [
        'camapignTypePlatform' => $campaignTypePlatformList,
      ];

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Campaign Type Platform List fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function downloadCampaignData(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }
    } catch (Exception $e) {
      Log::error("Campaign downloadCampaignData failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function exportExcel(Request $request) {

    try {

      $campaignId = $request->id;
      $data = NewCampaignData::with('masterDataEntry')->where('campaign_id', $campaignId)->get();
      $entriesIds = $data->pluck('masterDataEntry');

      $spreadsheet = new Spreadsheet();
      $sheet = $spreadsheet->getActiveSheet();
      $headers = ['Sr.No', 'Company Name', 'Industry', 'Address Line 1', 'Address Line 2', 'City', 'State', 'Pincode', 'Email', 'Phone No', 'Contact Person', 'Designation', 'Product Focus'];
      $sheet->fromArray([$headers], null, 'A1');

      foreach ($entriesIds as $key => $item) {
        $rowData = [
          $key + 1,
          $item->company,
          $item->industry,
          $item->address_1,
          $item->address_2,
          $item->city,
          $item->state,
          $item->pincode,
          $item->email,
          $item->phone_no,
          $item->contact_person,
          $item->designation,
          $item->product_focus,
        ];

        $sheet->fromArray([$rowData], null, 'A' . ($key + 2));
      }

      $filePath = $this->fileAccessPath  . "/campaign/Master_data_entries.xlsx";
      $writer = new Xlsx($spreadsheet);
      $writer->save($filePath);

      $this->response['status'] = 1;
      $this->response['msg'] = "File downloaded successfully";
      $this->response['filePath'] = $filePath;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("File Download failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }




  function getCampaignList(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $campaignTypeId = $request->campaign_type_id ?? '';
      $title = $request->title ?? '';
      $budget = $request->budget ?? '';
      $our_campaign_id = $request->our_campaign_id ?? "";
      $their_campaign_id = $request->their_campaign_id ?? "";


      $newCampaignObject = NewCampaign::where('campaign_type_id', $campaignTypeId);

      if ($budget) $newCampaignObject->where('budget', 'like', '%' . $budget . '%');
      if ($title) $newCampaignObject->where('title', 'like', '%' . $title . '%');
      if ($our_campaign_id) $newCampaignObject->where('our_campaign_id', 'like', '%' . $our_campaign_id . '%');
      if ($their_campaign_id) $newCampaignObject->where('their_campaign_id', 'like', '%' . $their_campaign_id . '%');

      $num_rows = $newCampaignObject->count();

      $result = $newCampaignObject->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['title'] = $title;
      $this->response['data']['their_campaign_id'] = $their_campaign_id;
      $this->response['data']['our_campaign_id'] = $our_campaign_id;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = $result;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Campaign view MasterData failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function viewCampaignDetail(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id ?? '';

      $list = NewCampaign::with('rsmUsers:id,name', 'marketingUsers:id,name', 'masterData:id,title', 'campaignType:id,title', 'campaignPlatform:id,title')->orderBy('updated_at', 'desc')->find($id);

      if (!$list) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "New Campaign"]);
        return $this->sendResponse($this->response, 200);
      }

      $this->response['status'] = 1;
      $this->response['data']['campaign_detail'] = $list;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Campaign View failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  function viewCampaignMaster(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $campaignId = $request->campaign_id ?? '';

      $list = NewCampaignData::where('campaign_id', $campaignId)->get()->toArray();

      $masterEntryIds = [];
      foreach ($list as $item) {
        $masterEntryIds[] = $item['master_data_entry_id'] ?? '';
      }

      $ids = array_unique($masterEntryIds);
      $masterDataEntryList = NewCampaignMasterDataEntry::whereIn('id', $ids)->get()->toArray();

      $this->response['status'] = 1;
      $this->response['data']['list'] = $masterDataEntryList;
      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Campaign Master View failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addReport(REQUEST $request) {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddReport($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $campaignId = $request->campaign_id;
      $totalData = $request->total_data;
      $delivered = $request->delivered;
      $DeliveryRate = $request->delivery_rate;
      $opens = $request->opens;
      $openRate = $request->open_rate;
      $enquireNow = $request->enquire_now;
      $facebook = $request->facebook;
      $twitter = $request->twitter;
      $instagram = $request->instagram;
      $linkedin = $request->linkedin;
      $pinterest = $request->pinterest;
      $website = $request->website;
      $totalClicks = $request->total_clicks;
      $clicks = $request->clicks;
      $clickToOpenRate = $request->click_to_open_rate;
      $unsubscribe = $request->unsubscribe;
      $unsubscribeRate = $request->unsubscribe_rate;
      $bounce = $request->bounce;
      $bounceRate = $request->bounce_rate;
      $reportDate = $request->report_date ? Carbon::createFromFormat('d/m/Y g:i A', $request->report_date)->format('Y-m-d H:i:s') : null;


      $campaignReportObject = NewCampaignReport::where('campaign_id', $campaignId)->first();

      if (!$campaignReportObject) {
        $campaignReportObject = new NewCampaignReport();
        $campaignReportObject->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => 'Campaign Report']);
      } else {
        $campaignReportObject->updated_by = $this->userId;
        $this->response['msg'] = __('admin.updated', ['module' => 'Campaign Report']);
      }

      $campaignReportObject->campaign_id = $campaignId;
      $campaignReportObject->report_date = $reportDate;
      $campaignReportObject->total_data = $totalData;
      $campaignReportObject->delivered = $delivered;
      $campaignReportObject->delivery_rate = $DeliveryRate;
      $campaignReportObject->opens = $opens;
      $campaignReportObject->open_rate = $openRate;
      $campaignReportObject->enquire_now = $enquireNow;
      $campaignReportObject->facebook = $facebook;
      $campaignReportObject->twitter = $twitter;
      $campaignReportObject->instagram = $instagram;
      $campaignReportObject->linkedin = $linkedin;
      $campaignReportObject->pinterest = $pinterest;
      $campaignReportObject->website = $website;
      $campaignReportObject->total_clicks = $totalClicks;
      $campaignReportObject->clicks = $clicks;
      $campaignReportObject->click_to_open_rate = $clickToOpenRate;
      $campaignReportObject->unsubscribe = $unsubscribe;
      $campaignReportObject->unsubscribe_rate = $unsubscribeRate;
      $campaignReportObject->bounce = $bounce;
      $campaignReportObject->bounce_rate = $bounceRate;
      $campaignReportObject->updated_by = $this->userId;

      $campaignReportObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Report: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Campaign Report"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function getCampaignReportDetail(Request $request) {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $camapignId = $request->campaign_id ?? "";

      if ($camapignId) {
        $campaignReportObject = NewCampaignReport::where('campaign_id', $camapignId)->first();
        // if (!$campaignReportObject) {
        //   $this->response['error'] = __('admin.id_not_found', ['module' => "Camapign Report"]);
        //   return $this->sendResponse($this->response, 200);
        // }
      }

      $this->response['status'] = 1;
      $this->response['data'] = $campaignReportObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Camapign Report Details fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function generatePdf(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $name = $request->name ?? '';
      $address1 = $request->address_1 ?? '';
      $address2 = $request->address_2 ?? '';
      $city = $request->city ?? '';
      $mobile = $request->mobile ?? '';
      $email = $request->email ?? '';

      $campaignId = $request->campaign_id ?? '';

      $list = NewCampaignData::where('campaign_id', $campaignId)->get()->toArray();
      $masterEntryIds = [];
      foreach ($list as $item) {
        $masterEntryIds[] = $item['master_data_entry_id'] ?? '';
      }

      $ids = array_unique($masterEntryIds);
      $BOOKPOSTDATA = NewCampaignMasterDataEntry::whereIn('id', $ids);

      // $BOOKPOSTDATA = new NewCampaignMasterDataEntry();

      if ($name) {
        $BOOKPOSTDATA->where('name', 'like', '%' . $name . '%');
      }

      if ($address1) {
        $BOOKPOSTDATA->where('address_1', 'like', '%' . $address1 . '%');
      }

      if ($city) {
        $BOOKPOSTDATA->where('city', 'like', '%' . $city . '%');
      }

      if ($mobile) {
        $BOOKPOSTDATA->where('mobile', 'like', '%' . $mobile . '%');
      }

      if ($email) {
        $BOOKPOSTDATA->where('email', 'like', '%' . $email . '%');
      }

      $BOOKPOSTDATA = $BOOKPOSTDATA->get();

      $envelopeWidth = 377;
      $envelopeHeight = 170;

      $htmlContent = bookPostPdfContent($BOOKPOSTDATA, $envelopeWidth, $envelopeHeight);
      $filePath = $this->generateRandomCode() . '.pdf';


      // 
      // dompdf
      // 

      $dompdf = new Dompdf();
      $dompdf->loadHtml($htmlContent);

      // Render the PDF
      $dompdf->render();

      $pdfContent = $dompdf->output(); // Get the generated PDF content

      file_put_contents(storage_path('app/public/uploads/temp/' . $filePath), $pdfContent); // Save the PDF to the specified file path

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Bookpost Campaign"]);
      $this->response['data'] = $this->fileAccessPath . '/temp/' . $filePath;
      $this->response['filePath'] = $this->fileAccessPath . '/temp/' . $filePath;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Bookpost Campaign Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  function generateRandomCode() {
    $prefix = 'Book-Post-Data-';
    $randomNumber = mt_rand(100, 999); // Adjust the range as needed

    return $prefix . $randomNumber;
}



  /////////// VALIDATION ////////////

  private function saveMasterDataValidation($request) {
    return Validator::make($request, [
      'title' => 'required',
      'division_ids' => 'required',
      'industry_ids' => 'required',
      'file' => 'required_if:id,null',
    ], [
      'title.required' => 'Title field is required',
      'division_ids.required' => 'Division field is required',
      'file.required_if' => 'Master Data file is required',
    ])->errors()->toArray();
  }

  private function saveCampaignValidation($request) {
    return Validator::make($request, [
      'title' => 'required',
      'our_campaign_id' => '',
      'their_campaign_id' => '',
      'campaign_type_id' => 'required',
      'campaign_platform_id' => '',
      'master_data_id' => 'required',
      'start_date' => 'required|date_format:d/m/Y',
      'end_date' => 'required|date_format:d/m/Y|after:start_date',
      'budget' => 'required',
    ], [
      'title.required' => 'Title is required',
      'campaign_type_id.required' => 'Campaign Type is required',
      'master_data_id.required' => 'Please select database',
      'budget.required' => 'Budget is required',
      'start_date.required' => 'Invalid Start Date',
      'start_date.date_format' => 'Invalid Date Format',
      'end_date.required' => 'End Date is required',
      'end_date.date_format' => 'Invalid Date Format',
      'end_date.after' => 'End Date should be greater than Start Date',
    ])->errors()->toArray();
  }

  private function validateAddReport(Request $request) {
    return Validator::make(
      $request->all(),
      [
        'report_date' => 'nullable|date_format:d/m/Y g:i A',
        'total_data' => 'nullable|integer',
        'delivered' => 'nullable|integer',
        'delivery_rate' => 'nullable|numeric',
        'opens' => 'nullable|integer',
        'open_rate' => 'nullable|numeric',
        'enquire_now' => 'nullable|integer',
        'facebook' => 'nullable|integer',
        'twitter' => 'nullable|integer',
        'instagram' => 'nullable|integer',
        'linkedin' => 'nullable|integer',
        'pinterest' => 'nullable|integer',
        'website' => 'nullable|integer',
        'total_clicks' => 'nullable|integer',
        'clicks' => 'nullable|integer',
        'click_to_open_rate' => 'nullable|numeric',
        'unsubscribe' => 'nullable|integer',
        'unsubscribe_rate' => 'nullable|numeric',
        'bounce' => 'nullable|integer',
        'bounce_rate' => 'nullable|numeric',
      ],
      [
        'report_date.date_format' => 'Invalid Date Format',
      ]
    )->errors();
  }
}
