<?php

namespace App\Http\Controllers\API;

use App\Models\Rfq;
use App\Models\City;
use App\Models\Lead;
use App\Models\User;
use App\Enums\Months;
use App\Models\Stage;
use App\Models\State;
use App\Models\Region;
use App\Models\Source;
use App\Models\Status;
use App\Enums\TaskFrom;
use App\Models\Country;
use App\Models\Product;
use App\Models\Industry;
use App\Models\SubStage;
use App\Models\Supplier;
use App\Models\TaskType;
use App\Models\TypeTask;
use App\Models\UserRole;
use App\Models\Parameter;
use App\Models\Department;
use App\Models\Designation;
use App\Models\ProjectType;
use App\Models\SmsCampaign;
use App\Models\ActivityType;
use Illuminate\Http\Request;
use App\Models\DepartmentType;
use App\Models\ProjectSegment;
use App\Models\LeadDesignation;
use App\Models\BookpostCampaign;
use App\Models\SfcEmailCampaign;
use Illuminate\Support\Facades\Log;
use App\Http\Resources\AllUserResource;
use App\Http\Resources\UserResourceForSelectInput;
use App\Models\Currency;
use App\Models\GstApiLog;
use App\Models\LeadAddresses;
use App\Models\ProductPart;
use App\Models\TenderSubStage;
use Exception;
use GuzzleHttp\Client;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Carbon;

class CommonController extends AppBaseController
{

    public function departmentTypeList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $departmentTypeObject = DepartmentType::select('id', 'title')->orderBy('title');

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Department Type"]);
            $this->response['data']['list'] = $departmentTypeObject->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Department Type fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function departmentList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $departmentObject = Department::select('id', 'title')->where('is_department', 1)->orderBy('title');

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Department Type"]);
            $this->response['data']['list'] = $departmentObject->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Department fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function designationList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $designationObject = Designation::select('id', 'title')->where('status', 1)->orderBy('title');

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Designation"]);
            $this->response['data']['list'] = $designationObject->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Designation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function smsCampaignList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $smsCampaignObject = SmsCampaign::where('status', 1);

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "SMS Campaign"]);
            $this->response['data']['list'] = $smsCampaignObject->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Designation fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function uploadImages(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            if (!$request->hasFile('files')) {
                $this->response['error'] = __('admin.file_upload_error');
                return $this->sendResponse($this->response, 200);
            }

            $files = [];
            $imageTempPath = 'uploads/temp';
            foreach ($request->file('files') as $index => $file) {
                // Reading uploaded file from temp directory

                $extension = $file->extension();

                if (!in_array($extension, ['png', 'jpeg', 'jpg'])) {
                    $this->response['error'] = __('admin.image_type_error');
                    return $this->sendResponse($this->response, 200);
                }
                $tempImageName = uniqid() . '.' . $extension;
                $file->storeAs($imageTempPath, $tempImageName, 'public');

                $files[] = ['filename' => $tempImageName, 'path' =>  $this->fileAccessPath . '/temp/' . $tempImageName];
            }

            $this->response['status'] = 1;
            $this->response['files'] = $files;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function importFiles(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            if (!$request->hasFile('files')) {
                $this->response['error'] = __('admin.file_upload_error');
                return $this->sendResponse($this->response, 200);
            }

            $files = [];
            $imageTempPath = 'uploads/temp';

            foreach ($request->file('files') as $index => $file) {
                // Reading uploaded file from temp directory

                $extension = $file->extension();

                if (!in_array($extension, ['xlsx', 'csv'])) {
                    $this->response['error'] = __('admin.excel_type_error');
                    return $this->sendResponse($this->response, 200);
                }
                $tempImageName = uniqid() . '.' . $extension;
                $file->storeAs($imageTempPath, $tempImageName, 'public');

                $files[] = ['filename' => $tempImageName, 'path' => $this->fileAccessPath . '/temp/'  . $tempImageName];
            }

            $this->response['status'] = 1;
            $this->response['files'] = $files;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function sampleXlsx(Request $request)
    {
        try {

            $name = $request->name;
            $rfqType = $request->rfq_type;

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            if ($request->sample_for == "") {
                $this->response['error'] = __('admin.sample_for_error');
                return $this->sendResponse($this->response, 200);
            }

            $filePath = "";
            if ($request->sample_for == "sms") {
                $filePath = $this->fileAccessPath . "/sample/SMS Sample Data.xlsx";
            } elseif ($request->sample_for == "email") {
                $filePath = $this->fileAccessPath . "/sample/Email Sample Data.xlsx";
            } elseif ($request->sample_for == "sfcemail") {
                $filePath = $this->fileAccessPath . "/sample/SFC Email Sample Data.xlsx";
            } elseif ($request->sample_for == "bookpost") {
                $filePath = $this->fileAccessPath . "/sample/Bookpost Sample Data.xlsx";
            } elseif ($request->sample_for == "lead") {
                $filePath = $this->fileAccessPath . "/sample/Lead Sample.xlsx";
            } elseif ($request->sample_for == "region") {
                $filePath = $this->fileAccessPath . "/sample/Region List.xlsx";
            } elseif ($request->sample_for == "source") {
                $filePath = $this->fileAccessPath . "/sample/Source List.xlsx";
            } elseif ($request->sample_for == "monthlyplan") {
                $filePath = $this->fileAccessPath . "/sample/Monthly Plan Sheet.xlsx";
            } elseif ($request->sample_for == "upcomingTender") {
                $filePath = $this->fileAccessPath . "/sample/Upcoming Tender.xlsx";
            } elseif ($request->sample_for == "campaign") {
                $filePath = $this->fileAccessPath . "/campaign/Master_data_entries.xlsx";
            } elseif ($request->sample_for == "dayinout") {
                $filePath = $this->fileAccessPath . "/dayinout/Day_in_out.xlsx";
            } elseif ($request->sample_for == "activity") {
                $filePath = $this->fileAccessPath . "/activity/Activity.xlsx";
            } elseif ($request->sample_for == "activity_dayinout") {
                $filePath = $this->fileAccessPath . "/activity_dayinout/" . $name . "_Activity_list.xlsx";
            } elseif ($request->sample_for == "rfq") {
                $filePath = $this->fileAccessPath . "/rfq/rfq_" . $rfqType . ".xlsx";
            } elseif ($request->sample_for == "daywise") {
                $filePath = $this->fileAccessPath . "/report/Day_wise_report.xlsx";
            } elseif ($request->sample_for == "customer") {
                $filePath = $this->fileAccessPath . "/report/Customer_interaction_report.xlsx";
            } elseif ($request->sample_for == "interaction") {
                $filePath = $this->fileAccessPath . "/report/Interaction_report.xlsx";
            } elseif ($request->sample_for == "location") {
                $filePath = $this->fileAccessPath . "/report/Location_report.xlsx";
            } elseif ($request->sample_for == "quotation") {
                $filePath = $this->fileAccessPath . "/quotation/Quotation.xlsx";
            } elseif ($request->sample_for == "lead_new") {
                $filePath = $this->fileAccessPath . "/lead/lead_list.xlsx";
            } elseif ($request->sample_for == "svr") {
                $filePath = $this->fileAccessPath . "/svr/Sale_visit_report.xlsx";
            } elseif ($request->sample_for == "dispatch") {
                $filePath = $this->fileAccessPath . "/sample/dispatch.xlsx";
            } else {
                $this->response['error'] =  __('admin.fetched', ['file' => $request->sample_for]);
                return $this->sendResponse($this->response, 200);
            }

            $this->response['status'] = 1;
            $this->response['msg'] = "File downloaded successfully";
            $this->response['filePath'] = $filePath;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function sourceList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $list = Source::where('status', 1)->orderBy('name')->get();
            $this->response['status'] = 1;
            $this->response['data'] = ['list' => $list];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function sourceCodeList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $list = Source::get();

            $this->response['status'] = 1;
            $this->response['data'] = ['list' => $list->map(function ($item) {
                return [
                    $item->code
                ];
            })];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function regionList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = Region::orderBy('name')->get();

            $this->response['status'] = 1;
            $this->response['data'] = ['list' => $list];
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function leadDesignationList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = LeadDesignation::where('status', 1)->orderBy('name')->get();

            $showButton = false;
            if ($this->isUserAdmin || $this->isUserRSM) {
                $showButton = true;
            }

            $this->response['status'] = 1;
            $this->response['data'] = ['list' => $list];
            $this->response['show_button'] = $showButton;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function rsmList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $type = $request->type ?? '';

            $juniorUserIds = $this->getJuniorIds(true);
            $currUser = User::find($this->userId);
            $divisionIds = explode(',', $currUser->division_ids);

            if ($this->isUserAdmin || $this->isManagement || $this->isUserHr || $this->isUserFinance || $this->isUserInsideSale) {
                $list = User::with('roles')->orderBy("name", "asc");
                $list->whereHas('roles', function ($query) {
                    $query->where('fk_department_id', 5);
                    $query->whereNot('fk_department_id', 1);
                });
            } else {
                if ($type === 'juniorsOnly') {
                    $list = User::with('roles')
                        ->whereIn('id', $juniorUserIds)
                        ->where(function ($query) use ($divisionIds) {
                            foreach ($divisionIds as $i => $divId) {
                                $method = $i === 0 ? 'whereRaw' : 'orWhereRaw';
                                $query->$method('FIND_IN_SET(?, division_ids)', [$divId]);
                            }
                        })
                        ->whereHas('roles', function ($query) {
                            $query->where('fk_department_id', 5)
                                ->where('fk_department_id', '!=', 1);
                        })
                        ->orderBy("name", "asc");
                } else {
                    $list = User::with('roles')->orderBy("name", "asc");
                    $list->whereHas('roles', function ($query) {
                        $query->where('fk_department_id', 5);
                        $query->whereNot('fk_department_id', 1);
                    });
                }
            }

            $showRsmPerson = true;
            $userExecId = '';
            $execUser = UserRole::where(['fk_user_id' => $this->userId, 'fk_department_type_id' => 2])->first();
            if ($execUser) {
                $showRsmPerson = false;
                $userExecId = $execUser->fk_user_id;
            }

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list->get();
            $this->response['data']['loggedInUser'] =  intval($this->userId) ?? '';
            $this->response['data']['showRsmPerson'] =  $showRsmPerson;
            $this->response['data']['userExecId'] =  $userExecId;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function marketingList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = User::with('roles')->orderBy("name", "asc");
            $list->whereHas('roles', function ($query) {
                $query->where(['fk_department_id' => 4]);
            });

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list->get();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function taskUserList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            // $list = User::with('roles.department')->where('id', '<>', $this->userId);
            $list = User::with('roles.department')->orderBy("name", "asc");

            $this->response['status'] = 1;
            $this->response['data']['list'] = UserResourceForSelectInput::collection($list->get());
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }
    public function sfcEmailCampaignList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = SfcEmailCampaign::get();

            $this->response['status'] = 1;
            $this->response['data'] = ['list' => $list];
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function bookpostCampaignList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = BookpostCampaign::get();

            $this->response['status'] = 1;
            $this->response['data'] = ['list' => $list];
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function countryList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = Country::get();

            $this->response['status'] = 1;
            $this->response['data'] = ['list' => $list];
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function taskTypeList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = TaskType::orderBy('name')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $list;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Task Type List Fetch Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function taskStatusList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = Status::orderBy('name')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $list;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Task Type List Fetch Failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function salesPersonList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $list = UserRole::with('user:id,name')
                ->where('fk_department_id', 5)
                ->join('users', 'user_roles.fk_user_id', '=', 'users.id')
                ->orderBy('users.name');

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list->get();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function industryList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = Industry::where('status', 1);

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list->get();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function uploadFiles(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $for = $request->for ?? '';

            if (!$request->hasFile('files')) {
                $this->response['error'] = __('admin.file_upload_error');
                return $this->sendResponse($this->response, 200);
            }

            $files = [];
            $imageTempPath = 'uploads/temp';

            foreach ($request->file('files') as $index => $file) {
                $extension = $file->extension();

                if ($for === 'PO' && strtolower($extension) !== 'pdf') {
                    $this->response['error'] = "Please upload PDF files only.";
                    return $this->sendResponse($this->response, 200);
                }

                $tempImageName = uniqid() . '.' . $extension;
                $file->storeAs($imageTempPath, $tempImageName, 'public');

                $files[] = ['filename' => $tempImageName, 'path' => $this->fileAccessPath . '/temp/' . $tempImageName];
            }

            $this->response['status'] = 1;
            $this->response['files'] = $files;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("File Upload failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    public function getDefaultBanner(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $defaultBannerName = 'avlock.png';

            $this->response['status'] = 1;
            $this->response['defaultBannerPath'] = $this->fileAccessPath . '/avlock/' . $defaultBannerName;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Fetch Default Banner failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function leadList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $list = Lead::where('status', 1);

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list->get();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function leadLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $company = trim($request->company ?? '');

            $list = Lead::where('status', 1)
                ->where('company', 'like', $company . '%')
                ->take(10)
                ->orderBy('company')
                ->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function rfqList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $company = trim($request->input('company', ''));

            $listQuery = Rfq::with(['product', 'lead'])->where('status', 1)->take(10);

            if ($company !== '') {
                $listQuery->whereHas('lead', function ($query) use ($company) {
                    $query->where('company', 'like', $company . '%')->orderBy('company');
                });
            }

            if ($request->filled('lead')) {
                $listQuery->whereIn('lead_id', $request->input('lead'));
            }

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $listQuery->get();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 401);
        }
    }

    public function stageList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $list = Stage::where('status', 1)->orderBy('order', 'asc')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function subStageList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $list = SubStage::where('status', 1)->orderBy('name');

            if (isset($request->stage) && !empty($request->stage)) {
                $list->where('stage_id', $request->stage);
            }

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list->get();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function tenderSubStageList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $list = TenderSubStage::where('status', 1)->orderBy('name');

            if (isset($request->stage) && !empty($request->stage)) {
                $list->where('stage_id', $request->stage);
            }

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list->get();
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function allUserList()
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $rsmUser = UserRole::with('user', 'department')->whereHas('user', function ($q) {
                $q->whereNotNull('id');
            })->where('fk_department_id', 5)->groupBy('fk_user_id')->get()->sortBy(function ($item) {
                return $item->user->name;
            }); // For RSM department id is 5
            $salesUser = UserRole::with('user', 'department')->whereHas('user', function ($q) {
                $q->whereNotNull('id');
            })->where('fk_department_id', 5)->groupBy('fk_user_id')->get()->sortBy(function ($item) {
                return $item->user->name;
            }); // For Sales department id is 5
            $marketingUser = UserRole::with('user', 'department')->whereHas('user', function ($q) {
                $q->whereNotNull('id');
            })->where('fk_department_id', 4)->groupBy('fk_user_id')->get()->sortBy(function ($item) {
                return $item->user->name;
            }); // For Marketing department id is 4
            $insideSalesUser = UserRole::with('user', 'department')->whereHas('user', function ($q) {
                $q->whereNotNull('id');
            })->where('fk_department_id', 6)->groupBy('fk_user_id')->get()->sortBy(function ($item) {
                return $item->user->name;
            }); // For Inside Sales department id is 6
            $psmUser = UserRole::with('user', 'department')->whereHas('user', function ($q) {
                $q->whereNotNull('id');
            })->where('fk_department_id', 7)->groupBy('fk_user_id')->get()->sortBy(function ($item) {
                return $item->user->name;
            }); // For PSM department id is 7
            $financeUser = UserRole::with('user', 'department')->whereHas('user', function ($q) {
                $q->whereNotNull('id');
            })->where('fk_department_id', 11)->groupBy('fk_user_id')->get()->sortBy(function ($item) {
                return $item->user->name;
            }); // For Finance department id is 11
            $qualityUser = UserRole::with('user', 'department')->whereHas('user', function ($q) {
                $q->whereNotNull('id');
            })->where('fk_department_id', 8)->groupBy('fk_user_id')->get()->sortBy(function ($item) {
                return $item->user->name;
            }); // For Quality department id is 8
            $dispatchUser = UserRole::with('user', 'department')->whereHas('user', function ($q) {
                $q->whereNotNull('id');
            })->where('fk_department_id', 9)->groupBy('fk_user_id')->get()->sortBy(function ($item) {
                return $item->user->name;
            }); // For Dispatch department id is 9
            $allUser = User::orderBy('name')->get();
            $currentUser = User::where('id', $this->userId)->orderBy("name", "asc")->get();

            $this->response['status'] = 1;
            $this->response['data']['rsm_user'] =  AllUserResource::collection($rsmUser);
            $this->response['data']['sales_user'] =  AllUserResource::collection($salesUser);
            $this->response['data']['marketing_user'] =  AllUserResource::collection($marketingUser);
            $this->response['data']['inside_sales_user'] =  AllUserResource::collection($insideSalesUser);
            $this->response['data']['psm_user'] =  AllUserResource::collection($psmUser);
            $this->response['data']['finance_user'] =  AllUserResource::collection($financeUser);
            $this->response['data']['quality_user'] =  AllUserResource::collection($qualityUser);
            $this->response['data']['dispatch_user'] =  AllUserResource::collection($dispatchUser);
            $this->response['data']['allUser'] =  $allUser;
            $this->response['data']['current_user'] =  $currentUser;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("User Fetched failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function commonLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $leadList = Lead::where('status', 1)->orderBy('company')->get();
            $productList = Product::where('status', 1)->orderby('product_name')->get();
            $taskTypeList = TaskType::get();
            $activityTypeList = ActivityType::where('status', 1)->orderBy('title')->get();
            $projectTypeList = ProjectType::where('status', 1)->orderBy('name')->get();
            $projectSegmentList = ProjectSegment::where('status', 1)->orderBy('name')->get();
            $parameterList = Parameter::where('status', 1)->orderBy('name')->get();
            $stateList = State::get();

            $this->response['status'] = 1;
            $this->response['data'] = [
                'leads' => $leadList,
                'products' => $productList,
                'task_type' => $taskTypeList,
                'activity_type' => $activityTypeList,
                'project_type_list' => $projectTypeList,
                'project_segment_list' => $projectSegmentList,
                'parameter_list' => $parameterList,
                'state_list' => $stateList,
            ];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Common List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function cityLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $city = trim($request->city ?? '');
            $state_id = $request->state_id ?? '';

            $list = City::where('state_id', $state_id)->where('name', 'like', $city . '%')
                ->take(10)
                ->orderBy('name')
                ->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function fetchCity(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $cityId = $request->city_id ?? '';

            $list = City::find($cityId);

            $this->response['status'] = 1;
            $this->response['data']['list'] =  $list;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    public function productLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $productList = Product::where('status', 1)->orderBy('product_name')->get();

            $this->response['status'] = 1;
            $this->response['data'] = [
                'products' => $productList,
            ];

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Project List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function productListsNew(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $searchTerm = trim($request->input('search_item', ''));
            $normalizedSearchTerm = strtolower(str_replace(['-', ' ', '.'], '', $searchTerm));

            $productLists = Product::select('id', 'product_name')
                ->with(['partNo' => function ($query) use ($normalizedSearchTerm) {
                    $query->select('id', 'product_id', 'part_no', 'description');
                    if ($normalizedSearchTerm) {
                        $query->orderByRaw("CASE WHEN REPLACE(REPLACE(REPLACE(LOWER(part_no), '-', ''), ' ', ''), '.', '') = ? THEN 0 ELSE 1 END", [$normalizedSearchTerm]);
                    }
                }])
                ->where(function ($query) use ($normalizedSearchTerm) {
                    $query->whereRaw("REPLACE(REPLACE(REPLACE(LOWER(product_name), '-', ''), ' ', ''), '.', '') like ?", ["%{$normalizedSearchTerm}%"])
                        ->orWhereHas('partNo', function ($query) use ($normalizedSearchTerm) {
                            $query->whereRaw("REPLACE(REPLACE(REPLACE(LOWER(part_no), '-', ''), ' ', ''), '.', '') like ?", ["%{$normalizedSearchTerm}%"]);
                        });
                })
                ->whereNull('deleted_at')
                ->orderBy('product_name')
                ->take(10)
                ->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $productLists;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }


    public function productPartLists(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $partNo = trim($request->part_no ?? '');
            $productId = $request->product_id ?? '';

            $query = ProductPart::with('product:id,product_name')
                ->where('product_id', $productId)
                ->whereNull('deleted_at')
                ->where('status', 1);
            if ($partNo) {
                $query->where('part_no', 'like', '%' . $partNo . '%');
            }
            $productPartLists = $query->orderBy('part_no')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $productPartLists;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 200);
        }
    }

    public function productPartListsAll(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $partNo = trim($request->part_no ?? '');

            $query = ProductPart::with('product:id,product_name')
                ->whereNull('deleted_at')
                ->where('status', 1);
            if ($partNo) {
                $query->where('part_no', 'like', '%' . $partNo . '%');
            }
            $productPartLists = $query->orderBy('part_no')->take(10)->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $productPartLists;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Product Part List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 200);
        }
    }


    public function supplierList(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }
            $supplierList = Supplier::select('id', 'organization_name as name')->get();

            $this->response['status'] = 1;
            $this->response['data']['list'] = $supplierList;
            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Supplier List fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getMonths(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Months"]);
            $this->response['data']['list'] = Months::getListForHTML();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Months fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function getYearOptions()
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $currentYear = date("Y");
            $options = [
                ["id" => $currentYear - 1, "name" => $currentYear - 1],
                ["id" => $currentYear, "name" => $currentYear],
                ["id" => $currentYear + 1, "name" => $currentYear + 1]
            ];


            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Years"]);
            $this->response['data']['list'] = $options;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Years fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    function getInspectionOptions()
    {

        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $options = [
                ["id" => 1, "name" => 'Consignee'],
                ["id" => 2, "name" => 'TPI'],
            ];

            $this->response['status'] = 1;
            $this->response['msg'] =  __('admin.fetched', ['module' => "Inspection"]);
            $this->response['data']['list'] = $options;

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("Years fetching failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getGstDetails(Request $request)
    {
        try {
            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $gst = $request->gst ?? '';
            $company = substr(trim($request->company ?? ''), 0, 4);

            $todaysDate = Carbon::now();
            $currentDate = Carbon::now();

            $pastDate = $currentDate->subDays(30);
            if ($pastDate->month !== $currentDate->month) {
                $pastDate = $pastDate->endOfMonth();
            }

            $formattedPastDate = $pastDate->format('Y-m-d');

            $existingGst = GstApiLog::where('request_payload->gst', $gst)
                ->whereDate('created_at', '>=', $formattedPastDate)
                ->whereDate('created_at', '<=', $todaysDate)->latest()->first();


            if (empty($gst) && empty($company)) {
                $this->response['error'] = 'Please provide either GST or company name.';
                return $this->sendResponse($this->response, 200);
            }

            if (!empty($gst)) {
                if (!preg_match('/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/', $gst)) {
                    $this->response['error'] = 'Invalid GST number format';
                    return $this->sendResponse($this->response, 200);
                }
            }

            $ip = $request->ip();

            // $lastHitTime = GstApiLog::where('ip_address', $ip)->latest()->value('created_at');

            // if ($lastHitTime && now()->diffInSeconds($lastHitTime) < config('global.API_LIMIT')) {
            //   return $this->response = ['error' => 'Please wait for 30 seconds before trying again.'];
            //   return $this->sendResponse($this->response, 429);
            // }

            $statusCode = '';
            $msg = '';
            $companyInfo = [];

            if (empty($existingGst)) {
                if (!empty($gst)) {
                    $apiKey = 'cc22d317580bc0fa9486942a5237cc27';
                    $url = "http://sheet.gstincheck.co.in/check/{$apiKey}/{$gst}";

                    $client = new Client();
                    $response = $client->get($url);

                    $statusCode = $response->getStatusCode();
                    $data = $response->getBody()->getContents();
                }
            } else {
                $statusCode = 200;
                $data = $existingGst->response;
            }

            if ($statusCode == 200) {

                GstApiLog::create([
                    'ip_address' => $ip,
                    'request_payload' => json_encode($request->all()),
                    'response' => $data,
                ]);

                $responseData = json_decode($data, true);

                if (isset($responseData['flag']) && $responseData['flag'] === false) {
                    $message = isset($responseData['message']) ? $responseData['message'] : 'GST Number not found';
                    $this->response['error'] = $message;
                    return $this->sendResponse($this->response, 200);
                }

                $companyInfo = [
                    'gstin' => null,
                    'company_name' => null,
                    'address' => null,
                    'state' => null,
                    'city' => null,
                    'pincode' => null,
                ];

                if (isset($responseData['data']['gstin'])) {
                    $companyInfo['gstin'] = $responseData['data']['gstin'];
                }

                if (isset($responseData['data']['tradeNam'])) {
                    $companyInfo['company_name'] = $responseData['data']['tradeNam'];
                }

                if (isset($responseData['data']['pradr']['adr'])) {
                    $address = $responseData['data']['pradr']['adr'];
                    $companyInfo['address'] = $address;
                }

                if (isset($responseData['data']['pradr']['addr']['stcd'])) {
                    $state = $responseData['data']['pradr']['addr']['stcd'];
                    $companyInfo['state'] = $state;
                }

                if (isset($responseData['data']['pradr']['addr']['dst'])) {
                    $city = $responseData['data']['pradr']['addr']['dst'];
                    $companyInfo['city'] = $city;
                }

                if (isset($responseData['data']['pradr']['addr']['pncd'])) {
                    $pincode = $responseData['data']['pradr']['addr']['pncd'];
                    $companyInfo['pincode'] = $pincode;
                }

                $msg = isset($responseData['message']) ? $responseData['message'] : 'GSTIN found.';
            }

            $gstLead = [];
            $companyLeads = [];
            $showButton = false;

            if ($gst) {
                $gstLead = Lead::with('leadAddress', 'LeadContactPeople')->where('status', 1)->where('gstin', $gst)->get();
                if ($gstLead->isEmpty()) {
                    $showButton = true;
                }
            }

            if ($company) {
                $companyLeads = Lead::where('status', 1)->where('company', 'like', $company . '%')->get();
            }

            $this->response['status'] = 1;
            $this->response['msg'] = $msg;
            $this->response['data']['show_select_button'] = $showButton;
            $this->response['data']['gst'] = $companyInfo;
            $this->response['data']['existing'] = $gstLead;
            $this->response['data']['similar'] = $companyLeads;
            return $this->sendResponse($this->response, 200);
        } catch (Exception $e) {
            Log::error("Failed to retrieve GST details: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        } catch (ModelNotFoundException $e) {
            Log::error("Record Not Found: " . $e->getMessage());
            $this->response['error'] = __('admin.record_not_found', ['module' => "Lead"]);
            return $this->sendResponse($this->response, 500);
        }
    }

    public function getCurrencyList(Request $request)
    {
        try {

            if (!$this->userId) {
                $this->response['error'] = __('auth.authentication_failed');
                return $this->sendResponse($this->response, 401);
            }

            $this->response['status'] = 1;
            $this->response['msg'] =  "Currency list";
            $this->response['data']['list'] = Currency::where('status', 1)->get();

            return $this->sendResponse($this->response, 200);
        } catch (\Exception $e) {
            Log::error("getCurrencyList failed: " . $e->getMessage());
            $this->response['error'] = __('auth.something_went_wrong');
            return $this->sendResponse($this->response, 500);
        }
    }
}
