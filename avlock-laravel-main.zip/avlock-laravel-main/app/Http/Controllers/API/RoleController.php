<?php

namespace App\Http\Controllers\API;

use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Http\Resources\RoleResource;
use App\Models\Menu;
use Illuminate\Support\Facades\Validator;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class RoleController extends AppBaseController
{

  public function index(REQUEST $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = $request->page ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = $request->per_page ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $role = Role::with('department', 'departmentType');
      $num_rows = $role->count();
      // $role = $role->limit($per_page)->offset($offset)->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['model' => 'Role']);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['list'] = RoleResource::collection($role->get());
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Role fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(REQUEST $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateRole($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $roleObject = new Role();
      $id = $request->id;
      $department_id = $request->department_id ?? 0;
      $department_type_id = $request->department_type_id ?? 0;
      $permissions = json_encode($request->permissions);

      if ($id) {
        $roleObject = Role::find($id);

        if (!$roleObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Designation"]);
          return $this->sendResponse($this->response, 401);
        }

        $roleObject->first();
        $this->response['msg'] = __('admin.updated', ['module' => "Role"]);
      } else {
        $this->response['msg'] = __('admin.created', ['module' => "Role"]);
      }

      $roleObject->department_id = $department_id;
      $roleObject->department_type_id = $department_type_id;
      $roleObject->permissions = $permissions;

      $roleObject->save();
      $this->response['status'] = 1;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Failed Creating Role: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Role"]);

      return $this->sendResponse($this->response, 401);
    }
  }

  public function get(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;
      $roleObject = Role::find($id);

      if (!$roleObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Role"]);
        return $this->sendResponse($this->response, 401);
      }
      $roleObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Role"]);
      $this->response['data'] = $roleObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Role fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function menu_list()
  {
    try {
      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $menuObject = Menu::where('status', 1)->get();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Menu"]);
      $this->response['data']['list'] = $menuObject;
      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Menu fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  public function delete(Request $request)
  {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $roleObject = Role::find($id);

      if (!$roleObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Role"]);
        return $this->sendResponse($this->response, 401);
      }

      $roleObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Role"]);
      $this->response['data'] = $roleObject;

      return $this->sendResponse($this->response, 200);
    } catch (\Exception $e) {
      Log::error("Role Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 401);
    }
  }

  private function validateAddUpdateRole(Request $request)
  {
    return Validator::make(
      $request->all(),
      [
        'department_id' => 'required|integer|unique:roles,department_id,' . $request->id . ',id,department_type_id,' . $request->department_type_id . ',deleted_at,NULL',
        'department_type_id' => 'required|integer',
        'permissions' => 'required',
      ],
      [
        'department_id.unique'  => 'Role is already present with given criteria!',
      ]
    )->errors();
  }
}
