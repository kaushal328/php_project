<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\TenderTerm;
use Exception;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;

class TenderTermController extends AppBaseController {
   /**
   * Display a listing of the Tender Term.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function index(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $page = (isset($request->page) && $request->page != 'undefined') ? intval($request->page) : config('global.DEFAULT_PAGE');
      $per_page = (isset($request->per_page) && $request->per_page != 'undefined') ? intval($request->per_page) : config('global.DEFAULT_PAGINATE_LENGTH');
      $offset = ($page - 1) * $per_page;

      $title = $request->title ?? '';
      $termsCategory = $request->terms_category ?? '';
      $status = $request->status ?? '';

      $tenderTerm = TenderTerm::with('termsCategory')->orderBy("id", "desc");
      $num_rows = $tenderTerm->count();

      if ($termsCategory) {
        $tenderTerm->where('fk_category_id', $termsCategory);
      }

      if ($title) {
        $tenderTerm->where('title', 'like', '%' . $title . '%');
      }

      if ($status) {
        $tenderTerm->where('status', $status);
      }

      $this->response['status'] = 1;
      $this->response['msg'] =  __('admin.fetched', ['module' => "Tender Term"]);
      $this->response['data']['page'] = $page;
      $this->response['data']['per_page'] = $per_page;
      $this->response['data']['num_rows'] = $num_rows;
      $this->response['data']['total_pages'] = $num_rows < $per_page ? 1 : ceil($num_rows / $per_page);
      $this->response['data']['terms_category'] = $termsCategory;
      $this->response['data']['title'] = $title;
      $this->response['data']['list'] = $tenderTerm->limit($per_page)->offset($offset)->get();

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Tender Term fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function addUpdate(Request $request) {

    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $validationErrors = $this->validateAddUpdateTenderTerm($request);

      if (count($validationErrors)) {
        Log::error("Validation Errors: " . implode(", ", $validationErrors->all()));
        $this->response['errors'] = $this->formatValidationErrors($validationErrors->toArray());
        return $this->sendResponse($this->response, 200);
      }

      $quotationTermObject = new TenderTerm();
      $id = $request->id;
      $fk_category_id = $request->fk_category_id ?? 0;
      $title = $request->title ?? '';
      $status = $request->status ?? 1;



      if ($id) {
        $quotationTermObject = TenderTerm::find($id);

        if (!$quotationTermObject) {
          $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Term"]);
          return $this->sendResponse($this->response, 401);
        }

        $quotationTermObject->first();
        $quotationTermObject->updated_by = $this->userId;
        $this->response['msg'] = __('admin.updated', ['module' => "Tender Term"]);
      } else {
        $quotationTermObject->created_by = $this->userId;
        $this->response['msg'] = __('admin.created', ['module' => "Tender Term"]);
      }

      $quotationTermObject->fk_category_id = $fk_category_id;
      $quotationTermObject->title = $title;
      $quotationTermObject->status = $status;

      $quotationTermObject->save();

      $this->response['status'] = 1;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Failed Creating Tender Term: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    } catch (ModelNotFoundException $e) {
      Log::error("Record Not Found: " . $e->getMessage());
      $this->response['error'] = __('admin.record_not_found', ['module' => "Tender Term"]);

      return $this->sendResponse($this->response, 500);
    }
  }

  public function get(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $quotationTermObject = TenderTerm::with('termsCategory')->find($id);

      if (!$quotationTermObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Term"]);
        return $this->sendResponse($this->response, 401);
      }
      $quotationTermObject->first();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.fetched', ['module' => "Tender Term"]);
      $this->response['data'] = $quotationTermObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Tender Term fetching failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  public function delete(Request $request) {
    try {

      if (!$this->userId) {
        $this->response['error'] = __('auth.authentication_failed');
        return $this->sendResponse($this->response, 401);
      }

      $id = $request->id;

      $quotationTermObject = TenderTerm::find($id);

      if (!$quotationTermObject) {
        $this->response['error'] = __('admin.id_not_found', ['module' => "Tender Term"]);
        return $this->sendResponse($this->response, 401);
      }

      $quotationTermObject->delete();

      $this->response['status'] = 1;
      $this->response['msg'] = __('admin.deleted', ['module' => "Tender Term"]);
      $this->response['data'] = $quotationTermObject;

      return $this->sendResponse($this->response, 200);
    } catch (Exception $e) {
      Log::error("Tender Term Delete failed: " . $e->getMessage());
      $this->response['error'] = __('auth.something_went_wrong');
      return $this->sendResponse($this->response, 500);
    }
  }

  private function validateAddUpdateTenderTerm(Request $request) {
    return Validator::make($request->all(), [
      'fk_category_id' => 'required|integer|exists:tender_term_categories,id',
      // 'title' => 'required|string|unique:quotation_terms,title,' . $request->id . ',id,deleted_at,NULL',
      'title' => 'required|string',
      'status' => 'sometimes|required|integer|in:0,1',
    ], [
      'fk_category_id.required' => "Terms Category is Required"
    ])->errors();
  }
}
