<?php

namespace App\Http\Resources;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PurchaseInvoiceResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);
        $data['purchaseOrderNo'] = $this->po->po_no ?? '';
        $data['purchaseInvoiceNo'] = $this->pi_no ?? '';

        $piDetailArr = isset($this->pi_details) ? json_decode($this->pi_details) : [];
        $temp = [];
        if (isset($piDetailArr) && !empty($piDetailArr)) {
            foreach ($piDetailArr as $key => $pid) {
                $productId = $pid->product_id ?? '';
                $productName = Product::where('id', $productId)->value('product_name') ?? '';
                $description = $pid->description ?? '';
                $partNo = $pid->part_no ?? '';
                $hsn = $pid->hsn ?? '';
                $qty = $pid->qty ?? '';
                $rate = $pid->rate ?? '';
                $totalAmount = $pid->total_amount ?? '';
                $custDesc = $pid->cust_description ?? '';

                $temp[] = [
                    'product_name' => $productName,
                    'part_no' => $partNo,
                    'description' => $description,
                    'hsn' => $hsn,
                    'qty' => $qty,
                    'rate' => $rate,
                    'total_amount' => $totalAmount,
                    'cust_description' => $custDesc,
                ];
            }
        }

        $data['piDetails'] = $temp;

        return $data;
    }
}
