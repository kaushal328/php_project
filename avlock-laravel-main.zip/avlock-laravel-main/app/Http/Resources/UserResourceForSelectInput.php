<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResourceForSelectInput extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {
    $output = parent::toArray($request);
    //for User Role & Department
    $userRoles = $this->roles->map(function ($role) {
      return $role->department->title . ' ' . $role->departmentType->title;
    })->toArray();
    $userDesignation = $this->designation->title ?? '';

    $output['roles'] = $userRoles;

    $rolesString = '';

    if (!empty($userRoles)) {
      $rolesString = '(' . implode(', ', $userRoles) . ')';
    }

    $output['name'] = $this->name . ' ' . $rolesString;
    $output['des_name'] = $this->name;
    $output['designation'] = $userDesignation;
    $output['user_designation'] = $this->name . ' ' . '(' . $userDesignation . ')';
    return $output;
  }
}
