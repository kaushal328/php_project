<?php

namespace App\Http\Resources;

use App\Models\ProjectSegment;
use App\Models\RfqProduct;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RfqProjectSheetResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data =  parent::toArray($request);
        $proSegmentIds = $this->project_segments ?? '';
        $proSegmentIds = json_decode($proSegmentIds);
        if (is_array($proSegmentIds)) {
            $proSegments = ProjectSegment::whereIn('id', $proSegmentIds)->pluck('name')->implode(', ');
        }

        $rfqProducts = RfqProduct::select('id', 'rfq_id', 'product_part_id', 'product_qty')->with([
            'productPart:id,part_no,description'
        ])->where('rfq_id', $this->id)->get();

        $data['project_segments'] = $proSegments ?? '';
        $data['rfq_products'] = $rfqProducts ?? '';
        return $data;
    }
}
