<?php

namespace App\Http\Resources;

use App\Models\Division;
use App\Models\SubStage;
use App\Models\UserRole;
use App\Models\ProjectLog;
use App\Models\RfqProduct;
use App\Models\RfqResponse;
use Illuminate\Http\Request;
use App\Models\PurchaseOrder;
use App\Models\Rfq;
use Illuminate\Http\Resources\Json\JsonResource;

class RfqListResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {
    $data = parent::toArray($request);

    $data['products'] = RfqProduct::with('product')->where('rfq_id', $this->id)->get()->toArray();
    $data['project_type'] = $this->projectType->name ?? "";
    $data['project_segment'] = $this->projectSegment->name ?? "";
    $data['division_name'] = Division::where('id', $this->division_id)->pluck('name')->first();
    // $data['quotation_no'] = isset($this->quotationTemp) && !empty($this->quotationTemp) ? $this->quotationTemp->quotation_no : '';

    $data['stage'] = $this->stage->name ?? "RFQ Generated";
    $data['sub_stage'] = $this->subStage->name ?? "RFQ Generated";
    // $data['curr_user'] = $this->curr_user ? implode(', ', array_column(json_decode($this->curr_user, true), 'name')) : "-";
    $data['curr_user'] = $this->curr_user ? json_decode($this->curr_user, true) : [];
    $poList = PurchaseOrder::with('agreement', 'packaging', 'labelling', 'dneInvoice', 'qualityReport', 'lr', 'purchaseInvoice', 'stage', 'subStage')->where('fk_rfq_id', $this->id)->get();
    $data['po_list'] = PurchaseOrderResource::collection($poList);
    $lastLog = ProjectLog::where('fk_rfq_id', $this->id)
      ->latest()
      ->first();

    if ($lastLog) {
      $data['last_log_date'] = $lastLog->created_at;
    }

    // $checkRfqResponse = RfqProduct::where('rfq_id', $this->id)->where('is_response_received', 1)->count();
    $checkRfqResponse = Rfq::where('id', $this->id)->where('is_response_received', 1)->count();
    $showChangeStageButton = true;
    $actionMsg = '';

    if ($checkRfqResponse == 0) {
      $actionMsg = 'RFQ Response Not Received';
      $showChangeStageButton = false;
    }
    if ($this->assigned_rsm == 0) {
      $actionMsg = 'Please Assign RSM';
      $showChangeStageButton = false;
    }


    $data['action_msg'] = $actionMsg;
    $data['show_change_stage_button'] = $showChangeStageButton;

    switch ($this->curr_sub_stage_id) {
        // for RFQ Generated
      case 0:
        $data['next_sub_stages'] = SubStage::whereIn('id', [19]) //before 1, 19->where('status', 1)
          ->orderBy('id', 'asc')
          ->get();
        break;

        // case 3: // For Check Sample Available or not check
        //   $data['next_sub_stages'] = SubStage::whereIn('id', [3, 4, 6])->where('status', 1)
        //     ->orderBy('id', 'asc')
        //     ->get();
        //   break;

        // case 5: // for if sample available
        //   $data['next_sub_stages'] = SubStage::whereIn('id', [5, 16])->where('status', 1)
        //     ->orderBy('id', 'asc')
        //     ->get();
        //   break;

      case 18: // for if sample available
        $data['next_sub_stages'] = SubStage::whereIn('id', [20]) //before 18, 20->where('status', 1)
          ->orderBy('id', 'asc')
          ->get();

      case 21: // to check rfq aprroved or Denied
        $data['next_sub_stages'] = SubStage::whereIn('id', [21, 22, 28])->where('status', 1)
          ->orderBy('id', 'asc')
          ->get();
        break;

      case 23: // for Quotation prepared initiated
        $data['active_sub_stages'] = SubStage::wherein('id', [26])->where('status', 1)
          ->orderBy('id', 'asc')
          ->get();
        break;

      case 27: // show stage PO Received By RSM
        $data['next_sub_stages'] = SubStage::whereIn('id', [27, 34])->where('status', 1)
          ->orderBy('id', 'asc')
          ->get();
        break;

      case 34: // show Stage PO Verified with Quotation and PO not matched
        $data['next_sub_stages'] = SubStage::whereIn('id', [34, 35, 50])->where('status', 1)
          ->orderBy('id', 'asc')
          ->get();
        break;

      case 49: //Show Stage PO Received By RSM
        $data['next_sub_stages'] = SubStage::whereIn('id', [49, 34])->where('status', 1)
          ->orderBy('id', 'asc')
          ->get();
        break;

      case 52: //Show Stage PO Received By RSM
        $data['next_sub_stages'] = SubStage::whereIn('id', [52, 34])->where('status', 1)
          ->orderBy('id', 'asc')
          ->get();
        break;

      default:
        $subStageObject = SubStage::find($this->curr_sub_stage_id);
        if ($subStageObject) {
          $currSubstageOrder = $subStageObject->order;
          $currStageId = $subStageObject->stage_id;
          $nextSubStageOrder = $currSubstageOrder + 1;

          $data['next_sub_stages'] = SubStage::where(['status' => 1, 'order' => $nextSubStageOrder, 'stage_id' => $currStageId]);


          // if ($this->curr_sub_stage_id != 41) {
          //   $data['next_sub_stages']->orWhere('id', $this->curr_sub_stage_id);
          // }

          if ($this->curr_sub_stage_id > 34) {
            $data['next_sub_stages']->orWhere('id', 34);
          }

          $data['next_sub_stages'] = $data['next_sub_stages']
            ->orderBy('id', 'asc')
            ->get();
        }
        break;
    }

    $nextSubStageArray = [];
    $departmentIds = [];

    if (isset($data['next_sub_stages'])) {
      foreach ($data['next_sub_stages'] as $stage) {
        $stageName = $stage->name ?? '';
        $toDepartments = $stage->to_departments ?? '';
        if ($stageName != '') {
          $nextSubStageArray[] = $stageName;
        }
        if ($toDepartments != '') {
          $departmentIds = array_merge($departmentIds, explode(",", $toDepartments));
        }
      }
    }



    $data['next_users_array'] =   $departmentIds;
    $data['next_sub_stages_array'] =   $nextSubStageArray;

    $user = UserRole::with('user.roles.department', 'user.roles.departmentType', 'department')
      ->whereHas('user.roles', function ($q) {
        $q->whereNotNull('id');
      })
      ->whereIn('fk_department_id', array_unique($departmentIds))->groupBy('fk_user_id')->get()
      ->sortBy(function ($item) {
        return $item->user->name;
      });

    $data['next_stage_users'] =  AllUserResource::collection($user);

    return $data;
  }
}
