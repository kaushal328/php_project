<?php

namespace App\Http\Resources;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TenderSalesOrderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);
        $data['purchaseOrderNo'] = $this->po->po_no ?? '';
        $data['salesOrderNo'] = $this->so_no ?? '';

        $soDetailArr = isset($this->so_details) ? json_decode($this->so_details) : [];
        $temp = [];
        if (isset($soDetailArr) && !empty($soDetailArr)) {
            foreach ($soDetailArr as $key => $sod) {
                $productId = $sod->product_id ?? '';
                $productName = Product::where('id', $productId)->value('product_name') ?? '';
                $description = $sod->description ?? '';
                $partNo = $sod->part_no ?? '';
                $hsn = $sod->hsn ?? '';
                $qty = $sod->qty ?? '';
                $rate = $sod->rate ?? '';
                $totalAmount = $sod->total_amount ?? '';
                $custDesc = $sod->cust_description ?? '';

                $temp[] = [
                    'product_name' => $productName,
                    'part_no' => $partNo,
                    'description' => $description,
                    'hsn' => $hsn,
                    'qty' => $qty,
                    'rate' => $rate,
                    'total_amount' => $totalAmount,
                    'cust_description' => $custDesc,
                ];
            }
        }

        $data['soDetails'] = $temp;


        return $data;
    }
}
