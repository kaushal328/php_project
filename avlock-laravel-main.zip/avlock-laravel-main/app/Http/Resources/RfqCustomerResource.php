<?php

namespace App\Http\Resources;

use App\Models\Rfq;
use App\Models\Stage;
use App\Enums\PoStatus;
use App\Models\AvlockPurchaseInvoice;
use App\Models\AvlockSalesOrder;
use App\Models\EvaBill;
use App\Models\Product;
use App\Models\SubStage;
use App\Models\UserRole;
use App\Models\Department;
use App\Models\Division;
use App\Models\LeadContactPeople;
use App\Models\LeadDesignation;
use App\Models\PoDespatchDetail;
use App\Models\RfqProduct;
use App\Models\RfqResponse;
use Illuminate\Http\Request;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderLr;
use App\Models\ProductParameter;
use App\Models\ProjectQuotation;
use App\Models\ProjectQuotationTemp;
use App\Models\ProjectSegment;
use App\Models\ProjectType;
use App\Models\PurchaseOrderEInvoice;
use App\Models\PurchaseOrderAgreement;
use App\Models\PurchaseOrderLabelling;
use App\Models\PurchaseOrderDneInvoice;
use App\Models\PurchaseOrderPdrQuality;
use App\Models\PurchaseOrderPackagingList;
use App\Models\PurchaseOrderRnr;
use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class RfqCustomerResource extends JsonResource
{
    /**`
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);

        unset($data);
        $data = ($this->rfq ?? []) ? $this->rfq->toArray() : [];
        $data['customer_name'] = $this->customer_name ?? "";
        $data['company'] = $this->company ?? "";
        $data['email'] = isset($this->id) ? $this->email : (isset($this->rfq->id) ? $this->rfq->email : '');
        $data['contact_no'] = isset($this->id) ? $this->contact_no : (isset($this->rfq->id) ? $this->rfq->contact_no : '');
        $data['address1'] = isset($this->id) ? $this->address1 : (isset($this->rfq->id) ? $this->rfq->address1 : '');
        $data['address2'] = isset($this->id) ? $this->address2 : (isset($this->rfq->id) ? $this->rfq->address2 : '');
        $data['city'] = isset($this->id) ? $this->city : (isset($this->rfq->id) ? $this->rfq->city : '');
        $data['is_client'] = $this->is_client ?? "";
        $data['credit_limit'] = $this->credit_limit ?? "";
        $data['credit_days'] = $this->credit_days ?? "";
        $data['client_type'] = $this->client_type ?? "";
        $data['pincode'] = isset($this->id) ? $this->pincode : (isset($this->rfq->id) ? $this->rfq->pincode : '');
        $data['state'] = isset($this->id) ? $this->state : (isset($this->rfq->id) ? $this->rfq->state : '');
        $data['designation_id'] = $this->fk_designation_id ?? "";
        $data['fk_project_segment_id'] = $this->fk_project_segment_id ?? "";
        $data['fk_project_type_id'] = $this->rfq->fk_project_type_id ?? "";
        $data['rsm_id'] = $this->customer->id ?? null;
        $data['rsm_name'] = $this->customer->name ?? "";
        $data['rfq_id'] = $this->rfq ?? [];
        $data['is_export'] = $this->is_export ?? [];
        $data['fk_source_id'] = isset($this->rfq) ? $this->rfq->fk_source_id : '';
        $data['products'] = [];

        $designationLeadContactId = $this->rfq?->lead_contact_people_id ?? null;

        $desgIds = $designationLeadContactId ? LeadContactPeople::find($designationLeadContactId) : null;
        $data['designations'] = $desgIds && is_array($desgIds->designations)  ? LeadDesignation::whereIn('id', $desgIds->designations)->pluck('name')->implode(', ')  : '';

        if (isset($this->rfq->id)) {
            $data['products'] = RfqProduct::with('product', 'productPart')->where('rfq_id', $this->rfq->id)->orderBy('sequence')->get()->toArray();
            $productNew = [];

            foreach ($data['products'] as $pro) {
                $temp = [];
                $temp['id'] = $pro['id'];
                $temp['product_id'] = $pro['product']['id'] ?? null;
                $temp['product_cat_id'] = $pro['product']['product_category_id'] ?? null;
                $temp['product_name'] = $pro['product']['product_name'] ?? null;
                $temp['description'] = $pro['product']['short_description'] ?? null;
                $temp['hsn'] = $pro['product']['hsn'] ?? null;
                $temp['product_part_id'] = $pro['product_part']['id'] ?? null;
                $temp['partNoName'] = [$pro['product_part']['part_no'] ?? null];
                $temp['partDescription'] = $pro['product_part']['description'] ?? null;
                $temp['qty'] = $pro['product_qty'] ?? 0;
                $productNew[] = $temp;
            }

            $data['productPlus'] = $productNew;
        }

        if (isset($data['curr_sub_stage_id'])) {

            if (isset($data['po_id'])) {
                $data['curr_sub_stage_id'] = PurchaseOrder::where('id', $data['po_id'])->pluck('curr_sub_stage_id')->first();

                $currentPo = PurchaseOrder::where('id', $data['po_id'])->first();
                $poAgreement = PurchaseOrderAgreement::where('fk_po_id', $data['po_id'])->first();
                $poPackagingList = PurchaseOrderPackagingList::where('fk_po_id', $data['po_id'])->first();
                $poLabel = PurchaseOrderLabelling::where('fk_po_id', $data['po_id'])->first();
                $poDneInvoice = PurchaseOrderDneInvoice::where('fk_po_id', $data['po_id'])->first();
                $poEInvoice = PurchaseOrderEInvoice::where('fk_po_id', $data['po_id'])->first();
                $salesOrder = AvlockSalesOrder::where('fk_po_id', $data['po_id'])->first();
                $purchaseInvoice = AvlockPurchaseInvoice::where('fk_po_id', $data['po_id'])->first();
                $evaBill = EvaBill::where('fk_po_id', $data['po_id'])->first();
                $poPdrQuality = PurchaseOrderPdrQuality::where('fk_po_id', $data['po_id'])->first();
                $poLr = PurchaseOrderLr::where('fk_po_id', $data['po_id'])->first();
                $poRn = PurchaseOrderRnr::where('fk_po_id', $data['po_id'])->first();

                $data['po_date'] = $currentPo->po_date ?? '';
                $data['po_no'] = $currentPo->po_no ?? '';
                $data['po_type_id'] = $currentPo->po_type_id ?? '';
                $data['po_details'] = $currentPo->po_details ?? [];
                $data['service_details'] = $currentPo->service_details ?? [];
                $data['po_details_total'] = $currentPo->po_details_total ?? '';
                $data['curr_user'] = $currentPo->curr_user ?? '';
                $data['curr_sub_stage_id'] = $currentPo->curr_sub_stage_id ?? '';
                $data['attachments'] = $currentPo->attachments ?? [];
                $data['po_cgst'] = $currentPo->cgst ?? 0;
                $data['po_cgst_value'] = $currentPo->cgst_value ?? 0;
                $data['po_sgst'] = $currentPo->sgst ?? 0;
                $data['po_sgst_value'] = $currentPo->sgst_value ?? 0;
                $data['po_igst'] = $currentPo->igst ?? 0;
                $data['po_igst_value'] = $currentPo->igst_value ?? 0;

                /*
                 __,  _,   __, _  _, __,  _, ___  _, _,_
                 |_) / \   | \ | (_  |_) / \  |  / ` |_|
                 |   \ /   |_/ | , ) |   |~|  |  \ , | |
                 ~    ~    ~   ~  ~  ~   ~ ~  ~   ~  ~ ~
                */

                foreach (json_decode($currentPo->po_details) as $value) {
                    $productId = $value->product_id ?? "";
                    $productPartId = $value->product_part_id ?? ($value->part_noId ?? '');
                    $proName = Product::where('id', $productId)->pluck('product_name')->first();
                    $description = $value->description ?? "";
                    $partNo = $value->part_no ?? "";
                    $qty = $value->qty ?? "";
                    $hsn = $value->hsn ?? "";
                    $rate = $value->rate ?? "";
                    $totaAmnt = $value->total_amount ?? "";

                    $products[] = [
                        "product_id" => $productId,
                        "product_part_id" => $productPartId,
                        "product_name" => $proName,
                        "description" => $description,
                        "part_no" => $partNo,
                        "qty" => $qty,
                        "hsn" => $hsn,
                        "rate" => $rate,
                        "total_amount" => $totaAmnt
                    ];
                }

                $data['pro_po_details'] = $products ?? [];

                $serviceDetails = json_decode($currentPo->service_details, true) ?? [];

                $initialPoDispatch = [
                    [
                        'id' => '',
                        'po_despatch_date' => Carbon::now()->format('d/m/Y'),
                        'details' => $products ?? [],
                        'service_details' => $serviceDetails
                    ]
                ];

                $poDispatch = PoDespatchDetail::where(['po_id' => $data['po_id']])->get();
                $groupedData = [];

                foreach ($poDispatch as $value) {
                    $id = $value->id ?? '';
                    $despatchDate = $value->despatch_date ?? '';
                    $details = json_decode($value->details, true) ?? [];
                    $serviceDetails = json_decode($value->service_details, true) ?? [];



                    $groupedData[] = [
                        'id' => $id,
                        'po_despatch_date' => Carbon::parse($despatchDate)->format('d/m/Y'),
                        'details' => $details,
                        'service_details' => $serviceDetails

                    ];
                }

                $data['poDespatch'] = !empty($groupedData) ? $groupedData : $initialPoDispatch;

                //FOR DISPATCH DATE DROPDOWN
                $poDispatchDetail = PoDespatchDetail::where('po_id', $data['po_id'])->get()->toArray();
                $dispatchDate = [];

                if (!empty($poDispatchDetail) && is_array($poDispatchDetail)) {
                    $dispatchDate = array_map(
                        fn($detail) => [
                            'id' => $detail['id'],
                            'dispatch_date' => Carbon::createFromFormat('Y-m-d', $detail['despatch_date'])->format('d/m/Y') ?? ''
                        ],
                        $poDispatchDetail
                    );
                }

                if (is_array($dispatchDate) && !empty($dispatchDate)) {
                    sort($dispatchDate);
                }

                $salesOrderObject = AvlockSalesOrder::where('fk_po_id', $data['po_id'])->get()->toArray();
                $salesOrderDate = [];

                if (!empty($salesOrderObject) && is_array($salesOrderObject)) {
                    $salesOrderDate = array_map(
                        fn($detail) => [
                            'id' => $detail['id'],
                            'so_date' =>  $detail['so_no'] . ' -' .  Carbon::createFromFormat('Y-m-d', $detail['so_date'])->format('d/m/Y') ?? ''
                        ],
                        $salesOrderObject
                    );
                }

                if (is_array($salesOrderDate) && !empty($salesOrderDate)) {
                    sort($salesOrderDate);
                }

                $data['dispatch_date'] = $dispatchDate ?? [];
                $data['sales_order_date'] = $salesOrderDate ?? [];


                $data['agreement_id'] = $poAgreement->id ?? 0;
                $data['agreement_no'] = $poAgreement->agreement_no ?? '';
                $data['agreement_date'] = $poAgreement->agreement_date ?? '';
                $data['agreement_ramark'] = $poAgreement->remark ?? '';

                $data['packaging_id'] = $poPackagingList->id ?? 0;
                $data['packaging_no'] = $poPackagingList->packaging_no ?? '';
                $data['packaging_date'] = $poPackagingList->packaging_date ?? '';
                $data['packaging_ramark'] = $poPackagingList->remark ?? '';


                $data['label_id'] = $poLabel->id ?? 0;
                $data['label_no'] = $poLabel->label_no ?? '';
                $data['label_date'] = $poLabel->label_date ?? '';
                $data['label_ramark'] = $poLabel->remark ?? '';


                $data['so_id'] = $salesOrder->id ?? 0;
                $data['so_no'] = $salesOrder->so_no ?? '';
                $data['so_date'] = $salesOrder->so_date ?? '';
                $data['so_remark'] = $salesOrder->remark ?? '';
                $data['so_no'] = $salesOrder->so_no ?? '';
                $data['so_details'] = $salesOrder->so_details ?? [];
                $data['so_service_details'] = $salesOrder->service_details ?? [];
                $data['so_details_total'] = $salesOrder->so_details_total ?? '';
                $data['so_curr_user'] = $salesOrder->curr_user ?? '';
                $data['so_curr_sub_stage_id'] = $salesOrder->curr_sub_stage_id ?? '';
                $data['so_attachments'] = $salesOrder->attachments ?? [];
                $data['so_cgst'] = $salesOrder->cgst ?? 0;
                $data['so_cgst_value'] = $salesOrder->cgst_value ?? 0;
                $data['so_sgst'] = $salesOrder->sgst ?? 0;
                $data['so_sgst_value'] = $salesOrder->sgst_value ?? 0;
                $data['so_igst'] = $salesOrder->igst ?? 0;
                $data['so_igst_value'] = $salesOrder->igst_value ?? 0;
                $data['so_billing_address1'] = $salesOrder->billing_address1 ?? '';
                $data['so_billing_address2'] = $salesOrder->billing_address2 ?? '';
                $data['so_billing_state'] = $salesOrder->billing_state ?? '';
                $data['so_billing_city'] = $salesOrder->billing_city ?? '';
                $data['so_billing_pincode'] = $salesOrder->billing_pincode ?? '';
                $data['so_shipping_address1'] = $salesOrder->shipping_address1 ?? '';
                $data['so_shipping_address2'] = $salesOrder->shipping_address2 ?? '';
                $data['so_shipping_state'] = $salesOrder->shipping_state ?? '';
                $data['so_shipping_city'] = $salesOrder->shipping_city ?? '';
                $data['so_shipping_pincode'] = $salesOrder->shipping_pincode ?? '';
                $data['so_billing_contact_no'] = $salesOrder->billing_contact_no ?? '';
                $data['so_billing_customer_name'] = $salesOrder->billing_customer_name ?? '';
                $data['so_billing_email'] = $salesOrder->billing_email ?? '';
                $data['so_shipping_contact_no'] = $salesOrder->shipping_contact_no ?? '';
                $data['so_shipping_customer_name'] = $salesOrder->shipping_customer_name ?? '';
                $data['so_shipping_email'] = $salesOrder->shipping_email ?? '';



                $data['pi_id'] = $purchaseInvoice->id ?? 0;
                $data['pi_no'] = $purchaseInvoice->pi_no ?? '';
                $data['pi_date'] = $purchaseInvoice->pi_date ?? '';
                $data['pi_remark'] = $purchaseInvoice->remark ?? '';
                $data['pi_no'] = $purchaseInvoice->pi_no ?? '';
                $data['pi_details'] = $purchaseInvoice->pi_details ?? [];
                $data['pi_service_details'] = $purchaseInvoice->service_details ?? [];
                $data['pi_details_total'] = $purchaseInvoice->pi_details_total ?? '';
                $data['pi_curr_user'] = $purchaseInvoice->curr_user ?? '';
                $data['pi_curr_sub_stage_id'] = $purchaseInvoice->curr_sub_stage_id ?? '';
                $data['pi_attachments'] = $purchaseInvoice->attachments ?? [];
                $data['pi_cgst'] = $purchaseInvoice->cgst ?? 0;
                $data['pi_cgst_value'] = $purchaseInvoice->cgst_value ?? 0;
                $data['pi_sgst'] = $purchaseInvoice->sgst ?? 0;
                $data['pi_sgst_value'] = $purchaseInvoice->sgst_value ?? 0;
                $data['pi_igst'] = $purchaseInvoice->igst ?? 0;
                $data['pi_igst_value'] = $purchaseInvoice->igst_value ?? 0;


                $data['dne_invoice_id'] = $poDneInvoice->id ?? 0;
                $data['dne_invoice_no'] = $poDneInvoice->dne_invoice_no ?? '';
                $data['dne_invoice_date'] = $poDneInvoice->dne_invoice_date ?? '';
                $data['dne_invoice_ramark'] = $poDneInvoice->remark ?? '';
                $data['dne_invoice_charges'] = $poDneInvoice->invoice_charges ?? [];

                $data['e_invoice_id'] = $poEInvoice->id ?? 0;
                $data['e_invoice_no'] = $poEInvoice->e_invoice_no ?? '';
                $data['e_invoice_date'] = $poEInvoice->e_invoice_date ?? '';
                $data['e_invoice_ramark'] = $poEInvoice->remark ?? '';
                $data['invoice_charges_detail'] = $poEInvoice->invoice_charges_detail ?? [];

                $data['eva_bill_no'] = $evaBill->eva_bill_no ?? '';
                $data['eva_bill_date'] = $evaBill->eva_bill_date ?? '';

                $data['delivery_date'] = $poDneInvoice->delivery_date ?? '';
                $data['recieved_by'] = $poDneInvoice->recieved_by ?? '';

                $data['quality_report_id'] = $poPdrQuality->id ?? 0;
                $data['quality_report_no'] = $poPdrQuality->quality_report_no ?? '';
                $data['quality_rmtc_no'] = $poPdrQuality->quality_rmtc_no ?? '';
                $data['quality_report_date'] = $poPdrQuality->quality_report_date ?? '';
                $data['quality_report_ramark'] = $poPdrQuality->remark ?? '';


                $data['lr_id'] = $poLr->id ?? 0;
                $data['lr_no'] = $poLr->lr_no ?? '';
                $data['lr_date'] = $poLr->lr_date ?? '';
                $data['lr_ramark'] = $poLr->remark ?? '';

                $data['rn_id'] = $poRn->id ?? 0;
                $data['rn_no'] = $poRn->lr_no ?? '';
                $data['rn_date'] = $poRn->lr_date ?? '';
                $data['rn_ramark'] = $poRn->remark ?? '';
            }



            switch ($data['curr_sub_stage_id']) {
                case 0: // for RFQ Generated
                    $data['active_sub_stages'] = SubStage::whereIn('id', [1, 19])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 3: // For Check Sample Available or not check
                    $data['active_sub_stages'] = SubStage::whereIn('id', [3, 4, 6])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 5: // for if sample available
                    $data['active_sub_stages'] = SubStage::whereIn('id', [5, 16])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 18: // for if sample available
                    $data['active_sub_stages'] = SubStage::whereIn('id', [18, 20])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();

                case 21: // to check rfq aprroved or Denied
                    $data['active_sub_stages'] = SubStage::whereIn('id', [21, 22, 28])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 22: // to check rfq aprroved or Denied
                    $data['active_sub_stages'] = SubStage::whereIn('id', [22, 37])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 37: // for Quotation prepared initiated
                    $data['active_sub_stages'] = SubStage::whereIn('id', [37, 23])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 23: // for Quotation prepared initiated
                    $data['active_sub_stages'] = SubStage::whereIn('id', [23, 26])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 27: // show stage PO Received By RSM
                    $data['active_sub_stages'] = SubStage::whereIn('id', [27, 34, 57])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 57: // show stage PO Received By RSM
                    $data['active_sub_stages'] = SubStage::whereIn('id', [57])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 34: // show Stage PO Verified with Quotation and PO not matched
                    $data['active_sub_stages'] = SubStage::whereIn('id', [34, 35, 50])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 39: // show Stage PO Verified with Quotation and PO not matched
                    $data['active_sub_stages'] = SubStage::whereIn('id', [34, 39, 56, 55])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 40: // show Stage PO Verified with Quotation and PO not matched
                    $data['active_sub_stages'] = SubStage::whereIn('id', [34, 40, 42,])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                case 56: // show Stage PO Verified with Quotation and PO not matched
                    $data['active_sub_stages'] = SubStage::whereIn('id', [34, 56, 49,])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                // case 49: //Show Stage PO Received By RSM
                //   $data['active_sub_stages'] = SubStage::whereIn('id', [49, 34])->where('status', 1)
                //     ->orderBy('id', 'asc')
                //     ->get();
                //   break;

                case 52: //Show Stage PO Received By RSM
                    $data['active_sub_stages'] = SubStage::whereIn('id', [52, 34])->where('status', 1)
                        ->orderBy('id', 'asc')
                        ->get();
                    break;

                default:
                    $subStageObject = SubStage::find($data['curr_sub_stage_id']);
                    if ($subStageObject) {
                        $currSubstageOrder = $subStageObject->order;
                        $currStageId = $subStageObject->stage_id;
                        $nextSubStageOrder = $currSubstageOrder + 1;

                        $data['active_sub_stages'] = SubStage::where(['status' => 1, 'order' => $nextSubStageOrder, 'stage_id' => $currStageId]);

                        if ($data['curr_sub_stage_id'] != 41) {
                            $data['active_sub_stages']->orWhere('id', $data['curr_sub_stage_id']);
                        } else {
                            $data['active_sub_stages']->orWhere('id', $data['curr_sub_stage_id']);
                        }

                        if ($data['curr_sub_stage_id'] > 34) {
                            $data['active_sub_stages']->orWhere('id', 34);
                        }

                        $data['active_sub_stages'] = $data['active_sub_stages']
                            ->orderBy('id', 'asc')
                            ->get();
                    }
                    break;
            }

            // Retrieve departmentIds and users based on active_sub_stages
            $departmentIds = [];
            if (isset($data['active_sub_stages']) && !empty($data['active_sub_stages'])) {
                foreach ($data['active_sub_stages'] as $stage) {
                    $toDepartments = $stage->to_departments ?? '';
                    if ($toDepartments != '') {
                        $departmentIds = array_merge($departmentIds, explode(",", $toDepartments));
                    }
                }
            }

            // $user = UserRole::with(['user' => function ($query) {
            //   $query->orderBy('name', 'asc');
            // }, 'user.roles.department', 'user.roles.departmentType', 'department'])
            //   ->whereIn('fk_department_id', array_unique($departmentIds))
            //   ->groupBy('fk_user_id')
            //   ->get();
            // $user = UserRole::with('user.roles.designation', 'user.roles.departmentType','department')
            //   ->whereHas('user.roles', function ($q) {
            //     $q->whereNotNull('id');
            //   })
            //   ->whereIn('fk_department_id', array_unique($departmentIds))->groupBy('fk_user_id')->get()->sortBy(function ($item) {
            //   return $item->user->name;
            // });
            // For RSM department id is 5

            $user = UserRole::with('user.roles.department', 'user.roles.departmentType', 'department')
                ->whereHas('user.roles', function ($q) {
                    $q->whereNotNull('id');
                })
                ->whereIn('fk_department_id', array_unique($departmentIds))->groupBy('fk_user_id')->get()
                ->sortBy(function ($item) {
                    return $item->user->name;
                });

            $data['active_users'] =  AllUserResource::collection($user);
            $data['departmentIds'] =  $departmentIds;

            $selectDepartment = Department::whereIn('id', $departmentIds)->get()->toArray();
            $data['cur_user_departments'] = implode(', ', array_column($selectDepartment, 'title'));

            if ($data['curr_sub_stage_id'] >= 22) {
                $projectQuotationTempFound = ProjectQuotationTemp::where('fk_rfq_id', $this->rfq->id)->first();
                if ($projectQuotationTempFound) {
                    $data['quotation_id'] =  $projectQuotationTempFound->id;
                    $data['quotation_req_details'] = json_decode($projectQuotationTempFound->requirements, true) ?? [];
                    $data['quotation_cgst'] = $projectQuotationTempFound->cgst ?? [];
                    $data['quotation_cgst_value'] = $projectQuotationTempFound->cgst_value ?? [];
                    $data['quotation_sgst'] = $projectQuotationTempFound->sgst ?? [];
                    $data['quotation_sgst_value'] = $projectQuotationTempFound->sgst_value ?? [];
                    $data['quotation_igst'] = $projectQuotationTempFound->igst ?? [];
                    $data['quotation_igst_value'] = $projectQuotationTempFound->igst_value ?? [];
                    $data['quotation_service_details'] = json_decode($projectQuotationTempFound->service_detail, true) ?? [];
                }
            }
        }


        // if (isset($this->rfq->product_id)) {
        //   $productId = $this->rfq->product_id;

        //   $productQtyParameter = ProductParameter::where('product_id', $productId)->where('is_qty', '1')->first();

        //   if ($productQtyParameter) {
        //     $qtyParamId = $productQtyParameter->id;
        //     $rfqResponse = RfqResponse::where('rfq_id', $this->rfq->id)->first();
        //     if ($rfqResponse) {
        //       $response = $rfqResponse->response ? json_decode($rfqResponse->response) : [];
        //       if (!empty($response)) {
        //         foreach ($response as $item) {
        //           if ($item->id === $qtyParamId) {
        //             $qty = (int)$item->value[0] ?? 0;
        //             $data['response_qty'] = $qty;

        //             if (isset($data['quotation_id'])) {
        //               $poObject = PurchaseOrder::where('fk_quotation_id', $data['quotation_id'])->where('po_status', "!=", PoStatus::PO_NOT_MATCH)->get();
        //               $count = $poObject->count();
        //               $totalPoQtyDone = 0;

        //               if ($count > 0) {
        //                 $poArray = $poObject->toArray();

        //                 foreach ($poArray as $key => $value) {
        //                   $poDetails = $value['po_details'] ? json_decode($value['po_details']) : [];
        //                   if (!empty($poDetails)) {
        //                     foreach ($poDetails as $item) {
        //                       $totalPoQtyDone += (int)$item->qty ?? 0;
        //                     }
        //                   }
        //                   # code...
        //                 }
        //               }

        //               $data['po_qty_remaining'] = max(0, (int)$qty - (int)$totalPoQtyDone);
        //             }


        //             break;
        //           }
        //         }
        //       }
        //     }
        //   }
        // }

        if (isset($this->rfq->id)) {
            $rfqProduct = RfqProduct::where('rfq_id', $this->rfq->id)->get()->toArray();
            if (!empty($rfqProduct)) {
                $totalResponseQty = 0;
                $totalPoQtyDone = 0;

                foreach ($rfqProduct as $rfqResponse) {
                    $qty = (int)($rfqResponse['product_qty'] ?? 0);
                    $totalResponseQty += $qty;
                }

                if (isset($data['quotation_id'])) {
                    $poObject = PurchaseOrder::where('fk_quotation_id', $data['quotation_id'])->where('po_status', "!=", PoStatus::PO_NOT_MATCH)->get();
                    $count = $poObject->count();

                    if ($count > 0) {
                        $poArray = $poObject->toArray();

                        foreach ($poArray as $key => $value) {
                            $poDetails = $value['po_details'] ? json_decode($value['po_details']) : [];
                            if (!empty($poDetails)) {
                                foreach ($poDetails as $item) {
                                    $totalPoQtyDone += (int)($item->qty ?? 0);
                                }
                            }
                        }
                    }
                }

                $productIds = array_column($rfqProduct, 'product_id');
                $data['rfq_approved_products'] = Product::select('id', 'product_name')->whereIn('id', $productIds)->get();
                $data['all_products'] = Product::select('id', 'product_name')->get();

                $data['response_qty'] = $totalResponseQty;
                $data['po_qty_remaining'] = max(0, $totalResponseQty - $totalPoQtyDone);
            }
        }
        $data['attachment_required_stage'] = config('global.ATTACHMENT_REQUIRED_STAGE');

        $projectSegmentsIds = isset($this->rfq->project_segments) ? json_decode($this->rfq->project_segments) : [];
        $projectTypeId = ($this->rfq) ? $this->rfq->fk_project_type_id : null;
        $divisionId = ($this->rfq) ? $this->rfq->division_id : null;

        if ($divisionId !== null) {
            $data['divisionName'] = Division::where('id', $this->rfq->division_id)->pluck('name')->first();
        } else {
            $data['divisionName'] = [];
        }

        if ($projectTypeId !== null) {
            $data['projectTypeName'] = ProjectType::where('id', $this->rfq->fk_project_type_id)->pluck('name')->first();
        } else {
            $data['projectTypeName'] = [];
        }

        $data['projectSegmentNames'] = ProjectSegment::whereIn('id', $projectSegmentsIds)->pluck('name')->implode(', ');
        $data['projectSegmentsIds'] = $projectSegmentsIds;
        $data['projectSegments'] = Rfq::whereIn('id', $projectSegmentsIds)->get()->toArray();

        return $data;
    }
}
