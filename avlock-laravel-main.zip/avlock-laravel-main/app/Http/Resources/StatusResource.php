<?php

namespace App\Http\Resources;

use App\Models\Task;
use App\Models\TaskUser;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class StatusResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {

    $editAllInput = TRUE;
    $editStatusInput = TRUE;
    $output =  parent::toArray($request);
    unset($output['statuses']);
    unset($output['taskType']);
    $output['name'] = $this->statuses->name ?? '';
    $output['code'] = $this->statuses->code ?? '';
    $output['status_id'] = $this->statuses->id;
    $output['status_name'] = $this->statuses->name;
    $output['task_type_id'] = $this->taskType->id ?? '';
    $output['task_type_name'] = $this->taskType->name ?? '';
    $output['calendar'] = $this->statuses->name;
    $output['assignedToName'] = $this->assignedTo->name ?? '';
    $output['assignedByName'] = $this->assignedBy->name ?? '';
    $output['color'] = $this->assignedTo->color_code ?? '';
    $taskUser = TaskUser::select('id', 'fk_user_id as id', 'user_name as name')->where('fk_task_id', $this->id)->get();
    $output['task_user'] = $taskUser;

    if ($this->created_by != $this->loggedInUserId) {
      $editAllInput = FALSE;
    }

    $editStatus = TaskUser::where('fk_task_id', $this->id)->where('fk_user_id', $this->loggedInUserId)->count();

    if ($editStatus == 0 && $this->created_by != $this->loggedInUserId) {
      $editStatusInput = FALSE;
    }

    $output['edit_all_input'] = $editAllInput;
    $output['edit_status_input'] = $editStatusInput;

    return $output;
  }
}
