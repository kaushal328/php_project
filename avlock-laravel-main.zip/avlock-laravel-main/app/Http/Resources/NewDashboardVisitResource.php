<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class NewDashboardVisitResource extends JsonResource {
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array {
        $data = parent::toArray($request);

        $output['company'] = $this->fk_task_type_id != 0 ? ($this->lead->company ?? '') : '-';
        $output['contact_person'] = $this->customer_name ?? '-';
        $output['contact_no'] = $this->fk_task_type_id != 0 ? ($this->lead->contact_no ?? '') : '-';

        return $data;
    }
}
