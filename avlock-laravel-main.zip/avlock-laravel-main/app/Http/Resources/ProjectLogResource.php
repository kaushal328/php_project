<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProjectLogResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {
    $data = parent::toArray($request);

    $data['stage'] = $this->stage->name ?? "RFQ Generated";
    $data['sub_stage'] = $this->subStage->name ?? "RFQ Generated";
    $data['action_by'] = $this->actionBy->name ?? "";
    // $data['curr_user'] = $this->curr_user ? implode(', ', array_column(json_decode($this->curr_user, true), 'name')) : "-";
    $data['curr_user'] = $this->curr_user ? json_decode($this->curr_user, true) : [];
    $data['attachments'] = $this->attachments ? json_decode($this->attachments, true) : [];
    $data['po_no'] = $this->po->po_no ?? "";


    return $data;
  }
}
