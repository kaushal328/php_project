<?php

namespace App\Http\Resources;

use App\Models\SubStage;
use App\Models\UserRole;
use App\Models\Designation;
use App\Models\PurchaseOrder;
use App\Models\TenderConsigneeRequirment;
use App\Models\TenderQuotation;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\TenderSubStage;

class TenderListResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {
    $data = parent::toArray($request);

    unset($data['sub_stage_users']);

    $nextSubStage = $this->currentSubStage->next_sub_stage_ids ?? [];
    $products = $this->products->toArray() ?? [];

    $tenderPartNoConsignee = [];

    foreach ($products as $key => $value) {
      $partNo = $value['part_no'];
      $proQty = $value['qty'];

      $tenderConsignees = TenderConsigneeRequirment::where('tender_id', $value['tender_id'])
        ->where('product_id', $value['id'])
        ->get();

      $consignees = [];
      foreach ($tenderConsignees as $index => $tenderConsignee) {
        $consignees[] = [
          'consignee_name' => $tenderConsignee->name ?? '',
          'consignee_qty' => $tenderConsignee->qty ?? ''
        ];
      }

      $tenderPartNoConsignee[] = [
        'part_no' => $partNo ?? '',
        'proQty' => $proQty ?? '',
        'consignees' => $consignees,
      ];
    }

    $data['tenderPartNoConsignee'] = $tenderPartNoConsignee;

    if (isset($products) && !empty($products)) {
      $partNo = array_map(
        fn($products) => $products['part_no'],
        $products
      );
    }

    $proQty = array_reduce(
      $products,
      fn($carry, $product) => $carry + $product['qty'],
      0
    );

    $data['total_qty'] = $proQty;

    $data['part_no'] = $partNo ?? [];

    $tender = TenderSubStage::with('nextSubStage')->whereIn('id', $nextSubStage)->get();
    $nextSubStageName = $tender->map(function ($item) {
      return $item->name;
    })->toArray();

    $data['quotation'] = TenderQuotation::where('tender_id', $this->id)->first();
    if (empty($data['quotation'])) {
      $data['quotation'] = null;
    }


    $departmentIds = [];
    foreach ($tender as $stage) {
      $toDepartments = $stage->to_departments ?? '';
      if ($toDepartments != '') {
        $departmentIds = array_merge($departmentIds, explode(", ", $toDepartments));
      }
    }

    $data['next_sub_stages_array'] =   $nextSubStageName;

    $user = UserRole::with('user.roles.department', 'user.roles.departmentType', 'department')
      ->whereHas('user.roles', function ($q) {
        $q->whereNotNull('id');
      })
      ->whereIn('fk_department_id', array_unique($departmentIds))->groupBy('fk_user_id')->get()
      ->sortBy(function ($item) {
        return $item->user->name;
      });

    $allDocuments = [];

    $tenderAttachment = !empty($this->sub_stage_attachments) ? json_decode($this->sub_stage_attachments, true) : [];

    $purchaseOrders = PurchaseOrder::where('fk_tender_id', $this->id)->get();
    $poAttachment = [];
    foreach ($purchaseOrders as $purchaseOrder) {
      $attachments = !empty($purchaseOrder->attachments) ? json_decode($purchaseOrder->attachments, true) : [];
      foreach ($attachments as $attachment) {
        $poAttachment[] = $attachment;
      }
    }

    $allDocuments = [
      'tender_attachment' => $tenderAttachment,
      'po_attachment' => $poAttachment,
    ];

    $data['all_documents'] = $allDocuments;
    $data['next_stage_users'] =  AllUserResource::collection($user);

    $userDesignation = $this->subStageUsers->map(function ($user) {
      return $user->name . ' (' . $user->designation->title . ')';
    })->toArray();

    $data['curr_users'] = $userDesignation;
    $data['all_po_completed'] = $this->pos->map(function ($po) {
      return ($po->tenderSubStage && $po->tenderSubStage->is_last_stage == 1) ? 1 : 0;
    });


    return $data;
  }
}
