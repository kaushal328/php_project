<?php

namespace App\Http\Resources;

use App\Models\Lead;
use App\Models\LeadContactPeople;
use App\Models\LeadDesignation;
use App\Models\ProjectSegment;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Models\RfqProduct;
use App\Models\Source;

class RfqFillDetailsResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {
    $data = parent::toArray($request);

    unset($data);
    $data['rfq_response_id'] = $this->rfqResponse->id ?? null;
    $data['selected_industries'] = $this->response_industries ?? '';
    $data['other_industries'] = $this->response_other_industries ?? '';
    $data['banner_image'] = $this->banner->images ?? [];
    $data['footer_image'] = $this->footer->images ?? '';
    $data['rfq_id'] = $this->id ?? null;
    $data['rfq_number'] = $this->rfq_number ?? '';
    $data['industry'] = $this->industry;
    $data['product_images'] = $this->product_images;
    $data['product_field_count'] = $this->product_field_count;
    $data['customer_name'] = $this->customer_name;
    $data['assigned_rsm_name'] = $this->assigned_rsm_name;
    $data['company'] = $this->lead->company ?? '';
    $data['designation'] = $this->designation->name ?? '';
    $data['email'] = $this->email;
    $data['contact_no'] = $this->contact_no;
    $data['address1'] = $this->address1;
    $data['address2'] = $this->address2;
    $data['city'] = $this->city;
    $data['pincode'] = $this->pincode;
    $data['state'] = $this->state;
    $data['product_name'] = $this->product_name;
    $source = Source::where('id', $this->fk_source_id)->first();
    $data['source'] = $source ? $source->name : null;
    $proSegmentsIds = json_decode($this->project_segments, true) ?? [];
    $projectSegments = ProjectSegment::whereIn('id', $proSegmentsIds)->pluck('name')->implode(', ');
    $data['project_segments'] = $projectSegments;
    $data['product_id'] = $this->product_id;
    $data['created_at'] = $this->created_at;
    $data['rfq_date'] = $this->rfq_date;
    $data['rfq_remark'] = $this->rfq_remark;
    $data['gstin'] = isset($this->lead) ? $this->lead->gstin : '';
    $data['products'] = $this->product;

    $designationIds = $this->lead?->designations ?? [];
    $data['designationIds'] = $designationIds;

    $designationLeadContactId = $this?->lead_contact_people_id ?? null;

    $desgIds = $designationLeadContactId ? LeadContactPeople::find($designationLeadContactId) : null;
    $data['designations'] = $desgIds && is_array($desgIds->designations)  ? LeadDesignation::whereIn('id', $desgIds->designations)->pluck('name')->implode(', ')  : '';

    $product = $this->product->load('productPart');

    $data['property_list'] = RfqProductResource::collection($product);

    // $rfqResponseObj = [];
    // $responseData = json_decode($this->rfqResponse->response ?? "", true);
    // if ($responseData) {
    //   foreach ($responseData as $obj) {
    //     foreach ($obj['value'] as $index => $val) {
    //       $key = $obj['id'] . '-' . ($index + 1);
    //       $rfqResponseObj[$key] = $val;
    //     }
    //   }
    // }
    // $data['rfq_response_obj'] = $rfqResponseObj;
    // $data['product_qty'] = $this->rfqResponse->product_qty ?? 0;

    // if (isset($this->id)) {
    //   $products = RfqProduct::with('product', 'productPart')->where('rfq_id', $this->id)->get()->toArray();
    //   $proPlus = [];

    //   foreach ($products as $pro) {
    //     $temp = [];
    //     $temp['id'] = $pro['id'];
    //     $temp['product_id'] = $pro['product']['id'];
    //     $temp['product_cat_id'] = $pro['product']['product_category_id'];
    //     $temp['description'] = $pro['product']['short_description'];
    //     $temp['hsn'] = $pro['product']['hsn'];
    //     $temp['product_part_id'] = $pro['product_part']['id'] ?? '';
    //     $temp['partNoName'] = $pro['product_part']['part_no'] ?? '';
    //     $temp['qty'] = $pro['product_qty'] ?? 0;
    //     $proPlus[] = $temp;
    //   }

    //   $data['productPlus'] = $proPlus;
    // }


    return $data;
  }
}
