<?php

namespace App\Http\Resources;

use App\Enums\PoStatus;
use App\Models\AvlockSalesOrder;
use App\Models\DeliveryConfirmation;
use App\Models\LeadDesignation;
use App\Models\PoDespatchDetail;
use App\Models\Product;
use App\Models\ProductParameter;
use App\Models\PurchaseInvoice;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderLog;
use App\Models\RfqProduct;
use App\Models\RfqResponse;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PoDispatchResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);

        $products = [];

        if (isset($this->po_details) && !empty($this->po_details)) {
            foreach (json_decode($this->po_details) as $value) {
                $productId = $value->product_id ?? "";
                $productPartId = $value->product_part_id ?? ($value->part_noId ?? '');
                $proName = Product::where('id', $productId)->pluck('product_name')->first();
                $description = $value->description ?? "";
                $partNo = $value->part_no ?? "";
                $hsn = $value->hsn ?? "";
                $qty = $value->qty ?? "";
                $rate = $value->rate ?? "";
                $totaAmnt = $value->total_amount ?? "";

                $products[] = [
                    "product_id" => $productId,
                    "product_part_id" => $productPartId,
                    "product_name" => $proName,
                    "description" => $description,
                    "part_no" => $partNo,
                    "hsn" => $hsn,
                    "qty" => $qty,
                    "rate" => $rate,
                    "total_amount" => $totaAmnt
                ];
            }
        }

        $data['pro_po_details'] = $products;

        $serviceDetails = json_decode($this->service_details, true) ?? [];

        $initialPoDispatch = [
            [
                'id' => '',
                'po_despatch_date' => Carbon::now()->format('d/m/Y'),
                'details' => $products,
                'service_details' => $serviceDetails
            ]
        ];
        $poDispatch = PoDespatchDetail::where(['po_id' => $this->id])->get();
        $groupedData = [];

        foreach ($poDispatch as $value) {
            $id = $value->id ?? '';
            $despatchDate = $value->despatch_date ?? '';
            $details = json_decode($value->details, true) ?? [];
            $serviceDetails = json_decode($value->service_details, true) ?? [];


            $groupedData[] = [
                'id' => $id,
                'po_despatch_date' => Carbon::parse($despatchDate)->format('d/m/Y'),
                'details' => $details,
                'service_details' => $serviceDetails
            ];
        }

        // if ($poDispatch) {
        //     $poDispatchIds = $poDispatch->map(function ($poDispatch) {
        //         return $poDispatch->id ?? '';
        //     });

        //     $salesOrdersForPoDispatch = AvlockSalesOrder::whereIn('dispatch_id', $poDispatchIds)->get();

        // }

        $soForDispatch = [];

        if (!empty($poDispatch)) {
            foreach ($poDispatch as $value) {
                $dispatchDate = $value->despatch_date ?? '';
                $soData = [];

                $salesOrders = AvlockSalesOrder::where('dispatch_id', $value->id)->get();
                foreach ($salesOrders as $item) {
                    $soNo = $item->so_no ?? '';
                    $status = DeliveryConfirmation::where('sales_order_id', $item->id)->exists() ? 'Delivered' : 'In-Process';

                    $soData[] = [
                        'sales_order_no' => $soNo,
                        'progress' => $status,
                    ];
                }

                $soForDispatch[] = [
                    'id' => $value->id ?? '',
                    'dispatch_date' => Carbon::parse($despatchDate)->format('d M Y'),
                    'so_details' => $soData,
                ];
            }
        }

        $isMaterialSubmit = false;
        $poObj = PurchaseOrder::find($this->id);
        $poDespatchObj = PoDespatchDetail::where('po_id', $this->id)->first();
        if ($poObj->curr_sub_stage_id >= 39 && $poDespatchObj) {
            $isMaterialSubmit = true;
        }

        $data['so_for_dispatch'] = $soForDispatch ?? [];
        $data['is_material_submit'] = $isMaterialSubmit;
        $data['poDespatch'] = !empty($groupedData) ? $groupedData : $initialPoDispatch;

        return $data;
    }
}
