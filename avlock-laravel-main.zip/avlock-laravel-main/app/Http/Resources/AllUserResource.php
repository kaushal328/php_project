<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AllUserResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array {

    $output['id'] = $this->user->id;
    // $output['name'] = $this->user->name;
    $output['department'] = $this->department->title ?? '';
    $designation = new UserResourceForSelectInput($this->user);
    $designationData = $designation->toArray($request);
    $output['name'] = $designationData['name'];
    $output['user_designation'] = $designationData['des_name'] . ' ' .'(' .$designationData['designation']. ')';
    return $output;
  }
}
