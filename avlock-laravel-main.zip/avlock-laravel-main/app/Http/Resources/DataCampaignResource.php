<?php

namespace App\Http\Resources;

use App\Models\SmsCampaign;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DataCampaignResource extends JsonResource {
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray($request) {
    
    // $output = parent::toArray($request);
    $output['id'] = $this->campaign->id;
    $output['campaign_id'] = $this->campaign->campaign_id ?? '';
    $output['title'] = $this->campaign->title ?? '';

    return $output;
}
}
