<?php

namespace App\Http\Resources;

use App\Models\UserRole;
use Illuminate\Http\Request;
use App\Http\Resources\AllUserResource;
use App\Models\ProjectSamplingSubStage;
use Illuminate\Http\Resources\Json\JsonResource;

class SamplingListResource extends JsonResource {
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array {
    $data = parent::toArray($request);

    unset($data['sub_stage_users']);

    $nextSubStage = $this->currentSubStage->next_sub_stage_ids ?? [];

    $projectSampling = ProjectSamplingSubStage::with('nextSubStage')->whereIn('id', $nextSubStage)->get();
    $nextSubStageName = $projectSampling->map(function ($item) {
      return $item->name;
    })->toArray();
    

    $departmentIds = [];
    foreach ($projectSampling as $stage) {
      $toDepartments = $stage->to_departments ?? '';
      if ($toDepartments != '') {
        $departmentIds = array_merge($departmentIds, explode(", ", $toDepartments));
      }
    }

    $data['next_sub_stages_array'] =   $nextSubStageName;

      $user = UserRole::with('user.roles.department', 'user.roles.departmentType', 'department')
      ->whereHas('user.roles', function ($q) {
          $q->whereNotNull('id');
      })
      ->whereIn('fk_department_id', array_unique($departmentIds))->groupBy('fk_user_id')->get()
      ->sortBy(function ($item) {
          return $item->user->name;
      });
    

      $data['next_stage_users'] =  AllUserResource::collection($user);

      $userDesignation = $this->subStageUsers->map(function ($user) {
        return $user->name . ' (' . $user->designation->title . ')';
      })->toArray();

      $data['curr_users'] = $userDesignation;

      return $data;

  }
}
