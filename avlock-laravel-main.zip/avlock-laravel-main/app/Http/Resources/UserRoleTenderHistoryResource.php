<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserRoleTenderHistoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $output = parent::toArray($request);

        $output['users'] = $this->users->map(function ($user) {
            $user = [
                'id' => $user->id,
                'name' => $user->name,
                'roles' => $user->roles->map(function ($role) {
                    return $role->department->title;
                })->toArray()
            ];

            return $user;
        })->toArray();

        return $output;
    }
}
