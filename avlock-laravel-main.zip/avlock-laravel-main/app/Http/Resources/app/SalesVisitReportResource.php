<?php

namespace App\Http\Resources\app;

use App\Models\Product;
use App\Models\SvrProduct;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SalesVisitReportResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $output = parent::toArray($request);
        $output['industry_type'] = isset($this->industry_type) ? json_decode($this->industry_type, true) : [];
        $output['customer_representatives'] = isset($this->customer_representatives) ? json_decode($this->customer_representatives, true) : [];

        $jsonString = trim($this->products, '"');

        // Decode the JSON string and handle errors
        $productIds = json_decode($jsonString, true);

        if ($productIds !== null && is_array($productIds)) {
            $products = Product::whereIn('id', $productIds)->get();
            $productNames = $products->pluck('product_name')->implode(', ');
            $output['product_names'] = $productNames;
        } else {
            $output['product_names'] = '';
        }
        // $productIds = $this->products ? json_decode($this->products, true) : [];
        $output['products'] = $productIds;

        if (!empty($this->id)) {
            $svrProduct = SvrProduct::with('product')->where('svr_id', $this->id)->get()->toArray();
        }
        $proInterest = [];

        foreach ($svrProduct as $svrPro) {
            $temp = [];
            $temp['id'] = $svrPro['id'];
            $temp['product_id'] = $svrPro['product']['id'];
            $proInterest[] = $temp;
        }

        $output['proInterest'] = $proInterest;

        return $output;
    }
}
