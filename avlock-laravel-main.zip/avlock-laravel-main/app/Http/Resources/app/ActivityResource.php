<?php

namespace App\Http\Resources\app;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ActivityResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *s
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {
    $output = parent::toArray($request);
    $output['attachment'] = isset($this->attachment) ? json_decode($this->attachment, true) : [];
    return $output;
  }
}
