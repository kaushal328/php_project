<?php

namespace App\Http\Resources\app;

use App\Models\ReminderUser;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ReminderResource extends JsonResource {
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array {
    $output =  parent::toArray($request);
    unset($output['task_type']);
    unset($output['remminderlead']);
    unset($output['remminderfq']);
    $output['task_type_id'] = $this->taskType->id;
    $output['task_type_name'] = $this->taskType->name ?? '';
    $output['lead_id'] = $this->Remminderlead->id ?? '';
    $output['customer_name'] = $this->Remminderlead->customer_name ?? '';
    $output['rfq_id'] = $this->Remminderfq->id ?? '';
    $output['rfq_number'] = $this->Remminderfq->rfq_number ?? '';
    $reminderUser = ReminderUser::select('id', 'fk_user_id as id', 'user_name as name')->where('fk_reminder_id', $this->id)->get();
    $output['reminder_user'] = $reminderUser;
    return $output;
  }
}
