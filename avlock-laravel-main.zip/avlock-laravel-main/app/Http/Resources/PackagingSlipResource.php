<?php

namespace App\Http\Resources;

use App\Models\Labeling;
use App\Models\PackagingSlipDetail;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PackagingSlipResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {

        $output = parent::toArray($request);
        // $output['id'] = $this->id;
        // $output['packaging_slip_no'] = $this->packaging_slip_no ?? '';
        // $output['packaging_slip_date'] = $this->packaging_slip_date ?? '';
        // $output['sales_order_date_format'] = $this->sales_order_date ?? '';
        // $output['sales_order_date'] = $this->salesOrderDate ?? '';

        // $output['despatch_date'] = $this->deapatch_date ?? '';
        $PsdObject = PackagingSlipDetail::with('labeling', 'dispatchDate')->where('packaging_slip_id', $this->id)->get();
        $labeling = Labeling::where('packaging_slip_id', $this->id)->get();


        $packagingDetails = [];
        foreach ($PsdObject as $value) {
            $psdId = $value->id ?? '';
            $productPartIds = !empty($value->product_part_ids) ? array_map('intval', explode(',', $value->product_part_ids)) : [];
            $batchNo = $value->batch_no ?? '';
            $dispatchDate = $value->dispatch_date ?? '';
            $lists = [];

            foreach ($labeling as $item) {
                if ($item->packaging_slip_detail_id == $value->id) {
                    $labelingId = $item->id ?? '';
                    $qty = $item->qty ?? '';
                    $noOfCarton = $item->no_of_carton ?? '';
                    $totalQty = $item->total_qty ?? '';
                    $weightCarton = $item->weight_carton ?? '';
                    $totalWeight = $item->total_weight ?? '';
                    $weightUnit = $item->weight_unit ?? '';

                    $lists[] = [
                        "id" => $labelingId  ?? '',
                        "qty" => $qty  ?? '',
                        "no_of_carton" => $noOfCarton  ?? '',
                        "total_qty" => $totalQty  ?? '',
                        "weight_carton" => $weightCarton  ?? '',
                        "total_weight" => $totalWeight  ?? '',
                        "weight_unit" => $weightUnit  ?? '',
                    ];
                }
            }


            $packagingDetails[] = [
                'id' => $psdId,
                'product_part_ids' => $productPartIds,
                'batch_no' => $batchNo,
                'dispatch_date' => $dispatchDate,
                'lists' => $lists
            ];
        }

        $output['packaging_detail'] = $packagingDetails ?? [];

        return $output;
    }
}
