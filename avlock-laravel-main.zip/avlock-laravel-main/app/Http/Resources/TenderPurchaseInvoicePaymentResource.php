<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use App\Models\TenderPurchaseInvoice;
use Illuminate\Http\Resources\Json\JsonResource;

class TenderPurchaseInvoicePaymentResource extends JsonResource {
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array {
    $data = parent::toArray($request);

    $inoiceIds = $this->fk_pi_id ? explode(",", $this->fk_pi_id) : [];

    $invoices = [];

    if (!empty($inoiceIds)) {
      $invoices = TenderPurchaseInvoice::whereIn('id', $inoiceIds)->get()->toArray();
    }

    $data['invoices'] = $invoices;

    return $data;
  }
}
