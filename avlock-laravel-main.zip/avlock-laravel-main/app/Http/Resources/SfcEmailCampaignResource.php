<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SfcEmailCampaignResource extends JsonResource {
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array {
      $output =  parent::toArray($request);
      unset($output['sfc_email_campaign']);
      $output['campaign_id'] = $this->campaign->id;
      return $output;
    }
}
