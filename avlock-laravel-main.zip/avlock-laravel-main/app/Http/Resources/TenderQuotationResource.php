<?php

namespace App\Http\Resources;

use App\Enums\QuotationStatus;
use App\Models\BiddingConsigneeRequirment;
use App\Models\BiddingProductRequirment;
use App\Models\Footer;
use App\Models\Product;
use App\Models\ProductParameter;
use App\Models\RfqBanner;
use App\Models\RfqProduct;
use App\Models\RfqResponse;
use App\Models\TenderConsigneeRequirment;
use App\Models\TenderProductRequirement;
use App\Models\Unit;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TenderQuotationResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {
    $data = parent::toArray($request);

    $data['requirement_total_in_words'] = $this->tender->total_amount ? convertAmountToWords((float)$this->tender->total_amount) : "";
    $data['banner_image'] = RfqBanner::find(1)->images ?? [];
    $data['footer_image'] = Footer::find(1)->images ?? [];
    $products = BiddingProductRequirment::with('product')->where('tender_id', $this->tender_id)->get();
    $productsWithTotal = $products->map(function ($item) {
      $qty = floatval($item->qty);
      $rate = floatval($item->rate);
      $total = $qty * $rate;
      return $item->setAttribute('total_amount', $total);
    });

    $biddingProduct = [];

    foreach ($products as $key => $value) {
      $partNo = $value->part_no ?? '';
      $desc = $value->description ?? '';
      $avlockDesc = $value->avlock_description ?? '';
      $rate = $value->rate ?? '';

      $consignees = [];
      $totalConsigneeQty = 0;

      $con = BiddingConsigneeRequirment::where('product_id', $value->id)->get();
      foreach ($con as $ckey => $item) {
        $name = $item->name ?? '';
        $cqty = $item->qty ?? 0;
        $unit = $item->unit ?? '';

        if ($unit) {
          $unitObj = Unit::find($unit);
        }

        $consignees[] = [
          'name' => $name,
          'qty' => $cqty,
          'unit' => $unitObj->title ?? '',
        ];

        $totalConsigneeQty += floatVal($cqty);
      }

      $totalAmount = $totalConsigneeQty * floatVal($rate);
      $biddingProduct[] = [
        'part_no' => $partNo,
        'description' => $desc,
        'avlock_description' => $avlockDesc,
        'qty' => $totalConsigneeQty,
        'rate' => $rate,
        'total_amount' => $totalAmount,
        'consignees' => $consignees,
      ];
    }


    $totalAmountSum = array_reduce($biddingProduct, function ($carry, $product) {
      return $carry + ($product['total_amount'] ?? 0);
    }, 0);


    $data['total_bid_value'] = $totalAmountSum ?? '';
    $data['total_bid_value_in_word'] = convertAmountToWords($totalAmountSum);

    $data['bidding_products'] = $biddingProduct;

    $footer = Footer::find(1);
    $data['footer_image'] = $footer ? ($footer->pluck('images')->isNotEmpty() ? $footer->pluck('images') : '') : '';
    $header = RfqBanner::find(1);
    $data['header_image'] = $header ? ($header->pluck('images')->isNotEmpty() ? $footer->pluck('images') : '') : '';

    $data['products'] = $productsWithTotal;
    $totalAmountSum = $productsWithTotal->sum('total_amount');
    $formattedTotalAmount = moneyFormatIndia($totalAmountSum);
    $data['total_value'] = $formattedTotalAmount;
    $total_basic_value = $this->tender->set_value ? ($this->tender->set_value * $totalAmountSum) : 0;
    $data['total_basic_value'] = moneyFormatIndia($total_basic_value);
    $amountInwords = $totalAmountSum + $total_basic_value;
    $data['total_amount_in_words'] = convertAmountToWords($amountInwords);

    return $data;
  }
}
