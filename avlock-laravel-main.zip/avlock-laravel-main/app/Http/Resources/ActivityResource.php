<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Carbon;

class ActivityResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data =  parent::toArray($request);

        $startTime = Carbon::parse($this->start_time) ?? '';
        $endTime = Carbon::parse($this->end_time) ?? '';

        if ($endTime) {
            $totalMinutes = $startTime->diffInMinutes($endTime);
            $hours = floor($totalMinutes / 60);
            $minutes = $totalMinutes % 60;

            $totalTime = sprintf("%d hrs %d min", $hours, $minutes);
        }

        $data['total_time'] = $totalTime ?? '';

        return $data;
    }
}
