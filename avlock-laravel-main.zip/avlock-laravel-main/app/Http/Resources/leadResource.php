<?php

namespace App\Http\Resources;

use App\Enums\ClientType;
use App\Models\Activity;
use App\Models\Designation;
use App\Models\LeadAddresses;
use App\Models\LeadContactPeople;
use App\Models\LeadDesignation;
use App\Models\ProjectQuotationTemp;
use App\Models\PurchaseOrder;
use App\Models\SalesVisitReport;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class LeadResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $output = parent::toArray($request);
        $output['region_name'] = $this->region->name ?? '';
        unset($output['region']);
        $output['source_name'] = $this->source->name ?? '';
        unset($output['source']);
        $output['division_name'] = $this->division->name ?? '';
        // unset($output['division']);
        $output['designation_name'] = $this->designation->title ?? '';
        unset($output['designation']);
        $output['rsmr_name'] = $this->rsmr->name ?? '';
        unset($output['rsmr']);
        $output['rsmv_name'] = $this->rsmv->name ?? '';
        unset($output['rsmv']);
        $output['fk_rfq_id'] = $this->rfq->id ?? null;

        unset($output['assigned_rsm']);
        $output['assigned_rsm_name'] = $this->rsmv->name ?? '';

        $output['assigned_rsm_name'] = $this->assignedRsm->name ?? '';

        $designationIds = $this->designations ? $this->designations : [];
        if (!is_array($designationIds)) {
            $designationIds = explode(',', $designationIds);
        }
        $output['designationIds'] = $designationIds;
        $output['designations'] = Designation::whereIn('id', $designationIds)->get()->toArray();

        $leadAddresses = LeadAddresses::where('lead_id', $this->id)->get()->toArray();

        $hasDefault = array_filter($leadAddresses, function ($val) {
            return $val['is_default'] == 1;
        });

        if (!count($hasDefault)) {
            $leadAddresses[] = [
                'id' => null,
                'is_default' => 1,
                'address1' => $this->address1,
                'address2' => $this->address2,
                'pincode' => $this->pincode,
                'city' => $this->city,
                'shipping_address1' => $this->shipping_address1,
                'shipping_address2' => $this->shipping_address2,
                'shipping_pincode' => $this->shipping_pincode,
                'shipping_city' => $this->shipping_city,
                'shipping_state' => $this->shipping_state,
                'is_shipping_same' => $this->is_shipping_same ?? 0,
            ];
        }

        $leadContactPeople = LeadContactPeople::where('lead_id', $this->id)->get();

        $defaultAddress = LeadAddresses::where('lead_id', $this->id)->where('is_default', 1)->first();
        $output['default_address_id'] = !empty($defaultAddress) ? $defaultAddress->id : null;

        // $defaultContactPerson = LeadContactPeople::where('lead_id', $this->id)->where('is_default', 1)->first();
        // $output['default_contact_person_id'] = !empty($defaultContactPerson) ? $defaultContactPerson->id : null;

        $addresses = [];
        if (!empty($leadAddresses) || !empty($leadContactPeople)) {
            foreach ($leadAddresses as $leadAdd) {
                $contactPerson = [];
                $leadAddId = $leadAdd['id'] ?? '';
                $isDefault = $leadAdd['is_default'] ?? 0;
                $add1 = $leadAdd['address1'] ?? '';
                $add2 = $leadAdd['address2'] ?? '';
                $pincode = $leadAdd['pincode'] ?? '';
                $city = $leadAdd['city'] ?? '';
                $state = $leadAdd['state'] ?? '';
                $shippingAddress1 = $leadAdd['shipping_address1'] ?? '';
                $shippingAddress2 = $leadAdd['shipping_address2'] ?? '';
                $shippingPincode = $leadAdd['shipping_pincode'] ?? '';
                $shippingCity = $leadAdd['shipping_city'] ?? '';
                $shippingState = $leadAdd['shipping_state'] ?? '';
                $isShippingSame = $leadAdd['is_shipping_same'] ?? 0;

                foreach ($leadContactPeople as $lcp) {
                    if ($lcp->lead_address_id === $leadAdd['id']) {
                        $id = $lcp->id ?? '';
                        $leadAddressId = $lcp->lead_address_id ?? '';
                        $monogram = $lcp->monogram ?? '';
                        $customer_name = $lcp->customer_name ?? '';
                        $designations = $lcp->designations ?? [];
                        $email = $lcp->email ?? '';
                        $contact_no = $lcp->contact_no ?? '';
                        $altEmailOne = $lcp->alt_email_one ?? '';
                        $altEmailTwo = $lcp->alt_email_two ?? '';
                        $altContactOne = $lcp->alt_contact_one ?? '';
                        $altContactTwo = $lcp->alt_contact_two ?? '';
                        $desg = $lcp->designations ?? [];
                        $designationName = LeadDesignation::whereIn('id', $desg)->pluck('name')->implode(', ');
                        $designationNames = explode(', ', $designationName);

                        $contactPerson[] = [
                            'id' => $id,
                            'lead_address_id' => $leadAddressId,
                            'monogram' => $monogram,
                            'customer_name' => $customer_name,
                            'designations' => $designations,
                            'email' => $email,
                            'contact_no' => $contact_no,
                            'alt_email_one' => $altEmailOne,
                            'alt_email_two' => $altEmailTwo,
                            'alt_contact_one' => $altContactOne,
                            'alt_contact_two' => $altContactTwo,
                            'designation_names' => $designationNames,
                        ];
                    }
                }

                if (!$leadAddId) {
                    $contactPerson[] = [
                        'id' => '',
                        'monogram' => $this->monogram,
                        'customer_name' => $this->customer_name,
                        'email' => $this->email,
                        'designations' => $this->designations,
                        'contact_no' => $this->contact_no,
                        'alt_email_one' => $this->alt_email_one,
                        'alt_email_two' => $this->alt_email_two,
                        'alt_contact_one' => $this->alt_contact_one,
                        'alt_contact_two' => $this->alt_contact_two,
                    ];
                }

                $addresses[] = [
                    'id' => $leadAddId,
                    'is_default' => $isDefault,
                    'address1' => $add1,
                    'address2' => $add2,
                    'pincode' => $pincode,
                    'city' => $city,
                    'state' => $state,
                    'shipping_address1' => $shippingAddress1,
                    'shipping_address2' => $shippingAddress2,
                    'shipping_pincode' => $shippingPincode,
                    'shipping_city' => $shippingCity,
                    'shipping_state' => $shippingState,
                    'is_shipping_same' => $isShippingSame,
                    'contact_person' => $contactPerson,
                ];
            }
        }

        $leadContactPeople = LeadContactPeople::where('lead_id', $this->id)->get();

        if ($leadContactPeople->isNotEmpty()) {
            $lcpDesgId = $leadContactPeople->pluck('designations')->collapse()->toArray();
            if (!empty($lcpDesgId)) {
                $lcpDesg = LeadDesignation::whereIn('id', $lcpDesgId)->get();
                $lcpDesignations = $lcpDesg->pluck('name', 'id')->toArray();
                foreach ($leadContactPeople as $contactPerson) {
                    if (!is_null($contactPerson->designations) && is_array($contactPerson->designations)) {
                        $designations = array_intersect_key($lcpDesignations, array_flip($contactPerson->designations));
                        $contactPerson->designations = implode(', ', $designations);
                    } else {
                        $contactPerson->designations = '';
                    }
                }


                $output['lead_contact_people'] = $leadContactPeople;
            }
        }

        $output['addresses'] = $addresses;

        unset($output['rfqCount']);
        $svrCount = SalesVisitReport::where('fk_lead_id', $this->id)->count();
        $qtnCount = ProjectQuotationTemp::where('fk_lead_id', $this->id)->count();
        $poCount = PurchaseOrder::where('fk_lead_id', $this->id)->count();
        $output['rfq_count'] = count($this->rfqCount) ?? 0;
        $output['svr_count'] = $svrCount ?? 0;
        $output['qtn_count'] = $qtnCount ?? 0;
        $output['po_count'] = $poCount ?? 0;

        unset($output['activityCount']);
        $output['activity_count'] = count($this->activityCount) ?? 0;
        $output['client_type_text'] = $this->is_client ? ClientType::getTextFromValue($this->client_type) : 'Not Defined';

        return $output;
    }
}
