<?php

namespace App\Http\Resources;

use App\Models\Division;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource {
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array {
    $output = parent::toArray($request);
    $output['roles'] = $this->roles->map(function ($role) {
      return [
        $role->department->title . ' ' . $role->departmentType->title
      ];
    });

    $divisionIds = $this->division_ids ? explode(',', $this->division_ids) : [];

    if (!empty($divisionIds)) {
      $divisions = Division::whereIn('id', $divisionIds)->pluck('name');
      $output['divisionNames'] = implode(', ', $divisions->toArray());
    } else {
      $output['divisionNames'] = '';
    }

    return $output;
  }
}
