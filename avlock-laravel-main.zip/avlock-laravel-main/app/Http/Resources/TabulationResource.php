<?php

namespace App\Http\Resources;

use App\Models\BiddingConsigneeRequirment;
use App\Models\BiddingProductRequirment;
use App\Models\PurchaseOrder;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TabulationResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {
    $data =  parent::toArray($request);

    $td = json_decode($this->tabulation_detail);

    $tempTd = [
      'lc' => $this->lc ?? 0,
      'tab_details' => $td ?? [],
    ];

    $data['tabulationDetails'] = $tempTd ?? [];

    $po = PurchaseOrder::where(['fk_tender_id' => $this->tender_id, 'po_type' => 2])->first();

    $biddingPro = BiddingProductRequirment::where('tender_id', $this->tender_id)->get();

    $tenderPartNoConsignee = [];
    foreach ($biddingPro as $key => $value) {
      $partNo = $value->part_no;
      $proQty = $value->qty;

      $tenderConsignees = BiddingConsigneeRequirment::where('tender_id', $value->tender_id)
        ->where('product_id', $value->id)
        ->get();

      $consignees = [];
      foreach ($tenderConsignees as $index => $tenderConsignee) {
        $consignees[] = [
          'consignee_name' => $tenderConsignee->name ?? '',
          'consignee_qty' => $tenderConsignee->qty ?? ''
        ];
      }

      $tenderPartNoConsignee[] = [
        'part_no' => $partNo ?? '',
        'proQty' => $proQty ?? '',
        'consignees' => $consignees,
      ];
    }

    $purchaseOrders = PurchaseOrder::where('fk_tender_id', $this->tender_id)->get();
    $totalPoQty = 0;

    foreach ($purchaseOrders as $po) {
      $poDetails = json_decode($po->po_details) ?? [];

      if (!empty($poDetails)) {
        foreach ($poDetails as $detail) {
          if (isset($detail->consignees) && is_array($detail->consignees)) {
            foreach ($detail->consignees as $consignee) {
              $totalPoQty += $consignee->qty ?? 0;
            }
          }
        }
      }
    }

    $data['po_recevied_qty'] = $totalPoQty;
    $data['tenderPartNoConsignee'] = $tenderPartNoConsignee;
    return $data;
  }
}
