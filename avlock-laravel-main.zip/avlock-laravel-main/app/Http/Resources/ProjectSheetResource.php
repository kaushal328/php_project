<?php

namespace App\Http\Resources;

use App\Models\ProjectSegment;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProjectSheetResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);
        $proSegmentIds = $this->rfq ? json_decode($this->rfq->project_segments, true) : [];
        $proSegmentIds = is_array($proSegmentIds) ? $proSegmentIds : [];
        $proSegmentNames = ProjectSegment::whereIn('id', $proSegmentIds)->pluck('name')->implode(', ');

        $requirements = $this->requirements ? json_decode($this->requirements, true) : [];


        $data['proSegmentNames'] = $proSegmentNames;
        $data['qtn_requirements'] = $requirements;

        return $data;
    }
}
