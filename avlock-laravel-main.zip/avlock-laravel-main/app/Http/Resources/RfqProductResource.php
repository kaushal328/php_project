<?php

namespace App\Http\Resources;

use App\Models\ProductParameter;
use App\Models\ProductPart;
use Illuminate\Database\Eloquent\Factories\Sequence;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RfqProductResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {

    $data = parent::toArray($request);
    unset($data);

    $rfqResponseObj = [];
    $responseData = json_decode($this->response ?? "", true);
    // if ($responseData) {
    //   foreach ($responseData as $obj) {
    //     foreach ($obj['value'] as $index => $val) {
    //       $key = $obj['id'] . '-' . ($index + 1);
    //       $rfqResponseObj[] = [$key => $val];
    //     }
    //   }
    // }

    $data['id'] = $this->id;
    $data['product_name'] = $this->product->product_name;
    $data['product_description'] = $this->product->long_description;
    $data['part_no'] = $this->productPart->part_no ?? '';
    $data['description'] = $this->productPart->description ?? '';
    // $data['parameters'] = $this->product->parameters;
    $data['parameters'] = ProductParameter::where('product_id', $this->product->id)->orderBy('sequence')->get();
    $data['rfq_response_obj'] = $responseData ?? [];
    $data['product_qty'] = $this->product_qty ?? 0;


    return $data;
  }
}
