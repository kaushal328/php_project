<?php

namespace App\Http\Resources;

use App\Enums\QuotationStatus;
use App\Models\Designation;
use App\Models\Division;
use App\Models\LeadContactPeople;
use App\Models\LeadDesignation;
use App\Models\Product;
use App\Models\ProductParameter;
use App\Models\PurchaseOrder;
use App\Models\RfqProduct;
use App\Models\RfqResponse;
use App\Models\User;
use App\Models\UserRole;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProjectQuotationResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {
    $data = parent::toArray($request);

    $data['quotation_status_for_list'] = $this->quotation_status ? QuotationStatus::getTextFromValue($this->quotation_status) : "";
    $data['requirement_total_in_words'] = $this->final_amount ? convertAmountToWords((float)$this->final_amount, $this->rfq->currencyData->title ?? '') : "";
    $data['banner_image'] = $this->rfq->banner->images ?? [];
    $data['footer_image'] = $this->rfq->footer->images ?? '';
    $data['source'] = $this->lead->source ?? '';
    $data['response_qty'] = 0;
    $data['terms'] = $this->terms;
    $data['rsmName'] = $this->rfq->rsm->name ?? '';
    $data['rsm_designation'] = $this->rfq->rsm->designation->title ?? '';

    $designationLeadContactId = $this?->rfq?->lead_contact_people_id ?? null;
    $desgIds = $designationLeadContactId ? LeadContactPeople::find($designationLeadContactId) : null;
    $data['leadDesg'] = $desgIds && is_array($desgIds->designations)  ? LeadDesignation::whereIn('id', $desgIds->designations)->pluck('name')->implode(', ')  : '';

    $designationIdsString = $this->lead->designations ?? '';
    $designationIds = $designationIdsString;
    if ($designationIds) {
      $designation = LeadDesignation::whereIn('id', $designationIds)->get();
      $designation = $designation->map(function ($query) {
        return $query->name ?? '';
      });
    }

    $data['designation_title'] = $designation ?? '';

    //Get checked By
    $userRoleName = [];
    $usersList = [];
    if (!empty($this->rfq->division_id)) {
      $usersList = User::where('division_ids', $this->rfq->division_id)->get()->toArray();
    }
    $userIds = array_column($usersList, 'id');

    // $userLists = User::where('division_ids', $this->rfq->division_id)->get()->toArray();
    // $userIds = array_column($userLists, 'id');

    $checkedByUser = UserRole::with('user')
      ->whereIn('fk_user_id', $userIds)
      ->where('fk_department_id', 6)
      ->where(function ($query) {
        $query->where('fk_department_type_id', 4)
          ->orWhere('fk_department_type_id', 1);
      })
      ->first();

    $checkedBy = isset($checkedByUser->user) ? $checkedByUser->user->name ?? 'AVLOCK' : 'AVLOCK';

    $approvedBy = User::where('fk_designation_id', 1)->first();
    $data['approved_by'] = $approvedBy->name;

    $data['checked_by'] = $checkedBy;
    $data['show_download_button'] = TRUE;

    if (isset($this->rfq->id)) {
      $rfqProduct = RfqProduct::where('rfq_id', $this->rfq->id)->get()->toArray();
      if (!empty($rfqProduct)) {
        $totalResponseQty = 0;

        foreach ($rfqProduct as $rfqResponse) {
          $qty = (int)($rfqResponse['product_qty'] ?? 0);
          $totalResponseQty += $qty;
        }
        $productIds = array_column($rfqProduct, 'product_id');
        $data['rfq_products'] = Product::select('id', 'product_name')->whereIn('id', $productIds)->get();
        $data['response_qty'] = $totalResponseQty;
      }
    }

    $po = PurchaseOrder::where('fk_quotation_id', $this->id)->first();

    $showDelete = false;
    if (empty($po)) {
      $showDelete = true;
    }

    $data['show_delete'] = $showDelete;



    return $data;
  }
}
