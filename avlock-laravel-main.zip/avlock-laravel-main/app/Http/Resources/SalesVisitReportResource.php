<?php

namespace App\Http\Resources;

use App\Models\Product;
use App\Models\SvrProduct;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SalesVisitReportResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $output = parent::toArray($request);

        // Remove extra double quotes if present
        $jsonString = trim($this->products, '"');

        // Decode the JSON string and handle errors
        $productIds = json_decode($jsonString, true);

        if ($productIds !== null && is_array($productIds)) {
            $products = Product::whereIn('id', $productIds)->get();
            $productNames = $products->pluck('product_name')->implode(', ');
            $output['product_names'] = $productNames;
        } else {
            $output['product_names'] = '';
        }
        // $productIds = $this->products ? json_decode($this->products, true) : [];
        $output['products'] = $productIds;

        if (!empty($this->id)) {
            $svrProduct = svrProduct::with('product')->where('svr_id', $this->id)->get()->toArray();
        }
        $proInterest = [];

        foreach ($svrProduct as $svrPro) {
            $temp = [];
            $temp['id'] = $svrPro['id'];
            $temp['product_id'] = $svrPro['product']['id'];
            $temp['product_name'] = $svrPro['product']['product_name'];
            $proInterest[] = $temp;
        }

        $output['proInterest'] = $proInterest;
        $output['divison_name'] = isset($this->division) ? $this->division->name : '';
        $output['application_segments_arr'] = isset($this->application_segments) ? json_decode($this->application_segments, true) : [];
        return $output;
    }
}
