<?php

namespace App\Http\Resources;

use App\Enums\PoStatus;
use App\Models\LeadDesignation;
use App\Models\Product;
use App\Models\ProductParameter;
use App\Models\PurchaseInvoice;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderLog;
use App\Models\RfqProduct;
use App\Models\RfqResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PurchaseOrderResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {
    $data = parent::toArray($request);

    $data['po_status_for_list'] = $this->po_status ? PoStatus::getTextFromValue($this->po_status) : "";
    $data['stage'] = $this->stage->name ?? "Quotation Sent to Client";
    $data['sub_stage'] = $this->subStage->name ?? "Quotation Sent to Client";

    $status = '';
    if (!empty($this->curr_sub_stage_id) && $this->curr_sub_stage_id == config('global.DELIVERY CONFIRMATION')) {
      $status = 'Completed';
    } else {
      $status = 'Pending';
    }

    $data['po_state'] = $status;

    $data['curr_user'] = $this->curr_user ? json_decode($this->curr_user, true) : [];
    $lastLog = PurchaseOrderLog::where('fk_po_id', $this->id)
      ->latest()
      ->first();

    if ($lastLog) {
      $data['last_log_date'] = $lastLog->created_at;
    }

    $showAddInvoiceButton = false;

    $piCount = PurchaseInvoice::where('fk_po_id', $this->id)->count();
    if ($piCount > 0) {
      $showAddInvoiceButton = true;
    }

    $data['show_add_invoice_button'] = $showAddInvoiceButton;

    // if (isset($this->rfq->product_id)) {
    //   $productId = $this->rfq->product_id;

    //   $productQtyParameter = ProductParameter::where('product_id', $productId)->where('is_qty', '1')->first();

    //   if ($productQtyParameter) {
    //     $qtyParamId = $productQtyParameter->id;
    //     $rfqResponse = RfqResponse::where('rfq_id', $this->rfq->id)->first();
    //     if ($rfqResponse) {
    //       $response = $rfqResponse->response ? json_decode($rfqResponse->response) : [];
    //       if (!empty($response)) {
    //         foreach ($response as $item) {
    //           if ($item->id === $qtyParamId) {
    //             $qty = (int)$item->value[0] ?? 0;
    //             $data['response_qty'] = $qty;

    //             if (isset($this->id)) {
    //               $poObject = PurchaseOrder::where('id', $this->id)->get();
    //               $count = $poObject->count();
    //               $totalPoQtyDone = 0;

    //               if ($count > 0) {
    //                 $poArray = $poObject->toArray();

    //                 foreach ($poArray as $key => $value) {
    //                   $poDetails = $value['po_details'] ? json_decode($value['po_details']) : [];
    //                   if (!empty($poDetails)) {
    //                     foreach ($poDetails as $item) {
    //                       $totalPoQtyDone += (int)$item->qty ?? 0;
    //                     }
    //                   }
    //                   # code...
    //                 }
    //               }

    //               $data['pi_qty_remaining'] = max(0, (int)$qty - (int)$totalPoQtyDone);
    //             }


    //             break;
    //           }
    //         }
    //       }
    //     }
    //   }
    // }

    $designationIds = $this->lead->designations ?? [];
    if ($designationIds) {
      $designation = LeadDesignation::whereIn('id', $designationIds)->get();
      $designation = $designation->map(function ($query) {
        return $query->name ?? '';
      });
    }

    $data['designation_title'] = $designation ?? '';

    $poDetailArr = isset($this->po_details) ? json_decode($this->po_details) : [];
    $temp = [];
    if (isset($poDetailArr) && !empty($poDetailArr)) {
      foreach ($poDetailArr as $key => $pod) {
        $productId = $pod->product_id ?? '';
        $productName = Product::where('id', $productId)->value('product_name') ?? '';
        $description = $pod->description ?? '';
        $partNo = $pod->part_no ?? '';
        $hsn = $pod->hsn ?? '';
        $qty = $pod->qty ?? '';
        $rate = $pod->rate ?? '';
        $totalAmount = $pod->total_amount ?? '';
        $custDesc = $pod->cust_description ?? '';

        $temp[] = [
          'product_name' => $productName,
          'part_no' => $partNo,
          'description' => $description,
          'hsn' => $hsn,
          'qty' => $qty,
          'rate' => $rate,
          'total_amount' => $totalAmount,
          'cust_description' => $custDesc,
        ];
      }
    }

    $data['poDetails'] = $temp;
    $serviceTotal = $this->service_total;
    $poDetailTotal = $this->po_details_total;
    $finalAmount = $serviceTotal + $poDetailTotal;
    $data['final_amount'] = $finalAmount;

    $data['amount_in_words'] = $finalAmount ? convertAmountToWords((float)$finalAmount, $this->rfq->currencyData->title ?? '') : "";


    if (isset($this->rfq->id)) {
      $rfqProduct = RfqProduct::where('rfq_id', $this->rfq->id)->get()->toArray();
      if (!empty($rfqProduct)) {
        $totalResponseQty = 0;
        $totalPoQtyDone = 0;

        foreach ($rfqProduct as $rfqResponse) {
          $qty = (int)($rfqResponse['product_qty'] ?? 0);
          $totalResponseQty += $qty;
        }

        if (isset($data['quotation_id'])) {
          $poObject = PurchaseOrder::where('fk_quotation_id', $data['quotation_id'])->where('po_status', "!=", PoStatus::PO_NOT_MATCH)->get();
          $count = $poObject->count();

          if ($count > 0) {
            $poArray = $poObject->toArray();

            foreach ($poArray as $key => $value) {
              $poDetails = $value['po_details'] ? json_decode($value['po_details']) : [];
              if (!empty($poDetails)) {
                foreach ($poDetails as $item) {
                  $totalPoQtyDone += (int)($item->qty ?? 0);
                }
              }
            }
          }
        }

        $data['response_qty'] = $totalResponseQty;
        $data['po_qty_remaining'] = max(0, $totalResponseQty - $totalPoQtyDone);
      }
    }

    return $data;
  }
}
