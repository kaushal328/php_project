<?php

namespace App\Http\Resources;

use App\Models\AvlockPurchaseInvoice;
use App\Models\AvlockSalesOrder;
use App\Models\DeliveryConfirmation;
use App\Models\DeliveryNote;
use App\Models\EwayBill;
use App\Models\OrderDispatch;
use App\Models\PackagingSlip;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Carbon;

class SalesOrderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);
        $data['purchaseOrderNo'] = $this->po->po_no ?? '';
        $data['salesOrderNo'] = $this->so_no ?? '';

        $soDetailArr = isset($this->so_details) ? json_decode($this->so_details) : [];
        $temp = [];
        if (isset($soDetailArr) && !empty($soDetailArr)) {
            foreach ($soDetailArr as $key => $sod) {
                $productId = $sod->product_id ?? '';
                $productName = Product::where('id', $productId)->value('product_name') ?? '';
                $description = $sod->description ?? '';
                $partNo = $sod->part_no ?? '';
                $hsn = $sod->hsn ?? '';
                $qty = $sod->qty ?? '';
                $rate = $sod->rate ?? '';
                $totalAmount = $sod->total_amount ?? '';
                $custDesc = $sod->cust_description ?? '';

                $temp[] = [
                    'product_name' => $productName,
                    'part_no' => $partNo,
                    'description' => $description,
                    'hsn' => $hsn,
                    'qty' => $qty,
                    'rate' => $rate,
                    'total_amount' => $totalAmount,
                    'cust_description' => $custDesc,
                ];
            }
        }


        $status = DeliveryConfirmation::where('sales_order_id', $this->id)->exists() ? 'Delivered' : 'In-Process';


        $salesOrderDate = [
            'id' => $this->id ?? '',
            'so_date' =>  $this->so_no . ' -' .  Carbon::createFromFormat('Y-m-d', $this->so_date)->format('d/m/Y') ?? ''
        ];

        $packagingCount = PackagingSlip::where('sales_order_date', $this->id)->count();
        $deliveryNoteCount = DeliveryNote::where('sales_order_id', $this->id)->count();
        $invoiceCount = AvlockPurchaseInvoice::where('sales_order_id', $this->id)->count();
        $ewayBillCount = EwayBill::where('sales_order_id', $this->id)->count();
        $orderDispatchCount = OrderDispatch::where('sales_order_id', $this->id)->count();
        $deliveryConfirmationCount = DeliveryConfirmation::where('sales_order_id', $this->id)->count();


        $data['packaging_count'] = $packagingCount;
        $data['delivery_note_count'] = $deliveryNoteCount;
        $data['invoice_count'] = $invoiceCount;
        $data['eway_bill_count'] = $ewayBillCount;
        $data['od_count'] = $orderDispatchCount;
        $data['sales_order_date'] = $salesOrderDate;
        $data['dc_count'] = $deliveryConfirmationCount;
        $data['curr_status'] = $status;
        $data['soDetails'] = $temp;

        return $data;
    }
}
