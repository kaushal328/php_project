<?php

namespace App\Http\Resources;

use App\Enums\PoStatus;
use App\Models\AvlockSalesOrder;
use App\Models\LeadDesignation;
use App\Models\PoDespatchDetail;
use App\Models\Product;
use App\Models\ProductParameter;
use App\Models\ProductPart;
use App\Models\PurchaseInvoice;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderLog;
use App\Models\RfqProduct;
use App\Models\RfqResponse;
use App\Models\TenderBidding;
use App\Models\TenderPoDispatch;
use App\Models\TenderQuotation;
use App\Models\Unit;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TenderPurchaseOrderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);

        $poDetailArr = isset($this->po_details) ? json_decode($this->po_details) : [];
        $temp = [];
        if (isset($poDetailArr) && !empty($poDetailArr)) {
            foreach ($poDetailArr as $key => $pod) {
                $productId = $pod->product_id ?? '';
                $productPartId = $pod->product_part_id ?? '';
                $productName = Product::where('id', $productId)->value('product_name') ?? '';
                $description = $pod->description ?? '';
                $partNo = $pod->part_no ?? '';
                $proQty = $pod->qty ?? '';
                $rate = $pod->rate ?? '';
                $deliveryStartDate = $pod->delivery_start_date ?? '';
                $deliveryEndDate = $pod->delivery_end_date ?? '';
                $consignees = $pod->consignees ?? [];
                $mf = $pod->mf ?? '';
                $lc = $pod->lc ?? '';
                $totalAmount = floatVal($pod->qty) * floatVal($pod->rate);

                foreach ($consignees as $key => $consignee) {
                    $name = $consignee->name ?? '';
                    $qty = $consignee->qty ?? '';
                    $unit = $consignee->unit ?? '';
                    if ($unit) {
                        $unitObj = Unit::find($unit);
                    }
                    $deliveryPeriod = $consignee->delivery_period ?? '';

                    $consigneeDetails[] = [
                        'name' => $name,
                        'qty' => $qty,
                        'unit' => $unitObj->title ?? '',
                        'delivery_period' => $deliveryPeriod,
                    ];
                }

                $temp[] = [
                    'product_part_id' => $productPartId,
                    'product_name' => $productName,
                    'part_no' => $partNo,
                    'description' => $description,
                    'qty' => $proQty,
                    'delivery_start_date' => $deliveryStartDate,
                    'delivery_end_date' => $deliveryEndDate,
                    'rate' => $rate,
                    'total_amount' => $totalAmount,
                    'lc' => $lc,
                    'mf' => $mf,
                    'consignees' => $consigneeDetails,
                ];
            }
        }

        $dispatchDate = [];
        $tenderPoDispatch = PoDespatchDetail::where('po_id', $this->id)->get()->toArray();
        if (!empty($tenderPoDispatch) && is_array($tenderPoDispatch)) {
            $dispatchDate = array_map(
                fn($detail) => [
                    'id' => $detail['id'],
                    'despatch_date' => Carbon::createFromFormat('Y-m-d', $detail['despatch_date'])->format('d/m/Y') ?? '',
                ],
                $tenderPoDispatch
            );
        }

        $data['dispatch_date'] = $dispatchDate ?? [];

        $soObject = AvlockSalesOrder::where('fk_po_id', $this->id)->first();
        if ($soObject && $soObject->so_details) {
            $soDetails = json_decode($soObject->so_details);
            if (is_array($soDetails)) {
                $partNoIds = array_map(
                    fn($detail) => $detail->product_part_id ?? $detail->part_noId,
                    $soDetails
                );
            }

            if ($partNoIds) {
                $partNoLists = ProductPart::whereIn('id', $partNoIds)->get();
            }
        }

        $quotationCount = TenderBidding::where('tender_id', $this->fk_tender_id)->count();

        $data['poDetails'] = $temp;
        $serviceTotal = $this->service_total;
        $poDetailTotal = $this->po_details_total;
        $finalAmount = $serviceTotal + $poDetailTotal;
        $data['final_amount'] = $finalAmount;
        $data['part_no_lists'] = $partNoLists ?? [];
        
        $data['quotation_count'] = $quotationCount ?? 0;
        $data['amount_in_words'] = $finalAmount ? convertAmountToWords((float)$finalAmount) : "";

        return $data;
    }
}
