<?php

namespace App\Http\Resources;

use App\Enums\PoStatus;
use App\Models\AvlockSalesOrder;
use App\Models\DeliveryConfirmation;
use App\Models\LeadDesignation;
use App\Models\PoDespatchDetail;
use App\Models\Product;
use App\Models\ProductParameter;
use App\Models\PurchaseInvoice;
use App\Models\PurchaseOrder;
use App\Models\PurchaseOrderLog;
use App\Models\RfqProduct;
use App\Models\RfqResponse;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TenderDispatchResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);

        $poDispatch = PoDespatchDetail::where(['po_id' => $this->id])->get();
        $groupedData = [];

        foreach ($poDispatch as $value) {
            $id = $value->id ?? '';
            $despatchDate = $value->despatch_date ?? '';
            $details = json_decode($value->details, true) ?? [];
            $serviceDetails = json_decode($value->service_details, true) ?? [];


            $groupedData[] = [
                'id' => $id,
                'po_despatch_date' => Carbon::parse($despatchDate)->format('d/m/Y'),
                'details' => $details,
                'service_details' => $serviceDetails
            ];
        }

        // if ($poDispatch) {
        //     $poDispatchIds = $poDispatch->map(function ($poDispatch) {
        //         return $poDispatch->id ?? '';
        //     });

        //     $salesOrdersForPoDispatch = AvlockSalesOrder::whereIn('dispatch_id', $poDispatchIds)->get();

        // }

        $soForDispatch = [];

        if (!empty($poDispatch)) {
            foreach ($poDispatch as $value) {
                $dispatchDate = $value->despatch_date ?? '';
                $soData = [];

                $salesOrders = AvlockSalesOrder::where('dispatch_id', $value->id)->get();
                foreach ($salesOrders as $item) {
                    $soNo = $item->so_no ?? '';
                    $status = DeliveryConfirmation::where('sales_order_id', $item->id)->exists() ? 'Delivered' : 'In-Process';

                    $soData[] = [
                        'sales_order_no' => $soNo,
                        'progress' => $status,
                    ];
                }

                $soForDispatch[] = [
                    'id' => $value->id,
                    'dispatch_date' => Carbon::parse($despatchDate)->format('d M Y'),
                    'so_details' => $soData,
                ];
            }
        }

        $tenderPoDispatch = PoDespatchDetail::where(['po_id' => $this->id,])->get();

        $dispatchDetails = [];

        if (!empty($tenderPoDispatch)) {
            foreach ($tenderPoDispatch as $value) {
                $temp = [];

                $despatchDetails = json_decode($value->details) ?? [];
                foreach ($despatchDetails as $item) {
                    $productId = $item->product_id ?? '';
                    $productName = Product::where('id', $productId)->pluck('product_name')->first();
                    $partNo = $item->part_no ?? '';
                    $description = $item->description ?? '';
                    $avlockDescription = $item->avlock_description ?? '';
                    $qty = $item->qty ?? 0;
                    $rate = $item->rate ?? 0;
                    $consignees = $item->consignees ?? [];

                    $temp[] = [
                        'product_id' => $productId,
                        'product_name' => $productName,
                        'part_no' => $partNo,
                        'description' => $description,
                        'avlock_description' => $avlockDescription,
                        'qty' => $qty,
                        'rate' => $rate,
                        'consignees' => $consignees
                    ];
                }

                $dispatchDetails[] = [
                    'id' => $value->id ?? '',
                    'po_despatch_date' => isset($value) && $value->despatch_date
                        ? Carbon::createFromFormat('Y-m-d', $value->despatch_date)->format('d/m/Y')
                        : '',
                    'remark' => isset($value) && $value->remark ? $value->remark : '',
                    'details' => $temp,
                ];
            }
        }

        $data['dispatch_details'] = $dispatchDetails ?? [];

        $isMaterialSubmit = false;
        $poObj = PurchaseOrder::find($this->id);
        $poDespatchObj = PoDespatchDetail::where(['po_id' => $this->id, 'po_type' => 2])->first();
        if ($poObj->curr_sub_stage_id >= 30 && $poDespatchObj) {
            $isMaterialSubmit = true;
        }

        $data['so_for_dispatch'] = $soForDispatch ?? [];
        $data['is_material_submit'] = $isMaterialSubmit;

        return $data;
    }
}
