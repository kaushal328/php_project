<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RoleResource extends JsonResource
{
  /**
   * Transform the resource into an array.
   *
   * @return array<string, mixed>
   */
  public function toArray(Request $request): array
  {

    $output = parent::toArray($request);
    $output['department_title'] = $this->department->title ?? '';
    $output['role_title'] = $this->departmentType->title ?? '';
    return $output;
  }
}
