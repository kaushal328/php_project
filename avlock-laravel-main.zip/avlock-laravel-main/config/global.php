<?php
/*
   *   created by : Maaz Ansari | Digi Interface
   *   Created On : 3rd july 2023
   *   Uses :  To display message on admin panel
*/
return [
  'FCM_SERVER_KEY' => 'AAAA0Rsmq7s:APA91bExsgjD1v-12RFkF0zP4XV9r1dYGOaUxf6NKjd2WwOpk3BXGIv1jLWiEe2WrflHop9aq6OZ1afv7eCGbElzVHeG_vVKIeOvSBi9CqcnvmpOHXcx3fe7xs5c09AOpod_bzDeBQ4d',
  'PLATFORM' => ['ios', 'android', 'web'],
  'DEFAULT_PAGINATE_LENGTH' => 25,
  'DEFAULT_PAGE' => 1,
  "CAMPAIGN_DATA_HEADER_FORMAT" => ["Name", "Mobile", "Email", "Address", "City"],
  "EMAIL_DATA_HEADER_FORMAT" => ["Name", "Mobile", "Email", "Address", "City"],
  "SFCEMAILCAMPAIGN_DATA_HEADER_FORMAT" => ["Name", "Mobile", "Email", "Address", "City"],
  "BOOKPOST_CAMPAIGN_DATA_HEADER_FORMAT" => [
    "Name",
    "Mobile",
    "Email",
    "Address",
    "City",
    "Designation",
    "Country",
    "Pincode",
  ],
  "SMO_CAMPAIGN_PLATFORM" => ["Facebook", "Instagram", "LinkedIn"],
  "ADWORDS_CAMPAIGN_PLATFORM" => ["Google"],
  "LEAD_HEADER_FORMAT" => [
    "Region",
    "Enquiry Date",
    "Customer Name",
    "Company",
    "Address1",
    "Address2",
    "City",
    "Pincode",
    "State",
    "Application",
    "Description",
    "FK Designation Id",
    "Email",
    "Contact No",
    "Source",
    "SMO Platform",
    "AdWords Platform",
    "RSM",
    "RSP",
    "Reference",
  ],

  "DISPATCH_HEADER_FORMAT" => [
    "Sales Order No.",
    "Delivery Note Number",
    "Delivery Note Date",
    "Delivery Note Remark",
    "Invoice Date",
    "Voucher No.",
    "Gross Total",
    "Invoice Remark",
    "E Way Bill Date",
    "E Way Bill No",
    "E Way Bill Remark"
  ],

  // "MONTHLY_PLAN_HEADER_FORMAT" => [
  //   "Date",
  //   "Title",
  //   "Description",
  //   "Remark",
  // ],

  "MONTHLY_PLAN_HEADER_FORMAT" => [
    "Date of Visit",
    "Name of the customer",
    "Place",
    "Type of Industry",
    "Type of customer",
    "Product to be discussed",
    "Purpose of visit / interaction planned",
    "SVR Number",
    "Mode of Discussion",
    "Key Points of discussion with customer",
    "Next action plan",
    "Comment from direct boss / Mnagement",
    "Name who made the comments",
    "Your reply to management on their comment / instructions",
    "Plan Type",
  ],

  "UPCOMING_TENDER_FORMAT" => [
    "Tender No",
    "Name",
    "Organization",
    "Tender Start Date",
    "Tender End Date",
    "Tender End Time",
  ],

  "PRODUCT_PART_FORMAT" => [
    "Product Id",
    "Category Name",
    "Product Name",
    "Part No",
    "Part No Desc",
  ],

  "ATTACHMENT_REQUIRED_STAGE" => [43, 45, 46, 47],

  "INSIDE_SALES_STAGE" => [2, 5, 6, 20, 22, 23, 25, 26, 28, 35, 36, 37, 40, 41, 50],

  "PSM_STAGE" => [3, 4, 7, 8, 9, 10, 11, 15, 21, 24, 29, 30, 31, 39, 42],

  "DISPATCH_STAGE" => [16, 30, 43, 44, 47, 48],

  'DELIVERY CONFIRMATION' => 49,


  "COMPANY_NAME" => 'AVLOCK INTERNATIONAL INDIA PRIVATE LIMITED',
  'REACT_URL_LOCAL' => 'http://localhost:3001',
  'REACT_URL_LIVE' => 'https://avlock.myassistantz.com',
  'VERSION' => '1',
  'MIN_VERSION' => '1',
  'TERMS_CONDITION' => 'https://dev.digiinterface.com/2023/avlock/terms',
  'PRIVACY_POLICY' => 'https://dev.digiinterface.com/2023/avlock/privacy',

  // Supplier Form Master Data
  "SUPPLIER_CATEGORY" => [
    [
      'id' => 1,
      'title' => 'MANUFACTURE',
    ],
    [
      'id' => 2,
      'title' => 'DEALER',
    ],
    [
      'id' => 3,
      'title' => 'TRADER',
    ],
  ],

  "CONSTITUTION" => ["PUBLIC LIMITED", "PRIVATE LIMITED", "PARTNERSHIP", "PROPRIETOR"],

  "WEEK_DAYS" => [
    [
      "id" => 1,
      "title" => "SUNDAY",
    ],
    [
      "id" => 2,
      "title" => "MONDAY",
    ],
    [
      "id" => 3,
      "title" => "TUESDAY",
    ],
    [
      "id" => 4,
      "title" => "WEDNESDAY",
    ],
    [
      "id" => 5,
      "title" => "THURSDAY",
    ],
    [
      "id" => 6,
      "title" => "FIRDAY",
    ],
    [
      "id" => 7,
      "title" => "SATURDAY",
    ],
  ],


  "BUSINESS_NATURE" => ["SMALL SCALE", "MEDIUM", "LARGE SCALE"],
  "OPERATIONS_CARRIEDOUT" => [
    [
      "id" => 1,
      "title" => "TURNING",
    ],
    [
      "id" => 2,
      "title" => "FABRICATION",
    ],
    [
      "id" => 3,
      "title" => "MILLING",
    ],
    [
      "id" => 4,
      "title" => "GRINDING",
    ],
    [
      "id" => 5,
      "title" => "DRILLING+TAPPING",
    ],
    [
      "id" => 6,
      "title" => "SHAPING",
    ],
    [
      "id" => 7,
      "title" => "PRESSING OPERATIONS",
    ],
    [
      "id" => 8,
      "title" => "INJECTION MOULDING",
    ],
    [
      "id" => 9,
      "title" => "VACCUM POWDER COATING",
    ],
    [
      "id" => 10,
      "title" => "RUBBER EXTRUSION",
    ],
    [
      "id" => 11,
      "title" => "FORMING",
    ],
    [
      "id" => 12,
      "title" => "PLATING",
    ],
    [
      "id" => 13,
      "title" => "ALUMINIUM EXTRUSION",
    ],
  ],

  "PROBLEM_SOLVING_TECHNIQUES" => [
    [
      "id" => 1,
      "title" => "BRAIN STORMING",
    ],
    [
      "id" => 2,
      "title" => "PARETO DIAGRAM",
    ],
    [
      "id" => 3,
      "title" => "FLOW DIAGRAM",
    ],
    [
      "id" => 4,
      "title" => "CAUSE-EFFECT DIAGRAM"
    ],
    [
      "id" => 5,
      "title" => "GRAPHS(STRATIFICATION, SCATTER DIAGRAM, HISTOGRAM)",
    ],
  ],

  "SCRAPS_DISPOSAL_SYSTEM" => [
    [
      "id" => 1,
      "title" => "AUCTION",
    ],
    [
      "id" => 2,
      "title" => "TENDER",
    ],
    [
      "id" => 3,
      "title" => "OPEN BIDDING",
    ],
    [
      "id" => 4,
      "title" => "CLOSED BIDDING",
    ],
    [
      "id" => 5,
      "title" => "DIRECT WITH SCRAP MERCHANT"
    ],
  ],

  "MASTER_CAMPAIGN_FILE_HEADER_FORMAT" => [
    "Sr. No.",
    "Company Name",
    "Industry",
    "Address line 1",
    "Address line 2",
    "City",
    "State",
    "Pincode",
    "Email",
    "Phone No",
    "Contact Person",
    "Designation",
    "Product Focus",
  ],

  "API_LIMIT" => 30,

];
