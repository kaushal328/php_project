<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('donations', function (Blueprint $table) {
            $table->id();
            $table->integer('kiosk_id');
            $table->string('campaign_id')->nullable();
            
            $table->string('card_number')->nullable()->comment('last 4 digits of the card number');
            $table->string('card_holder_name')->nullable();
            $table->string('card_expiry')->nullable();

            $table->decimal('amount', 10, 2);
            $table->string('currency');
            
            $table->string('donor_first_name')->nullable();
            $table->string('donor_last_name')->nullable();
            $table->string('donor_phone')->nullable();
            $table->string('donor_email')->nullable();
            $table->text('donor_message')->nullable();

            $table->integer('payment_gateway_id');
            $table->string('payment_status')->default('pending')->comment('pending, completed, failed');
            $table->string('payment_type')->default('one_time')->comment('one_time, recurring');
            $table->string('subscription_duration')->nullable()->comment('0: forever, e.g., 12 for 12 months, 1 for 1 month, etc.');

            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('donations');
    }
};
