<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PaymentGatewayFieldSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('payment_gateway_fields')->insert([
            [
                'payment_gateway_id' => '1',
                'key_name' => 'test_publish_key',
            ],
            [
                'payment_gateway_id' => '1',
                'key_name' => 'test_secret_key',
            ],
            [
                'payment_gateway_id' => '1',
                'key_name' => 'live_publish_key',
            ],
            [
                'payment_gateway_id' => '1',
                'key_name' => 'live_secret_key',
            ],

            [
                'payment_gateway_id' => '2',
                'key_name' => 'test_one_time_supplier_url',
            ],
            [
                'payment_gateway_id' => '2',
                'key_name' => 'test_one_time_supplier',
            ],
            [
                'payment_gateway_id' => '2',
                'key_name' => 'test_one_time_password',
            ],

            [
                'payment_gateway_id' => '2',
                'key_name' => 'live_one_time_supplier_url',
            ],
            [
                'payment_gateway_id' => '2',
                'key_name' => 'live_one_time_supplier',
            ],
            [
                'payment_gateway_id' => '2',
                'key_name' => 'live_one_time_password',
            ],

            [
                'payment_gateway_id' => '2',
                'key_name' => 'test_recurring_app_key',
            ],
            [
                'payment_gateway_id' => '2',
                'key_name' => 'test_recurring_secret',
            ],
            [
                'payment_gateway_id' => '2',
                'key_name' => 'test_recurring_terminal',
            ],

            [
                'payment_gateway_id' => '2',
                'key_name' => 'live_recurring_app_key',
            ],
            [
                'payment_gateway_id' => '2',
                'key_name' => 'live_recurring_secret',
            ],
            [
                'payment_gateway_id' => '2',
                'key_name' => 'live_recurring_terminal',
            ],
        ]);
    }
}
