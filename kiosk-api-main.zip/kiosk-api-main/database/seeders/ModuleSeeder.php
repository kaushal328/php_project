<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ModuleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('modules')->insert([
            [
                'module_name' => 'Kiosk',
                'slug' => 'kiosk',
                'status' => '1',
            ],
            [
                'module_name' => 'User',
                'slug' => 'user',
                'status' => '1',
            ],
            [
                'module_name' => 'Donation',
                'slug' => 'donation',
                'status' => '1',
            ]
        ]);
    }
}
