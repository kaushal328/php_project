<?php

namespace Database\Seeders;

use App\Models\Currency;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CurrencySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('currencies')->insert([
            [
                'name' => 'US Dollar',
                'short_name' => 'USD',
                'symbol' => '$',
            ],
            [
                'name' => 'Israeli Shekel',
                'short_name' => 'ILS',
                'symbol' => '₪',
            ],
            [
                'name' => 'Pund Sterling',
                'short_name' => 'GBP',
                'symbol' => '£',
            ],
            [
                'name' => 'Canadian Dollar',
                'short_name' => 'CAD',
                'symbol' => '$',
            ],
            [
                'name' => 'Australian Dollar',
                'short_name' => 'AUD',
                'symbol' => '$',
            ],
        ]);
    }
}
