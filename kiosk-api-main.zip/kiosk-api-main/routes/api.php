<?php

use App\Http\Controllers\Api\Admin\AuthController;
use App\Http\Controllers\Api\Admin\CommonController;
use App\Http\Controllers\Api\Admin\DonationsController;
use App\Http\Controllers\Api\Admin\KioskController;
use App\Http\Controllers\Api\Admin\ProfileController;
use App\Http\Controllers\Api\Admin\UserController;
use App\Http\Controllers\Api\Web\KioskController as WebKioskController;
use App\Http\Controllers\Api\Web\StripeController;
use App\Http\Controllers\Webhook\MakeController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return response()->json(['message' => 'Working...']);
});

Route::prefix('admin')->group(function () {
    Route::prefix('auth')->group(function () {
        Route::post('login', [AuthController::class, 'login']);
        Route::get('me', [AuthController::class, 'me'])->middleware('auth:api');
    });

    Route::middleware('auth:api')->group(function () {
        Route::prefix('user')->group(function () {
            Route::get('list', [UserController::class, 'userList']);
            Route::get('get', [UserController::class, 'getUser']);
            Route::post('save', [UserController::class, 'saveUser']);
            Route::post('delete', [UserController::class, 'deleteUser']);
        });

        Route::prefix('kiosk')->group(function () {
            Route::get('list', [KioskController::class, 'kioskList']);
            Route::get('get', [KioskController::class, 'getKiosk']);
            Route::post('save', [KioskController::class, 'saveKiosk']);
        });

        Route::prefix('common')->group(function () {
            Route::get('payment_gateway_list', [CommonController::class, 'paymentGatewayList']);
            Route::get('payment_gateway_field_list', [CommonController::class, 'paymentGatewayFieldList']);
            Route::get('currency_list', [CommonController::class, 'currencyList']);
            Route::post('upload_files', [CommonController::class, 'uploadFiles']);
            Route::get('module_list', [CommonController::class, 'moduleList']);
        });

        Route::prefix('donation')->group(function () {
            Route::get('list', [DonationsController::class, 'index']);
            Route::get('get', [DonationsController::class, 'getDonation']);

        });

        Route::prefix('profile')->group(function () {
            Route::post('update', [ProfileController::class, 'updateProfile']);
            Route::post('change_password', [ProfileController::class, 'saveChangePassword']);
        });
    });
});

Route::prefix('web')->group(function () {
    Route::prefix('kiosk')->group(function () {
        Route::get('get', [WebKioskController::class, 'getKiosk']);
        Route::post('donate', [WebKioskController::class, 'donate']);
        Route::post('save-donor', [WebKioskController::class, 'saveDonor']);
    });
});

Route::post('webhook/make-webhook', [MakeController::class, 'getGroups']);

Route::prefix('stripe')->group(function () {
    Route::get('payment-success', [StripeController::class, 'paymentSuccess']);
    Route::get('payment-cancel', [StripeController::class, 'paymentCancel']);
});