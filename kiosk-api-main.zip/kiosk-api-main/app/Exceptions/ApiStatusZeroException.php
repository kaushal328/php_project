<?php

namespace App\Exceptions;

use Exception;

class ApiStatusZeroException extends Exception
{
    //
}
