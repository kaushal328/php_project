<?php

namespace App\Services;

use App\Exceptions\ApiStatusZeroException;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class TranzilaPaymentService
{
    protected $supplierUrl;
    protected $supplier;
    protected $password;

    protected $createCardEndpoint = 'https://api.tranzila.com/v1/transaction/credit_card/create';
    protected $createSTOEndpoint = 'https://api.tranzila.com/v2/sto/create';
    protected $bitPaymentEndpoint = 'https://api.tranzila.com/v1/transaction/bit/init';

    protected $appKey;
    protected $secret;
    protected $terminal;

    public function __construct($supplierUrl, $supplier, $password, $appKey, $secret, $terminal)
    {
        // For One Time
        $this->supplierUrl = $supplierUrl;
        $this->supplier = $supplier;
        $this->password = $password;
        // For Recurring
        $this->appKey = $appKey;
        $this->secret = $secret;
        $this->terminal = $terminal;
    }

    function processPayment($paymentType, $kioskName, $customer, $card, $currency, $amount, $duration)
    {
        switch ($paymentType) {
            case 'one_time':
                return $this->createOneTimePayment($kioskName, $customer, $card, $currency, $amount);
            case 'recurring':
                return $this->createSubscription($kioskName, $customer, $card, $currency, $amount, $duration);
            case 'bit':
                return $this->initBitPayment($kioskName, $customer, $currency, $amount);
            default:
                Log::error("Unsupported payment type: $paymentType");
                throw new Exception("Unsupported payment type: $paymentType");
        }
    }

    function createOneTimePayment($kioskName, $customer, $card, $currency, $amount)
    {
        $credentials = [
            'supplier' => $this->supplier,
            'TranzilaPW' => $this->password,
        ];

        $data = [
            'tranmode' => 'A',
            'cred_type' => 1,
            'currency' => $currency->currency_code,
            'reciepttext' => $kioskName,
            'pdesc' => $kioskName,
            'firstname' => $customer['firstname'],
            'lastname' => $customer['lastname'],
            'email' => $customer['email'],
            'phone' => $customer['phone'],
            'contact' => $customer['firstname'] . ' ' . $customer['lastname'],
            'ccno' => $card['card_number'],
            'expdate' => $card['card_expiry'],
            'mycvv' => $card['cvv'] ?? '',
            'myid' => $card['id'] ?? '',
            'sum' => $amount,
        ];

        $payload = array_merge($credentials, $data);

        $response = Http::asForm()
            ->withoutVerifying()
            ->withOptions(['verify' => false])
            ->get($this->supplierUrl, $payload);

        parse_str($response->body(), $parsed);

        return $parsed;
    }

    function createSubscription($kioskName, $customer, $card, $currency, $amount, $duration)
    {
        $cardNumber = strval($card['card_number'] ?? '');
        $expMonth = intval(explode('/', $card['card_expiry'])[0]);
        $expYear = intval('20' . explode('/', $card['card_expiry'])[1]); // added 20 at the start to make the year 20xx
        $cvv = strval($card['cvv']);

        // Prepare data for creating a card
        $createCardData = [];
        $createCardData['terminal_name'] = $this->terminal;
        $createCardData['txn_type'] = 'debit';
        $createCardData['verify_mode'] = 2;
        $createCardData['card_number'] = $cardNumber;
        $createCardData['expire_month'] = $expMonth;
        $createCardData['expire_year'] = $expYear;
        // $createCardData['cvv'] = $cvv;
        $createCardData['items'][] = [
            "name" => 'Pantry Packers',
            "type" => 'I',
            "unit_price" => intval($amount),
            "units_number" => 1,
        ];

        $cardResponse = $this->createCard($createCardData);

        if (!$cardResponse) {
            Log::error('Failed to create card', ['data' => $createCardData]);
            throw new Exception("There was a problem processing your payment!");
        }

        $cardToken = $cardResponse['transaction_result']['token'];
        if (!$cardToken) {
            Log::error('Card token not found in response', ['response' => $cardResponse]);
            throw new Exception("There was a problem processing your payment!");
        }

        // Prepare data for creating a subscription (STO)
        $createSTOData = [];
        $createSTOData['terminal_name'] = $this->terminal;
        $createSTOData['sto_payments_number'] = $duration == 0 ? 9999 : intval($duration ?? 6);
        $createSTOData["charge_frequency"] = "monthly";
        $createSTOData["first_charge_date"] = date('Y-m-d');
        $createSTOData["currency_code"] = $currency->short_name;
        $createSTOData["charge_dom"] = intval(date('d'));
        $createSTOData["vat_percent"] = 0;

        $createSTOData["client"]['name'] = $customer['firstname'] . ' ' . $customer['lastname'];
        $createSTOData["client"]['email'] = $customer['email'];
        $createSTOData["client"]['phone_number'] = $customer['phone'];

        $createSTOData['items'][] = [
            "name" => $kioskName, // was "Pantry Packers"
            "unit_price" => intval($amount),
            "units_number" => 1,
        ];

        $createSTOData['card']['token'] = $cardToken;
        $createSTOData['card']['expire_month'] = $expMonth;
        $createSTOData['card']['expire_year'] = $expYear;
        $createSTOData['card']['card_holder_name'] = $customer['firstname'] . ' ' . $customer['lastname'];

        $createSTOData['response_language'] = "english";

        $stoResponse = $this->createSto($createSTOData);

        return $stoResponse;
    }

    // Utils

    function getHeadersData($appKey, $secret)
    {
        $time = time();
        $nonce = bin2hex(random_bytes(40)); //actually 80 characters string
        $accessToken = hash_hmac('sha256', $appKey, $secret . $time . $nonce);

        return [
            'X-tranzila-api-request-time' => $time,
            'X-tranzila-api-app-key' => $appKey,
            'X-tranzila-api-nonce' => $nonce,
            'X-tranzila-api-access-token' => $accessToken,
            'Content-Type' => 'application/json'
        ];
    }

    function createCard($data)
    {
        $headers = $this->getHeadersData($this->appKey, $this->secret);

        $response = Http::withoutVerifying()
            ->withHeaders($headers)
            ->withOptions(['verify' => false])
            ->post($this->createCardEndpoint, $data);

        $response = $response->json();

        if (!isset($response['error_code'])) return false;

        if ($response['error_code'] != 0) return false;

        if (!isset($response['transaction_result'])) return false;

        $processorResponseCodes = ['000', '004'];

        if (!in_array($response['transaction_result']['processor_response_code'], $processorResponseCodes)) return false;

        return $response;
    }

    function createSto($data)
    {
        $headers = $this->getHeadersData($this->appKey, $this->secret);

        $response = Http::withoutVerifying()
            ->withHeaders($headers)
            ->withOptions(['verify' => false])
            ->post($this->createSTOEndpoint, $data);

        return $response->json();
    }

    function initBitPayment($kioskName, $customer, $currency, $amount)
    {
        $headers = $this->getHeadersData($this->appKey, $this->secret);

        $data = [
            'terminal_name' => $this->terminal,
            'txn_currency_code' => $currency->short_name,
            'txn_type' => 'debit',
            'success_url' => 'http://localhost:8003',
            'failure_url' => 'http://localhost:8003',
            'client' => [
                'name' => $customer['firstname'] . ' ' . $customer['lastname'],
                'email' => $customer['email']
            ],
            'items' => [
                [
                    "name" => $kioskName, // was "Pantry Packers"
                    "type" => 'I',
                    "unit_price" => intval($amount),
                    "units_number" => 1,
                ]
            ],
            'response_language' => 'english',
        ];

        $response = Http::withoutVerifying()
            ->withHeaders($headers)
            ->withOptions(['verify' => false])
            ->post($this->bitPaymentEndpoint, $data);

        dd($response->json());
    }
}
