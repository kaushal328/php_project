<?php

namespace App\Services;

use Exception;

class PaymentResponseService
{
    function handleResponse($paymentGatewayName, $paymentType, $response)
    {
        // Handle the response based on the payment gateway and type
        switch ($paymentGatewayName) {
            case 'Stripe':
                return $this->handleStripeResponse($paymentType, $response);
            case 'Tranzila':
                return $this->handleTranzilaResponse($paymentType, $response);
            default:
                throw new Exception("Unsupported payment gateway: $paymentGatewayName");
        }
    }

    private function handleStripeResponse($paymentType, $response)
    {
        if ($paymentType === 'one_time') {
            if ($response['status'] == 'succeeded') {
                // Handle successful one-time payment response
                return [
                    'status' => 'success',
                    'data' => $response,
                ];
            } else {
                // Handle failed one-time payment response
                return [
                    'status' => 'failed',
                    'error' => $response['failure_message'] ?? 'Payment failed',
                ];
            }
        }
        
        if ($paymentType === 'recurring') {
            if ($response['status'] == 'active') {
                // Handle successful recurring payment response
                return [
                    'status' => 'success',
                    'data' => $response,
                ];
            } else {
                // Handle failed recurring payment response
                return [
                    'status' => 'failed',
                    'error' => $response['failure_message'] ?? 'Subscription creation failed',
                ];
            }
        }
        
        throw new Exception("Unsupported payment type: $paymentType");
    }

    private function handleTranzilaResponse($paymentType, $response)
    {
        $testMode = env('PAYMENT_GATEWAY_TEST_MODE', false);

        if ($paymentType === 'one_time') {
            if (isset($response) && !empty($response)) {
                $responseCode = $response['Response'] ?? null;

                $successResults = ['000'];
                if ($testMode) {
                    $successResults[] = '004'; // test mode success code
                }
                
                if (in_array($responseCode, $successResults)) {
                    return [
                        'status' => 'success',
                        'data' => $response,
                    ];
                }
            }

            return [
                'status' => 'failed',
                'error' => 'Payment failed',
            ];
        }
        
        if ($paymentType === 'recurring') {
            if (isset($response) && !empty($response)) {
                $errorCode = $response['error_code'] ?? null;

                if ($errorCode == '0') {
                    return [
                        'status' => 'success',
                        'data' => $response,
                    ];
                }
            }

            return [
                'status' => 'failed',
                'error' => 'Payment failed',
            ];
        }
        
        throw new Exception("Unsupported payment type: $paymentType");
    }
}