<?php

namespace App\Services;

use App\Models\PaymentGatewayField;
use Exception;

class PaymentGatewayService
{
    protected $testMode = false;
    protected $paymentGateway;
    protected $paymentType;
    protected $fields;

    function __construct($paymentGateway, $paymentType, $fields)
    {
        $this->testMode = env('PAYMENT_GATEWAY_TEST_MODE', false);
        $this->paymentGateway = $paymentGateway;
        $this->paymentType = $paymentType;
        $this->fields = $fields;
    }

    function getKeys()
    {
        $fieldValues = json_decode($this->fields, true);

        $paymentGatewayField = PaymentGatewayField::where('payment_gateway_id', $this->paymentGateway->id)->where('status', 1);

        if ($this->paymentGateway->name == 'Stripe') {
            $secretKeyName = $this->testMode ? env('TEST_STRIPE_SECRET_KEY_KEY_NAME') : env('LIVE_STRIPE_SECRET_KEY_KEY_NAME');
            $publishableKeyName = $this->testMode ? env('TEST_STRIPE_PUBLISHABLE_KEY_KEY_NAME') : env('LIVE_STRIPE_PUBLISHABLE_KEY_KEY_NAME');
            
            $secretKeyId = (clone $paymentGatewayField)->where('key_name', $secretKeyName)->value('id');
            $publishableKeyId = (clone $paymentGatewayField)->where('key_name', $publishableKeyName)->value('id');

            $secretKey = collect($fieldValues)->where('payment_gateway_field_id', $secretKeyId)->value('value');
            $publishableKey = collect($fieldValues)->where('payment_gateway_field_id', $publishableKeyId)->value('value');

            return [
                'secret_key' => $secretKey,
                'publishable_key' => $publishableKey,
            ];
        }

        if ($this->paymentGateway->name == 'Tranzila') {
            $paymentGatewayField->where('payment_type', $this->paymentType);

            if ($this->paymentType == 'one_time') {
                $supplierUrlKeyName = $this->testMode ? env('TEST_TRANZILA_ONE_TIME_SUPPLIER_URL_KEY_NAME') : env('LIVE_TRANZILA_ONE_TIME_SUPPLIER_URL_KEY_NAME');
                $supplierKeyName = $this->testMode ? env('TEST_TRANZILA_ONE_TIME_SUPPLIER_KEY_NAME') : env('LIVE_TRANZILA_ONE_TIME_SUPPLIER_KEY_NAME');
                $passwordKeyName = $this->testMode ? env('TEST_TRANZILA_ONE_TIME_PASSWORD_KEY_NAME') : env('LIVE_TRANZILA_ONE_TIME_PASSWORD_KEY_NAME');

                $supplierUrlKeyId = (clone $paymentGatewayField)->where('key_name', $supplierUrlKeyName)->value('id');
                $supplierKeyId = (clone $paymentGatewayField)->where('key_name', $supplierKeyName)->value('id');
                $passwordKeyId = (clone $paymentGatewayField)->where('key_name', $passwordKeyName)->value('id');

                $supplierUrl = collect($fieldValues)->where('payment_gateway_field_id', $supplierUrlKeyId)->value('value');
                $supplier = collect($fieldValues)->where('payment_gateway_field_id', $supplierKeyId)->value('value');
                $password = collect($fieldValues)->where('payment_gateway_field_id', $passwordKeyId)->value('value');

                return [
                    'supplier_url' => $supplierUrl,
                    'supplier' => $supplier,
                    'password' => $password,
                ];
            }

            if ($this->paymentType == 'recurring') {
                $appKeyKeyName = $this->testMode ? env('TEST_TRANZILA_RECURRING_APP_KEY_KEY_NAME') : env('LIVE_TRANZILA_RECURRING_APP_KEY_KEY_NAME');
                $secretKeyName = $this->testMode ? env('TEST_TRANZILA_RECURRING_SECRET_KEY_NAME') : env('LIVE_TRANZILA_RECURRING_SECRET_KEY_NAME');
                $terminalKeyName = $this->testMode ? env('TEST_TRANZILA_RECURRING_TERMINAL_KEY_NAME') : env('LIVE_TRANZILA_RECURRING_TERMINAL_KEY_NAME');

                $appKeyKeyId = (clone $paymentGatewayField)->where('key_name', $appKeyKeyName)->value('id');
                $secretKeyId = (clone $paymentGatewayField)->where('key_name', $secretKeyName)->value('id');
                $terminalKeyId = (clone $paymentGatewayField)->where('key_name', $terminalKeyName)->value('id');

                $appKey = collect($fieldValues)->where('payment_gateway_field_id', $appKeyKeyId)->value('value');
                $secret = collect($fieldValues)->where('payment_gateway_field_id', $secretKeyId)->value('value');
                $terminal = collect($fieldValues)->where('payment_gateway_field_id', $terminalKeyId)->value('value');

                return [
                    'app_key' => $appKey,
                    'secret' => $secret,
                    'terminal' => $terminal,
                ];
            }
        }

        throw new Exception("Unsupported payment gateway or type.");
    }
}
