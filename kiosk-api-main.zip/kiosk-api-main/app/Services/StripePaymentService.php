<?php

namespace App\Services;

use Carbon\Carbon;
use Exception;
use Stripe\Charge;
use Stripe\Checkout\Session;
use Stripe\Stripe;
use Stripe\Customer;
use Stripe\PaymentIntent;
use Stripe\Subscription;
use Stripe\Exception\ApiErrorException;
use Stripe\Price;
use Stripe\Token;

class StripePaymentService
{
    public function __construct($secretKey, $publishableKey)
    {
        Stripe::setApiKey($secretKey);
    }

    /**
     * Create card token.
     */
    private function createCardToken($cardNumber, $expMonth, $expYear, $cvv)
    {
        $token = Token::create([
            'card' => [
                'number'    => $cardNumber,
                'exp_month' => $expMonth,
                'exp_year'  => $expYear,
                'cvc'       => $cvv,
            ],
        ]);

        return $token->id;
    }

    /**
     * Create or retrieve a Stripe customer.
     */
    private function createOrGetCustomer($name, $email, $cardToken = null)
    {
        $customer = Customer::create([
            'email' => $email,
            'name'  => $name,
            'source' => $cardToken, // Assuming you have a card token
        ]);

        return $customer;
    }

    /**
     * Create one time payment.
     */
    public function createOneTimePayment($customer, $amount, $currency, $description = '')
    {
        $charge = Charge::create([
            'customer' => $customer->id,
            'amount'   => $amount * 100, // Amount in cents
            'currency' => $currency,
            'description' => $description,
        ]);

        return $charge;
    }

    /**
     * Create a subscription.
     */
    public function createSubscription($customer, $amount, $currency, $duration)
    {
        $price = Price::create([
            'unit_amount' => $amount * 100,
            'currency' => $currency,
            'recurring' => ['interval' => 'month', 'interval_count' => 1],
            'product_data' => [
                'name' => 'Subscription Plan',
            ],
        ]);

        $subscriptionData = [
            'customer' => $customer->id,
            'items'    => [['price' => $price->id]],
        ];

        if ($duration > 0) {
            $subscriptionData['cancel_at'] = Carbon::now()->addMonths(intval($duration))->timestamp;
        }

        $subscription = Subscription::create($subscriptionData);

        return $subscription;
    }

    public function processPayment($paymentType, $customer, $card, $amount, $currency, $description = '', $duration = 0)
    {
        $cardToken = $this->createCardToken($card['card_number'], $card['exp_month'], $card['exp_year'], $card['cvv']);
        $customer = $this->createOrGetCustomer($customer['name'], $customer['email'], $cardToken);

        if ($paymentType === 'one_time') {
            return $this->createOneTimePayment($customer, $amount, $currency, $description);
        } elseif ($paymentType === 'recurring') {
            return $this->createSubscription($customer, $amount, $currency, $duration);
        }

        throw new Exception('Invalid payment type');
    }

    // experimental

    public function processCheckoutSession($paymentType, $amount, $currency, $description = '', $duration = 0)
    {
        if ($paymentType === 'one_time') {
            return $this->createOneTimeCheckoutSession($amount, $currency, $description);
        } elseif ($paymentType === 'recurring') {
            return $this->createSubscriptionCheckoutSession($amount, $currency, $duration, $description);
        }

        throw new Exception('Invalid payment type');
    }

    function createOneTimeCheckoutSession($amount, $currency, $description)
    {
        $session = Session::create([
            'payment_method_types' => ['card'],
            'line_items' => [[
                'price_data' => [
                    'currency' => $currency,
                    'unit_amount' => $amount * 100,
                    'product_data' => [
                        'name' => $description,
                    ],
                ],
                'quantity' => 1,
            ]],
            'mode' => 'payment',
            'success_url' => url('/api/stripe/payment-success'),
            'cancel_url' => url('/api/stripe/payment-cancel'),
        ]);

        return $session->url;
    }

    function createSubscriptionCheckoutSession($amount, $currency, $duration, $description)
    {
        $sessionData = [
            'payment_method_types' => ['card'],
            'mode' => 'subscription',
            'line_items' => [[
                'price_data' => [
                    'currency' => $currency,
                    'unit_amount' => $amount * 100,
                    'recurring' => [
                        'interval' => 'month',
                    ],
                    'product_data' => [
                        'name' => $description,
                    ],
                ],
                'quantity' => 1,
            ]],
            'success_url' => url('/api/stripe/subscription-success?session_id={CHECKOUT_SESSION_ID}'),
            'cancel_url' => url('/api/stripe/subscription-cancel'),
        ];

        // if ($duration > 0) {
        //     $sessionData['subscription_data'] = [
        //         'cancel_at' => Carbon::now()->addMonths(intval($duration))->timestamp,
        //     ];
        // }

        $session = Session::create($sessionData);

        return $session->url;
    }
}
