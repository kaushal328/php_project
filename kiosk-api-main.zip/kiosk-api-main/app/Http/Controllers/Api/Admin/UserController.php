<?php

namespace App\Http\Controllers\Api\Admin;

use App\Exceptions\ApiStatusZeroException;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserPermission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    function userList(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $listQuery = User::where('id', '!=', 1)->orderBy('created_at');

            $list = $listQuery->get();

            $data['list'] = $list;

            $this->response['data'] = $data;
            return response()->json($this->response);
        });
    }

    function saveUser(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $request->validate([
                'name' => 'required|min:3',
                'email' => 'required|email',
                'phone' => 'required|numeric',
                'password' => 'sometimes|required_id:id,null|min:8',
                'permissions' => 'required|array',
                'status' => 'required',
            ]);

            $id = $request->post('id');
            $name = $request->post('name');
            $email = $request->post('email');
            $phone = $request->post('phone');
            $password = $request->post('password');
            $permissions = $request->post('permissions');
            $status = $request->post('status');

            $user = new User();

            if ($id) {
                $user = User::find($id);
                if (!$user) {
                    throw new ApiStatusZeroException("Something went wrong! Invalid record.");
                }
            }

            $user->name = $name;
            $user->email = $email;
            $user->phone = $phone;
            if (!$id) $user->password = Hash::make($password);
            $user->status = $status;
            $user->save();

            $userPermissions = UserPermission::where('user_id', $user->id)->get();
            if ($userPermissions->isNotEmpty()) {
                foreach ($userPermissions as $userPermission) {
                    $userPermission->delete();
                }
            }

            $permissionsArr = [];
            foreach ($permissions as $permission) {
                $permissionsArr[] = [
                    'user_id' => $user->id,
                    'module_id' => $permission['module_id'],
                    'create' => $permission['create'],
                    'read' => $permission['read'],
                    'update' => $permission['update'],
                    'delete' => $permission['delete'],
                ];
            }

            UserPermission::insert($permissionsArr);

            $this->response['msg'] = 'Record saved';
            return response()->json($this->response);
        });
    }

    function getUser(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $id = $request->get('id');

            $user = User::find($id);

            if (!$user) {
                throw new ApiStatusZeroException("User not found!");
            }

            $permissions = UserPermission::where('user_id', $user->id)->get();

            $user->permissions = $permissions;

            $this->response['data'] = $user;
            return response()->json($this->response);
        });
    }

    function deleteUser(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $id = $request->get('id');

            $user = User::find($id);

            if (!$user) {
                throw new ApiStatusZeroException("User not found!");
            }

            $user->delete();

            $this->response['msg'] = "Record deleted!";
            return response()->json($this->response);
        });
    }
}
