<?php

namespace App\Http\Controllers\Api\Admin;

use App\Exceptions\ApiStatusZeroException;
use App\Http\Controllers\Controller;
use App\Models\Kiosk;
use App\Models\KioskPaymentGatewayDetail;
use Illuminate\Http\Request;

class KioskController extends Controller
{
    function kioskList(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $listQuery = Kiosk::select(
                'id',
                'name',
                'slug',
                'status',
                'created_at'
            )->orderBy('created_at');

            $list = $listQuery->get();

            $data['list'] = $list;

            $this->response['data'] = $data;
            return response()->json($this->response);
        });
    }

    function getKiosk(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $id = $request->get('id');

            $kiosk = Kiosk::find($id);

            if (!$kiosk) {
                throw new ApiStatusZeroException("Kiosk not found!");
            }

            $kiosk->load('kioskPaymentGatewayDetails');

            $this->response['data'] = $kiosk;
            return response()->json($this->response);
        });
    }

    function saveKiosk(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $request->validate([
                'name' => 'required',
                'amounts' => 'required|array',
                'has_group' => 'required',
                'payment_gateway_details' => 'required|array',
                'payment_gateway_details.*.currency_id' => 'required',
                'payment_gateway_details.*.payment_gateway_id' => 'required',
                'payment_gateway_details.*.field_values' => 'required|array',
                'payment_gateway_details.*.field_values.*.payment_gateway_field_id' => 'required',
                'payment_gateway_details.*.field_values.*.value' => 'required',
                'layout_name' => 'required',
                'logo' => 'required',
                'layout_background' => 'required',
                'email_from_name' => 'required',
                'email_from' => 'required',
                'email_subject' => 'required',
                'email_body' => 'required',
                'status' => 'required',
            ]);

            $id = $request->post('id');
            $name = $request->post('name');
            $amounts = $request->post('amounts') ?? [];
            $hasGroup = $request->post('has_group');
            $layoutName = $request->post('layout_name');
            $logo = $request->post('logo');
            $layoutBackground = $request->post('layout_background');
            $emailFromName = $request->post('email_from_name');
            $emailFrom = $request->post('email_from');
            $emailSubject = $request->post('email_subject');
            $emailBody = $request->post('email_body');
            $status = $request->post('status');
            $paymentGatwayDetails = $request->post('payment_gateway_details');

            if ($logo) {
                $logoMoveResponse = moveImage('uploads/temp', 'uploads/kiosk/logo', $logo);
                if (!$logoMoveResponse['success']) {
                    throw new ApiStatusZeroException("Please upload a valid logo image.");
                }

                $logo = $logoMoveResponse['data']['filename'];
            }

            if ($layoutBackground) {
                $layoutBackgroundMoveResponse = moveImage('uploads/temp', 'uploads/kiosk/layout_background', $layoutBackground);
                if (!$layoutBackgroundMoveResponse['success']) {
                    throw new ApiStatusZeroException("Please upload a valid layout background image.");
                }

                $layoutBackground = $layoutBackgroundMoveResponse['data']['filename'];
            }

            $uniqueCurrencies = array_unique(array_column($paymentGatwayDetails, 'currency_id'));
            if (count($uniqueCurrencies) != count($paymentGatwayDetails)) {
                throw new ApiStatusZeroException("Currencies should be unique");
            }

            $kiosk = new Kiosk();

            if ($id) {
                $kiosk = Kiosk::find($id);
                if (!$kiosk) {
                    throw new ApiStatusZeroException("Something went wrong! Kiosk not found.");
                }
            }

            $kiosk->name = $name;
            $kiosk->slug = createSlug('kiosks', $name, $kiosk->id);
            $kiosk->amounts = json_encode($amounts);
            $kiosk->has_group = $hasGroup;
            $kiosk->layout_name = $layoutName;
            $kiosk->logo = $logo;
            $kiosk->layout_background = $layoutBackground;
            $kiosk->email_from_name = $emailFromName;
            $kiosk->email_from = $emailFrom;
            $kiosk->email_subject = $emailSubject;
            $kiosk->email_body = $emailBody;
            $kiosk->status = $status;
            $kiosk->save();

            KioskPaymentGatewayDetail::where('kiosk_id', $kiosk->id)->delete();

            foreach ($paymentGatwayDetails as $paymentGatwayDetail) {
                $paymentGatwayDetailId = $paymentGatwayDetail['id'] ?? null;

                $kioskPaymentGatwayDetail = KioskPaymentGatewayDetail::withTrashed()->find($paymentGatwayDetailId);
                if (!$kioskPaymentGatwayDetail) {
                    $kioskPaymentGatwayDetail = new KioskPaymentGatewayDetail();
                }else{
                    $kioskPaymentGatwayDetail = $kioskPaymentGatwayDetail->restore();
                }

                $kioskPaymentGatwayDetail->kiosk_id = $kiosk->id;
                $kioskPaymentGatwayDetail->currency_id = $paymentGatwayDetail['currency_id'];
                $kioskPaymentGatwayDetail->payment_gateway_id = $paymentGatwayDetail['payment_gateway_id'];
                $kioskPaymentGatwayDetail->field_values = json_encode($paymentGatwayDetail['field_values']);
                $kioskPaymentGatwayDetail->save();
            }

            $this->response['msg'] = "Kiosk saved";
            return response()->json($this->response);
        });
    }
}
