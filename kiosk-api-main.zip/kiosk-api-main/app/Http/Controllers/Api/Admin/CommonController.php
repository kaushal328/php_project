<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use App\Models\Module;
use App\Models\PaymentGateway;
use App\Models\PaymentGatewayField;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CommonController extends Controller
{
    function paymentGatewayList(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $list = PaymentGateway::where('status', 1)->get();

            $this->response['data'] = $list;
            return response()->json($this->response);
        });
    }

    function paymentGatewayFieldList(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $paymentGatewayId = $request->get('payment_gateway_id') ?? null;

            $list = PaymentGatewayField::where('payment_gateway_id', $paymentGatewayId)->where('status', 1)->get();

            $this->response['data'] = $list;
            return response()->json($this->response);
        });
    }

    function currencyList(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $list = Currency::where('status', 1)->get();

            $this->response['data'] = $list;
            return response()->json($this->response);
        });
    }

    function uploadFiles(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $allowedExtensions = ['jpg', 'jpeg', 'png'];

            // Validate the files
            $request->validate([
                'files' => 'required|array',
                'files.*' => ['required', 'file', 'mimes:' . implode(',', $allowedExtensions)],
            ], [
                'files.*.required' => 'Please upload at least one file.',
                'files.*.file' => 'The uploaded item must be a valid file.',
                'files.*.mimes' => 'Only files with the following extensions are allowed: ' . implode(', ', $allowedExtensions)
            ]);

            $data = [];
            $destinationPath = 'uploads/temp';

            if ($request->file('files')) {
                foreach ($request->file('files') as $key => $file) {
                    $path = $file->store($destinationPath, 'public');
                    $fileName = $file->hashName();
                    $data[] = ['filename' => $fileName, 'path' => Storage::disk('public')->url($path)];
                }
            }

            $this->response['data'] = ['list' => $data];
            return response()->json($this->response);
        });
    }

    function moduleList(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $list = Module::where('status', 1)->get();

            $this->response['data'] = $list;
            return response()->json($this->response);
        });
    }
}
