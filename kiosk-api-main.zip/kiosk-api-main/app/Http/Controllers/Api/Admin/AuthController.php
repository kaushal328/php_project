<?php

namespace App\Http\Controllers\Api\Admin;

use App\Exceptions\ApiStatusZeroException;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\UserPermission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;

class AuthController extends Controller
{
    function login(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $request->validate([
                'email' => 'required',
                'password' => 'required',
            ]);

            $email = $request->post('email');
            $password = $request->post('password');

            $user = User::where('email', $email)->first();

            if (!$user || !Hash::check($password, $user->password)) {
                throw new ApiStatusZeroException("Invalid email or password!");
            }

            if ($user->status != 1) {
                throw new ApiStatusZeroException("Your account is put on hold! Please contact administrator.");
            }

            $user->permissions = UserPermission::with(['module'])->where('user_id', $user->id)->get();

            $data = [
                'user' => $user,
                'access_token' => $user->createToken('access-token')->plainTextToken,
            ];

            $this->response['msg'] = 'Logged in successfully';
            $this->response['data'] = $data;
            return response()->json($this->response);
        });
    }

    function me(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $user = $request->user();

            if ($user->status != 1) {
                return response()->json(['error' => 'Unauthorized'], 401);
            }

            $user->permissions = UserPermission::with(['module'])->where('user_id', $user->id)->get();

            $this->response['data'] = $user;

            return response()->json($this->response);
        });
    }
}
