<?php

namespace App\Http\Controllers\Api\Admin;

use App\Exceptions\ApiStatusZeroException;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;


class ProfileController extends Controller
{
    public function updateProfile(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $request->validate([
                'name' => 'required',
                'email' => 'required|email:rfc,dns',
                'phone' => 'required',
            ]);

            $user = $request->user();

            if( !$user)
            {
                throw new ApiStatusZeroException("User not found!!");   
            }
            $user->name = $request->name;
            $user->email = $request->email;
            $user->phone = $request->phone;
            $user->save();

            $this->response['msg'] = "Profile Updated ";
            return response()->json($this->response);
        });
    }

    public function saveChangePassword(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $request->validate([
                'current_password' => 'required',
                'password_confirmation' => 'required|min:6',
                'password' => 'required|confirmed|min:6',
            ]);

            $user = $request->user();   

            if (!Hash::check($request->current_password, $user->password)) {
                throw new ApiStatusZeroException("Invalid current pasword!");   
            }
            
            $user->password = Hash::make($request->password);
            $user->save();

            $this->response['msg'] = "Password change";
            return response()->json($this->response);
        });
    }
}
