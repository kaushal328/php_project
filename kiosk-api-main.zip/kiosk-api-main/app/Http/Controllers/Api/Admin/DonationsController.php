<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Donation;
use Illuminate\Http\Request;
use App\Exceptions\ApiStatusZeroException;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class DonationsController extends Controller
{
    public function index(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $data = [];

            $page = $request->page ?? 1;
            $perPage = $request->per_page ?? 50;
            $search = $data['search'] = $request->search ?? '';
            $kioskId = $data['kiosk_id'] = $request->kiosk_id ?? '';
            $dateRange = $data['date_range'] = $request->date_range ?? '';
            $fromDate = $data['from_date'] = $request->from_date ?? '';
            $toDate = $data['to_date'] = $request->to_date ?? '';
            $paymentStatus = $data['payment_status'] = $request->payment_status ?? '';
            $export = $request->export;

            $listQuery = Donation::with(['paymentGateway', 'kiosk'])
                ->select(
                    'id',
                    'kiosk_id',
                    'donor_first_name',
                    'donor_last_name',
                    'donor_phone',
                    'donor_email',
                    'subscription_duration',
                    'donor_message',
                    'card_number',
                    'card_holder_name',
                    'card_expiry',
                    'payment_status',
                    'payment_gateway_id',
                    'amount',
                    'currency',
                    'created_at',
                )->orderBy('created_at');

            if ($kioskId) {
                $listQuery->where('kiosk_id', $kioskId);
            }

            if ($search) {
                $searchParam = '%' . $search . '%';
                $listQuery->where(function ($query) use ($searchParam) {
                    $query->where('donor_first_name', 'like', $searchParam)
                        ->orWhere('donor_last_name', 'like', $searchParam)
                        ->orWhere('donor_email', 'like', $searchParam)
                        ->orWhere('donor_phone', 'like', $searchParam);
                });

                $listQuery->orWhereHas('kiosk', function ($query) use ($searchParam) {
                    $query->where('name', 'like', $searchParam);
                });
            }

            if ($paymentStatus) {
                $listQuery->where('payment_status', $paymentStatus);
            }

            $totalRows = $listQuery->count();
            $totalPages = ceil($totalRows / $perPage);
            $paginatedList = $listQuery->limit($perPage)->offset(($page - 1) * $perPage)->get();

            $data['page'] = $page;
            $data['per_page'] = $perPage;
            $data['num_rows'] = $totalRows;
            $data['total_pages'] = $totalPages;
            $data['list'] = $paginatedList;

            $list = $listQuery->get();
            $exportfile = '';
            if ($export == 1) {
                $exportfile = $this->downloadDonationExport($list);
            }

            $this->response['data'] = $data;
            $this->response['file'] = $exportfile;
            return response()->json($this->response);
        });
    }

    function getDonation(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $id = $request->get('id');

            $donation = Donation::with(['paymentGateway', 'kiosk'])->find($id);

            if (!$donation) {
                throw new ApiStatusZeroException("Donation not found!");
            }

            $this->response['data'] = $donation;
            return response()->json($this->response);
        });
    }

    public function downloadDonationExport($list)
    {
        $donation = $list;
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $headers = [
            'ID',
            'Donor first name',
            'Donor last name',
            'Donor phone',
            'Donor email',
            'Subscription_duration',
            'Donor_message',
            'Payment_gateway_id',
            'Amount',
            'Currency',
            'Date'
        ];


        $column = 'A';
        foreach ($headers as $header) {
            $sheet->setCellValue($column . '1', $header);
            $column++;
        }


        $row = 2;
        foreach ($donation as $index => $donationexport) {
            $sheet->setCellValue('A' . $row, $index + 1);
            $sheet->setCellValue('B' . $row, $donationexport->donor_first_name ?? '');
            $sheet->setCellValue('C' . $row, $donationexport->donor_last_name ?? '');
            $sheet->setCellValue('D' . $row, $donationexport->donor_phone ?? '');
            $sheet->setCellValue('E' . $row, $donationexport->donor_email ?? '');
            $sheet->setCellValue('F' . $row, $donationexport->subscription_duration ?? '');
            $sheet->setCellValue('G' . $row, $donationexport->donor_message ?? '');
            $sheet->setCellValue('H' . $row, $donationexport->payment_gateway_id ?? '');
            $sheet->setCellValue('I' . $row, $donationexport->amount ?? '');
            $sheet->setCellValue('J' . $row, $donationexport->currency ?? '');
            $sheet->setCellValue('K' . $row, optional($donationexport->created_at)->format('d F Y'));
            $row++; 
        }


        $filename = 'donationExport_' . now()->format('Ymd_His') . '.xlsx';
        // $filePath = storage_path('app/uploads/export/' . $filename);
        $filepath = Storage::disk('public')->path('uploads/export/' . $filename);


        // if (!file_exists(dirname($filePath))) {
        //     mkdir(dirname($filePath), 0755, true);
        // }

        $writer = new Xlsx($spreadsheet);
        $writer->save($filepath);

        return asset('storage/uploads/export/' . $filename);


    }
}
