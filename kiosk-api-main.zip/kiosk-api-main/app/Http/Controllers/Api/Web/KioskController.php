<?php

namespace App\Http\Controllers\Api\Web;

use App\Exceptions\ApiStatusZeroException;
use App\Http\Controllers\Controller;
use App\Mail\DonationReceiptMail;
use App\Models\Donation;
use App\Models\Kiosk;
use App\Models\KioskPaymentGatewayDetail;
use App\Models\PaymentGatewayField;
use App\Services\PaymentGatewayService;
use App\Services\PaymentResponseService;
use App\Services\StripePaymentService;
use App\Services\TranzilaPaymentService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class KioskController extends Controller
{
    public $sendEmail = false;

    function __construct()
    {
        $this->sendEmail = env('SEND_EMAIL', false);
    }

    function getKiosk(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $slug = $request->slug;

            $kiosk = Kiosk::select('id', 'name', 'slug', 'amounts', 'has_group', 'layout_name', 'logo', 'layout_background')
                ->where('slug', $slug)
                ->where('status', 1)
                ->first();

            if (!$kiosk) {
                $this->response['success'] = false;
                $this->response['error'] = "Kiosk not found!";
                return response()->json($this->response, 404);
            }

            $paymentOptions = KioskPaymentGatewayDetail::select('id', 'kiosk_id', 'currency_id', 'payment_gateway_id')
                ->with('currency:id,name,symbol,short_name')
                ->where('kiosk_id', $kiosk->id)
                ->where('status', 1)
                ->get();

            $groups = [];
            if ($kiosk->has_group == 1) {
                $groups = [
                    [
                        'id' => 1,
                        'group_name' => 'First',
                    ],
                    [
                        'id' => 2,
                        'group_name' => 'Second',
                    ]
                ];

                // $response = Http::get('https://hook.eu2.make.com/n4cxhb12m4b8ujxrteowbxyxfmpb39yj');

                // if ($response->ok()) {
                //     $groupResponse = $response->json();
                //     if (isset($groupResponse['array'])) {
                //         foreach ($groupResponse['array'] as $index => $item) {
                //             $groups[] = [
                //                 'id' => $item['0'],
                //                 'group_name' => $item['1']
                //             ];
                //         }
                //     }
                // }
            }

            $this->response['data'] = $kiosk;
            $this->response['data']['groups'] = $groups;
            $this->response['data']['payment_options'] = $paymentOptions;
            return response()->json($this->response);
        });
    }

    function saveDonor(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $request->validate([
                'donor_first_name' => 'required',
                'donor_last_name' => 'required',
                'donor_phone' => 'required',
                'donor_email' => 'required|email',
                'donor_message' => '',
            ]);

            $donationId = $request->post('donation_id');
            $donorFirstName = $request->post('donor_first_name');
            $donorLastName = $request->post('donor_last_name');
            $donorPhone = $request->post('donor_phone');
            $donorEmail = $request->post('donor_email');
            $donorMessage = $request->post('donor_message');

            $donation = Donation::with(['kiosk'])->find($donationId);
            if (!$donation) {
                $this->response['success'] = false;
                $this->response['error'] = 'Donation details not found! Please contact support.';
                return response()->json($this->response);
            }

            $donation->donor_first_name = $donorFirstName;
            $donation->donor_last_name = $donorLastName;
            $donation->donor_phone = $donorPhone;
            $donation->donor_email = $donorEmail;
            $donation->donor_message = $donorMessage;
            $donation->save();

            $kiosk = $donation->kiosk;

            if ($this->sendEmail && $kiosk->email_body && $donorEmail) {
                Mail::to($donorEmail)->send(new DonationReceiptMail($donation, $kiosk));
            }

            $this->response['message'] = 'Thank you for your contribution.';
            return response()->json($this->response);
        });
    }

    function donate(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            $kioskSlug = $request->slug;
            $groupId = $request->group_id;

            $paymentGatewayDetailsId = $request->payment_gateway_details_id;
            $amount = $request->amount;
            $paymentType = $request->payment_type ?? 'one_time'; // 'one_time' or 'recurring'
            $subscriptionDuration = $request->subscription_duration; // e.g., '0' for forever, '12' for 12 months, etc.

            $cardNumber = $request->card_number; // last 4 digits
            $cardExpiry = $request->card_expiry; // MM/YY format
            $cardCvv = $request->card_cvv; // 3 or 4 digits
            $cardHolderName = $request->card_holder_name;

            if (!$amount || $amount <= 0) {
                throw new ApiStatusZeroException("Amount must be greater than zero.");
            }

            if ($paymentType == 'recurring' && !$subscriptionDuration) {
                throw new ApiStatusZeroException("Subscription duration is required for recurring payments.");
            }

            if (!$cardNumber || strlen($cardNumber) < 13) {
                throw new ApiStatusZeroException("Invalid Card Number.");
            }

            if (!$cardExpiry || !preg_match('/^(0[1-9]|1[0-2])\/?([0-9]{2})$/', $cardExpiry)) {
                throw new ApiStatusZeroException("Invalid Card Expiry.");
            }

            // Validate from database

            $kiosk = Kiosk::where('slug', $kioskSlug)->where('status', 1)->first();
            if (!$kiosk) {
                throw new ApiStatusZeroException("Something went wrong! Kiosk not found.");
            }

            $paymentGatewayDetails = KioskPaymentGatewayDetail::with(['paymentGateway'])->where('id', $paymentGatewayDetailsId)->where('status', 1)->first();
            if (!$paymentGatewayDetails || !$paymentGatewayDetails->paymentGateway) {
                throw new ApiStatusZeroException("Invalid payment gateway.");
            }

            $currency = $paymentGatewayDetails->currency;
            $paymentGateway = $paymentGatewayDetails->paymentGateway;
            $fields = $paymentGatewayDetails->field_values;
            $cardExpiryParts = explode('/', $cardExpiry);

            $paymentGatewayService = new PaymentGatewayService($paymentGateway, $paymentType, $fields);
            $gatewayKeys = $paymentGatewayService->getKeys();
            $paymentStatus = 'pending'; // Initial status

            $donation = new Donation();
            $donation->kiosk_id = $kiosk->id;
            $donation->campaign_id = $groupId;
            $donation->card_number = substr($cardNumber, -4); // Store only last 4 digits
            $donation->card_holder_name = $cardHolderName;
            $donation->card_expiry = $cardExpiry;
            $donation->amount = $amount;
            $donation->currency = $currency->short_name;
            $donation->payment_gateway_id = $paymentGateway->id;
            $donation->payment_status = 'pending'; // Set initial status
            $donation->payment_type = $paymentType;
            $donation->subscription_duration = $paymentType == 'recurring' ? $subscriptionDuration : null;
            $donation->save();

            if ($paymentGateway->name == 'Stripe') {
                $stripeSecretKey = $gatewayKeys['secret_key'] ?? null;
                $stripePublishableKey = $gatewayKeys['publishable_key'] ?? null;

                if (!$stripeSecretKey || !$stripePublishableKey) {
                    Log::error("Stripe keys are not set for kiosk: {$kiosk->id}");
                    throw new ApiStatusZeroException("Unable to process payment.");
                }

                $stripeService = new StripePaymentService($stripeSecretKey, $stripePublishableKey);

                $stripePaymentResponse = $stripeService->processPayment(
                    $paymentType,
                    [
                        'name' => 'Kiosk',
                        'email' => '',
                    ],
                    [
                        'card_number' => $cardNumber,
                        'exp_month' => trim($cardExpiryParts[0]),
                        'exp_year' => trim($cardExpiryParts[1]),
                        'cvv' => $cardCvv,
                    ],
                    $amount,
                    $currency->short_name,
                    "Donation to {$kiosk->name}",
                    $subscriptionDuration
                );

                if (!$stripePaymentResponse) {
                    throw new ApiStatusZeroException("Payment processing failed.");
                }

                $paymentResponseService = new PaymentResponseService();
                $paymentResponse = $paymentResponseService->handleResponse($paymentGateway->name, $paymentType, $stripePaymentResponse);
                $paymentStatus = $paymentResponse['status'] ?? 'failed';

                $donation->payment_response = $stripePaymentResponse;

                $this->response['abcd'] = $stripeService->processCheckoutSession(
                    $paymentType,
                    $amount,
                    $currency->short_name,
                    "Donation to {$kiosk->name}",
                    $subscriptionDuration
                );
            } else if ($paymentGateway->name == 'Tranzila') {
                $tranzilaSupplierUrl = $gatewayKeys['supplier_url'] ?? null;
                $tranzilaSupplier = $gatewayKeys['supplier'] ?? null;
                $tranzilaPassword = $gatewayKeys['password'] ?? null;
                $tranzilaAppKey = $gatewayKeys['app_key'] ?? null;
                $tranzilaSecret = $gatewayKeys['secret'] ?? null;
                $tranzilaTerminal = $gatewayKeys['terminal'] ?? null;

                if ($paymentType == 'one_time') {
                    if (!$tranzilaSupplierUrl || !$tranzilaSupplier || !$tranzilaPassword) {
                        Log::error("Tranzila keys are not set for kiosk: {$kiosk->id}");
                        throw new ApiStatusZeroException("Unable to process payment.");
                    }
                } else if ($paymentType == 'recurring') {
                    if (!$tranzilaAppKey || !$tranzilaSecret || !$tranzilaTerminal) {
                        Log::error("Tranzila keys are not set for kiosk: {$kiosk->id}");
                        throw new ApiStatusZeroException("Unable to process payment.");
                    }
                }

                $tranzilaService = new TranzilaPaymentService($tranzilaSupplierUrl, $tranzilaSupplier, $tranzilaPassword, $tranzilaAppKey, $tranzilaSecret, $tranzilaTerminal);

                $tranzilaPaymentResponse = $tranzilaService->processPayment(
                    $paymentType,
                    $kiosk->name,
                    [
                        'firstname' => '',
                        'lastname' => '',
                        'email' => '',
                        'phone' => '',
                    ],
                    [
                        'card_number' => $cardNumber,
                        'card_expiry' => $cardExpiry,
                        'cvv' => $cardCvv,
                    ],
                    $currency,
                    $amount,
                    $subscriptionDuration,
                );

                $paymentResponseService = new PaymentResponseService();
                $paymentResponse = $paymentResponseService->handleResponse($paymentGateway->name, $paymentType, $tranzilaPaymentResponse);
                $paymentStatus = $paymentResponse['status'] ?? 'failed';

                $donation->payment_response = $paymentResponse;
            }

            $donation->payment_status = $paymentStatus;
            $donation->save();

            if ($paymentStatus == 'failed') {
                throw new ApiStatusZeroException("There was a problem processing the payment!");
            }

            if ($paymentStatus == 'pending') {
                throw new ApiStatusZeroException("Payment is still pending. You will receive a confirmation once the payment is processed.");
            }

            $this->response['message'] = "Donation processed successfully!";
            return response()->json($this->response);
        });
    }
}
