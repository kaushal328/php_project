<?php

namespace App\Http\Controllers;

abstract class Controller
{
    public $response = [
        'success' => true
    ];
}
