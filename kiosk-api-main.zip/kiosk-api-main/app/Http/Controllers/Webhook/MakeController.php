<?php

namespace App\Http\Controllers\Webhook;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class MakeController extends Controller
{
    function getGroups(Request $request)
    {
        return handleApiRequest(function () use ($request) {
            Log::info('Make.com data received', $request->all());

            return response()->json(['success' => true]);
        });
    }
}
