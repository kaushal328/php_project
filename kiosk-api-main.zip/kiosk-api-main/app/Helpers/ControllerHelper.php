<?php

use App\Exceptions\ApiStatusZeroException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

if (!function_exists('handleApiRequest')) {
    function handleApiRequest(Closure $callback)
    {
        try {
            $response = $callback();
            return $response;
        } catch (ValidationException $e) {
            return response()->json([
                'success' => false,
                'errors' => formatErrors($e->errors())
            ]);
        } catch (ApiStatusZeroException $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ]);
        } catch (Exception $e) {
            Log::error("Unhandled Exception: " . $e);
            return response()->json([
                'success' => false,
                'error' => 'Server error occurred!'
            ], 500);
        }
    }
}
