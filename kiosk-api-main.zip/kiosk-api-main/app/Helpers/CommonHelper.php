<?php

use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

function formatErrors($errors = [])
{
    $error_array = [];

    if (count($errors) > 0) {
        foreach ($errors as $k => $v) {
            $error_array[$k] = $v[0];
        }
    }

    return $error_array;
}

function createSlug($table_name = '', $name = '', $id = '')
{
    $count = 0;
    $name = Str::slug($name);
    $slug_name = $name; // Create temp name
    while (true) {
        $result = DB::table($table_name)
            ->select('id')
            ->when($id, function ($q) use ($id) {
                $q->where('id', '!=', $id);
            })
            ->where('slug', $slug_name)
            ->count();

        if ($result == 0) {
            break;
        }

        $slug_name = $name . '-' . ++$count;
    }
    return $slug_name; // Return temp name
}

function generateUniqueId($table = '', $column = '', $length = 10, $numericOnly = false, $prefix = '')
{
    if ($column && $table) {
        if ($numericOnly) {
            $uniqueId = str_pad(mt_rand(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);
        } else {
            $uniqueId = Str::random($length);
        }

        if ($prefix) {
            $uniqueId = $prefix . $uniqueId;
        }

        while (DB::table($table)->where($column, $uniqueId)->exists()) {
            if ($numericOnly) {
                $uniqueId = str_pad(mt_rand(0, pow(10, $length) - 1), $length, '0', STR_PAD_LEFT);
            } else {
                $uniqueId = Str::random($length);
            }

            if ($prefix) {
                $uniqueId = $prefix . $uniqueId;
            }
        }

        return $uniqueId;
    }

    throw new Exception('Column and table name are required.');
}

function custom_encrypt($str)
{
    $key = env('APP_KEY');
    $iv = substr(hash('sha256', $key), 0, 16);
    $output = openssl_encrypt($str, 'AES-256-CBC', $key, 0, $iv);
    return base64_encode($output);
}

function custom_decrypt($str)
{
    $key = env('APP_KEY');
    $iv = substr(hash('sha256', $key), 0, 16);
    $output = openssl_decrypt(base64_decode($str), 'AES-256-CBC', $key, 0, $iv);
    return $output;
}

function moveImage($fromDirectory, $toDirectory, $file)
{
    // Construct full file paths
    $sourceFile = $fromDirectory . '/' . $file;
    $targetFile = $toDirectory . '/' . $file;

    if (Storage::disk('public')->exists($targetFile)) {
        return ['success' => true, 'data' => ['filename' => $file]];
    }

    if (Storage::disk('public')->exists($sourceFile)) {
        Storage::disk('public')->move($sourceFile, $targetFile);

        return ['success' => true, 'data' => ['filename' => $file]];
    }

    return ['success' => false, 'error' => 'Upload a valid file'];
}

function replacePlaceholders($text, array $data): string
{
    foreach ($data as $key => $value) {
        $text = str_replace('%%' . $key . '%%', $value, $text);
    }
    return $text;
}