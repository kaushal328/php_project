<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Storage;

class Kiosk extends Model
{
    use SoftDeletes;

    protected $appends = ['logo_path', 'layout_background_path', 'amount_values'];

    function logoPath(): Attribute
    {
        return Attribute::get(function () {
            $file = $this->attributes['logo'] ?? null;
            if ($file) {
                return Storage::disk('public')->url('uploads/kiosk/logo/' . $file);
            }

            return null;
        });
    }

    function layoutBackgroundPath(): Attribute
    {
        return Attribute::get(function () {
            $file = $this->attributes['layout_background'] ?? null;
            if ($file) {
                return Storage::disk('public')->url('uploads/kiosk/layout_background/' . $file);
            }

            return null;
        });
    }

    function amountValues(): Attribute
    {
        return Attribute::get(function () {
            $amounts = $this->attributes['amounts'] ?? null;
            if ($amounts) {
                return json_decode($amounts, true);
            }

            return null;
        });
    }

    function kioskPaymentGatewayDetails()
    {
        return $this->hasMany(KioskPaymentGatewayDetail::class, 'kiosk_id');
    }
}
