<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class UserPermission extends Model
{
    function module()
    {
        return $this->belongsTo(Module::class, 'module_id');
    }
}
