<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class KioskPaymentGatewayDetail extends Model
{
    use SoftDeletes;

    function currency()
    {
        return $this->belongsTo(Currency::class, 'currency_id');
    }

    function paymentGateway()
    {
        return $this->belongsTo(PaymentGateway::class, 'payment_gateway_id');
    }
}
