<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class DonationReceiptMail extends Mailable
{
    use Queueable, SerializesModels;

    public $donation;
    public $kiosk;

    /**
     * Create a new message instance.
     */
    public function __construct($donation, $kiosk)
    {
        $this->donation = $donation;
        $this->kiosk = $kiosk;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->kiosk->email_subject ?? 'Donation Receipt',
            bcc: explode(',', env('MAIL_BCC', '')),
        );
    }

    function build()
    {
        $emailBody = $this->kiosk->email_body;

        $body = replacePlaceholders($emailBody, [
            'first_name' => $this->donation->donor_first_name,
            'last_name' => $this->donation->donor_last_name,
            'email' => $this->donation->donor_email,
            'phone' => $this->donation->donor_phone,
            'currency' => $this->donation->currency,
            'amount' => $this->donation->amount,
            'payment_type' => $this->donation->payment_type == 'one_time' ? 'One Time' : 'Recurring',
            'date' => now()->toDateTimeString(),
        ]);

        $this->from($this->kiosk->email_from)->html($body);
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
